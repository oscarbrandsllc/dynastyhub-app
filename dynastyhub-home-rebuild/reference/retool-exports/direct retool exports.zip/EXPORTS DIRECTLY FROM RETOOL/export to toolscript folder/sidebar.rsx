<SidebarFrame
  id="sidebarFrame1"
  footerPadding="18px 12px"
  headerPadding="8px 12px"
  isHiddenOnMobile={true}
  margin="8px 8px"
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  style={{
    background: "#141a32",
    border: "rgba(240, 239, 246, 0)",
    headerBackground: "#141a32",
  }}
  styleContext={{ ordered: [] }}
  width="large"
>
  <Header>
    <Container
      id="container161"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      heightType="fixed"
      overflowType="hidden"
      padding="0"
      showBody={true}
      style={{ map: { background: "tertiary" } }}
    >
      <Header>
        <Text
          id="containerTitle168"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="3c78c" viewKey="View 1">
        <Image
          id="image5"
          fit="contain"
          heightType="fixed"
          horizontalAlign="center"
          margin="0"
          retoolStorageFileId="80bd206c-52fc-45fd-8b65-fd6769b89a12"
          src="data:image/svg+xml,%3csvg%20width='70'%20height='24'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3ccircle%20cx='10'%20cy='12'%20r='10'%20fill='%23B3B3B3'/%3e%3cpath%20d='M9.283%207.069c.218-.705%201.216-.705%201.434%200l.713%202.309a.75.75%200%200%200%20.717.528h2.386c.717%200%201.025.91.455%201.346l-1.994%201.524a.75.75%200%200%200-.261.817l.746%202.415c.215.698-.592%201.26-1.172.817l-1.852-1.414a.75.75%200%200%200-.91%200l-1.852%201.414c-.58.444-1.388-.12-1.172-.817l.746-2.415a.75.75%200%200%200-.261-.817l-1.994-1.524c-.57-.435-.262-1.346.455-1.346h2.386a.75.75%200%200%200%20.717-.528l.713-2.31Z'%20fill='%23fff'%20stroke='%23fff'%20stroke-width='.375'/%3e%3cpath%20d='M27.138%2018V4.91h2.767v10.808h5.613V18h-8.38Zm14.598.192c-.993%200-1.852-.211-2.576-.633a4.33%204.33%200%200%201-1.669-1.777c-.392-.763-.588-1.647-.588-2.653%200-1.014.196-1.9.588-2.659a4.28%204.28%200%200%201%201.669-1.777c.724-.426%201.583-.639%202.576-.639.992%200%201.849.213%202.57.64a4.266%204.266%200%200%201%201.674%201.776c.392.759.588%201.645.588%202.66%200%201.005-.196%201.89-.588%202.652a4.317%204.317%200%200%201-1.675%201.777c-.72.422-1.577.633-2.57.633Zm.012-2.11c.452%200%20.83-.128%201.132-.383.302-.26.53-.614.684-1.061.157-.448.236-.957.236-1.528%200-.57-.079-1.08-.236-1.528-.154-.447-.382-.8-.684-1.06-.303-.26-.68-.39-1.132-.39-.456%200-.84.13-1.15.39-.307.26-.54.613-.697%201.06-.153.448-.23.957-.23%201.528%200%20.571.077%201.08.23%201.528.158.447.39.8.697%201.06.31.256.694.384%201.15.384Zm11.014%205.804c-.882%200-1.639-.121-2.27-.364-.626-.239-1.124-.565-1.495-.978a3.006%203.006%200%200%201-.722-1.393l2.518-.34c.077.197.198.38.364.55.167.171.386.307.659.41.277.106.613.16%201.01.16.592%200%201.08-.146%201.464-.435.387-.286.581-.765.581-1.438V16.26h-.115c-.12.273-.298.53-.537.774a2.707%202.707%200%200%201-.92.594c-.375.154-.823.23-1.343.23a4.03%204.03%200%200%201-2.013-.511c-.6-.345-1.08-.871-1.438-1.579-.354-.712-.53-1.61-.53-2.697%200-1.112.18-2.041.543-2.787.362-.746.843-1.304%201.444-1.675a3.733%203.733%200%200%201%201.988-.556c.55%200%201.01.094%201.38.281.372.183.67.414.896.69.23.273.407.542.53.806h.102V8.18h2.704v9.915c0%20.835-.204%201.534-.613%202.096-.41.563-.976.985-1.7%201.266-.72.286-1.55.428-2.487.428Zm.057-6.072c.44%200%20.81-.109%201.113-.326.306-.222.54-.537.703-.946.166-.413.25-.908.25-1.483%200-.575-.082-1.074-.244-1.496-.162-.426-.396-.756-.703-.99-.307-.235-.68-.352-1.119-.352-.447%200-.824.121-1.131.364-.307.239-.539.571-.697.997-.157.426-.236.919-.236%201.477%200%20.567.079%201.057.236%201.47.162.41.395.727.697.953.307.221.684.332%201.131.332Zm11.346%202.378c-.993%200-1.851-.211-2.576-.633a4.33%204.33%200%200%201-1.668-1.777c-.392-.763-.588-1.647-.588-2.653%200-1.014.196-1.9.588-2.659a4.278%204.278%200%200%201%201.668-1.777c.725-.426%201.583-.639%202.576-.639.993%200%201.85.213%202.57.64a4.267%204.267%200%200%201%201.675%201.776c.392.759.588%201.645.588%202.66%200%201.005-.196%201.89-.588%202.652a4.317%204.317%200%200%201-1.675%201.777c-.72.422-1.577.633-2.57.633Zm.013-2.11c.452%200%20.829-.128%201.132-.383.302-.26.53-.614.683-1.061.158-.448.237-.957.237-1.528%200-.57-.079-1.08-.237-1.528-.153-.447-.381-.8-.683-1.06-.303-.26-.68-.39-1.132-.39-.456%200-.84.13-1.15.39-.307.26-.54.613-.697%201.06-.154.448-.23.957-.23%201.528%200%20.571.076%201.08.23%201.528.157.447.39.8.697%201.06.31.256.694.384%201.15.384Z'%20fill='%23555'/%3e%3c/svg%3e"
          srcType="retoolStorageFileId"
          style={{}}
        />
      </View>
    </Container>
  </Header>
  <Body>
    <Navigation
      id="navigation13"
      data="{{ retoolContext.pages }}"
      highlightByIndex="{{ retoolContext.currentPage === item.id }}"
      horizontalAlignment="center"
      itemMode="static"
      labels="{{ item.title || item.id }}"
      margin="8px 14px"
      orientation="vertical"
      retoolFileObject={{ ordered: [] }}
      showInEditor={true}
      style={{
        ordered: [
          { highlightText: "#7476ff" },
          { fontSize: "16px" },
          { fontWeight: "700" },
          { fontFamily: "Quicksand" },
          { background: "#212843" },
          { highlightBackground: "#2c334f" },
          { hoverText: "secondary" },
        ],
      }}
    >
      <Option
        id="1de3f"
        icon="bold/interface-home-3"
        iconPosition="left"
        itemType="page"
        label="Home"
        screenTargetId="Home"
      />
      <Option
        id="60b8d"
        icon="bold/interface-arrows-diagonal"
        iconPosition="left"
        itemType="page"
        label="Data Hub"
        screenTargetId="DataHub"
      />
      <Option
        id="c05bb"
        disabled={false}
        hidden={false}
        highlight={false}
        icon="bold/shopping-business-startup"
        iconPosition="left"
        itemType="page"
        label="Rookies"
        screenTargetId="Rookies"
      />
      <Option
        id="b6a91"
        disabled={false}
        hidden={false}
        highlight={false}
        icon="bold/interface-award-crown"
        iconPosition="left"
        itemType="page"
        label="Rankings"
        screenTargetId="page2"
      />
      <Option
        id="c2822"
        disabled="true"
        hidden={false}
        icon="bold/ecology-science-erlenmeyer-flask"
        iconPosition="left"
        itemType="page"
        label="Research"
        screenTargetId="page3"
      />
      <Option
        id="d4f21"
        disabled="true"
        icon="bold/money-graph-arrow-increase"
        iconPosition="left"
        itemType="page"
        label="Charts"
        screenTargetId="Charts"
      />
      <Option
        id="e3f09"
        disabled={false}
        hidden={false}
        highlight={false}
        icon="bold/interface-share-user"
        iconPosition="left"
        itemType="page"
        label="League HQ"
        screenTargetId="page5"
      />
      <Option
        id="718b5"
        disabled="true"
        hidden={false}
        highlight={false}
        icon="bold/shopping-jewelry-diamond-2"
        iconPosition="left"
        itemType="page"
        label="Subscribe"
      />
      <Option
        id="1d317"
        disabled={false}
        hidden={false}
        highlight={false}
        icon={'{{  "/icon:bold/interface-login-key"   }}'}
        iconPosition="left"
        itemType="custom"
        label="   — KEY"
      >
        <Event
          event="click"
          method="show"
          params={{ ordered: [] }}
          pluginId="modalFrame2"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </Option>
      <Event
        event="click"
        method="openPage"
        params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Navigation>
  </Body>
  <Footer>
    <Container
      id="stack6"
      _flexWrap={true}
      _gap="0px"
      _type="stack"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      heightType="fixed"
      margin="0"
      overflowType="hidden"
      padding="0"
      showBody={true}
      style={{
        ordered: [
          { background: "rgb(33, 40, 67)" },
          { border: "rgba(0, 0, 0, 0)" },
          { boxShadow: "0 0 0px 0px rgba(0, 0, 0, 0.0)" },
        ],
      }}
    >
      <View id="26835" viewKey="View 1">
        <IFrame
          id="iFrame10"
          allowForms={true}
          allowModals={true}
          allowPopups={true}
          allowSameOrigin={true}
          allowTopNavigation={true}
          margin="0"
          src="https://oboczarski.github.io/follow-button/"
          style={{
            ordered: [
              { background: "#141a32" },
              { borderColor: "rgba(48, 53, 75, 0)" },
              { boxShadow: "0 0 0px 0px rgba(0, 0, 0, 0.00)" },
            ],
          }}
          title="{{ self.src }}"
        />
      </View>
    </Container>
    <Avatar
      id="avatar1"
      fallback="{{ current_user.fullName }}"
      icon="bold/shopping-jewelry-diamond-1"
      imageSize={40}
      label="THE_ORACLE"
      labelCaption="{{ current_user.email }}"
      margin="4px 4px"
      src="https://iili.io/3UnQQ5u.th.png)](https://freeimage.host/i/3UnQQ5u)"
      style={{
        background: "surfaceSecondary",
        sharedLabelFontSize: "13px",
        sharedLabelFontWeight: "300",
        sharedLabelFontFamily: "Quicksand",
      }}
    />
  </Footer>
</SidebarFrame>
