<App>
  <Include src="./functions.rsx" />
  <Include src="./src/Home.rsx" />
  <Include src="./src/DataHub.rsx" />
  <Include src="./src/Charts.rsx" />
  <Include src="./src/page2.rsx" />
  <CustomAppTheme
    id="$appTheme"
    _migrated={true}
    automatic={[
      "#fde68a",
      "#ff008a",
      "#00ceb8",
      "#4f97e5",
      "#eecff3",
      "#a7f3d0",
      "#bfdbfe",
      "#ffb056",
      "#fecaca",
      "#fcd6bb",
    ]}
    borderRadius="10px"
    canvas="#141a32"
    danger="#fa0088"
    defaultFont={{ size: "12px", fontWeight: "400", fontId: "" }}
    defaultFontId="0ffcda2e"
    fontIds={[
      "63701036",
      "0ffcda2e",
      "dc13af32",
      "426372f7",
      "77f8ca93",
      "3482bbc4",
      "c47a42c6",
      "5d60c7a2",
      "aac2e5f6",
      "d87065be",
      "1c4a895f",
      "56a9c28b",
      "b14bd06a",
      "14d0a4b4",
      "f81ee159",
      "834d48f3",
      "e5a99d8b",
      "51e13e58",
      "0293fc16",
      "c9aeeebf",
      "c9560613",
      "4377f4a3",
      "49cd39b5",
    ]}
    fontMap={{
      63701036: {
        name: "Bruno Ace",
        source:
          "https://fonts.googleapis.com/css2?family=Bruno+Ace&display=swap",
        fontWeights: ["400"],
      },
      "0ffcda2e": {
        name: "Product Sans",
        source:
          "https://fonts.googleapis.com/css2?family=Product+Sans:wght@100;200;300;400;500;700;900&display=swap",
        fontWeights: ["100", "200", "300", "400", "500", "600", "700"],
      },
      dc13af32: {
        name: "Raleway",
        source:
          "https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900",
        fontWeights: [
          "100",
          "200",
          "300",
          "400",
          "500",
          "600",
          "700",
          "800",
          "900",
        ],
      },
      "426372f7": {
        name: "RedHatDisplay",
        source:
          "https://fonts.googleapis.com/css2?family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap",
        fontWeights: ["300", "400", "500", "600", "700", "800", "900", "200"],
      },
      "77f8ca93": {
        name: "ORBITRON",
        source:
          "https://fonts.googleapis.com/css2?family=Orbitron:wght@400..900&display=swap",
        fontWeights: ["300", "400", "500", "600", "700"],
      },
      "3482bbc4": {
        name: "Gruppo",
        source: "https://fonts.googleapis.com/css2?family=Gruppo&display=swap",
        fontWeights: ["400"],
      },
      c47a42c6: {
        name: "Roboto Flex",
        source:
          "https://fonts.googleapis.com/css2?family=Roboto+Flex:opsz,wdth,wght,GRAD,XOPQ,XTRA,YOPQ,YTAS,YTDE,YTFI,YTLC,YTUC@8..144,136,100,150,75,523,60,754,-223,788,570,760&display=swap",
        fontWeights: ["100"],
      },
      "5d60c7a2": {
        name: "Livvic",
        source:
          "https://fonts.googleapis.com/css2?family=Livvic:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,900&display=swap",
        fontWeights: ["100", "200", "300", "400", "500", "600", "700", "900"],
      },
      aac2e5f6: {
        name: "Anta",
        source: "https://fonts.googleapis.com/css2?family=Anta&display=swap",
        fontWeights: ["400"],
      },
      d87065be: {
        name: "Baumans",
        source: "https://fonts.googleapis.com/css2?family=Baumans&display=swap",
        fontWeights: ["400"],
      },
      "1c4a895f": {
        name: "Raleway",
        source:
          "https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900",
        fontWeights: [
          "100",
          "200",
          "300",
          "400",
          "500",
          "600",
          "700",
          "800",
          "900",
        ],
      },
      "56a9c28b": {
        name: "Host Grotesk",
        source:
          "https://fonts.googleapis.com/css2?family=Host+Grotesk:ital,wght@0,300..800;1,300..800&display=swap",
        fontWeights: ["300", "400", "500", "600", "700", "800"],
      },
      b14bd06a: {
        name: "DM Sans",
        source:
          "https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap",
        fontWeights: [
          "100",
          "200",
          "300",
          "400",
          "500",
          "600",
          "700",
          "800",
          "900",
        ],
      },
      "14d0a4b4": {
        name: "Audiowide",
        source:
          "https://fonts.googleapis.com/css2?family=Audiowide&display=swap",
        fontWeights: ["400", "700", "900", "100"],
      },
      f81ee159: {
        name: "Roboto",
        source:
          "https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900",
        fontWeights: ["100", "300", "400", "500", "700", "900"],
      },
      "834d48f3": {
        name: "Comfortaa",
        source:
          "https://fonts.googleapis.com/css2?family=Comfortaa:wght@300..700&display=swap",
        fontWeights: ["300", "400", "500", "600", "700"],
      },
      e5a99d8b: {
        name: "Syncopate",
        source:
          "https://fonts.googleapis.com/css2?family=Syncopate:wght@400;700&display=swap",
        fontWeights: ["400", "700"],
      },
      "51e13e58": {
        name: "Jura",
        source:
          "https://fonts.googleapis.com/css2?family=Jura:wght@300..700&display=swap",
        fontWeights: ["300", "400", "500", "600", "700"],
      },
      "0293fc16": {
        name: "Google Sans",
        source:
          "https://fonts.googleapis.com/css?family=Google+Sans:100,300,400,500,700,900,100i,300i,400i,500i,700i,900i&display=swap",
        fontWeights: ["300", "400", "500", "600", "700", "800", "200", "100"],
      },
      c9aeeebf: {
        name: "Michroma",
        source:
          "https://fonts.googleapis.com/css2?family=Michroma&display=swap",
        fontWeights: ["400"],
      },
      c9560613: {
        name: "Montserrat",
        source:
          "https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,500,600,700,800,900",
        fontWeights: [
          "100",
          "200",
          "300",
          "400",
          "500",
          "600",
          "700",
          "800",
          "900",
        ],
      },
      "4377f4a3": {
        name: "Quicksand",
        source:
          "https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&display=swap",
        fontWeights: ["300", "400", "500", "600", "700"],
      },
      "49cd39b5": {
        name: "Space Grotesk",
        source:
          "https://fonts.googleapis.com/css?family=Space+Grotesk:300,400,500,600,700",
        fontWeights: ["300", "400", "500", "600", "700"],
      },
    }}
    h1Font={{ size: "38px", fontWeight: "400", fontId: "14d0a4b4" }}
    h2Font={{ size: "28px", fontWeight: "700" }}
    h3Font={{ size: "24px", fontWeight: "700" }}
    h4Font={{ size: "18px", fontWeight: "700" }}
    h5Font={{ size: "16px", fontWeight: "700" }}
    h6Font={{ size: "14px", fontWeight: "700" }}
    highlight="#6700ff"
    info="#6bb0ff"
    labelEmphasizedFont={{
      size: "12px",
      fontWeight: "600",
      fontId: "4377f4a3",
    }}
    labelFont={{ size: "12px", fontWeight: "500" }}
    lowElevation="0 0 0px 0px rgba(0, 0, 0, 0)"
    primary="#141a32"
    secondary="#7300ff"
    success="#6affd0"
    surfacePrimary="#ffffff"
    surfacePrimaryBorder=""
    surfaceSecondary="#2c334f"
    surfaceSecondaryBorder=""
    tertiary="#212843"
    textDark="#262626"
    textLight="#ffffff"
    warning="#ffae58"
  />
  <Include src="./src/page3.rsx" />
  <Include src="./src/Rookies.rsx" />
  <Include src="./src/page5.rsx" />
  <AppStyles id="$appStyles" css={include("./lib/$appStyles.css", "string")} />
  <Include src="./src/page6.rsx" />
  <Include src="./src/Home2.rsx" />
  <Include src="./src/modalFrame2.rsx" />
  <Include src="./sidebar.rsx" />
  <Statistic
    id="statistic329"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/nature-ecology-comet"
    label=""
    labelCaption="ELUSIVENESS GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.981"
  />
  <Text
    id="containerTitle302"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle325"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic350"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/nature-ecology-comet"
    label=""
    labelCaption="ELUSIVENESS GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.981"
  />
  <Text
    id="containerTitle336"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic389"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/nature-ecology-comet"
    label=""
    labelCaption="ELUSIVENESS GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.981"
  />
  <Statistic
    id="statistic274"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.943"
  />
  <Statistic
    id="statistic332"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.943"
  />
  <Text
    id="containerTitle305"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle329"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic351"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.943"
  />
  <Text
    id="containerTitle337"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic298"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "rgba(107, 176, 255, 1)",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.893"
  />
  <Statistic
    id="statistic335"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "rgba(107, 176, 255, 1)",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.893"
  />
  <Text
    id="containerTitle308"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle332"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic352"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "rgba(107, 176, 255, 1)",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.893"
  />
  <Text
    id="containerTitle338"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic302"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".951"
  />
  <Statistic
    id="statistic338"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".951"
  />
  <Text
    id="containerTitle311"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic353"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".951"
  />
  <Text
    id="containerTitle339"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle368"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic341"
    align="center"
    decimalPlaces=""
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".977"
  />
  <Text
    id="containerTitle314"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic354"
    align="center"
    decimalPlaces=""
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".977"
  />
  <Text
    id="containerTitle340"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle371"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic382"
    align="center"
    decimalPlaces=""
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".977"
  />
  <Statistic
    id="statistic344"
    align="center"
    decimalPlaces=""
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#5789ff",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.898"
  />
  <Text
    id="containerTitle318"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic355"
    align="center"
    decimalPlaces=""
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#5789ff",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.898"
  />
  <Text
    id="containerTitle341"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle374"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic383"
    align="center"
    decimalPlaces=""
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#5789ff",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.898"
  />
  <Statistic
    id="statistic347"
    align="center"
    decimalPlaces=""
    formattingStyle="percent"
    icon="bold/computer-connection-usb-port"
    label=""
    labelCaption="ROUTE RUNNING GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "rgba(87, 137, 255, 1)",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.89"
  />
  <Text
    id="containerTitle323"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic356"
    align="center"
    decimalPlaces=""
    formattingStyle="percent"
    icon="bold/computer-connection-usb-port"
    label=""
    labelCaption="ROUTE RUNNING GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "rgba(87, 137, 255, 1)",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.89"
  />
  <Text
    id="containerTitle342"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle377"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic384"
    align="center"
    decimalPlaces=""
    formattingStyle="percent"
    icon="bold/computer-connection-usb-port"
    label=""
    labelCaption="ROUTE RUNNING GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "rgba(87, 137, 255, 1)",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.89"
  />
  <Statistic
    id="statistic349"
    align="center"
    decimalPlaces=""
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.87"
  />
  <Text
    id="containerTitle328"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic357"
    align="center"
    decimalPlaces=""
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.87"
  />
  <Text
    id="containerTitle343"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle380"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic385"
    align="center"
    decimalPlaces=""
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.87"
  />
  <Statistic
    id="statistic319"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6bb0ff",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".862"
  />
  <Text
    id="containerTitle294"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic358"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6bb0ff",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".862"
  />
  <Text
    id="containerTitle344"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle383"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic386"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6bb0ff",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".862"
  />
  <Statistic
    id="statistic323"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6bb0ff",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.828"
  />
  <Text
    id="containerTitle297"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic359"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6bb0ff",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.828"
  />
  <Text
    id="containerTitle345"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle386"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic387"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6bb0ff",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.828"
  />
  <Statistic
    id="statistic327"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/nature-ecology-comet"
    label=""
    labelCaption="ELUSIVENESS GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6bb0ff",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.864"
  />
  <Text
    id="containerTitle300"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle321"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic360"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/nature-ecology-comet"
    label=""
    labelCaption="ELUSIVENESS GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6bb0ff",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.864"
  />
  <Text
    id="containerTitle346"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic388"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/nature-ecology-comet"
    label=""
    labelCaption="ELUSIVENESS GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6bb0ff",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.864"
  />
  <Statistic
    id="statistic330"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6bb0ff",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.89"
  />
  <Text
    id="containerTitle303"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle326"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic361"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6bb0ff",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.89"
  />
  <Text
    id="containerTitle347"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic390"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6bb0ff",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.89"
  />
  <Statistic
    id="statistic285"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#65aeff",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".887"
  />
  <Statistic
    id="statistic333"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#65aeff",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".887"
  />
  <Text
    id="containerTitle306"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle330"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic362"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#65aeff",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".887"
  />
  <Text
    id="containerTitle348"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic299"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.963"
  />
  <Statistic
    id="statistic336"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.963"
  />
  <Text
    id="containerTitle309"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle333"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic363"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.963"
  />
  <Text
    id="containerTitle349"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic300"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/computer-connection-usb-port"
    label=""
    labelCaption="ROUTE RUNNING GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.931"
  />
  <Statistic
    id="statistic339"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/computer-connection-usb-port"
    label=""
    labelCaption="ROUTE RUNNING GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.931"
  />
  <Text
    id="containerTitle312"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic364"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/computer-connection-usb-port"
    label=""
    labelCaption="ROUTE RUNNING GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.931"
  />
  <Text
    id="containerTitle350"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle369"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic303"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.961"
  />
  <Statistic
    id="statistic342"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.961"
  />
  <Text
    id="containerTitle315"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic365"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.961"
  />
  <Text
    id="containerTitle351"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle372"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic305"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".949"
  />
  <Statistic
    id="statistic345"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".949"
  />
  <Text
    id="containerTitle319"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic366"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".949"
  />
  <Text
    id="containerTitle352"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle375"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic307"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#65aeff",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.869"
  />
  <Statistic
    id="statistic348"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#65aeff",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.869"
  />
  <Text
    id="containerTitle324"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic367"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#65aeff",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.869"
  />
  <Text
    id="containerTitle353"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle378"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic309"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/nature-ecology-comet"
    label=""
    labelCaption="ELUSIVENESS GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.927"
  />
  <Statistic
    id="statistic316"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/nature-ecology-comet"
    label=""
    labelCaption="ELUSIVENESS GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.927"
  />
  <Text
    id="containerTitle292"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic368"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/nature-ecology-comet"
    label=""
    labelCaption="ELUSIVENESS GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.927"
  />
  <Text
    id="containerTitle354"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle381"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic311"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#b991ff",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.770"
  />
  <Statistic
    id="statistic320"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#b991ff",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.770"
  />
  <Text
    id="containerTitle295"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic369"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#b991ff",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.770"
  />
  <Text
    id="containerTitle355"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle384"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic314"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".951"
  />
  <Statistic
    id="statistic324"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".951"
  />
  <Text
    id="containerTitle298"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle317"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic370"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".951"
  />
  <Text
    id="containerTitle356"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic318"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.916"
  />
  <Statistic
    id="statistic328"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.916"
  />
  <Text
    id="containerTitle301"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle322"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic371"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.916"
  />
  <Text
    id="containerTitle357"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic322"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/computer-connection-usb-port"
    label=""
    labelCaption="ROUTE RUNNING GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.982"
  />
  <Statistic
    id="statistic331"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/computer-connection-usb-port"
    label=""
    labelCaption="ROUTE RUNNING GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.982"
  />
  <Text
    id="containerTitle304"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle327"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic372"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/computer-connection-usb-port"
    label=""
    labelCaption="ROUTE RUNNING GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.982"
  />
  <Text
    id="containerTitle358"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic326"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.933"
  />
  <Statistic
    id="statistic334"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.933"
  />
  <Text
    id="containerTitle307"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle331"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic373"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.933"
  />
  <Text
    id="containerTitle359"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic297"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#65aeff",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".896"
  />
  <Statistic
    id="statistic337"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#65aeff",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".896"
  />
  <Text
    id="containerTitle310"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle334"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic374"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/money-graph-bar-increase"
    label=""
    labelCaption="PRODUCTION GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "rgba(232, 222, 255, 1)",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#65aeff",
      iconBackground: "#6e00ff",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value=".896"
  />
  <Text
    id="containerTitle360"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic301"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#65aeff",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.883"
  />
  <Statistic
    id="statistic340"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#65aeff",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.883"
  />
  <Text
    id="containerTitle313"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic375"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/shopping-store-discount-percent-increase"
    label=""
    labelCaption="EFFICIENCY GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#65aeff",
      iconBackground: "rgba(122, 20, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.883"
  />
  <Text
    id="containerTitle361"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle370"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic304"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/nature-ecology-comet"
    label=""
    labelCaption="ELUSIVENESS GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#b991ff",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.762"
  />
  <Statistic
    id="statistic343"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/nature-ecology-comet"
    label=""
    labelCaption="ELUSIVENESS GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#b991ff",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.762"
  />
  <Text
    id="containerTitle316"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic376"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/nature-ecology-comet"
    label=""
    labelCaption="ELUSIVENESS GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#b991ff",
      iconBackground: "rgba(144, 3, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.762"
  />
  <Text
    id="containerTitle362"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle373"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic306"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.940"
  />
  <Statistic
    id="statistic346"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.940"
  />
  <Text
    id="containerTitle320"
    value="#### Container title"
    verticalAlign="center"
  />
  <Statistic
    id="statistic377"
    align="center"
    decimalPlaces="1"
    formattingStyle="percent"
    icon="bold/image-flash-1"
    label=""
    labelCaption="ATHLETICISM GRADE"
    margin="0px 0px 1px 0px"
    padDecimal={true}
    positiveTrend="{{ self.value >= 0 }}"
    secondaryCurrency="USD"
    secondaryEnableTrend={true}
    secondaryFormattingStyle="percent"
    secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
    secondaryShowSeparators={true}
    secondarySignDisplay="trendArrows"
    secondaryValue=""
    showSeparators={true}
    style={{
      caption: "#e8deff",
      fontSize: "9px",
      valueFontSize: "20px",
      color: "#6affd0",
      iconBackground: "rgba(174, 0, 255, 1)",
      fontFamily: "Bruno Ace",
    }}
    suffix="%"
    value="0.940"
  />
  <Text
    id="containerTitle363"
    value="#### Container title"
    verticalAlign="center"
  />
  <Text
    id="containerTitle376"
    value="#### Container title"
    verticalAlign="center"
  />
</App>
