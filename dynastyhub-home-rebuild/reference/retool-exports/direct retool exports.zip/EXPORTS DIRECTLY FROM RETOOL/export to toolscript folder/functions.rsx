<GlobalFunctions>
  <GoogleSheetsQuery
    id="query25"
    limit="19"
    resourceDisplayName="Re2L Key"
    resourceName="6985f92e-df84-4111-8cf3-1f705d5b9991"
    runWhenModelUpdates={false}
    sheetName="Key"
    spreadsheetId="18qduTp-w-vcgkgQu40Yf79K4xovj1oA2k234Iq1pWoY"
  />
  <State id="variable1" />
</GlobalFunctions>
