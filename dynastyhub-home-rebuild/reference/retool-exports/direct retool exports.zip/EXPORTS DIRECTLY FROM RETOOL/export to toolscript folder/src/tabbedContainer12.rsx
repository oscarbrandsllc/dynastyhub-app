<Container
  id="tabbedContainer12"
  _gap="0px"
  currentViewKey="{{ self.viewKeys[0] }}"
  enableFullBleed={true}
  footerPadding="4px 12px"
  headerPadding="4px 12px"
  heightType="fixed"
  margin="8px 50px"
  padding="0"
  showBody={true}
  showHeader={true}
  style={{
    background: "rgba(15, 15, 15, 0.1)",
    headerBackground: "rgba(6, 10, 18, 0.95)",
    borderRadius: "14px",
    border: "rgba(19, 19, 19, 0.82)",
    boxShadow: "highElevation",
  }}
  styleContext={{}}
  transition="slide"
>
  <Header>
    <Text
      id="text24"
      heightType="fixed"
      horizontalAlign="center"
      margin="1px 10px"
      style={{}}
      value={
        '<div style="\n  background-color: #212843;\n  padding: 6px 35px;\n  border-radius: 0px;\n  display: inline-flex;\n  box-shadow: 0 0 4px #aa00ff;\n">\n  <span style="\n    font-size: 1.2cqw;\n    font-family: Orbitron;\n    background: linear-gradient(to right, #c332ff, #8d28ff, #6e00f6, #5700ff);\n    -webkit-background-clip: text;\n    background-clip: text;\n    color: transparent;\n  ">CFB ⌁ CAREER STATS</span>\n</div>\n'
      }
      verticalAlign="center"
    />
    <Container
      id="group9"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      margin="0"
      padding="0"
      showBody={true}
      style={{
        background: "rgba(115, 0, 255, 0.03)",
        border: "rgba(115, 0, 255, 0.6)",
        borderRadius: "10px",
        boxShadow: "0 0 5px 1px rgba(0, 0, 0, 0.06)",
      }}
    >
      <View id="00030" viewKey="View 1">
        <Container
          id="group7"
          footerPadding="4px 12px"
          headerPadding="4px 12px"
          margin="0"
          padding="0"
          showBody={true}
          showBorder={false}
          style={{ map: { background: "rgba(255, 255, 255, 0)" } }}
        >
          <View id="00030" viewKey="View 1">
            <Icon
              id="icon7"
              horizontalAlign="right"
              icon="bold/interface-geometric-square"
              margin="6px 4px"
              style={{ map: { color: "#b5a1fe" } }}
            />
            <Text
              id="text29"
              heightType="fixed"
              margin="0"
              style={{
                fontSize: "10px",
                fontWeight: "300",
                fontFamily: "Product Sans",
                color: "#b5a1fe",
              }}
              value="TOTAL"
              verticalAlign="center"
            />
          </View>
        </Container>
        <Container
          id="group8"
          footerPadding="4px 12px"
          headerPadding="4px 12px"
          margin="0"
          padding="0"
          showBody={true}
          style={{
            background: "rgba(255, 255, 255, 0)",
            border: "rgba(115, 0, 255, 0.12)",
          }}
        >
          <View id="00030" viewKey="View 1">
            <Icon
              id="icon8"
              horizontalAlign="right"
              icon="bold/interface-geometric-square"
              margin="6px 4px"
              style={{ map: { color: "#c6ffe8" } }}
            />
            <Text
              id="text30"
              heightType="fixed"
              margin="0"
              style={{
                fontSize: "10px",
                fontWeight: "300",
                fontFamily: "Product Sans",
                color: "#c6ffe8",
              }}
              value="RUSHING"
              verticalAlign="center"
            />
          </View>
        </Container>
        <Container
          id="group6"
          footerPadding="4px 12px"
          headerPadding="4px 12px"
          margin="0"
          padding="0"
          showBody={true}
          showBorder={false}
          style={{ map: { background: "rgba(255, 255, 255, 0)" } }}
        >
          <View id="00030" viewKey="View 1">
            <Icon
              id="icon6"
              horizontalAlign="right"
              icon="bold/interface-geometric-square"
              margin="6px 4px"
              style={{ map: { color: "#99cdff" } }}
            />
            <Text
              id="text28"
              heightType="fixed"
              margin="0"
              style={{
                fontSize: "10px",
                fontWeight: "300",
                fontFamily: "Product Sans",
                color: "#99cdff",
              }}
              value="RECEIVING"
              verticalAlign="center"
            />
          </View>
        </Container>
      </View>
    </Container>
    <Text
      id="text31"
      horizontalAlign="right"
      style={{
        fontSize: "12px",
        fontWeight: "300",
        fontFamily: "Product Sans",
      }}
      value="Stat Category Legend:"
      verticalAlign="center"
    />
    <Tabs
      id="tabs13"
      alignment="justify"
      heightType="fixed"
      itemMode="static"
      margin="4px 20px"
      navigateContainer={true}
      style={{
        fontSize: "13px",
        fontWeight: "400",
        fontFamily: "Gruppo",
        hoverBackground: "danger",
        selectedText: "surfacePrimary",
        selectedBackground: "rgb(103, 0, 255)",
        pillBorderRadius: "4px",
      }}
      targetContainerId="tabbedContainer12"
      value="{{ self.values[0] }}"
    >
      <Option id="d0134" label="ALL" value="Tab 1" />
      <Option
        id="c1fb3"
        icon="bold/travel-map-location-target-1"
        iconPosition="left"
        value="QB"
      />
      <Option id="9c928" value="Tab 3" />
    </Tabs>
    <Button
      id="button20"
      horizontalAlign="center"
      iconBefore="bold/interface-login-key"
      margin="0px 0px"
      style={{
        boxShadow: "mediumElevation",
        activeBackground: "rgba(116, 110, 110, 1)",
        background: "canvas",
        border: "#7300ff",
        fontSize: "18px",
        fontWeight: "400",
        fontFamily: "Gruppo",
        label: "#9350ff",
      }}
      submitTargetId=""
      text="KEY"
    >
      <Event
        event="click"
        method="show"
        params={{ ordered: [] }}
        pluginId="modalFrame3"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Icon
      id="icon3"
      icon={'{{  "/icon:bold/interface-alert-information-circle-alternate"  }}'}
      margin="6px 3px"
      style={{ map: { color: "secondary" } }}
      tooltipText={
        '<div style="\n  background-color: #212843;\n  color: #ffffff;\n  font-size: 11px;\n  text-align: center;\n  padding: 1px 4px;\n  margin: -5px;\n  font-weight: 300;\n  border-radius: 4px;\n  box-shadow: 0 0 14px #000000;\n">\n📈 · Hover over any column headers to view full stat labels<br> \n🗝️ · Select "KEY" for full definitions of all metrics, additional <br> info,and detailed breakdowns of advanced metrics.\n</div>'
      }
    >
      <Event
        enabled="onhover"
        event="click"
        method="showNotification"
        params={{
          map: {
            options: {
              notificationType: "info",
              title: "Career Stats",
              description:
                '✦ Hover on column headers to expand abbreviated metric terms.\n\n✦ Select "KEY"🔑 for full stat definitions, additional info, and detailed breakdowns of the advanced metrics.',
            },
          },
        }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Icon>
  </Header>
  <View
    id="325df"
    disabled={false}
    hidden={false}
    icon="bold/interface-page-controller-settings"
    iconPosition="left"
    viewKey="FLX"
  >
    <Table
      id="table84"
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "40": "NA",\n    "RK": "1",\n    "PLAYER": "Ashton Jeanty",\n    "POS": "RB",\n    "posRK": "1",\n    "TM": "LV",\n    "OVR GRADE": "96",\n    "truADP": "6.3",\n    "Rook ADP": "1",\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "6",\n    "NCAA": "BOIS",\n    "AGE": "21.6",\n    "HT": "5\'8",\n    "WT": "211",\n    "ATHL": "89",\n    "CL": "5",\n    "FL": "4.5",\n    "PRD GRADE": "95.1",\n    "EFF GRADE": "94.3",\n    "RR GRD": "NA",\n    "ELU GRADE": "98.1",\n    "FILM GRADE": "98",\n    "G": "40",\n    "SOS": "75",\n    "YDS(t)": "5637",\n    "TD(t)": "56",\n    "1D(t)": "97",\n    "YpG(t)": "140.9",\n    "OPP(t)": "845",\n    "IMP": "324",\n    "IMP/ OPP": "0.38",\n    "DMTR": "0.338",\n    "CAR": "748",\n    "ruYDS": "4760",\n    "YPC": "6.4",\n    "ruTD": "50",\n    "ru1D": "232",\n    "MTF/ A": "0.378",\n    "YACO/A": "4.76",\n    "ELU": "0.735",\n    "TGT": "97",\n    "REC": "82",\n    "recYDS": "877",\n    "recTD": "6",\n    "rec1D": "36",\n    "YPRR": "1.59",\n    "YPR": "11",\n    "YAC/R": "NA",\n    "Tier": "1"\n  },\n  {\n    "40": "NA",\n    "RK": "2",\n    "PLAYER": "Travis Hunter",\n    "POS": "WR",\n    "posRK": "1",\n    "TM": "JAX",\n    "OVR GRADE": "94",\n    "truADP": "34.4",\n    "Rook ADP": "3",\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "2",\n    "NCAA": "COLO",\n    "AGE": "22.2",\n    "HT": "6\'0",\n    "WT": "188",\n    "ATHL": "96",\n    "CL": "5",\n    "FL": "3.5",\n    "PRD GRADE": "88.7",\n    "EFF GRADE": "96.3",\n    "RR GRD": "93.4",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "93",\n    "G": "29",\n    "SOS": "82.6",\n    "YDS(t)": "2161",\n    "TD(t)": "25",\n    "1D(t)": "97",\n    "YpG(t)": "74.52",\n    "OPP(t)": "220",\n    "IMP": "122",\n    "IMP/ OPP": "0.55",\n    "DMTR": "0.269",\n    "CAR": "3",\n    "ruYDS": "-5",\n    "YPC": "-1.67",\n    "ruTD": "1",\n    "ru1D": "1",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "217",\n    "REC": "170",\n    "recYDS": "2166",\n    "recTD": "24",\n    "rec1D": "96",\n    "YPRR": "2.42",\n    "YPR": "12.7",\n    "YAC/R": "4.38",\n    "Tier": "1"\n  },\n  {\n    "40": "4.46",\n    "RK": "3",\n    "PLAYER": "Omarion Hampton",\n    "POS": "RB",\n    "posRK": "2",\n    "TM": "LAC",\n    "OVR GRADE": "90",\n    "truADP": "23.9",\n    "Rook ADP": "2",\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "22",\n    "NCAA": "UNC",\n    "AGE": "22.3",\n    "HT": "5\'12",\n    "WT": "221",\n    "ATHL": "89",\n    "CL": "4.5",\n    "FL": "4",\n    "PRD GRADE": "86.2",\n    "EFF GRADE": "82.8",\n    "RR GRD": "NA",\n    "ELU GRADE": "86.4",\n    "FILM GRADE": "86",\n    "G": "38",\n    "SOS": "80",\n    "YDS(t)": "4194",\n    "TD(t)": "40",\n    "1D(t)": "75",\n    "YpG(t)": "110.4",\n    "OPP(t)": "704",\n    "IMP": "248",\n    "IMP/ OPP": "0.35",\n    "DMTR": "0.249",\n    "CAR": "624",\n    "ruYDS": "3563",\n    "YPC": "5.7",\n    "ruTD": "37",\n    "ru1D": "183",\n    "MTF/ A": "0.247",\n    "YACO/A": "4.01",\n    "ELU": "0.548",\n    "TGT": "80",\n    "REC": "72",\n    "recYDS": "631",\n    "recTD": "3",\n    "rec1D": "25",\n    "YPRR": "1.06",\n    "YPR": "9",\n    "YAC/R": "NA",\n    "Tier": "2"\n  },\n  {\n    "40": "NA",\n    "RK": "4",\n    "PLAYER": "Tetairoa McMillan",\n    "POS": "WR",\n    "posRK": "2",\n    "TM": "CAR",\n    "OVR GRADE": "90",\n    "truADP": "36.3",\n    "Rook ADP": "4",\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "8",\n    "NCAA": "ARIZ",\n    "AGE": "22.3",\n    "HT": "6\'4",\n    "WT": "219",\n    "ATHL": "87",\n    "CL": "4.5",\n    "FL": "4",\n    "PRD GRADE": "97.7",\n    "EFF GRADE": "89.8",\n    "RR GRD": "89.1",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "88",\n    "G": "37",\n    "SOS": "81.4",\n    "YDS(t)": "3417",\n    "TD(t)": "26",\n    "1D(t)": "152",\n    "YpG(t)": "92.35",\n    "OPP(t)": "342",\n    "IMP": "178",\n    "IMP/ OPP": "0.52",\n    "DMTR": "0.32",\n    "CAR": "1",\n    "ruYDS": "3",\n    "YPC": "3",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "341",\n    "REC": "213",\n    "recYDS": "3414",\n    "recTD": "26",\n    "rec1D": "152",\n    "YPRR": "2.37",\n    "YPR": "16",\n    "YAC/R": "5.45",\n    "Tier": "2"\n  },\n  {\n    "40": "4.43",\n    "RK": "5",\n    "PLAYER": "TreVeyon Henderson",\n    "POS": "RB",\n    "posRK": "3",\n    "TM": "NE",\n    "OVR GRADE": "88",\n    "truADP": "39.1",\n    "Rook ADP": "5",\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "38",\n    "NCAA": "OSU",\n    "AGE": "22.7",\n    "HT": "5\'10",\n    "WT": "202",\n    "ATHL": "94",\n    "CL": "4.5",\n    "FL": "3.5",\n    "PRD GRADE": "89.6",\n    "EFF GRADE": "88.3",\n    "RR GRD": "NA",\n    "ELU GRADE": "76.2",\n    "FILM GRADE": "84",\n    "G": "47",\n    "SOS": "93.5",\n    "YDS(t)": "4609",\n    "TD(t)": "48",\n    "1D(t)": "43",\n    "YpG(t)": "98.1",\n    "OPP(t)": "678",\n    "IMP": "248",\n    "IMP/ OPP": "0.37",\n    "DMTR": "0.211",\n    "CAR": "590",\n    "ruYDS": "3759",\n    "YPC": "6.4",\n    "ruTD": "42",\n    "ru1D": "168",\n    "MTF/ A": "0.22",\n    "YACO/A": "3.89",\n    "ELU": "0.512",\n    "TGT": "88",\n    "REC": "76",\n    "recYDS": "850",\n    "recTD": "6",\n    "rec1D": "32",\n    "YPRR": "1.14",\n    "YPR": "11",\n    "YAC/R": "NA",\n    "Tier": "2"\n  },\n  {\n    "40": "4.48",\n    "RK": "6",\n    "PLAYER": "Quinshon Judkins",\n    "POS": "RB",\n    "posRK": "4",\n    "TM": "CLE",\n    "OVR GRADE": "88",\n    "truADP": "43.5",\n    "Rook ADP": "6",\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "36",\n    "NCAA": "OSU",\n    "AGE": "21.7",\n    "HT": "5\'12",\n    "WT": "221",\n    "ATHL": "95",\n    "CL": "4",\n    "FL": "3",\n    "PRD GRADE": "89.3",\n    "EFF GRADE": "87.3",\n    "RR GRD": "NA",\n    "ELU GRADE": "76.1",\n    "FILM GRADE": "82",\n    "G": "42",\n    "SOS": "93",\n    "YDS(t)": "4228",\n    "TD(t)": "50",\n    "1D(t)": "107",\n    "YpG(t)": "100.7",\n    "OPP(t)": "808",\n    "IMP": "294",\n    "IMP/ OPP": "0.36",\n    "DMTR": "0.245",\n    "CAR": "739",\n    "ruYDS": "3786",\n    "YPC": "5.1",\n    "ruTD": "45",\n    "ru1D": "222",\n    "MTF/ A": "0.267",\n    "YACO/A": "3.23",\n    "ELU": "0.509",\n    "TGT": "69",\n    "REC": "59",\n    "recYDS": "442",\n    "recTD": "5",\n    "rec1D": "22",\n    "YPRR": "0.76",\n    "YPR": "8",\n    "YAC/R": "NA",\n    "Tier": "2"\n  },\n  {\n    "40": "4.4",\n    "RK": "7",\n    "PLAYER": "R.J. Harvey",\n    "POS": "RB",\n    "posRK": "5",\n    "TM": "DEN",\n    "OVR GRADE": "86",\n    "truADP": "50.4",\n    "Rook ADP": "7",\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "60",\n    "NCAA": "UCF",\n    "AGE": "24.4",\n    "HT": "5\'8",\n    "WT": "205",\n    "ATHL": "89",\n    "CL": "4.5",\n    "FL": "2.5",\n    "PRD GRADE": "88.3",\n    "EFF GRADE": "90.2",\n    "RR GRD": "NA",\n    "ELU GRADE": "89.6",\n    "FILM GRADE": "79",\n    "G": "39",\n    "SOS": "79",\n    "YDS(t)": "4510",\n    "TD(t)": "48",\n    "1D(t)": "82",\n    "YpG(t)": "115.6",\n    "OPP(t)": "652",\n    "IMP": "273",\n    "IMP/ OPP": "0.42",\n    "DMTR": "0.258",\n    "CAR": "574",\n    "ruYDS": "3788",\n    "YPC": "6.6",\n    "ruTD": "43",\n    "ru1D": "196",\n    "MTF/ A": "0.315",\n    "YACO/A": "3.68",\n    "ELU": "0.591",\n    "TGT": "78",\n    "REC": "62",\n    "recYDS": "722",\n    "recTD": "5",\n    "rec1D": "29",\n    "YPRR": "1.4",\n    "YPR": "12",\n    "YAC/R": "NA",\n    "Tier": "3"\n  },\n  {\n    "40": "4.57",\n    "RK": "8",\n    "PLAYER": "Kaleb Johnson",\n    "POS": "RB",\n    "posRK": "6",\n    "TM": "PIT",\n    "OVR GRADE": "86",\n    "truADP": "55.5",\n    "Rook ADP": "9",\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "83",\n    "NCAA": "IOWA",\n    "AGE": "20.8",\n    "HT": "6\'1",\n    "WT": "224",\n    "ATHL": "79",\n    "CL": "3.5",\n    "FL": "4",\n    "PRD GRADE": "67.6",\n    "EFF GRADE": "70",\n    "RR GRD": "NA",\n    "ELU GRADE": "82.1",\n    "FILM GRADE": "76",\n    "G": "35",\n    "SOS": "91.5",\n    "YDS(t)": "3017",\n    "TD(t)": "32",\n    "1D(t)": "31",\n    "YpG(t)": "86.2",\n    "OPP(t)": "543",\n    "IMP": "156",\n    "IMP/ OPP": "0.29",\n    "DMTR": "0.381",\n    "CAR": "508",\n    "ruYDS": "2775",\n    "YPC": "5.5",\n    "ruTD": "30",\n    "ru1D": "116",\n    "MTF/ A": "0.266",\n    "YACO/A": "3.68",\n    "ELU": "0.542",\n    "TGT": "35",\n    "REC": "29",\n    "recYDS": "242",\n    "recTD": "2",\n    "rec1D": "8",\n    "YPRR": "0.9",\n    "YPR": "8",\n    "YAC/R": "NA",\n    "Tier": "3"\n  },\n  {\n    "40": "NA",\n    "RK": "9",\n    "PLAYER": "Colston Loveland",\n    "POS": "TE",\n    "posRK": "1",\n    "TM": "CHI",\n    "OVR GRADE": "90",\n    "truADP": "65.8",\n    "Rook ADP": "11",\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "10",\n    "NCAA": "MICH",\n    "AGE": "21.3",\n    "HT": "6\'6",\n    "WT": "248",\n    "ATHL": "91",\n    "CL": "5",\n    "FL": "4",\n    "PRD GRADE": "71.1",\n    "EFF GRADE": "72.9",\n    "RR GRD": "90.1",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "90",\n    "G": "39",\n    "SOS": "94.9",\n    "YDS(t)": "1465",\n    "TD(t)": "11",\n    "1D(t)": "72",\n    "YpG(t)": "37.56",\n    "OPP(t)": "171",\n    "IMP": "83",\n    "IMP/ OPP": "0.49",\n    "DMTR": "0.2",\n    "CAR": "1",\n    "ruYDS": "-2",\n    "YPC": "-2",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "170",\n    "REC": "116",\n    "recYDS": "1467",\n    "recTD": "11",\n    "rec1D": "72",\n    "YPRR": "2.22",\n    "YPR": "12.5",\n    "YAC/R": "5.37",\n    "Tier": "3"\n  },\n  {\n    "40": "4.5",\n    "RK": "10",\n    "PLAYER": "Emeka Egbuka",\n    "POS": "WR",\n    "posRK": "3",\n    "TM": "TB",\n    "OVR GRADE": "89",\n    "truADP": "59.2",\n    "Rook ADP": "10",\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "19",\n    "NCAA": "OSU",\n    "AGE": "22.8",\n    "HT": "6\'1",\n    "WT": "202",\n    "ATHL": "87",\n    "CL": "3.5",\n    "FL": "4",\n    "PRD GRADE": "95.7",\n    "EFF GRADE": "93.5",\n    "RR GRD": "91.1",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "86",\n    "G": "47",\n    "SOS": "95.7",\n    "YDS(t)": "3017",\n    "TD(t)": "26",\n    "1D(t)": "144",\n    "YpG(t)": "64.19",\n    "OPP(t)": "305",\n    "IMP": "170",\n    "IMP/ OPP": "0.56",\n    "DMTR": "0.195",\n    "CAR": "23",\n    "ruYDS": "150",\n    "YPC": "6.52",\n    "ruTD": "2",\n    "ru1D": "6",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "282",\n    "REC": "205",\n    "recYDS": "2867",\n    "recTD": "24",\n    "rec1D": "138",\n    "YPRR": "2.6",\n    "YPR": "14",\n    "YAC/R": "6.64",\n    "Tier": "3"\n  },\n  {\n    "40": "NA",\n    "RK": "11",\n    "PLAYER": "Tyler Warren",\n    "POS": "TE",\n    "posRK": "2",\n    "TM": "IND",\n    "OVR GRADE": "89",\n    "truADP": "54.7",\n    "Rook ADP": "8",\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "14",\n    "NCAA": "PSU",\n    "AGE": "23.1",\n    "HT": "6\'6",\n    "WT": "256",\n    "ATHL": "90",\n    "CL": "4.5",\n    "FL": "4.5",\n    "PRD GRADE": "87.8",\n    "EFF GRADE": "88.8",\n    "RR GRD": "86.7",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "90",\n    "G": "53",\n    "SOS": "95.3",\n    "YDS(t)": "2062",\n    "TD(t)": "25",\n    "1D(t)": "120",\n    "YpG(t)": "38.91",\n    "OPP(t)": "238",\n    "IMP": "145",\n    "IMP/ OPP": "0.61",\n    "DMTR": "0.159",\n    "CAR": "30",\n    "ruYDS": "225",\n    "YPC": "7.5",\n    "ruTD": "6",\n    "ru1D": "16",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "208",\n    "REC": "154",\n    "recYDS": "1837",\n    "recTD": "19",\n    "rec1D": "104",\n    "YPRR": "1.98",\n    "YPR": "11.9",\n    "YAC/R": "6.58",\n    "Tier": "3"\n  },\n  {\n    "40": "4.29",\n    "RK": "12",\n    "PLAYER": "Matthew Golden",\n    "POS": "WR",\n    "posRK": "4",\n    "TM": "GB",\n    "OVR GRADE": "87",\n    "truADP": "71.7",\n    "Rook ADP": "12",\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "23",\n    "NCAA": "TEX",\n    "AGE": "21.9",\n    "HT": "5\'11",\n    "WT": "191",\n    "ATHL": "94",\n    "CL": "4.5",\n    "FL": "2",\n    "PRD GRADE": "83.9",\n    "EFF GRADE": "81.3",\n    "RR GRD": "87.5",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "86",\n    "G": "36",\n    "SOS": "88.3",\n    "YDS(t)": "1990",\n    "TD(t)": "22",\n    "1D(t)": "96",\n    "YpG(t)": "55.28",\n    "OPP(t)": "202",\n    "IMP": "118",\n    "IMP/ OPP": "0.58",\n    "DMTR": "0.22",\n    "CAR": "0",\n    "ruYDS": "0",\n    "YPC": "NA",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "202",\n    "REC": "135",\n    "recYDS": "1990",\n    "recTD": "22",\n    "rec1D": "96",\n    "YPRR": "1.85",\n    "YPR": "14.7",\n    "YAC/R": "5.64",\n    "Tier": "4"\n  },\n  {\n    "40": "4.41",\n    "RK": "13",\n    "PLAYER": "Luther Burden",\n    "POS": "WR",\n    "posRK": "5",\n    "TM": "CHI",\n    "OVR GRADE": "87",\n    "truADP": "88.7",\n    "Rook ADP": "14",\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "39",\n    "NCAA": "MIZZ",\n    "AGE": "21.6",\n    "HT": "6\'0",\n    "WT": "206",\n    "ATHL": "88",\n    "CL": "5",\n    "FL": "2",\n    "PRD GRADE": "92.6",\n    "EFF GRADE": "87.6",\n    "RR GRD": "84.1",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "83",\n    "G": "38",\n    "SOS": "89.4",\n    "YDS(t)": "2493",\n    "TD(t)": "25",\n    "1D(t)": "104",\n    "YpG(t)": "65.61",\n    "OPP(t)": "307",\n    "IMP": "129",\n    "IMP/ OPP": "0.42",\n    "DMTR": "0.34",\n    "CAR": "32",\n    "ruYDS": "210",\n    "YPC": "6.56",\n    "ruTD": "4",\n    "ru1D": "11",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "275",\n    "REC": "193",\n    "recYDS": "2283",\n    "recTD": "21",\n    "rec1D": "93",\n    "YPRR": "2.32",\n    "YPR": "11.8",\n    "YAC/R": "7.26",\n    "Tier": "4"\n  },\n  {\n    "40": "4.47",\n    "RK": "14",\n    "PLAYER": "Jayden Higgins",\n    "POS": "WR",\n    "posRK": "6",\n    "TM": "HOU",\n    "OVR GRADE": "86",\n    "truADP": "90.9",\n    "Rook ADP": "15",\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "34",\n    "NCAA": "ISU",\n    "AGE": "22.6",\n    "HT": "6\'4",\n    "WT": "214",\n    "ATHL": "91",\n    "CL": "4",\n    "FL": "2.5",\n    "PRD GRADE": "83.6",\n    "EFF GRADE": "90.2",\n    "RR GRD": "87.8",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "80",\n    "G": "36",\n    "SOS": "83",\n    "YDS(t)": "2562",\n    "TD(t)": "28",\n    "1D(t)": "160",\n    "YpG(t)": "71.17",\n    "OPP(t)": "264",\n    "IMP": "188",\n    "IMP/ OPP": "0.71",\n    "DMTR": "0.331",\n    "CAR": "0",\n    "ruYDS": "0",\n    "YPC": "NA",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "264",\n    "REC": "169",\n    "recYDS": "2562",\n    "recTD": "28",\n    "rec1D": "160",\n    "YPRR": "2.37",\n    "YPR": "14.6",\n    "YAC/R": "4.64",\n    "Tier": "4"\n  },\n  {\n    "40": "NA",\n    "RK": "15",\n    "PLAYER": "Cameron Skattebo",\n    "POS": "RB",\n    "posRK": "7",\n    "TM": "NYG",\n    "OVR GRADE": "87",\n    "truADP": "76.7",\n    "Rook ADP": "13",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "105",\n    "NCAA": "ARIZST",\n    "AGE": "23.4",\n    "HT": "5\'10",\n    "WT": "219",\n    "ATHL": "77",\n    "CL": "4",\n    "FL": "3",\n    "PRD GRADE": "94.9",\n    "EFF GRADE": "86.9",\n    "RR GRD": "NA",\n    "ELU GRADE": "92.7",\n    "FILM GRADE": "85",\n    "G": "47",\n    "SOS": "81",\n    "YDS(t)": "5710",\n    "TD(t)": "51",\n    "1D(t)": "120",\n    "YpG(t)": "121.5",\n    "OPP(t)": "855",\n    "IMP": "363",\n    "IMP/ OPP": "0.43",\n    "DMTR": "0.285",\n    "CAR": "711",\n    "ruYDS": "4387",\n    "YPC": "6.2",\n    "ruTD": "43",\n    "ru1D": "258",\n    "MTF/ A": "0.366",\n    "YACO/A": "3.95",\n    "ELU": "0.662",\n    "TGT": "144",\n    "REC": "111",\n    "recYDS": "1323",\n    "recTD": "8",\n    "rec1D": "54",\n    "YPRR": "1.56",\n    "YPR": "12",\n    "YAC/R": "NA",\n    "Tier": "4"\n  },\n  {\n    "40": "4.54",\n    "RK": "16",\n    "PLAYER": "Tre Harris",\n    "POS": "WR",\n    "posRK": "7",\n    "TM": "LAC",\n    "OVR GRADE": "86",\n    "truADP": "95.3",\n    "Rook ADP": "16",\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "55",\n    "NCAA": "MISS",\n    "AGE": "23.3",\n    "HT": "6\'2",\n    "WT": "205",\n    "ATHL": "76",\n    "CL": "4",\n    "FL": "3",\n    "PRD GRADE": "94.4",\n    "EFF GRADE": "98",\n    "RR GRD": "83.1",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "80",\n    "G": "46",\n    "SOS": "90.1",\n    "YDS(t)": "3567",\n    "TD(t)": "29",\n    "1D(t)": "147",\n    "YpG(t)": "77.54",\n    "OPP(t)": "333",\n    "IMP": "176",\n    "IMP/ OPP": "0.53",\n    "DMTR": "0.289",\n    "CAR": "5",\n    "ruYDS": "22",\n    "YPC": "4.4",\n    "ruTD": "0",\n    "ru1D": "1",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "328",\n    "REC": "220",\n    "recYDS": "3545",\n    "recTD": "29",\n    "rec1D": "146",\n    "YPRR": "3",\n    "YPR": "16.1",\n    "YAC/R": "6.44",\n    "Tier": "4"\n  },\n  {\n    "40": "NA",\n    "RK": "17",\n    "PLAYER": "Jack Bech",\n    "POS": "WR",\n    "posRK": "8",\n    "TM": "LV",\n    "OVR GRADE": "86",\n    "truADP": "117.7",\n    "Rook ADP": "18",\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "58",\n    "NCAA": "TCU",\n    "AGE": "22.6",\n    "HT": "6\'1",\n    "WT": "214",\n    "ATHL": "77",\n    "CL": "3.5",\n    "FL": "3.5",\n    "PRD GRADE": "65.7",\n    "EFF GRADE": "72.9",\n    "RR GRD": "88.5",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "82",\n    "G": "45",\n    "SOS": "78.3",\n    "YDS(t)": "1866",\n    "TD(t)": "13",\n    "1D(t)": "87",\n    "YpG(t)": "41.47",\n    "OPP(t)": "203",\n    "IMP": "100",\n    "IMP/ OPP": "0.49",\n    "DMTR": "0.14",\n    "CAR": "3",\n    "ruYDS": "-3",\n    "YPC": "-1",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "200",\n    "REC": "133",\n    "recYDS": "1869",\n    "recTD": "13",\n    "rec1D": "87",\n    "YPRR": "1.86",\n    "YPR": "14.1",\n    "YAC/R": "5.5",\n    "Tier": "4"\n  },\n  {\n    "40": "4.4",\n    "RK": "18",\n    "PLAYER": "Kyle Williams",\n    "POS": "WR",\n    "posRK": "9",\n    "TM": "NE",\n    "OVR GRADE": "87",\n    "truADP": "128.6",\n    "Rook ADP": "21",\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "69",\n    "NCAA": "WSU",\n    "AGE": "22.7",\n    "HT": "5\'11",\n    "WT": "190",\n    "ATHL": "85",\n    "CL": "3.5",\n    "FL": "3",\n    "PRD GRADE": "92.4",\n    "EFF GRADE": "86",\n    "RR GRD": "88.1",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "50",\n    "SOS": "77.4",\n    "YDS(t)": "3678",\n    "TD(t)": "29",\n    "1D(t)": "160",\n    "YpG(t)": "73.56",\n    "OPP(t)": "393",\n    "IMP": "189",\n    "IMP/ OPP": "0.48",\n    "DMTR": "0.318",\n    "CAR": "17",\n    "ruYDS": "72",\n    "YPC": "4.24",\n    "ruTD": "0",\n    "ru1D": "5",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "376",\n    "REC": "248",\n    "recYDS": "3606",\n    "recTD": "29",\n    "rec1D": "155",\n    "YPRR": "2.07",\n    "YPR": "14.5",\n    "YAC/R": "6.35",\n    "Tier": "4"\n  },\n  {\n    "40": "4.32",\n    "RK": "19",\n    "PLAYER": "Bhayshul Tuten",\n    "POS": "RB",\n    "posRK": "8",\n    "TM": "JAX",\n    "OVR GRADE": "80",\n    "truADP": "121.2",\n    "Rook ADP": "20",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "104",\n    "NCAA": "VT",\n    "AGE": "22.4",\n    "HT": "5\'9",\n    "WT": "206",\n    "ATHL": "94",\n    "CL": "4",\n    "FL": "2",\n    "PRD GRADE": "61.9",\n    "EFF GRADE": "75.3",\n    "RR GRD": "NA",\n    "ELU GRADE": "90.2",\n    "FILM GRADE": "79",\n    "G": "45",\n    "SOS": "77",\n    "YDS(t)": "4449",\n    "TD(t)": "49",\n    "1D(t)": "152",\n    "YpG(t)": "98.9",\n    "OPP(t)": "718",\n    "IMP": "241",\n    "IMP/ OPP": "0.34",\n    "DMTR": "0.313",\n    "CAR": "600",\n    "ruYDS": "3584",\n    "YPC": "6",\n    "ruTD": "40",\n    "ru1D": "162",\n    "MTF/ A": "0.362",\n    "YACO/A": "4.18",\n    "ELU": "0.676",\n    "TGT": "118",\n    "REC": "87",\n    "recYDS": "865",\n    "recTD": "9",\n    "rec1D": "30",\n    "YPRR": "1.27",\n    "YPR": "10",\n    "YAC/R": "NA",\n    "Tier": "5"\n  },\n  {\n    "40": "4.39",\n    "RK": "20",\n    "PLAYER": "Jaylin Noel",\n    "POS": "WR",\n    "posRK": "10",\n    "TM": "HOU",\n    "OVR GRADE": "86",\n    "truADP": "145.3",\n    "Rook ADP": "24",\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "79",\n    "NCAA": "ISU",\n    "AGE": "22.8",\n    "HT": "5\'10",\n    "WT": "194",\n    "ATHL": "92",\n    "CL": "3.5",\n    "FL": "3",\n    "PRD GRADE": "92.4",\n    "EFF GRADE": "82.8",\n    "RR GRD": "87.7",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "79",\n    "G": "51",\n    "SOS": "83.6",\n    "YDS(t)": "2938",\n    "TD(t)": "18",\n    "1D(t)": "128",\n    "YpG(t)": "57.61",\n    "OPP(t)": "362",\n    "IMP": "146",\n    "IMP/ OPP": "0.4",\n    "DMTR": "0.212",\n    "CAR": "13",\n    "ruYDS": "84",\n    "YPC": "6.46",\n    "ruTD": "0",\n    "ru1D": "5",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "349",\n    "REC": "245",\n    "recYDS": "2854",\n    "recTD": "18",\n    "rec1D": "123",\n    "YPRR": "2.07",\n    "YPR": "11.6",\n    "YAC/R": "5.58",\n    "Tier": "5"\n  },\n  {\n    "40": "NA",\n    "RK": "21",\n    "PLAYER": "Mason Taylor",\n    "POS": "TE",\n    "posRK": "3",\n    "TM": "NYG",\n    "OVR GRADE": "75",\n    "truADP": "132.5",\n    "Rook ADP": "22",\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "42",\n    "NCAA": "LSU",\n    "AGE": "21.2",\n    "HT": "6\'5",\n    "WT": "251",\n    "ATHL": "86",\n    "CL": "3",\n    "FL": "3",\n    "PRD GRADE": "67.7",\n    "EFF GRADE": "58.5",\n    "RR GRD": "83.2",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "38",\n    "SOS": "90.7",\n    "YDS(t)": "1308",\n    "TD(t)": "6",\n    "1D(t)": "72",\n    "YpG(t)": "34.42",\n    "OPP(t)": "181",\n    "IMP": "78",\n    "IMP/ OPP": "0.43",\n    "DMTR": "0.089",\n    "CAR": "0",\n    "ruYDS": "0",\n    "YPC": "NA",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "181",\n    "REC": "129",\n    "recYDS": "1308",\n    "recTD": "6",\n    "rec1D": "72",\n    "YPRR": "1.09",\n    "YPR": "10.1",\n    "YAC/R": "5.36",\n    "Tier": "5"\n  },\n  {\n    "40": "4.38",\n    "RK": "22",\n    "PLAYER": "Jaydon Blue",\n    "POS": "RB",\n    "posRK": "9",\n    "TM": "DAL",\n    "OVR GRADE": "74",\n    "truADP": "118.9",\n    "Rook ADP": "19",\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "149",\n    "NCAA": "TEX",\n    "AGE": "21.5",\n    "HT": "5\'9",\n    "WT": "196",\n    "ATHL": "89",\n    "CL": "3",\n    "FL": "2.5",\n    "PRD GRADE": "57.5",\n    "EFF GRADE": "68.8",\n    "RR GRD": "NA",\n    "ELU GRADE": "76.5",\n    "FILM GRADE": "NA",\n    "G": "31",\n    "SOS": "91",\n    "YDS(t)": "1659",\n    "TD(t)": "18",\n    "1D(t)": "85",\n    "YpG(t)": "53.5",\n    "OPP(t)": "289",\n    "IMP": "101",\n    "IMP/ OPP": "0.35",\n    "DMTR": "0.131",\n    "CAR": "215",\n    "ruYDS": "1159",\n    "YPC": "5.4",\n    "ruTD": "11",\n    "ru1D": "56",\n    "MTF/ A": "0.26",\n    "YACO/A": "3.48",\n    "ELU": "0.521",\n    "TGT": "74",\n    "REC": "55",\n    "recYDS": "500",\n    "recTD": "7",\n    "rec1D": "27",\n    "YPRR": "1.59",\n    "YPR": "9",\n    "YAC/R": "NA",\n    "Tier": "5"\n  },\n  {\n    "40": "4.63",\n    "RK": "23",\n    "PLAYER": "Terrance Ferguson",\n    "POS": "TE",\n    "posRK": "4",\n    "TM": "LAC",\n    "OVR GRADE": "77",\n    "truADP": "162.0",\n    "Rook ADP": "27",\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "46",\n    "NCAA": "ORE",\n    "AGE": "22.4",\n    "HT": "6\'5",\n    "WT": "247",\n    "ATHL": "85",\n    "CL": "3.5",\n    "FL": "3",\n    "PRD GRADE": "72.7",\n    "EFF GRADE": "73.6",\n    "RR GRD": "75.8",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "53",\n    "SOS": "88.9",\n    "YDS(t)": "1537",\n    "TD(t)": "16",\n    "1D(t)": "85",\n    "YpG(t)": "29",\n    "OPP(t)": "183",\n    "IMP": "101",\n    "IMP/ OPP": "0.55",\n    "DMTR": "0.116",\n    "CAR": "0",\n    "ruYDS": "0",\n    "YPC": "NA",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "183",\n    "REC": "134",\n    "recYDS": "1537",\n    "recTD": "16",\n    "rec1D": "85",\n    "YPRR": "1.51",\n    "YPR": "11.5",\n    "YAC/R": "7.02",\n    "Tier": "5"\n  },\n  {\n    "40": "NA",\n    "RK": "24",\n    "PLAYER": "Dylan Sampson",\n    "POS": "RB",\n    "posRK": "10",\n    "TM": "CLE",\n    "OVR GRADE": "82",\n    "truADP": "143.1",\n    "Rook ADP": "23",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "126",\n    "NCAA": "TENN",\n    "AGE": "20.8",\n    "HT": "5\'8",\n    "WT": "200",\n    "ATHL": "80",\n    "CL": "2.5",\n    "FL": "2",\n    "PRD GRADE": "70.4",\n    "EFF GRADE": "85.4",\n    "RR GRD": "NA",\n    "ELU GRADE": "82.5",\n    "FILM GRADE": "85",\n    "G": "34",\n    "SOS": "91.5",\n    "YDS(t)": "2823",\n    "TD(t)": "36",\n    "1D(t)": "160",\n    "YpG(t)": "83",\n    "OPP(t)": "473",\n    "IMP": "185",\n    "IMP/ OPP": "0.39",\n    "DMTR": "0.203",\n    "CAR": "423",\n    "ruYDS": "2481",\n    "YPC": "5.9",\n    "ruTD": "35",\n    "ru1D": "131",\n    "MTF/ A": "0.262",\n    "YACO/A": "3.64",\n    "ELU": "0.535",\n    "TGT": "50",\n    "REC": "40",\n    "recYDS": "342",\n    "recTD": "1",\n    "rec1D": "18",\n    "YPRR": "1.06",\n    "YPR": "9",\n    "YAC/R": "NA",\n    "Tier": "5"\n  },\n  {\n    "40": "NA",\n    "RK": "25",\n    "PLAYER": "Elijah Arroyo",\n    "POS": "TE",\n    "posRK": "5",\n    "TM": "SEA",\n    "OVR GRADE": "74",\n    "truADP": "166.3",\n    "Rook ADP": "29",\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "50",\n    "NCAA": "MIA",\n    "AGE": "22.3",\n    "HT": "6\'5",\n    "WT": "250",\n    "ATHL": "85",\n    "CL": "4",\n    "FL": "2",\n    "PRD GRADE": "55.7",\n    "EFF GRADE": "68.3",\n    "RR GRD": "83.4",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "34",\n    "SOS": "82.9",\n    "YDS(t)": "747",\n    "TD(t)": "8",\n    "1D(t)": "31",\n    "YpG(t)": "21.97",\n    "OPP(t)": "63",\n    "IMP": "39",\n    "IMP/ OPP": "0.62",\n    "DMTR": "0.09",\n    "CAR": "0",\n    "ruYDS": "0",\n    "YPC": "NA",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "63",\n    "REC": "46",\n    "recYDS": "747",\n    "recTD": "8",\n    "rec1D": "31",\n    "YPRR": "1.61",\n    "YPR": "16.2",\n    "YAC/R": "8.8",\n    "Tier": "5"\n  },\n  {\n    "40": "4.61",\n    "RK": "26",\n    "PLAYER": "Pat Bryant",\n    "POS": "WR",\n    "posRK": "11",\n    "TM": "DEN",\n    "OVR GRADE": "80",\n    "truADP": "167.8",\n    "Rook ADP": "30",\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "74",\n    "NCAA": "ILL",\n    "AGE": "22.6",\n    "HT": "6\'2",\n    "WT": "204",\n    "ATHL": "72",\n    "CL": "3",\n    "FL": "2",\n    "PRD GRADE": "81.9",\n    "EFF GRADE": "82.8",\n    "RR GRD": "81.7",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "45",\n    "SOS": "88.4",\n    "YDS(t)": "2108",\n    "TD(t)": "19",\n    "1D(t)": "96",\n    "YpG(t)": "46.84",\n    "OPP(t)": "214",\n    "IMP": "115",\n    "IMP/ OPP": "0.54",\n    "DMTR": "0.255",\n    "CAR": "6",\n    "ruYDS": "17",\n    "YPC": "2.83",\n    "ruTD": "0",\n    "ru1D": "1",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "208",\n    "REC": "136",\n    "recYDS": "2091",\n    "recTD": "19",\n    "rec1D": "95",\n    "YPRR": "2.12",\n    "YPR": "15.4",\n    "YAC/R": "4.7",\n    "Tier": "5"\n  },\n  {\n    "40": "4.71",\n    "RK": "27",\n    "PLAYER": "Harold Fannin Jr.",\n    "POS": "TE",\n    "posRK": "6",\n    "TM": "CLE",\n    "OVR GRADE": "86",\n    "truADP": "179.8",\n    "Rook ADP": "34",\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "67",\n    "NCAA": "BGSU",\n    "AGE": "22",\n    "HT": "6\'3",\n    "WT": "241",\n    "ATHL": "79",\n    "CL": "4.5",\n    "FL": "1",\n    "PRD GRADE": "92",\n    "EFF GRADE": "94.6",\n    "RR GRD": "88.9",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "81",\n    "G": "36",\n    "SOS": "74.9",\n    "YDS(t)": "2555",\n    "TD(t)": "22",\n    "1D(t)": "123",\n    "YpG(t)": "70.97",\n    "OPP(t)": "265",\n    "IMP": "145",\n    "IMP/ OPP": "0.55",\n    "DMTR": "0.299",\n    "CAR": "33",\n    "ruYDS": "159",\n    "YPC": "4.82",\n    "ruTD": "5",\n    "ru1D": "15",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "232",\n    "REC": "180",\n    "recYDS": "2396",\n    "recTD": "17",\n    "rec1D": "108",\n    "YPRR": "2.99",\n    "YPR": "13.3",\n    "YAC/R": "8.1",\n    "Tier": "6"\n  },\n  {\n    "40": "4.58",\n    "RK": "28",\n    "PLAYER": "Devin Neal",\n    "POS": "RB",\n    "posRK": "11",\n    "TM": "NO",\n    "OVR GRADE": "81",\n    "truADP": "148.6",\n    "Rook ADP": "25",\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>⑥</span>",\n    "PK#": "184",\n    "NCAA": "KU",\n    "AGE": "21.9",\n    "HT": "5\'11",\n    "WT": "213",\n    "ATHL": "68",\n    "CL": "3",\n    "FL": "2",\n    "PRD GRADE": "92.1",\n    "EFF GRADE": "80.8",\n    "RR GRD": "NA",\n    "ELU GRADE": "68.2",\n    "FILM GRADE": "78",\n    "G": "49",\n    "SOS": "81",\n    "YDS(t)": "5063",\n    "TD(t)": "53",\n    "1D(t)": "96",\n    "YpG(t)": "103.3",\n    "OPP(t)": "860",\n    "IMP": "297",\n    "IMP/ OPP": "0.35",\n    "DMTR": "0.267",\n    "CAR": "759",\n    "ruYDS": "4340",\n    "YPC": "5.7",\n    "ruTD": "49",\n    "ru1D": "211",\n    "MTF/ A": "0.225",\n    "YACO/A": "3.33",\n    "ELU": "0.475",\n    "TGT": "101",\n    "REC": "79",\n    "recYDS": "723",\n    "recTD": "4",\n    "rec1D": "33",\n    "YPRR": "0.97",\n    "YPR": "9",\n    "YAC/R": "NA",\n    "Tier": "6"\n  },\n  {\n    "40": "4.42",\n    "RK": "29",\n    "PLAYER": "Jalen Royals",\n    "POS": "WR",\n    "posRK": "12",\n    "TM": "KC",\n    "OVR GRADE": "85",\n    "truADP": "160.1",\n    "Rook ADP": "26",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "133",\n    "NCAA": "USU",\n    "AGE": "22.4",\n    "HT": "6\'0",\n    "WT": "205",\n    "ATHL": "89",\n    "CL": "3.5",\n    "FL": "1.5",\n    "PRD GRADE": "78.8",\n    "EFF GRADE": "90.9",\n    "RR GRD": "86.1",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "80",\n    "G": "27",\n    "SOS": "70",\n    "YDS(t)": "1926",\n    "TD(t)": "21",\n    "1D(t)": "75",\n    "YpG(t)": "71.33",\n    "OPP(t)": "185",\n    "IMP": "96",\n    "IMP/ OPP": "0.52",\n    "DMTR": "0.333",\n    "CAR": "1",\n    "ruYDS": "3",\n    "YPC": "3",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "184",\n    "REC": "125",\n    "recYDS": "1923",\n    "recTD": "21",\n    "rec1D": "75",\n    "YPRR": "2.42",\n    "YPR": "15.4",\n    "YAC/R": "6.81",\n    "Tier": "6"\n  },\n  {\n    "40": "4.44",\n    "RK": "30",\n    "PLAYER": "Elic Ayomanor",\n    "POS": "WR",\n    "posRK": "13",\n    "TM": "TEN",\n    "OVR GRADE": "78",\n    "truADP": "169.8",\n    "Rook ADP": "31",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "136",\n    "NCAA": "STAN",\n    "AGE": "22.1",\n    "HT": "6\'2",\n    "WT": "206",\n    "ATHL": "83",\n    "CL": "3",\n    "FL": "1.5",\n    "PRD GRADE": "76.7",\n    "EFF GRADE": "76.4",\n    "RR GRD": "75.1",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "77",\n    "G": "24",\n    "SOS": "81.7",\n    "YDS(t)": "1853",\n    "TD(t)": "12",\n    "1D(t)": "82",\n    "YpG(t)": "77.21",\n    "OPP(t)": "216",\n    "IMP": "94",\n    "IMP/ OPP": "0.44",\n    "DMTR": "0.389",\n    "CAR": "0",\n    "ruYDS": "0",\n    "YPC": "NA",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "216",\n    "REC": "126",\n    "recYDS": "1853",\n    "recTD": "12",\n    "rec1D": "82",\n    "YPRR": "2.12",\n    "YPR": "14.7",\n    "YAC/R": "4.49",\n    "Tier": "6"\n  },\n  {\n    "40": "4.43",\n    "RK": "31",\n    "PLAYER": "DJ Giddens",\n    "POS": "RB",\n    "posRK": "12",\n    "TM": "IND",\n    "OVR GRADE": "81",\n    "truADP": "176.6",\n    "Rook ADP": "33",\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "151",\n    "NCAA": "KSU",\n    "AGE": "21.8",\n    "HT": "6\'0",\n    "WT": "212",\n    "ATHL": "85",\n    "CL": "3.5",\n    "FL": "2",\n    "PRD GRADE": "73.9",\n    "EFF GRADE": "82.7",\n    "RR GRD": "NA",\n    "ELU GRADE": "86.9",\n    "FILM GRADE": "70",\n    "G": "39",\n    "SOS": "82.5",\n    "YDS(t)": "3770",\n    "TD(t)": "27",\n    "1D(t)": "104",\n    "YpG(t)": "96.7",\n    "OPP(t)": "601",\n    "IMP": "209",\n    "IMP/ OPP": "0.35",\n    "DMTR": "0.196",\n    "CAR": "518",\n    "ruYDS": "3088",\n    "YPC": "6",\n    "ruTD": "23",\n    "ru1D": "156",\n    "MTF/ A": "0.284",\n    "YACO/A": "3.72",\n    "ELU": "0.563",\n    "TGT": "83",\n    "REC": "58",\n    "recYDS": "682",\n    "recTD": "4",\n    "rec1D": "26",\n    "YPRR": "1.24",\n    "YPR": "12",\n    "YAC/R": "NA",\n    "Tier": "6"\n  },\n  {\n    "40": "4.42",\n    "RK": "32",\n    "PLAYER": "Trevor Etienne",\n    "POS": "RB",\n    "posRK": "13",\n    "TM": "CAR",\n    "OVR GRADE": "80",\n    "truADP": "183.4",\n    "Rook ADP": "35",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "114",\n    "NCAA": "UGA",\n    "AGE": "21",\n    "HT": "5\'9",\n    "WT": "198",\n    "ATHL": "83",\n    "CL": "2.5",\n    "FL": "1.5",\n    "PRD GRADE": "63.4",\n    "EFF GRADE": "71.9",\n    "RR GRD": "NA",\n    "ELU GRADE": "86.7",\n    "FILM GRADE": "79",\n    "G": "34",\n    "SOS": "93.5",\n    "YDS(t)": "2510",\n    "TD(t)": "24",\n    "1D(t)": "153",\n    "YpG(t)": "73.8",\n    "OPP(t)": "433",\n    "IMP": "147",\n    "IMP/ OPP": "0.34",\n    "DMTR": "0.184",\n    "CAR": "370",\n    "ruYDS": "2078",\n    "YPC": "5.6",\n    "ruTD": "23",\n    "ru1D": "103",\n    "MTF/ A": "0.265",\n    "YACO/A": "3.8",\n    "ELU": "0.55",\n    "TGT": "63",\n    "REC": "62",\n    "recYDS": "432",\n    "recTD": "1",\n    "rec1D": "20",\n    "YPRR": "0.99",\n    "YPR": "7",\n    "YAC/R": "NA",\n    "Tier": "6"\n  },\n  {\n    "40": "4.61",\n    "RK": "33",\n    "PLAYER": "Ollie Gordon",\n    "POS": "RB",\n    "posRK": "14",\n    "TM": "MIA",\n    "OVR GRADE": "74",\n    "truADP": "174.7",\n    "Rook ADP": "32",\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>⑥</span>",\n    "PK#": "179",\n    "NCAA": "OKST",\n    "AGE": "21.5",\n    "HT": "6\'1",\n    "WT": "226",\n    "ATHL": "70",\n    "CL": "2.5",\n    "FL": "3",\n    "PRD GRADE": "81.9",\n    "EFF GRADE": "70.8",\n    "RR GRD": "NA",\n    "ELU GRADE": "64.9",\n    "FILM GRADE": "78",\n    "G": "39",\n    "SOS": "82",\n    "YDS(t)": "3495",\n    "TD(t)": "40",\n    "1D(t)": "96",\n    "YpG(t)": "89.6",\n    "OPP(t)": "638",\n    "IMP": "217",\n    "IMP/ OPP": "0.34",\n    "DMTR": "0.26",\n    "CAR": "535",\n    "ruYDS": "2891",\n    "YPC": "5.4",\n    "ruTD": "35",\n    "ru1D": "142",\n    "MTF/ A": "0.234",\n    "YACO/A": "3.47",\n    "ELU": "0.494",\n    "TGT": "103",\n    "REC": "81",\n    "recYDS": "604",\n    "recTD": "5",\n    "rec1D": "35",\n    "YPRR": "0.82",\n    "YPR": "8",\n    "YAC/R": "NA",\n    "Tier": "6"\n  },\n  {\n    "40": "4.44",\n    "RK": "34",\n    "PLAYER": "Jarquez Hunter",\n    "POS": "RB",\n    "posRK": "15",\n    "TM": "LAR",\n    "OVR GRADE": "76",\n    "truADP": "193.7",\n    "Rook ADP": "38",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "117",\n    "NCAA": "AUB",\n    "AGE": "22.5",\n    "HT": "5\'9",\n    "WT": "204",\n    "ATHL": "76",\n    "CL": "3",\n    "FL": "2",\n    "PRD GRADE": "79.1",\n    "EFF GRADE": "80.3",\n    "RR GRD": "NA",\n    "ELU GRADE": "90.1",\n    "FILM GRADE": "NA",\n    "G": "49",\n    "SOS": "92",\n    "YDS(t)": "3931",\n    "TD(t)": "29",\n    "1D(t)": "147",\n    "YpG(t)": "80.2",\n    "OPP(t)": "629",\n    "IMP": "219",\n    "IMP/ OPP": "0.35",\n    "DMTR": "0.196",\n    "CAR": "539",\n    "ruYDS": "3373",\n    "YPC": "6.3",\n    "ruTD": "25",\n    "ru1D": "166",\n    "MTF/ A": "0.304",\n    "YACO/A": "3.94",\n    "ELU": "0.6",\n    "TGT": "90",\n    "REC": "68",\n    "recYDS": "558",\n    "recTD": "4",\n    "rec1D": "24",\n    "YPRR": "0.89",\n    "YPR": "8",\n    "YAC/R": "NA",\n    "Tier": "6"\n  },\n  {\n    "40": "4.55",\n    "RK": "35",\n    "PLAYER": "Jordan James",\n    "POS": "RB",\n    "posRK": "16",\n    "TM": "SF",\n    "OVR GRADE": "76",\n    "truADP": "185.6",\n    "Rook ADP": "36",\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "147",\n    "NCAA": "ORE",\n    "AGE": "21.3",\n    "HT": "5\'10",\n    "WT": "205",\n    "ATHL": "71",\n    "CL": "3.5",\n    "FL": "1.5",\n    "PRD GRADE": "78.3",\n    "EFF GRADE": "81.4",\n    "RR GRD": "NA",\n    "ELU GRADE": "69.9",\n    "FILM GRADE": "NA",\n    "G": "37",\n    "SOS": "90",\n    "YDS(t)": "2568",\n    "TD(t)": "32",\n    "1D(t)": "160",\n    "YpG(t)": "69.4",\n    "OPP(t)": "439",\n    "IMP": "197",\n    "IMP/ OPP": "0.45",\n    "DMTR": "0.156",\n    "CAR": "386",\n    "ruYDS": "2223",\n    "YPC": "5.8",\n    "ruTD": "31",\n    "ru1D": "148",\n    "MTF/ A": "0.251",\n    "YACO/A": "3.32",\n    "ELU": "0.5",\n    "TGT": "53",\n    "REC": "42",\n    "recYDS": "345",\n    "recTD": "1",\n    "rec1D": "17",\n    "YPRR": "0.95",\n    "YPR": "8",\n    "YAC/R": "NA",\n    "Tier": "6"\n  },\n  {\n    "40": "4.43",\n    "RK": "36",\n    "PLAYER": "Isaac TeSlaa",\n    "POS": "WR",\n    "posRK": "14",\n    "TM": "DET",\n    "OVR GRADE": "75",\n    "truADP": "195.1",\n    "Rook ADP": "40",\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "70",\n    "NCAA": "ARK",\n    "AGE": "23.4",\n    "HT": "6\'4",\n    "WT": "214",\n    "ATHL": "91",\n    "CL": "4",\n    "FL": "1",\n    "PRD GRADE": "58.5",\n    "EFF GRADE": "65.5",\n    "RR GRD": "74.7",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "25",\n    "SOS": "NA",\n    "YDS(t)": "883",\n    "TD(t)": "5",\n    "1D(t)": "36",\n    "YpG(t)": "35.32",\n    "OPP(t)": "101",\n    "IMP": "41",\n    "IMP/ OPP": "0.41",\n    "DMTR": "0.142",\n    "CAR": "1",\n    "ruYDS": "0",\n    "YPC": "0",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "100",\n    "REC": "62",\n    "recYDS": "883",\n    "recTD": "5",\n    "rec1D": "36",\n    "YPRR": "1.45",\n    "YPR": "14.2",\n    "YAC/R": "4.97",\n    "Tier": "6"\n  },\n  {\n    "40": "4.39",\n    "RK": "37",\n    "PLAYER": "Brashard Smith",\n    "POS": "RB",\n    "posRK": "17",\n    "TM": "KC",\n    "OVR GRADE": "73",\n    "truADP": "198.4",\n    "Rook ADP": "41",\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "228",\n    "NCAA": "SMU",\n    "AGE": "22.3",\n    "HT": "5\'10",\n    "WT": "194",\n    "ATHL": "79",\n    "CL": "3.5",\n    "FL": "2",\n    "PRD GRADE": "66.6",\n    "EFF GRADE": "81.8",\n    "RR GRD": "NA",\n    "ELU GRADE": "60.3",\n    "FILM GRADE": "NA",\n    "G": "46",\n    "SOS": "78",\n    "YDS(t)": "2616",\n    "TD(t)": "23",\n    "1D(t)": "72",\n    "YpG(t)": "56.9",\n    "OPP(t)": "392",\n    "IMP": "149",\n    "IMP/ OPP": "0.38",\n    "DMTR": "0.135",\n    "CAR": "252",\n    "ruYDS": "1516",\n    "YPC": "6",\n    "ruTD": "15",\n    "ru1D": "76",\n    "MTF/ A": "0.226",\n    "YACO/A": "3.3",\n    "ELU": "0.474",\n    "TGT": "140",\n    "REC": "109",\n    "recYDS": "1100",\n    "recTD": "8",\n    "rec1D": "50",\n    "YPRR": "1.9",\n    "YPR": "10",\n    "YAC/R": "NA",\n    "Tier": "6"\n  },\n  {\n    "40": "4.41",\n    "RK": "38",\n    "PLAYER": "Tory Horton",\n    "POS": "WR",\n    "posRK": "15",\n    "TM": "SEA",\n    "OVR GRADE": "84",\n    "truADP": "199.7",\n    "Rook ADP": "42",\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "166",\n    "NCAA": "CSU",\n    "AGE": "22.6",\n    "HT": "6\'2",\n    "WT": "196",\n    "ATHL": "87",\n    "CL": "3.5",\n    "FL": "2",\n    "PRD GRADE": "90.7",\n    "EFF GRADE": "87.3",\n    "RR GRD": "82.9",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "50",\n    "SOS": "75.1",\n    "YDS(t)": "3632",\n    "TD(t)": "27",\n    "1D(t)": "153",\n    "YpG(t)": "72.64",\n    "OPP(t)": "381",\n    "IMP": "180",\n    "IMP/ OPP": "0.47",\n    "DMTR": "0.267",\n    "CAR": "2",\n    "ruYDS": "31",\n    "YPC": "15.5",\n    "ruTD": "0",\n    "ru1D": "1",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "379",\n    "REC": "264",\n    "recYDS": "3601",\n    "recTD": "27",\n    "rec1D": "152",\n    "YPRR": "2.46",\n    "YPR": "13.6",\n    "YAC/R": "5.83",\n    "Tier": "6"\n  },\n  {\n    "40": "4.54",\n    "RK": "39",\n    "PLAYER": "Jo\'quavious Marks",\n    "POS": "RB",\n    "posRK": "18",\n    "TM": "HOU",\n    "OVR GRADE": "70",\n    "truADP": "211.9",\n    "Rook ADP": "45",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "116",\n    "NCAA": "USC",\n    "AGE": "24.5",\n    "HT": "5\'10",\n    "WT": "207",\n    "ATHL": "76",\n    "CL": "2.5",\n    "FL": "1.5",\n    "PRD GRADE": "85.4",\n    "EFF GRADE": "59.2",\n    "RR GRD": "NA",\n    "ELU GRADE": "55.1",\n    "FILM GRADE": "NA",\n    "G": "57",\n    "SOS": "NA",\n    "YDS(t)": "4561",\n    "TD(t)": "36",\n    "1D(t)": "87",\n    "YpG(t)": "80",\n    "OPP(t)": "912",\n    "IMP": "288",\n    "IMP/ OPP": "0.32",\n    "DMTR": "0.199",\n    "CAR": "611",\n    "ruYDS": "3057",\n    "YPC": "5",\n    "ruTD": "31",\n    "ru1D": "182",\n    "MTF/ A": "0.155",\n    "YACO/A": "2.76",\n    "ELU": "0.362",\n    "TGT": "301",\n    "REC": "257",\n    "recYDS": "1504",\n    "recTD": "5",\n    "rec1D": "70",\n    "YPRR": "1.12",\n    "YPR": "6",\n    "YAC/R": "NA",\n    "Tier": "6"\n  },\n  {\n    "40": "NA",\n    "RK": "40",\n    "PLAYER": "Oronde Gadsden II",\n    "POS": "TE",\n    "posRK": "7",\n    "TM": "LAC",\n    "OVR GRADE": "79",\n    "truADP": "239.5",\n    "Rook ADP": "48",\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "165",\n    "NCAA": "SYR",\n    "AGE": "22",\n    "HT": "6\'5",\n    "WT": "243",\n    "ATHL": "75",\n    "CL": "3.5",\n    "FL": "2",\n    "PRD GRADE": "82",\n    "EFF GRADE": "82.7",\n    "RR GRD": "75.2",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "34",\n    "SOS": "80.9",\n    "YDS(t)": "2003",\n    "TD(t)": "14",\n    "1D(t)": "107",\n    "YpG(t)": "58.91",\n    "OPP(t)": "210",\n    "IMP": "121",\n    "IMP/ OPP": "0.58",\n    "DMTR": "0.257",\n    "CAR": "1",\n    "ruYDS": "12",\n    "YPC": "12",\n    "ruTD": "0",\n    "ru1D": "1",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "209",\n    "REC": "143",\n    "recYDS": "1991",\n    "recTD": "14",\n    "rec1D": "106",\n    "YPRR": "2.04",\n    "YPR": "13.9",\n    "YAC/R": "3.69",\n    "Tier": "6"\n  },\n  {\n    "40": "4.6",\n    "RK": "41",\n    "PLAYER": "Kyle Monangai",\n    "POS": "RB",\n    "posRK": "19",\n    "TM": "CHI",\n    "OVR GRADE": "74",\n    "truADP": "206.7",\n    "Rook ADP": "44",\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "233",\n    "NCAA": "RUT",\n    "AGE": "23.3",\n    "HT": "5\'8",\n    "WT": "211",\n    "ATHL": "70",\n    "CL": "2",\n    "FL": "2.5",\n    "PRD GRADE": "74",\n    "EFF GRADE": "64.4",\n    "RR GRD": "NA",\n    "ELU GRADE": "84.5",\n    "FILM GRADE": "NA",\n    "G": "47",\n    "SOS": "NA",\n    "YDS(t)": "3466",\n    "TD(t)": "28",\n    "1D(t)": "123",\n    "YpG(t)": "73.7",\n    "OPP(t)": "721",\n    "IMP": "225",\n    "IMP/ OPP": "0.31",\n    "DMTR": "0.227",\n    "CAR": "670",\n    "ruYDS": "3225",\n    "YPC": "4.8",\n    "ruTD": "27",\n    "ru1D": "190",\n    "MTF/ A": "0.258",\n    "YACO/A": "3.33",\n    "ELU": "0.508",\n    "TGT": "51",\n    "REC": "36",\n    "recYDS": "241",\n    "recTD": "1",\n    "rec1D": "7",\n    "YPRR": "0.52",\n    "YPR": "7",\n    "YAC/R": "NA",\n    "Tier": "6"\n  },\n  {\n    "40": "4.3",\n    "RK": "42",\n    "PLAYER": "Dont\'e Thornton",\n    "POS": "WR",\n    "posRK": "16",\n    "TM": "LV",\n    "OVR GRADE": "74",\n    "truADP": "233.8",\n    "Rook ADP": "46",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "108",\n    "NCAA": "TENN",\n    "AGE": "22.6",\n    "HT": "6\'5",\n    "WT": "205",\n    "ATHL": "95",\n    "CL": "4",\n    "FL": "1",\n    "PRD GRADE": "59.5",\n    "EFF GRADE": "75.6",\n    "RR GRD": "69.8",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "42",\n    "SOS": "90.7",\n    "YDS(t)": "1433",\n    "TD(t)": "10",\n    "1D(t)": "43",\n    "YpG(t)": "34.12",\n    "OPP(t)": "95",\n    "IMP": "53",\n    "IMP/ OPP": "0.56",\n    "DMTR": "0.139",\n    "CAR": "1",\n    "ruYDS": "9",\n    "YPC": "9",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "94",\n    "REC": "65",\n    "recYDS": "1424",\n    "recTD": "10",\n    "rec1D": "43",\n    "YPRR": "2.8",\n    "YPR": "21.9",\n    "YAC/R": "8.94",\n    "Tier": "6"\n  },\n  {\n    "40": "4.52",\n    "RK": "43",\n    "PLAYER": "Tahj Brooks",\n    "POS": "RB",\n    "posRK": "20",\n    "TM": "CIN",\n    "OVR GRADE": "81",\n    "truADP": "244.1",\n    "Rook ADP": "50",\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>⑥</span>",\n    "PK#": "193",\n    "NCAA": "TTU",\n    "AGE": "23.2",\n    "HT": "5\'9",\n    "WT": "214",\n    "ATHL": "86",\n    "CL": "3",\n    "FL": "2",\n    "PRD GRADE": "91.9",\n    "EFF GRADE": "63.7",\n    "RR GRD": "NA",\n    "ELU GRADE": "87.9",\n    "FILM GRADE": "NA",\n    "G": "53",\n    "SOS": "83",\n    "YDS(t)": "5136",\n    "TD(t)": "47",\n    "1D(t)": "45",\n    "YpG(t)": "96.9",\n    "OPP(t)": "1001",\n    "IMP": "332",\n    "IMP/ OPP": "0.33",\n    "DMTR": "0.226",\n    "CAR": "883",\n    "ruYDS": "4590",\n    "YPC": "5.2",\n    "ruTD": "45",\n    "ru1D": "263",\n    "MTF/ A": "0.266",\n    "YACO/A": "3.18",\n    "ELU": "0.505",\n    "TGT": "118",\n    "REC": "101",\n    "recYDS": "546",\n    "recTD": "2",\n    "rec1D": "22",\n    "YPRR": "0.54",\n    "YPR": "5",\n    "YAC/R": "NA",\n    "Tier": "7"\n  },\n  {\n    "40": "4.37",\n    "RK": "44",\n    "PLAYER": "Tai Felton",\n    "POS": "WR",\n    "posRK": "17",\n    "TM": "MIN",\n    "OVR GRADE": "82",\n    "truADP": "249.9",\n    "Rook ADP": "51",\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "102",\n    "NCAA": "MD",\n    "AGE": "22.3",\n    "HT": "6\'1",\n    "WT": "183",\n    "ATHL": "86",\n    "CL": "3.5",\n    "FL": "2",\n    "PRD GRADE": "87.8",\n    "EFF GRADE": "74.7",\n    "RR GRD": "78.2",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "43",\n    "SOS": "92.6",\n    "YDS(t)": "2250",\n    "TD(t)": "17",\n    "1D(t)": "108",\n    "YpG(t)": "52.33",\n    "OPP(t)": "267",\n    "IMP": "125",\n    "IMP/ OPP": "0.47",\n    "DMTR": "0.197",\n    "CAR": "3",\n    "ruYDS": "39",\n    "YPC": "13",\n    "ruTD": "0",\n    "ru1D": "2",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "264",\n    "REC": "172",\n    "recYDS": "2211",\n    "recTD": "17",\n    "rec1D": "106",\n    "YPRR": "1.86",\n    "YPR": "12.9",\n    "YAC/R": "6.19",\n    "Tier": "7"\n  },\n  {\n    "40": "4.48",\n    "RK": "45",\n    "PLAYER": "Savion Williams",\n    "POS": "WR",\n    "posRK": "18",\n    "TM": "GB",\n    "OVR GRADE": "78",\n    "truADP": "258.3",\n    "Rook ADP": "55",\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "87",\n    "NCAA": "TCU",\n    "AGE": "23.6",\n    "HT": "6\'4",\n    "WT": "222",\n    "ATHL": "87",\n    "CL": "3.5",\n    "FL": "1.5",\n    "PRD GRADE": "82.2",\n    "EFF GRADE": "76.6",\n    "RR GRD": "68.8",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "77",\n    "G": "50",\n    "SOS": "78.3",\n    "YDS(t)": "2053",\n    "TD(t)": "20",\n    "1D(t)": "104",\n    "YpG(t)": "41.06",\n    "OPP(t)": "272",\n    "IMP": "124",\n    "IMP/ OPP": "0.46",\n    "DMTR": "0.135",\n    "CAR": "62",\n    "ruYDS": "384",\n    "YPC": "6.19",\n    "ruTD": "6",\n    "ru1D": "22",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "210",\n    "REC": "138",\n    "recYDS": "1669",\n    "recTD": "14",\n    "rec1D": "82",\n    "YPRR": "1.55",\n    "YPR": "12.1",\n    "YAC/R": "5.41",\n    "Tier": "7"\n  },\n  {\n    "40": "4.51",\n    "RK": "46",\n    "PLAYER": "Damien Martinez",\n    "POS": "RB",\n    "posRK": "21",\n    "TM": "SEA",\n    "OVR GRADE": "81",\n    "truADP": "261.4",\n    "Rook ADP": "56",\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "223",\n    "NCAA": "MIA",\n    "AGE": "21.4",\n    "HT": "5\'12",\n    "WT": "217",\n    "ATHL": "73",\n    "CL": "2",\n    "FL": "2.5",\n    "PRD GRADE": "72.8",\n    "EFF GRADE": "85",\n    "RR GRD": "NA",\n    "ELU GRADE": "88.8",\n    "FILM GRADE": "NA",\n    "G": "38",\n    "SOS": "86.5",\n    "YDS(t)": "3564",\n    "TD(t)": "26",\n    "1D(t)": "144",\n    "YpG(t)": "93.8",\n    "OPP(t)": "566",\n    "IMP": "214",\n    "IMP/ OPP": "0.38",\n    "DMTR": "0.179",\n    "CAR": "516",\n    "ruYDS": "3173",\n    "YPC": "6.1",\n    "ruTD": "26",\n    "ru1D": "172",\n    "MTF/ A": "0.269",\n    "YACO/A": "3.91",\n    "ELU": "0.562",\n    "TGT": "50",\n    "REC": "32",\n    "recYDS": "391",\n    "recTD": "0",\n    "rec1D": "16",\n    "YPRR": "0.73",\n    "YPR": "12",\n    "YAC/R": "NA",\n    "Tier": "7"\n  },\n  {\n    "40": "4.45",\n    "RK": "47",\n    "PLAYER": "Jacory Croskey-Merritt",\n    "POS": "RB",\n    "posRK": "22",\n    "TM": "WAS",\n    "OVR GRADE": "72",\n    "truADP": "235.9",\n    "Rook ADP": "47",\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "245",\n    "NCAA": "ARIZ",\n    "AGE": "24.3",\n    "HT": "5\'11",\n    "WT": "208",\n    "ATHL": "75",\n    "CL": "2.5",\n    "FL": "1.5",\n    "PRD GRADE": "69.4",\n    "EFF GRADE": "65.3",\n    "RR GRD": "NA",\n    "ELU GRADE": "68.2",\n    "FILM GRADE": "NA",\n    "G": "43",\n    "SOS": "NA",\n    "YDS(t)": "2753",\n    "TD(t)": "31",\n    "1D(t)": "72",\n    "YpG(t)": "64",\n    "OPP(t)": "558",\n    "IMP": "190",\n    "IMP/ OPP": "0.34",\n    "DMTR": "0.227",\n    "CAR": "513",\n    "ruYDS": "2440",\n    "YPC": "4.8",\n    "ruTD": "29",\n    "ru1D": "143",\n    "MTF/ A": "0.25",\n    "YACO/A": "3.23",\n    "ELU": "0.492",\n    "TGT": "45",\n    "REC": "34",\n    "recYDS": "313",\n    "recTD": "2",\n    "rec1D": "16",\n    "YPRR": "0.79",\n    "YPR": "9",\n    "YAC/R": "NA",\n    "Tier": "7"\n  },\n  {\n    "40": "4.46",\n    "RK": "48",\n    "PLAYER": "Jimmy Horn Jr.",\n    "POS": "WR",\n    "posRK": "19",\n    "TM": "CAR",\n    "OVR GRADE": "72",\n    "truADP": "240.0",\n    "Rook ADP": "49",\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>⑥</span>",\n    "PK#": "208",\n    "NCAA": "COLO",\n    "AGE": "22.8",\n    "HT": "5\'8",\n    "WT": "174",\n    "ATHL": "71",\n    "CL": "2",\n    "FL": "2",\n    "PRD GRADE": "74.2",\n    "EFF GRADE": "67.2",\n    "RR GRD": "77.3",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "46",\n    "SOS": "NA",\n    "YDS(t)": "2092",\n    "TD(t)": "12",\n    "1D(t)": "92",\n    "YpG(t)": "45.48",\n    "OPP(t)": "258",\n    "IMP": "104",\n    "IMP/ OPP": "0.4",\n    "DMTR": "0.151",\n    "CAR": "16",\n    "ruYDS": "112",\n    "YPC": "7",\n    "ruTD": "1",\n    "ru1D": "7",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "242",\n    "REC": "163",\n    "recYDS": "1980",\n    "recTD": "11",\n    "rec1D": "85",\n    "YPRR": "1.55",\n    "YPR": "12.1",\n    "YAC/R": "7.02",\n    "Tier": "7"\n  },\n  {\n    "40": "4.84",\n    "RK": "49",\n    "PLAYER": "Gunnar Helm",\n    "POS": "TE",\n    "posRK": "8",\n    "TM": "TEN",\n    "OVR GRADE": "71",\n    "truADP": "257.5",\n    "Rook ADP": "54",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "120",\n    "NCAA": "TEX",\n    "AGE": "22.8",\n    "HT": "6\'5",\n    "WT": "241",\n    "ATHL": "71",\n    "CL": "3.5",\n    "FL": "3.5",\n    "PRD GRADE": "61.6",\n    "EFF GRADE": "64.9",\n    "RR GRD": "80.4",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "43",\n    "SOS": "89.7",\n    "YDS(t)": "1022",\n    "TD(t)": "9",\n    "1D(t)": "45",\n    "YpG(t)": "23.77",\n    "OPP(t)": "95",\n    "IMP": "54",\n    "IMP/ OPP": "0.57",\n    "DMTR": "0.096",\n    "CAR": "0",\n    "ruYDS": "0",\n    "YPC": "NA",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "95",\n    "REC": "79",\n    "recYDS": "1022",\n    "recTD": "9",\n    "rec1D": "45",\n    "YPRR": "1.38",\n    "YPR": "12.9",\n    "YAC/R": "6.85",\n    "Tier": "7"\n  },\n  {\n    "40": "4.37",\n    "RK": "50",\n    "PLAYER": "Keandre Lambert-Smith",\n    "POS": "WR",\n    "posRK": "20",\n    "TM": "LAC",\n    "OVR GRADE": "80",\n    "truADP": "310.2",\n    "Rook ADP": "66",\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "158",\n    "NCAA": "AUB",\n    "AGE": "22.9",\n    "HT": "6\'1",\n    "WT": "190",\n    "ATHL": "87",\n    "CL": "4",\n    "FL": "1.5",\n    "PRD GRADE": "80.1",\n    "EFF GRADE": "80.1",\n    "RR GRD": "71.5",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "58",\n    "SOS": "94.3",\n    "YDS(t)": "2704",\n    "TD(t)": "19",\n    "1D(t)": "115",\n    "YpG(t)": "46.62",\n    "OPP(t)": "285",\n    "IMP": "134",\n    "IMP/ OPP": "0.47",\n    "DMTR": "0.17",\n    "CAR": "1",\n    "ruYDS": "2",\n    "YPC": "2",\n    "ruTD": "0",\n    "ru1D": "1",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "284",\n    "REC": "176",\n    "recYDS": "2702",\n    "recTD": "19",\n    "rec1D": "114",\n    "YPRR": "1.77",\n    "YPR": "15.4",\n    "YAC/R": "7.03",\n    "Tier": "7"\n  },\n  {\n    "40": "4.34",\n    "RK": "51",\n    "PLAYER": "Jaylin Lane",\n    "POS": "WR",\n    "posRK": "21",\n    "TM": "WAS",\n    "OVR GRADE": "77",\n    "truADP": "278.6",\n    "Rook ADP": "57",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "125",\n    "NCAA": "VT",\n    "AGE": "23.2",\n    "HT": "5\'10",\n    "WT": "191",\n    "ATHL": "94",\n    "CL": "3",\n    "FL": "2",\n    "PRD GRADE": "83",\n    "EFF GRADE": "78.2",\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "54",\n    "SOS": "80.4",\n    "YDS(t)": "2804",\n    "TD(t)": "21",\n    "1D(t)": "133",\n    "YpG(t)": "51.93",\n    "OPP(t)": "340",\n    "IMP": "154",\n    "IMP/ OPP": "0.45",\n    "DMTR": "0.206",\n    "CAR": "46",\n    "ruYDS": "264",\n    "YPC": "5.74",\n    "ruTD": "3",\n    "ru1D": "14",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "294",\n    "REC": "203",\n    "recYDS": "2540",\n    "recTD": "18",\n    "rec1D": "119",\n    "YPRR": "2.01",\n    "YPR": "12.5",\n    "YAC/R": "8.06",\n    "Tier": "8"\n  },\n  {\n    "40": "4.34",\n    "RK": "52",\n    "PLAYER": "Chimere Dike",\n    "POS": "WR",\n    "posRK": "22",\n    "TM": "TEN",\n    "OVR GRADE": "76",\n    "truADP": "282.0",\n    "Rook ADP": "59",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "103",\n    "NCAA": "FLA",\n    "AGE": "23.6",\n    "HT": "6\'1",\n    "WT": "196",\n    "ATHL": "91",\n    "CL": "2.5",\n    "FL": "2.5",\n    "PRD GRADE": "72",\n    "EFF GRADE": "65.8",\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "57",\n    "SOS": "91.9",\n    "YDS(t)": "2360",\n    "TD(t)": "12",\n    "1D(t)": "100",\n    "YpG(t)": "41.4",\n    "OPP(t)": "251",\n    "IMP": "112",\n    "IMP/ OPP": "0.45",\n    "DMTR": "0.179",\n    "CAR": "14",\n    "ruYDS": "99",\n    "YPC": "7.07",\n    "ruTD": "1",\n    "ru1D": "5",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "237",\n    "REC": "139",\n    "recYDS": "2261",\n    "recTD": "11",\n    "rec1D": "95",\n    "YPRR": "1.72",\n    "YPR": "16.3",\n    "YAC/R": "5.42",\n    "Tier": "8"\n  },\n  {\n    "40": "4.36",\n    "RK": "53",\n    "PLAYER": "Arian Smith",\n    "POS": "WR",\n    "posRK": "23",\n    "TM": "NYG",\n    "OVR GRADE": "71",\n    "truADP": "285.2",\n    "Rook ADP": "60",\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "110",\n    "NCAA": "UGA",\n    "AGE": "22.8",\n    "HT": "6\'0",\n    "WT": "179",\n    "ATHL": "88",\n    "CL": "3",\n    "FL": "2",\n    "PRD GRADE": "60.3",\n    "EFF GRADE": "65.2",\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "45",\n    "SOS": "NA",\n    "YDS(t)": "1428",\n    "TD(t)": "10",\n    "1D(t)": "49",\n    "YpG(t)": "31.73",\n    "OPP(t)": "121",\n    "IMP": "59",\n    "IMP/ OPP": "0.49",\n    "DMTR": "0.105",\n    "CAR": "9",\n    "ruYDS": "88",\n    "YPC": "9.78",\n    "ruTD": "0",\n    "ru1D": "4",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "112",\n    "REC": "68",\n    "recYDS": "1340",\n    "recTD": "10",\n    "rec1D": "45",\n    "YPRR": "2.27",\n    "YPR": "19.7",\n    "YAC/R": "7.87",\n    "Tier": "8"\n  },\n  {\n    "40": "NA",\n    "RK": "54",\n    "PLAYER": "Phil Mafah",\n    "POS": "RB",\n    "posRK": "23",\n    "TM": "DAL",\n    "OVR GRADE": "68",\n    "truADP": "280.0",\n    "Rook ADP": "58",\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "239",\n    "NCAA": "CLEM",\n    "AGE": "22.7",\n    "HT": "6\'1",\n    "WT": "234",\n    "ATHL": "75",\n    "CL": "1.5",\n    "FL": "1",\n    "PRD GRADE": "72.2",\n    "EFF GRADE": "67.8",\n    "RR GRD": "NA",\n    "ELU GRADE": "61.6",\n    "FILM GRADE": "NA",\n    "G": "50",\n    "SOS": "NA",\n    "YDS(t)": "3204",\n    "TD(t)": "28",\n    "1D(t)": "36",\n    "YpG(t)": "64.1",\n    "OPP(t)": "635",\n    "IMP": "205",\n    "IMP/ OPP": "0.32",\n    "DMTR": "0.153",\n    "CAR": "559",\n    "ruYDS": "2895",\n    "YPC": "5.2",\n    "ruTD": "28",\n    "ru1D": "164",\n    "MTF/ A": "0.199",\n    "YACO/A": "3.47",\n    "ELU": "0.459",\n    "TGT": "76",\n    "REC": "58",\n    "recYDS": "309",\n    "recTD": "0",\n    "rec1D": "13",\n    "YPRR": "0.45",\n    "YPR": "5",\n    "YAC/R": "NA",\n    "Tier": "8"\n  },\n  {\n    "40": "NA",\n    "RK": "55",\n    "PLAYER": "LeQuint Allen",\n    "POS": "RB",\n    "posRK": "24",\n    "TM": "JAX",\n    "OVR GRADE": "67",\n    "truADP": "326.1",\n    "Rook ADP": "69",\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "236",\n    "NCAA": "SYR",\n    "AGE": "20.9",\n    "HT": "6\'0",\n    "WT": "204",\n    "ATHL": "70",\n    "CL": "3",\n    "FL": "2",\n    "PRD GRADE": "76",\n    "EFF GRADE": "58.6",\n    "RR GRD": "NA",\n    "ELU GRADE": "58.3",\n    "FILM GRADE": "NA",\n    "G": "38",\n    "SOS": "78",\n    "YDS(t)": "3232",\n    "TD(t)": "32",\n    "1D(t)": "128",\n    "YpG(t)": "85.1",\n    "OPP(t)": "660",\n    "IMP": "204",\n    "IMP/ OPP": "0.31",\n    "DMTR": "0.227",\n    "CAR": "513",\n    "ruYDS": "2366",\n    "YPC": "4.6",\n    "ruTD": "26",\n    "ru1D": "126",\n    "MTF/ A": "0.234",\n    "YACO/A": "3.19",\n    "ELU": "0.473",\n    "TGT": "147",\n    "REC": "121",\n    "recYDS": "866",\n    "recTD": "6",\n    "rec1D": "46",\n    "YPRR": "1.14",\n    "YPR": "7",\n    "YAC/R": "NA",\n    "Tier": "8"\n  },\n  {\n    "40": "4.51",\n    "RK": "56",\n    "PLAYER": "Tez Johnson",\n    "POS": "WR",\n    "posRK": "24",\n    "TM": "TB",\n    "OVR GRADE": "80",\n    "truADP": "291.6",\n    "Rook ADP": "61",\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "235",\n    "NCAA": "ORE",\n    "AGE": "23.2",\n    "HT": "5\'10",\n    "WT": "154",\n    "ATHL": "74",\n    "CL": "2",\n    "FL": "1.5",\n    "PRD GRADE": "95.9",\n    "EFF GRADE": "96.3",\n    "RR GRD": "88.8",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "62",\n    "SOS": "88.9",\n    "YDS(t)": "3925",\n    "TD(t)": "29",\n    "1D(t)": "181",\n    "YpG(t)": "63.31",\n    "OPP(t)": "416",\n    "IMP": "210",\n    "IMP/ OPP": "0.5",\n    "DMTR": "0.22",\n    "CAR": "12",\n    "ruYDS": "66",\n    "YPC": "5.5",\n    "ruTD": "1",\n    "ru1D": "3",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "404",\n    "REC": "307",\n    "recYDS": "3859",\n    "recTD": "28",\n    "rec1D": "178",\n    "YPRR": "2.85",\n    "YPR": "12.6",\n    "YAC/R": "7.92",\n    "Tier": "8"\n  },\n  {\n    "40": "4.74",\n    "RK": "57",\n    "PLAYER": "Mitchell Evans",\n    "POS": "TE",\n    "posRK": "9",\n    "TM": "CAR",\n    "OVR GRADE": "70",\n    "truADP": "341.6",\n    "Rook ADP": "73",\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "163",\n    "NCAA": "ND",\n    "AGE": "22.3",\n    "HT": "6\'5",\n    "WT": "258",\n    "ATHL": "77",\n    "CL": "2",\n    "FL": "2",\n    "PRD GRADE": "59.7",\n    "EFF GRADE": "59.5",\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "42",\n    "SOS": "90.1",\n    "YDS(t)": "913",\n    "TD(t)": "6",\n    "1D(t)": "56",\n    "YpG(t)": "21.74",\n    "OPP(t)": "117",\n    "IMP": "62",\n    "IMP/ OPP": "0.53",\n    "DMTR": "0.076",\n    "CAR": "9",\n    "ruYDS": "13",\n    "YPC": "1.44",\n    "ruTD": "1",\n    "ru1D": "7",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "108",\n    "REC": "77",\n    "recYDS": "900",\n    "recTD": "5",\n    "rec1D": "49",\n    "YPRR": "1.45",\n    "YPR": "11.7",\n    "YAC/R": "4.95",\n    "Tier": "8"\n  },\n  {\n    "40": "4.61",\n    "RK": "58",\n    "PLAYER": "Ricky White",\n    "POS": "WR",\n    "posRK": "25",\n    "TM": "SEA",\n    "OVR GRADE": "79",\n    "truADP": "368.5",\n    "Rook ADP": "76",\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "238",\n    "NCAA": "UNLV",\n    "AGE": "23.4",\n    "HT": "6\'1",\n    "WT": "184",\n    "ATHL": "69",\n    "CL": "1.5",\n    "FL": "2",\n    "PRD GRADE": "95.9",\n    "EFF GRADE": "88.6",\n    "RR GRD": "82.7",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "43",\n    "SOS": "NA",\n    "YDS(t)": "3369",\n    "TD(t)": "24",\n    "1D(t)": "137",\n    "YpG(t)": "78.35",\n    "OPP(t)": "363",\n    "IMP": "161",\n    "IMP/ OPP": "0.44",\n    "DMTR": "0.377",\n    "CAR": "3",\n    "ruYDS": "5",\n    "YPC": "1.67",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "360",\n    "REC": "227",\n    "recYDS": "3364",\n    "recTD": "24",\n    "rec1D": "137",\n    "YPRR": "2.69",\n    "YPR": "14.8",\n    "YAC/R": "6.03",\n    "Tier": "8"\n  },\n  {\n    "40": "4.81",\n    "RK": "59",\n    "PLAYER": "Moliki Matavao",\n    "POS": "TE",\n    "posRK": "10",\n    "TM": "NO",\n    "OVR GRADE": "63",\n    "truADP": "373.7",\n    "Rook ADP": "77",\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "248",\n    "NCAA": "UCLA",\n    "AGE": "22.3",\n    "HT": "6\'6",\n    "WT": "260",\n    "ATHL": "71",\n    "CL": "1.5",\n    "FL": "1.5",\n    "PRD GRADE": "58.1",\n    "EFF GRADE": "58.7",\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "50",\n    "SOS": "NA",\n    "YDS(t)": "1001",\n    "TD(t)": "7",\n    "1D(t)": "46",\n    "YpG(t)": "20.02",\n    "OPP(t)": "111",\n    "IMP": "53",\n    "IMP/ OPP": "0.48",\n    "DMTR": "0.076",\n    "CAR": "1",\n    "ruYDS": "3",\n    "YPC": "3",\n    "ruTD": "1",\n    "ru1D": "1",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "110",\n    "REC": "74",\n    "recYDS": "998",\n    "recTD": "6",\n    "rec1D": "45",\n    "YPRR": "1.5",\n    "YPR": "13.5",\n    "YAC/R": "6.69",\n    "Tier": "8"\n  },\n  {\n    "40": "4.7",\n    "RK": "60",\n    "PLAYER": "Thomas Fidone III",\n    "POS": "TE",\n    "posRK": "11",\n    "TM": "NYG",\n    "OVR GRADE": "70",\n    "truADP": "652.1",\n    "Rook ADP": "124",\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "219",\n    "NCAA": "NEB",\n    "AGE": "22.8",\n    "HT": "6\'5",\n    "WT": "243",\n    "ATHL": "81",\n    "CL": "2.5",\n    "FL": "2",\n    "PRD GRADE": "55",\n    "EFF GRADE": "55",\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "25",\n    "SOS": "86.6",\n    "YDS(t)": "633",\n    "TD(t)": "4",\n    "1D(t)": "26",\n    "YpG(t)": "25.32",\n    "OPP(t)": "88",\n    "IMP": "30",\n    "IMP/ OPP": "0.34",\n    "DMTR": "0.14",\n    "CAR": "0",\n    "ruYDS": "0",\n    "YPC": "NA",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "88",\n    "REC": "61",\n    "recYDS": "633",\n    "recTD": "4",\n    "rec1D": "26",\n    "YPRR": "1.32",\n    "YPR": "10.4",\n    "YAC/R": "3.95",\n    "Tier": "8"\n  },\n  {\n    "40": "4.46",\n    "RK": "61",\n    "PLAYER": "Kaden Prather",\n    "POS": "WR",\n    "posRK": "26",\n    "TM": "BUF",\n    "OVR GRADE": "73",\n    "truADP": "667.1",\n    "Rook ADP": "136",\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "240",\n    "NCAA": "MD",\n    "AGE": "22.8",\n    "HT": "6\'4",\n    "WT": "204",\n    "ATHL": "76",\n    "CL": "1.5",\n    "FL": "1",\n    "PRD GRADE": "80",\n    "EFF GRADE": "66.3",\n    "RR GRD": "69.5",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "45",\n    "SOS": "90.6",\n    "YDS(t)": "1997",\n    "TD(t)": "12",\n    "1D(t)": "103",\n    "YpG(t)": "44.38",\n    "OPP(t)": "258",\n    "IMP": "115",\n    "IMP/ OPP": "0.45",\n    "DMTR": "0.161",\n    "CAR": "2",\n    "ruYDS": "35",\n    "YPC": "17.5",\n    "ruTD": "0",\n    "ru1D": "1",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "256",\n    "REC": "162",\n    "recYDS": "1962",\n    "recTD": "12",\n    "rec1D": "102",\n    "YPRR": "1.52",\n    "YPR": "12.1",\n    "YAC/R": "4.51",\n    "Tier": "8"\n  },\n  {\n    "40": "4.46",\n    "RK": "62",\n    "PLAYER": "LaJohntay Wester",\n    "POS": "WR",\n    "posRK": "27",\n    "TM": "BAL",\n    "OVR GRADE": "74",\n    "truADP": "686.9",\n    "Rook ADP": "160",\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>⑥</span>",\n    "PK#": "203",\n    "NCAA": "COLO",\n    "AGE": "23.3",\n    "HT": "5\'10",\n    "WT": "163",\n    "ATHL": "72",\n    "CL": "1.5",\n    "FL": "1",\n    "PRD GRADE": "98",\n    "EFF GRADE": "86.8",\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "57",\n    "SOS": "NA",\n    "YDS(t)": "3810",\n    "TD(t)": "33",\n    "1D(t)": "184",\n    "YpG(t)": "66.84",\n    "OPP(t)": "498",\n    "IMP": "217",\n    "IMP/ OPP": "0.44",\n    "DMTR": "0.278",\n    "CAR": "37",\n    "ruYDS": "215",\n    "YPC": "5.81",\n    "ruTD": "2",\n    "ru1D": "11",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "461",\n    "REC": "324",\n    "recYDS": "3595",\n    "recTD": "31",\n    "rec1D": "173",\n    "YPRR": "2.03",\n    "YPR": "11.1",\n    "YAC/R": "5.64",\n    "Tier": "8"\n  },\n  {\n    "40": "NA",\n    "RK": "63",\n    "PLAYER": "Luke Lachey",\n    "POS": "TE",\n    "posRK": "12",\n    "TM": "HOU",\n    "OVR GRADE": "69",\n    "truADP": "690.0",\n    "Rook ADP": "167",\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "255",\n    "NCAA": "IOWA",\n    "AGE": "24",\n    "HT": "6\'6",\n    "WT": "251",\n    "ATHL": "64",\n    "CL": "2",\n    "FL": "3.5",\n    "PRD GRADE": "57.2",\n    "EFF GRADE": "57.1",\n    "RR GRD": "69.7",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": "41",\n    "SOS": "91.1",\n    "YDS(t)": "877",\n    "TD(t)": "4",\n    "1D(t)": "48",\n    "YpG(t)": "21.39",\n    "OPP(t)": "111",\n    "IMP": "52",\n    "IMP/ OPP": "0.47",\n    "DMTR": "0.142",\n    "CAR": "0",\n    "ruYDS": "0",\n    "YPC": "NA",\n    "ruTD": "0",\n    "ru1D": "0",\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": "111",\n    "REC": "74",\n    "recYDS": "877",\n    "recTD": "4",\n    "rec1D": "48",\n    "YPRR": "1.37",\n    "YPR": "11.9",\n    "YAC/R": "4.72",\n    "Tier": "8"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicColumnProperties={{ formatByIndex: "auto", labelByIndex: "f" }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      headerTextWrap={true}
      linkedFilterId=""
      primaryKeyColumnId="3220b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      style={{
        headerFontFamily: "Michroma",
        fontWeight: "200",
        rowSeparator: "rgba(130, 138, 179, 0.04)",
        border: "rgba(130, 138, 179, 0.2)",
        hoverRowBackground: "rgba(87, 0, 255, 0.4)",
        alternateRowBackground: "rgba(26, 26, 50, 1)",
        background: "rgba(23, 23, 44, 1)",
        cellText: "rgba(255, 255, 255, 1)",
        fontSize: "12px",
        fontFamily: "Product Sans",
        headerFontWeight: "400",
        headerBackground: "#141a32",
        headerFontSize: "10px",
      }}
    >
      <Column
        id="d6166"
        alignment="center"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="tag"
        formatOptions={{ automaticColors: false, color: "#acafc517" }}
        groupAggregationMode="sum"
        key="RK"
        label="RK"
        placeholder="Select option"
        position="left"
        size={45.796875}
        summaryAggregationMode="none"
        textColor="{{  currentSourceRow.RK < 3 ? '#00ffc4' :
  currentSourceRow.RK < 7 ? '#85fff3' :
  currentSourceRow.RK < 12 ? '#7dd1ff' :
  currentSourceRow.RK < 19 ? '#48a6ff' :
  currentSourceRow.RK < 25 ? '#957cff' :
  currentSourceRow.RK < 31 ? '#a642ff' :
  currentSourceRow.RK < 37 ? '#cf60ff' :
  currentSourceRow.RK < 49 ? '#ff6fe1' :
  currentSourceRow.RK < 61 ? '#ff2eb2' :
  currentSourceRow.RK < 70 ? '#ff0080' :  '' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRank\n</div>'
        }
      />
      <Column
        id="3220b"
        alignment="left"
        editable={false}
        format="string"
        groupAggregationMode="none"
        key="PLAYER"
        label="PLAYER"
        placeholder="Enter value"
        position="left"
        size={137.859375}
        summaryAggregationMode="none"
        textColor="{{ currentSourceRow.POS === 'RB' ? '#EaffEa'
  : currentSourceRow.POS === 'TE' ? '#ffefff'
  : currentSourceRow.POS === 'WR' ? '#e1ffff'
  : '' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPlayer Name\n</div>'
        }
      />
      <Column
        id="e0c89"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="tag"
        formatOptions={{ automaticColors: false, color: "#4b527cc0", icon: "" }}
        groupAggregationMode="sum"
        key="posRK"
        label="POS • RK"
        placeholder="Select option"
        position="left"
        size={81.859375}
        summaryAggregationMode="none"
        textColor="{{ currentSourceRow.POS == 'RB' ? '#00Efc3' :
  currentSourceRow.POS == 'WR' ? '#00D0fa' :
  currentSourceRow.POS == 'TE' ? '#c05cff' :  '' }}"
        valueOverride="{{ currentSourceRow.POS }} • {{ item }}"
      />
      <Column
        id="f83ae"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        hidden="true"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              ordered: [
                { value: "QB" },
                { color: "#ff2a6d" },
                { textColor: "rgba(18, 18, 18, 1)" },
                { icon: "" },
                { label: "" },
              ],
            },
            {
              value: "WR",
              color: "rgba(88, 167, 255, 0)",
              textColor: "#58a7ff",
              icon: "bold/computer-connection-usb-port",
            },
            {
              value: "RB",
              icon: "bold/travel-transportation-bus",
              color: "rgba(34, 228, 176, 0)",
              textColor: "#22e4b0",
            },
            {
              value: "TE",
              textColor: "#8300ff",
              color: "rgba(0, 0, 0, 0)",
              icon: "bold/interface-security-shield-4",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="left"
        size={66.859375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPosition\n</div>'
        }
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="a5b57"
        alignment="center"
        backgroundColor="{{
    currentSourceRow.Tier == 8 ? '#f3f00f' :
  currentSourceRow.Tier == 7 ? '#f300f0' :
  currentSourceRow.Tier == 6 ? '#03f0ff' :
  currentSourceRow.Tier == 5 ? '#33007f' :
  currentSourceRow.Tier == 4 ? '#35407f' :
  currentSourceRow.Tier == 3 ? '#33007f' :
  currentSourceRow.Tier == 2 ? '#33007f' :
  currentSourceRow.Tier ==  1 ? '#7300ff10; :
  '#33007f'
}}"
        editableOptions={{ showStepper: true, allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="sum"
        headerTextColor="rgba(23, 92, 97, 1)"
        key="Tier"
        label="TIER"
        optionList={{
          manualData: [
            {
              value: '"1"',
              label: "| Tier 1",
              color: "rgba(0, 0, 0, 0)",
              textColor: "#dfcd87",
              icon: "bold/interface-award-crown",
              caption: "",
            },
            {
              value: '"2"',
              label: "| Tier 2",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(196, 198, 218, 1)",
              icon: "bold/shopping-jewelry-diamond-2",
            },
            {
              value: '"3"',
              label: "| Tier 3",
              icon: "bold/interface-favorite-star",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(125, 170, 222, 1)",
            },
            {
              value: '"4"',
              label: "| Tier 4",
              icon: "bold/money-graph-arrow-increase",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(127, 111, 242, 1)",
            },
            {
              value: '"5"',
              label: "| Tier 5",
              icon: "bold/interface-hierarchy-9",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(186, 106, 255, 1)",
            },
            {
              value: '"6"',
              icon: "bold/interface-weather-rain-1",
              label: "| Tier 6",
              color: "rgba(0, 0, 0, 0)",
              textColor: "#ff89f6",
              fallbackText: "",
            },
            {
              value: '"7"',
              icon: "bold/money-graph-bar-decrease",
              label: "| Tier 7",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(255, 86, 238, 1)",
            },
            {
              value: '"8"',
              label: "| Tier 8",
              icon: "bold/interface-delete-bin-2",
              caption: "",
              textColor: "rgba(255, 62, 151, 1)",
              color: "rgba(72, 72, 72, 0)",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="left"
        size={91.84375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTier\n</div>'
        }
      />
      <Column
        id="a80e8"
        alignment="center"
        backgroundColor="rgba(75, 0, 255, 0.07)"
        cellTooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 12px #000000 ;\n">\n  Overall Grade<br> ⌁ <b>{{ (() => {\n    const map = {\n      "Ashton Jeanty": 95.7,\n      "Travis Hunter": 93.5,\n      "Omarion Hampton": 89.7,\n      "Tetairoa McMillan": 90.5,\n      "TreVeyon Henderson": 88.1,\n      "Quinshon Judkins": 87.5,\n      "Emeka Egbuka": 89.1,\n      "Tyler Warren": 88.9,\n      "Colston Loveland": 90.1,\n      "R.J. Harvey": 86.2,\n      "Kaleb Johnson": 85.6,\n      "Matthew Golden": 87.1,\n      "Luther Burden": 86.9,\n      "Jayden Higgins": 86.3,\n      "Tre Harris": 86.3,\n      "Jack Bech": 85.7,\n      "Cameron Skattebo": 87.3,\n      "Kyle Williams": 86.9,\n      "Mason Taylor": 74.8,\n      "Bhayshul Tuten": 79.8,\n      "Jaylin Noel": 85.6,\n      "Terrance Ferguson": 77.3,\n      "Jaydon Blue": 74.0,\n      "Elijah Arroyo": 74.1,\n      "Pat Bryant": 79.6,\n      "Dylan Sampson": 81.6,\n      "Harold Fannin Jr.": 86.5,\n      "Jalen Royals": 84.8,\n      "Devin Neal": 81.4,\n      "Trevor Etienne": 79.8,\n      "Elic Ayomanor": 78.0,\n      "Jarquez Hunter": 76.1,\n      "DJ Giddens": 80.7,\n      "Isaac TeSlaa": 74.9,\n      "Jordan James": 76.1,\n      "Ollie Gordon": 73.7,\n      "Jo\'quavious Marks": 69.9,\n      "Dont\'e Thornton": 74.5,\n      "Tory Horton": 84.1,\n      "Brashard Smith": 72.8,\n      "Oronde Gadsden II": 78.7,\n      "Savion Williams": 78.3,\n      "Tahj Brooks": 81.4,\n      "Kyle Monangai": 74.2,\n      "Tai Felton": 81.7,\n      "Chimere Dike": 76.3,\n      "Gunnar Helm": 71.3,\n      "Jaylin Lane": 77.2,\n      "Damien Martinez": 80.9,\n      "Jimmy Horn Jr.": 72.4,\n      "Jacory Croskey-Merritt": 72.1,\n      "Arian Smith": 71.2,\n      "Keandre Lambert-Smith": 79.7,\n      "Tez Johnson": 79.9,\n      "Phil Mafah": 68.0,\n      "LeQuint Allen": 66.7,\n      "Mitchell Evans": 70.5,\n      "Thomas Fidone III": 70.4,\n      "LaJohntay Wester": 74.2,\n      "Ricky White": 79.2,\n      "Moliki Matavao": 62.6,\n      "Kaden Prather": 72.9,\n      "Luke Lachey": 69.2\n    };\n    const v = map[currentSourceRow.PLAYER];\n    return v ?? item;    // Fallback to the cell value if name mismatch\n  })() }}</b> ⌁ \n</div>\n'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "60",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "79",
        }}
        groupAggregationMode="average"
        key="OVR GRADE"
        label="OVR GRD"
        optionList={{
          iconByIndex: "",
          mode: "manual",
          textColorByIndex: "",
          labelByIndex: "",
          valueByIndex: "",
          fallbackTextByIndex: "",
          hiddenByIndex: "",
          captionByIndex: "",
          colorByIndex: "",
          mappedData: "[]",
        }}
        placeholder="Enter value"
        position="center"
        size={102.34375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item >89}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(231, 255, 248, 0.03)",
              tooltip: "",
            },
            {
              showWhen: "{{item >80}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(0, 109, 242, 0.03)",
            },
            {
              showWhen: "{{item >75}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(124, 83, 204, 0.03)",
            },
            {
              showWhen: "true",
              label: "{{ item }}",
              icon: "",
              color: "rgba(68, 76, 87, 0.03)",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nOverall Grade\n</div>'
        }
      />
      <Column
        id="05ab0"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="tag"
        formatOptions={{ automaticColors: false, color: "#acafc51a" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(20, 26, 50)"
        headerTextColor="#ffffff"
        key="truADP"
        label="ADP"
        optionList={{
          iconByIndex: "",
          mode: "manual",
          textColorByIndex: "",
          labelByIndex: "",
          valueByIndex: "",
          fallbackTextByIndex: "",
          hiddenByIndex: "",
          captionByIndex: "",
          colorByIndex: "",
          mappedData: "",
        }}
        placeholder="Select option"
        position="center"
        size={70.1875}
        summaryAggregationMode="none"
        textColor="{{  currentSourceRow.truADP < 38 ? '#00ffc4' :
  currentSourceRow.truADP < 52 ? '#85fff3' :
  currentSourceRow.truADP < 69 ? '#7dd1ff' :
  currentSourceRow.truADP < 120 ? '#48a6ff' :
  currentSourceRow.truADP < 160 ? '#957cff' :
  currentSourceRow.truADP < 177 ? '#a642ff' :
  currentSourceRow.truADP < 200 ? '#cf60ff' :
  currentSourceRow.truADP < 265 ? '#ff6fe1' :
  currentSourceRow.truADP < 300 ? '#ff2eb2' :
  currentSourceRow.truADP < 800 ? '#ff0080' :  '' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nAverage Draft Position\n</div>'
        }
        valueOverride="{{item}} "
      />
      <Column
        id="328dc"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="Rook ADP"
        label="ROOKIE ADP  "
        placeholder="Enter value"
        position="center"
        size={75.21875}
        summaryAggregationMode="none"
        textColor="{{  currentSourceRow.truADP < 38 ? '#00ffc4' :
  currentSourceRow.truADP < 52 ? '#85fff3' :
  currentSourceRow.truADP < 69 ? '#7dd1ff' :
  currentSourceRow.truADP < 120 ? '#48a6ff' :
  currentSourceRow.truADP < 160 ? '#957cff' :
  currentSourceRow.truADP < 177 ? '#a642ff' :
  currentSourceRow.truADP < 200 ? '#cf60ff' :
  currentSourceRow.truADP < 265 ? '#ff6fe1' :
  currentSourceRow.truADP < 300 ? '#ff2eb2' :
  currentSourceRow.truADP < 800 ? '#ff0080' :  '' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRookie Average Draft Position\n</div>'
        }
      />
      <Column
        id="62082"
        alignment="center"
        backgroundColor="rgba(104, 141, 243, 0.03)"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RD"
        label="RD 📶"
        placeholder="Enter value"
        position="center"
        size={57.9375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "",
              label: "",
              color: "rgba(135, 230, 179, 1)",
              icon: "bold/interface-arrows-up-alternate",
            },
            {
              showWhen: "{{ item < 7 }}",
              label: "",
              color: "#F8DBD8",
              icon: "bold/money-graph-arrow-decrease",
            },
            {
              showWhen: "{{ item > 6 }}",
              label: "",
              color: "rgba(236, 116, 154, 1)",
              icon: "bold/interface-arrows-down-alternate",
            },
            {
              showWhen: "{{ item < 5 }}",
              label: "",
              color: "#D7EAE0",
              icon: "bold/money-graph-arrow-increase",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRound Drafted\n</div>'
        }
      />
      <Column
        id="95105"
        alignment="left"
        backgroundColor="rgba(104, 141, 243, 0.03)"
        cellTooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -10px;\n   font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 12px #000000 ;\n">\nPick Drafted<br> ⌁ <b>{{item}}</b> ⌁ \n</div>\n\n'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="sum"
        key="PK#"
        label="PK"
        placeholder="Enter value"
        position="center"
        size={62.390625}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item <33}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(196, 253, 234, 0.15)",
              tooltip: "",
            },
            {
              showWhen: "{{item < 68}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(186, 255, 255, 0.15)",
            },
            {
              showWhen: "{{item < 90}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(186, 243, 255, 0.15)",
            },
            {
              showWhen: "{{item < 130}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(229, 205, 255, 0.3)",
            },
            {
              showWhen: "{{item >190}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(251, 164, 234, 1)",
            },
            {
              showWhen: "{{item >130}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(232, 177, 250, 0.5)",
              tooltip: "",
            },
            { showWhen: "{{item}}", label: "UD", icon: "" },
          ],
        }}
        summaryAggregationMode="none"
        textColor="{{ theme.danger }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPick Drafted [Overall]\n</div>'
        }
        valueOverride="{{item}}"
      />
      <Column
        id="41f3f"
        alignment="center"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="NCAA"
        label="NCAA"
        placeholder="Enter value"
        position="center"
        size={61.515625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTeam [NCAA]\n</div>'
        }
      />
      <Column
        id="50caa"
        alignment="center"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="none"
        key="TM"
        label="TM"
        optionList={{
          mode: "mapped",
          mappedData:
            '\n\n[\n  { value: "ARI", color: "#97233F", textColor: "#ffffff" },  // red ⟡ yellow :contentReference[oaicite:0]{index=0}\n  { value: "ATL", color: "#Aa1930", textColor: "#000000" },  // red ⟡ black :contentReference[oaicite:1]{index=1}\n  { value: "BAL", color: "#341793", textColor: "#9E7C2C" },  // purple ⟡ gold :contentReference[oaicite:2]{index=2}\n  { value: "BUF", color: "#00338D99", textColor: "#C61C30ef" },  // royal ⟡ red :contentReference[oaicite:3]{index=3}\n  { value: "CAR", color: "#0085CAcc", textColor: "#000000" },  // blue ⟡ black :contentReference[oaicite:4]{index=4}\n  { value: "CHI", color: "#0B162A", textColor: "#f64F00" },  // navy ⟡ orange :contentReference[oaicite:5]{index=5}\n  { value: "CIN", color: "#FB3F14ef", textColor: "#000000" },  // orange ⟡ black :contentReference[oaicite:6]{index=6}\n  { value: "CLE", color: "#DF3C20", textColor: "#101010" },  // orange ⟡ brown :contentReference[oaicite:7]{index=7}\n  { value: "DAL", color: "#003594cd", textColor: "#A5ACAF" },  // navy ⟡ silver :contentReference[oaicite:8]{index=8}\n  { value: "DEN", color: "#FB2F14da", textColor: "#002244" },  // orange ⟡ navy :contentReference[oaicite:9]{index=9}\n  { value: "DET", color: "#0076B6aa", textColor: "#B0B7BC" },  // honolulu ⟡ silver :contentReference[oaicite:10]{index=10}\n  { value: "GB",  color: "#203731", textColor: "#FFB612" },  // green ⟡ gold :contentReference[oaicite:11]{index=11}\n  { value: "HOU", color: "#03202F", textColor: "#D71930ee" },  // deep blue ⟡ red :contentReference[oaicite:12]{index=12}\n  { value: "IND", color: "#002C5F", textColor: "#F2FAFD" },  // royal ⟡ gray :contentReference[oaicite:13]{index=13}\n  { value: "JAX", color: "#006778aa", textColor: "#D7A22A" },  // teal ⟡ gold :contentReference[oaicite:14]{index=14}\n  { value: "KC",  color: "#E31837cc", textColor: "#FFB612" },  // red ⟡ gold :contentReference[oaicite:15]{index=15}\n  { value: "LAC", color: "#0080C6aa", textColor: "#FFC20E" },  // powder ⟡ sunshine :contentReference[oaicite:16]{index=16}\n  { value: "LAR", color: "#003594bb", textColor: "#FFA300ec" },  // royal ⟡ sol :contentReference[oaicite:17]{index=17}\n  { value: "LV",  color: "#000000", textColor: "#A5ACAF" },  // black ⟡ silver :contentReference[oaicite:18]{index=18}\n  { value: "MIA", color: "#008E87aa", textColor: "#FC5C02" },  // aqua ⟡ orange :contentReference[oaicite:19]{index=19}\n  { value: "MIN", color: "#4F2683", textColor: "#FFC62F" },  // purple ⟡ gold :contentReference[oaicite:20]{index=20}\n  { value: "NE",  color: "#041E62", textColor: "#D60F51" },  // blue ⟡ red :contentReference[oaicite:21]{index=21}\n  { value: "NO",  color: "#D3BC8D", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:22]{index=22}\n  { value: "NYG", color: "#0B2265", textColor: "#DFDFDF" },  // blue ⟡ red :contentReference[oaicite:23]{index=23}\n  { value: "NYJ", color: "#125740ac", textColor: "#FFFFFF" },  // green ⟡ white :contentReference[oaicite:24]{index=24}\n  { value: "PHI", color: "#004C54cc", textColor: "#A5ACAF" },  // midnight ⟡ silver :contentReference[oaicite:25]{index=25}\n  { value: "PIT", color: "#FFB612cc", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:26]{index=26}\n  { value: "SEA", color: "#002244", textColor: "#69BE28" },  // navy ⟡ action-green :contentReference[oaicite:27]{index=27}\n  { value: "SF",  color: "#AA0000ac", textColor: "#B3995D" },  // scarlet ⟡ gold :contentReference[oaicite:28]{index=28}\n  { value: "TB",  color: "#D50A0Aec", textColor: "#0A0A08" },  // red ⟡ pewter :contentReference[oaicite:29]{index=29}\n  { value: "TEN", color: "#0C2340", textColor: "#4B92DB" },  // navy ⟡ titan-blue :contentReference[oaicite:30]{index=30}\n  { value: "WAS", color: "#5A1414ac", textColor: "#FFB612ee" },  // burgundy ⟡ gold :contentReference[oaicite:31]{index=31}\n  { value: "UDF", color: "#9E9E9E", textColor: "#FFFFFF" }  // neutral grey\n]',
          valueByIndex: "{{ item.value }}",
          labelByIndex: "{{ item.value }}",
          colorByIndex: "{{ item.color }}",
          textColorByIndex: "{{ item.textColor }}",
        }}
        placeholder="Select option"
        position="center"
        size={58.390625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTeam [NFL]\n</div>'
        }
      />
      <Column
        id="53da5"
        alignment="center"
        editable="false"
        format="multilineString"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
        textColor="rgba(255, 255, 255, 1)"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nAge\n</div>'
        }
      />
      <Column
        id="7a71b"
        alignment="center"
        format="string"
        formatOptions={{ automaticColors: true, notation: "standard" }}
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={46.03125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nHeight\n</div>'
        }
      />
      <Column
        id="f718d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={47.875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nWeight\n</div>'
        }
      />
      <Column
        id="05e56"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="40"
        label="40"
        placeholder="Enter value"
        position="center"
        size={46.515625}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow[\"40\"] == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n40 Yard Dash\n</div>'
        }
      />
      <Column
        id="cf84f"
        alignment="left"
        backgroundColor="rgba(185, 190, 209, 0.03)"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\nAthletic Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(198, 203, 231, 1)"
        key="ATHL"
        label="ATHL GRD"
        placeholder="Enter value"
        position="center"
        size={78.6875}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item > 91.9}}",
              label: "{{ item }}",
              icon: "bold/image-flash-1",
              color: "rgba(120, 210, 171, 1)",
            },
            {
              showWhen: "{{item > 87}}",
              label: "{{ item }}",
              icon: "bold/image-flash-2",
              color: "rgba(190, 254, 234, 0.17)",
            },
            {
              showWhen: "{{ item > 82.9 }}",
              label: "{{ item }}",
              icon: "bold/shopping-business-startup",
              color: "rgba(138, 255, 255, 0.13)",
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{item}}",
              icon: "bold/mail-send-email",
              color: "rgba(185, 223, 255, 0.13)",
            },
            {
              showWhen: "{{item > 76}}",
              label: "{{ item }}",
              icon: "bold/mail-send-email",
            },
            {
              showWhen: "{{item < 76}}",
              label: "{{item}}",
              icon: "bold/phone-signal-low",
              color: "rgba(255, 178, 214, 0.15)",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nAthletic Grade\n</div>'
        }
      />
      <Column
        id="4bffd"
        alignment="center"
        backgroundColor="rgba(63, 1, 255, 0.05)"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.9em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nCEILING ⌁ <b>{{item}}/5</b> \n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="rating"
        formatOptions={{ icon: "", size: "small", icons: "stars" }}
        groupAggregationMode="average"
        key="CL"
        label="CEILING"
        placeholder="Enter value"
        position="center"
        size={98}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProjected Ceiling\n</div>'
        }
      />
      <Column
        id="5b01a"
        alignment="center"
        backgroundColor="rgba(131, 0, 255, 0.05)"
        cellTooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.9em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nFLOOR ⌁ <b>{{item}}/5</b>\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="rating"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          size: "small",
          icons: "stars",
        }}
        groupAggregationMode="sum"
        key="FL"
        label="FLOOR"
        placeholder="Enter value"
        position="center"
        size={101.5}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProjected Floor\n</div>'
        }
      />
      <Column
        id="93ad9"
        alignment="center"
        backgroundColor="rgba(185, 190, 209, 0.03)"
        caption="• {{ item }} •"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProduction Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "55",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "75",
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#141a32"
        headerTextColor="rgba(183, 190, 223, 1)"
        key="PRD GRADE"
        label="PRD GRD"
        placeholder="Enter value"
        position="center"
        size={67.09375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProduction Grade\n</div>'
        }
      />
      <Column
        id="d91e6"
        alignment="center"
        backgroundColor="rgba(185, 190, 209, 0.03)"
        caption="• {{ item }} •"
        cellTooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nEfficiency Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "50",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "75",
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#141a32"
        headerTextColor="#aeb9ea"
        key="EFF GRADE"
        label="EFF GRD"
        placeholder="Enter value"
        position="center"
        size={69.671875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nEfficiency Grade\n</div>'
        }
      />
      <Column
        id="bf9a4"
        alignment="center"
        backgroundColor="rgba(178, 255, 249, 0.03)"
        cellTooltip="{{ item }}"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(178, 255, 249, 1)"
        key="ELU GRADE"
        label="ELU GRD💥"
        placeholder="Enter value"
        position="center"
        size={85.890625}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{ item > 85}}",
              label: "{{ item }}",
              icon: "bold/nature-ecology-comet",
              color: "rgba(190, 254, 234, 0.17)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nElusiveness Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{ item }}",
              icon: "bold/interface-arrows-shuffle",
              color: "rgba(224, 245, 255, 0.2)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nElusiveness Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item < 75}}",
              label: "{{ item }}",
              icon: "bold/interface-weather-humidity-none",
              color: "rgba(255, 178, 214, 0.15)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nElusiveness Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "true",
              label: "{{item}}",
              icon: "bold/interface-block",
              color: "rgba(224, 224, 224, 0.1)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\n <b>N/A</b> ⌁ [RB–ONLY Metric]\n</div>',
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nElusiveness Grade\n</div>'
        }
      />
      <Column
        id="a6c5e"
        alignment="center"
        backgroundColor="rgba(154, 186, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(154, 186, 255, 1)"
        key="RR GRD"
        label="RR GRD  ↰↱"
        placeholder="Enter value"
        position="center"
        size={82}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{ item > 85}} ",
              label: "{{item}}",
              icon: "bold/interface-arrows-bend-up-right-1-alternate",
              color: "rgba(190, 254, 234, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{item}}",
              icon: "bold/interface-arrows-bend-up-right-2-alternate",
              color: "rgba(224, 245, 255, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item < 75}}",
              label: "{{item}}",
              icon: "bold/interface-arrows-up-alternate",
              color: "rgba(255, 178, 214, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{ item == 'NA' }}",
              label: "{{ item }}",
              icon: "bold/interface-block",
              color: "rgba(160, 160, 160, 0.1)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\n <b>N/A</b> ⌁ [WR/TE–ONLY Metric]\n</div>',
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nSeperation / Route Running Grade\n</div>'
        }
      />
      <Column
        id="65b64"
        alignment="left"
        backgroundColor="rgba(182, 184, 193, 0.03)"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b7bedf"
        key="FILM GRADE"
        label="FILM 
GRD"
        placeholder="Enter value"
        position="center"
        size={77.609375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item > 85}}",
              label: "{{ item }}",
              icon: "bold/entertainment-camera-video",
              color: "rgba(190, 254, 234, 0.17)",
            },
            {
              showWhen: "{{  item > 78}}",
              label: "{{ item }}",
              icon: "bold/computer-connection-video-camera",
              color: "rgba(224, 245, 255, 0.2)",
            },
            {
              showWhen: "{{item < 79}}",
              label: "{{ item }}",
              icon: "bold/entertainment-recording-tape-1",
              color: "rgba(255, 178, 214, 0.15)",
            },
            {
              showWhen: "true",
              label: "{{item}}",
              icon: "bold/interface-page-controller-loading-half",
              color: "rgba(227, 223, 223, 0.1)",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nFilm Grade\n</div>'
        }
      />
      <Column
        id="6beae"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="G"
        label="G"
        placeholder="Enter value"
        position="center"
        size={37.6875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nGames Played\n</div>'
        }
      />
      <Column
        id="571eb"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="SOS"
        label="SOS"
        placeholder="Enter value"
        position="center"
        size={53}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow.SOS == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nNCAA Strength of Schedule [Career Avg.]\n</div>'
        }
      />
      <Column
        id="e9438"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(181, 161, 254, 1)"
        key="YDS(t)"
        label="YDS ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={64.734375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [Total]\n</div>'
        }
      />
      <Column
        id="37293"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="TD(t)"
        label="TD
 ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={50.25}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [Total]\n</div>'
        }
      />
      <Column
        id="7ab93"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="1D(t)"
        label="1D
⌈t⌋"
        placeholder="Enter value"
        position="center"
        size={55}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nFirst Downs [Total]\n</div>'
        }
      />
      <Column
        id="25637"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="YpG(t)"
        label="YpG 
⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={58.453125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards per Game [Total]\n</div>'
        }
      />
      <Column
        id="00b31"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="OPP(t)"
        label="OPP"
        placeholder="Enter value"
        position="center"
        size={58.15625}
        summaryAggregationMode="none"
        textColor="#ffffff"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nOpportunities [CAR+TGT]\n</div>'
        }
      />
      <Column
        id="45011"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="IMP"
        label="IMP"
        placeholder="Enter value"
        position="center"
        size={57.484375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nImpact Plays [TD+1D]\n</div>'
        }
      />
      <Column
        id="3ce33"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "0",
          padDecimal: false,
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="IMP/ OPP"
        label="IMP/OPP"
        placeholder="Enter value"
        position="center"
        size={81.84375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nImpact Plays per Opportunity\n</div>'
        }
      />
      <Column
        id="4c58c"
        alignment="center"
        backgroundColor="rgba(110, 137, 245, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "3",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        key="DMTR"
        label="DMTR"
        placeholder="Enter value"
        position="center"
        size={66.890625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nDominator Rating\n</div>'
        }
      />
      <Column
        id="89a9d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="CAR"
        label="CAR"
        placeholder="Enter value"
        position="center"
        size={52.640625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nCarries\n</div>'
        }
      />
      <Column
        id="1ed57"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="ruYDS"
        label="YDS ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={58.3125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nYards [Rushing]\n</div>'
        }
      />
      <Column
        id="c7beb"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="YPC"
        label="YPC"
        placeholder="Enter value"
        position="center"
        size={51.71875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nYards per Carry\n</div>'
        }
      />
      <Column
        id="bb829"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="ruTD"
        label="TD  ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={59.953125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTouchdowns [Rushing]\n</div>'
        }
      />
      <Column
        id="3dd7a"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="ru1D"
        label="1D ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={53.515625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nFirst Downs [Rushing]\n</div>'
        }
      />
      <Column
        id="8a9ca"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "3",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="MTF/ A"
        label="MTF/A"
        placeholder="Enter value"
        position="center"
        size={65.984375}
        summaryAggregationMode="none"
        textColor={
          "{{ currentSourceRow[\"MTF/ A\"] == \"NA\" ? '#8F8F8F':'' }}"
        }
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nMissed Tackles Forced per Attempt\n</div>'
        }
      />
      <Column
        id="bc182"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="YACO/A"
        label="YCO/A"
        placeholder="Enter value"
        position="center"
        size={73.953125}
        summaryAggregationMode="none"
        textColor={
          "{{ currentSourceRow[\"YACO/A\"] == \"NA\" ? '#8F8F8F':'' }}"
        }
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nYards after Contact\nper Attempt\n</div>'
        }
      />
      <Column
        id="76cd8"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "3",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="rgba(198, 255, 232, 1)"
        key="ELU"
        label="ELU"
        placeholder="Enter value"
        position="center"
        size={51.78125}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow.ELU == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nElusiveness Rating\n</div>'
        }
      />
      <Column
        id="3620d"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="TGT"
        label="TGT"
        placeholder="Enter value"
        position="center"
        size={56}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTargets\n</div>'
        }
      />
      <Column
        id="38694"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="REC"
        label="REC"
        placeholder="Enter value"
        position="center"
        size={59}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nReceptions\n</div>'
        }
      />
      <Column
        id="db7c4"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="recYDS"
        label="YDS
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={51.140625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [Receiving]\n</div>'
        }
      />
      <Column
        id="e7cf5"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="rgba(153, 205, 255, 1)"
        key="recTD"
        label="TD
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={50.9375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [Receiving]\n</div>'
        }
      />
      <Column
        id="23e31"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="rec1D"
        label="1D
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={67}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nFirst Downs [Receiving]\n</div>'
        }
      />
      <Column
        id="c40d1"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YPRR"
        label="YPRR"
        placeholder="Enter value"
        position="center"
        size={68}
        summaryAggregationMode="none"
        textColor="{{
(() => {
 const v = parseFloat(String(item).replace(/[^0-9.-]/g, ''));
 if (!isFinite(v)) return null;
 const rules = [
  [2.7, '#00ffc4'],
  [2.4, '#85fff3'],
  [2.3, '#7dd1ff'],
  [2.1, '#957cff'],
  [1.9, '#a642ff'],
  [1.7, '#cf60ff'],
  [1.5, '#ff6fe1'],
 ];
 for (const [t, c] of rules) if (v >= t) return c;
 return '#ff2eb2';
})()
}}"
        tooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 15px #000000 ;\n">\nYards per Route Run\n</div>'
        }
      />
      <Column
        id="fe787"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YPR"
        label="YPR"
        placeholder="Enter value"
        position="center"
        size={69}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards per Reception\n</div>'
        }
      />
      <Column
        id="fd480"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YAC/R"
        label="YAC/REC"
        placeholder="Enter value"
        position="center"
        size={83}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards after Catch per Reception\n</div>'
        }
      />
      <Event
        event="selectRow"
        method=""
        params={{}}
        pluginId=""
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Table>
  </View>
  <View
    id="9fb35"
    icon="bold/interface-user-multiple"
    iconPosition="left"
    viewKey="ALL"
  >
    <Table
      id="table87"
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "RK": 1,\n    "PLAYER": "Ashton Jeanty",\n    "POS": "RB",\n    "TM": "LV",\n    "OVR GRADE": 96,\n    "ADP [pos]": 1,\n    "Rook ADP": 1,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "6",\n    "NCAA": "BOIS",\n    "AGE": 21.6,\n    "HT": "5\'8\\"",\n    "WT": 211,\n    "40": "NA",\n    "ATHL": 89,\n    "CL": 5,\n    "FL": 4.5,\n    "PRD GRADE": 95.1,\n    "EFF GRADE": 94.3,\n    "RR GRD": "NA",\n    "ELU GRADE": 98.1,\n    "FILM GRADE": 98,\n    "G": 40,\n    "SOS": "75",\n    "YDS(t)": 5637,\n    "TD(t)": 56,\n    "1D(t)": 97,\n    "YpG(t)": 140.9,\n    "OPP(t)": 845,\n    "IMP": 324,\n    "IMP/ OPP": 0.38,\n    "DMTR": "0.338",\n    "CAR": 748,\n    "ruYDS": 4760,\n    "YPC": 6.4,\n    "ruTD": 50,\n    "ru1D": 232,\n    "MTF/ A": "0.378",\n    "YACO/A": "4.76",\n    "ELU": "0.735",\n    "TGT": 97,\n    "REC": 82,\n    "recYDS": 877,\n    "recTD": 6,\n    "rec1D": 36,\n    "YPRR": 1.59,\n    "YPR": 11,\n    "YAC/R": "NA",\n    "Tier": 1,\n  },\n  {\n    "RK": 2,\n    "PLAYER": "Travis Hunter",\n    "POS": "WR",\n    "TM": "JAX",\n    "OVR GRADE": 94,\n    "ADP [pos]": 1,\n    "Rook ADP": 3,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "2",\n    "NCAA": "COLO",\n    "AGE": 22.2,\n    "HT": "6\'0\\"",\n    "WT": 188,\n    "40": "NA",\n    "ATHL": 96,\n    "CL": 5,\n    "FL": 3.5,\n    "PRD GRADE": 88.7,\n    "EFF GRADE": 96.3,\n    "RR GRD": 93.4,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 93,\n    "G": 29,\n    "SOS": "82.6",\n    "YDS(t)": 2161,\n    "TD(t)": 25,\n    "1D(t)": 97,\n    "YpG(t)": 74.52,\n    "OPP(t)": 220,\n    "IMP": 122,\n    "IMP/ OPP": 0.55,\n    "DMTR": "0.269",\n    "CAR": 3,\n    "ruYDS": -5,\n    "YPC": -1.67,\n    "ruTD": 1,\n    "ru1D": 1,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 217,\n    "REC": 170,\n    "recYDS": 2166,\n    "recTD": 24,\n    "rec1D": 96,\n    "YPRR": 2.42,\n    "YPR": 12.7,\n    "YAC/R": 4.38,\n    "Tier": 1\n  },\n  {\n    "RK": 3,\n    "PLAYER": "Omarion Hampton",\n    "POS": "RB",\n    "TM": "LAC",\n    "OVR GRADE": 90,\n    "ADP [pos]": 2,\n    "Rook ADP": 2,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "22",\n    "NCAA": "UNC",\n    "AGE": 22.3,\n    "HT": "5\'12\\"",\n    "WT": 221,\n    "40": 4.46,\n    "ATHL": 89,\n    "CL": 4.5,\n    "FL": 4,\n    "PRD GRADE": 86.2,\n    "EFF GRADE": 82.8,\n    "RR GRD": "NA",\n    "ELU GRADE": 86.4,\n    "FILM GRADE": 86,\n    "G": 38,\n    "SOS": "80",\n    "YDS(t)": 4194,\n    "TD(t)": 40,\n    "1D(t)": 75,\n    "YpG(t)": 110.4,\n    "OPP(t)": 704,\n    "IMP": 248,\n    "IMP/ OPP": 0.35,\n    "DMTR": "0.249",\n    "CAR": 624,\n    "ruYDS": 3563,\n    "YPC": 5.7,\n    "ruTD": 37,\n    "ru1D": 183,\n    "MTF/ A": "0.247",\n    "YACO/A": "4.01",\n    "ELU": "0.548",\n    "TGT": 80,\n    "REC": 72,\n    "recYDS": 631,\n    "recTD": 3,\n    "rec1D": 25,\n    "YPRR": 1.06,\n    "YPR": 9,\n    "YAC/R": "NA",\n    "Tier": 2\n  },\n  {\n    "RK": 4,\n    "PLAYER": "Tetairoa McMillan",\n    "POS": "WR",\n    "TM": "CAR",\n    "OVR GRADE": 90,\n    "ADP [pos]": 2,\n    "Rook ADP": 4,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "8",\n    "NCAA": "ARIZ",\n    "AGE": 22.3,\n    "HT": "6\'4\\"",\n    "WT": 219,\n    "40": "NA",\n    "ATHL": 87,\n    "CL": 4.5,\n    "FL": 4,\n    "PRD GRADE": 97.7,\n    "EFF GRADE": 89.8,\n    "RR GRD": 89.1,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 88,\n    "G": 37,\n    "SOS": "81.4",\n    "YDS(t)": 3417,\n    "TD(t)": 26,\n    "1D(t)": 152,\n    "YpG(t)": 92.35,\n    "OPP(t)": 342,\n    "IMP": 178,\n    "IMP/ OPP": 0.52,\n    "DMTR": "0.32",\n    "CAR": 1,\n    "ruYDS": 3,\n    "YPC": 3,\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 341,\n    "REC": 213,\n    "recYDS": 3414,\n    "recTD": 26,\n    "rec1D": 152,\n    "YPRR": 2.37,\n    "YPR": 16,\n    "YAC/R": 5.45,\n    "Tier": 2\n  },\n  {\n    "RK": 5,\n    "PLAYER": "TreVeyon Henderson",\n    "POS": "RB",\n    "TM": "NE",\n    "OVR GRADE": 88,\n    "ADP [pos]": 3,\n    "Rook ADP": 5,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "38",\n    "NCAA": "OSU",\n    "AGE": 22.7,\n    "HT": "5\'10\\"",\n    "WT": 202,\n    "40": 4.43,\n    "ATHL": 94,\n    "CL": 4.5,\n    "FL": 3.5,\n    "PRD GRADE": 89.6,\n    "EFF GRADE": 88.3,\n    "RR GRD": "NA",\n    "ELU GRADE": 76.2,\n    "FILM GRADE": 84,\n    "G": 47,\n    "SOS": "93.5",\n    "YDS(t)": 4609,\n    "TD(t)": 48,\n    "1D(t)": 43,\n    "YpG(t)": 98.1,\n    "OPP(t)": 678,\n    "IMP": 248,\n    "IMP/ OPP": 0.37,\n    "DMTR": "0.211",\n    "CAR": 590,\n    "ruYDS": 3759,\n    "YPC": 6.4,\n    "ruTD": 42,\n    "ru1D": 168,\n    "MTF/ A": "0.220",\n    "YACO/A": "3.89",\n    "ELU": "0.512",\n    "TGT": 88,\n    "REC": 76,\n    "recYDS": 850,\n    "recTD": 6,\n    "rec1D": 32,\n    "YPRR": 1.14,\n    "YPR": 11,\n    "YAC/R": "NA",\n    "Tier": 2\n  },\n  {\n    "RK": 6,\n    "PLAYER": "Quinshon Judkins",\n    "POS": "RB",\n    "TM": "CLE",\n    "OVR GRADE": 88,\n    "ADP [pos]": 4,\n    "Rook ADP": 6,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "36",\n    "NCAA": "OSU",\n    "AGE": 21.7,\n    "HT": "5\'12\\"",\n    "WT": 221,\n    "40": 4.48,\n    "ATHL": 95,\n    "CL": 4,\n    "FL": 3,\n    "PRD GRADE": 89.3,\n    "EFF GRADE": 87.3,\n    "RR GRD": "NA",\n    "ELU GRADE": 76.1,\n    "FILM GRADE": 82,\n    "G": 42,\n    "SOS": "93",\n    "YDS(t)": 4228,\n    "TD(t)": 50,\n    "1D(t)": 107,\n    "YpG(t)": 100.7,\n    "OPP(t)": 808,\n    "IMP": 294,\n    "IMP/ OPP": 0.36,\n    "DMTR": "0.245",\n    "CAR": 739,\n    "ruYDS": 3786,\n    "YPC": 5.1,\n    "ruTD": 45,\n    "ru1D": 222,\n    "MTF/ A": "0.267",\n    "YACO/A": "3.23",\n    "ELU": "0.509",\n    "TGT": 69,\n    "REC": 59,\n    "recYDS": 442,\n    "recTD": 5,\n    "rec1D": 22,\n    "YPRR": 0.76,\n    "YPR": 8,\n    "YAC/R": "NA",\n    "Tier": 2\n  },\n  {\n    "RK": 7,\n    "PLAYER": "R.J. Harvey",\n    "POS": "RB",\n    "TM": "DEN",\n    "OVR GRADE": 86,\n    "ADP [pos]": 5,\n    "Rook ADP": 7,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "60",\n    "NCAA": "UCF",\n    "AGE": 24.4,\n    "HT": "5\'8\\"",\n    "WT": 205,\n    "40": 4.4,\n    "ATHL": 89,\n    "CL": 4.5,\n    "FL": 2.5,\n    "PRD GRADE": 88.3,\n    "EFF GRADE": 90.2,\n    "RR GRD": "NA",\n    "ELU GRADE": 89.6,\n    "FILM GRADE": 79,\n    "G": 39,\n    "SOS": "79",\n    "YDS(t)": 4510,\n    "TD(t)": 48,\n    "1D(t)": 82,\n    "YpG(t)": 115.6,\n    "OPP(t)": 652,\n    "IMP": 273,\n    "IMP/ OPP": 0.42,\n    "DMTR": "0.258",\n    "CAR": 574,\n    "ruYDS": 3788,\n    "YPC": 6.6,\n    "ruTD": 43,\n    "ru1D": 196,\n    "MTF/ A": "0.315",\n    "YACO/A": "3.68",\n    "ELU": "0.591",\n    "TGT": 78,\n    "REC": 62,\n    "recYDS": 722,\n    "recTD": 5,\n    "rec1D": 29,\n    "YPRR": 1.4,\n    "YPR": 12,\n    "YAC/R": "NA",\n    "Tier": 3\n  },\n  {\n    "RK": 8,\n    "PLAYER": "Kaleb Johnson",\n    "POS": "RB",\n    "TM": "PIT",\n    "OVR GRADE": 86,\n    "ADP [pos]": 6,\n    "Rook ADP": 9,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "83",\n    "NCAA": "IOWA",\n    "AGE": 20.8,\n    "HT": "6\'1\\"",\n    "WT": 224,\n    "40": 4.57,\n    "ATHL": 79,\n    "CL": 3.5,\n    "FL": 4,\n    "PRD GRADE": 67.6,\n    "EFF GRADE": 70,\n    "RR GRD": "NA",\n    "ELU GRADE": 82.1,\n    "FILM GRADE": 76,\n    "G": 35,\n    "SOS": "91.5",\n    "YDS(t)": 3017,\n    "TD(t)": 32,\n    "1D(t)": 31,\n    "YpG(t)": 86.2,\n    "OPP(t)": 543,\n    "IMP": 156,\n    "IMP/ OPP": 0.29,\n    "DMTR": "0.381",\n    "CAR": 508,\n    "ruYDS": 2775,\n    "YPC": 5.5,\n    "ruTD": 30,\n    "ru1D": 116,\n    "MTF/ A": "0.266",\n    "YACO/A": "3.68",\n    "ELU": "0.542",\n    "TGT": 35,\n    "REC": 29,\n    "recYDS": 242,\n    "recTD": 2,\n    "rec1D": 8,\n    "YPRR": 0.9,\n    "YPR": 8,\n    "YAC/R": "NA",\n    "Tier": 3\n  },\n  {\n    "RK": 9,\n    "PLAYER": "Colston Loveland",\n    "POS": "TE",\n    "TM": "CHI",\n    "OVR GRADE": 90,\n    "ADP [pos]": 2,\n    "Rook ADP": 11,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "10",\n    "NCAA": "MICH",\n    "AGE": 21.3,\n    "HT": "6\'6\\"",\n    "WT": 248,\n    "40": "NA",\n    "ATHL": 91,\n    "CL": 5,\n    "FL": 4,\n    "PRD GRADE": 71.1,\n    "EFF GRADE": 72.9,\n    "RR GRD": 90.1,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 90,\n    "G": 39,\n    "SOS": "94.9",\n    "YDS(t)": 1465,\n    "TD(t)": 11,\n    "1D(t)": 72,\n    "YpG(t)": 37.56,\n    "OPP(t)": 171,\n    "IMP": 83,\n    "IMP/ OPP": 0.49,\n    "DMTR": "0.2",\n    "CAR": 1,\n    "ruYDS": -2,\n    "YPC": -2,\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 170,\n    "REC": 116,\n    "recYDS": 1467,\n    "recTD": 11,\n    "rec1D": 72,\n    "YPRR": 2.22,\n    "YPR": 12.5,\n    "YAC/R": 5.37,\n    "Tier": 3\n  },\n  {\n    "RK": 10,\n    "PLAYER": "Emeka Egbuka",\n    "POS": "WR",\n    "TM": "TB",\n    "OVR GRADE": 89,\n    "ADP [pos]": 3,\n    "Rook ADP": 10,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "19",\n    "NCAA": "OSU",\n    "AGE": 22.8,\n    "HT": "6\'1\\"",\n    "WT": 202,\n    "40": 4.5,\n    "ATHL": 87,\n    "CL": 3.5,\n    "FL": 4,\n    "PRD GRADE": 95.7,\n    "EFF GRADE": 93.5,\n    "RR GRD": 91.1,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 86,\n    "G": 47,\n    "SOS": "95.7",\n    "YDS(t)": 3017,\n    "TD(t)": 26,\n    "1D(t)": 144,\n    "YpG(t)": 64.19,\n    "OPP(t)": 305,\n    "IMP": 170,\n    "IMP/ OPP": 0.56,\n    "DMTR": "0.195",\n    "CAR": 23,\n    "ruYDS": 150,\n    "YPC": 6.52,\n    "ruTD": 2,\n    "ru1D": 6,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 282,\n    "REC": 205,\n    "recYDS": 2867,\n    "recTD": 24,\n    "rec1D": 138,\n    "YPRR": 2.6,\n    "YPR": 14,\n    "YAC/R": 6.64,\n    "Tier": 3\n  },\n  {\n    "RK": 11,\n    "PLAYER": "Tyler Warren",\n    "POS": "TE",\n    "TM": "IND",\n    "OVR GRADE": 89,\n    "ADP [pos]": 1,\n    "Rook ADP": 9,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "14",\n    "NCAA": "PSU",\n    "AGE": 23.1,\n    "HT": "6\'6\\"",\n    "WT": 256,\n    "40": "NA",\n    "ATHL": 90,\n    "CL": 4.5,\n    "FL": 4.5,\n    "PRD GRADE": 87.8,\n    "EFF GRADE": 88.8,\n    "RR GRD": 86.7,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 90,\n    "G": 53,\n    "SOS": "95.3",\n    "YDS(t)": 2062,\n    "TD(t)": 25,\n    "1D(t)": 120,\n    "YpG(t)": 38.91,\n    "OPP(t)": 238,\n    "IMP": 145,\n    "IMP/ OPP": 0.61,\n    "DMTR": "0.159",\n    "CAR": 30,\n    "ruYDS": 225,\n    "YPC": 7.5,\n    "ruTD": 6,\n    "ru1D": 16,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 208,\n    "REC": 154,\n    "recYDS": 1837,\n    "recTD": 19,\n    "rec1D": 104,\n    "YPRR": 1.98,\n    "YPR": 11.9,\n    "YAC/R": 6.58,\n    "Tier": 3\n  },\n  {\n    "RK": 12,\n    "PLAYER": "Matthew Golden",\n    "POS": "WR",\n    "TM": "GB",\n    "OVR GRADE": 87,\n    "ADP [pos]": 4,\n    "Rook ADP": 12,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "23",\n    "NCAA": "TEX",\n    "AGE": 21.9,\n    "HT": "5\'11\\"",\n    "WT": 191,\n    "40": 4.29,\n    "ATHL": 94,\n    "CL": 4.5,\n    "FL": 2,\n    "PRD GRADE": 83.9,\n    "EFF GRADE": 81.3,\n    "RR GRD": 87.5,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 86,\n    "G": 36,\n    "SOS": "88.3",\n    "YDS(t)": 1990,\n    "TD(t)": 22,\n    "1D(t)": 96,\n    "YpG(t)": 55.28,\n    "OPP(t)": 202,\n    "IMP": 118,\n    "IMP/ OPP": 0.58,\n    "DMTR": "0.22",\n    "CAR": 0,\n    "ruYDS": 0,\n    "YPC": "NA",\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 202,\n    "REC": 135,\n    "recYDS": 1990,\n    "recTD": 22,\n    "rec1D": 96,\n    "YPRR": 1.85,\n    "YPR": 14.7,\n    "YAC/R": 5.64,\n    "Tier": 4\n  },\n  {\n    "RK": 13,\n    "PLAYER": "Luther Burden",\n    "POS": "WR",\n    "TM": "CHI",\n    "OVR GRADE": 87,\n    "ADP [pos]": 5,\n    "Rook ADP": 14,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "39",\n    "NCAA": "MIZZ",\n    "AGE": 21.6,\n    "HT": "6\'0\\"",\n    "WT": 206,\n    "40": 4.41,\n    "ATHL": 88,\n    "CL": 5,\n    "FL": 2,\n    "PRD GRADE": 92.6,\n    "EFF GRADE": 87.6,\n    "RR GRD": 84.1,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 83,\n    "G": 38,\n    "SOS": "89.4",\n    "YDS(t)": 2493,\n    "TD(t)": 25,\n    "1D(t)": 104,\n    "YpG(t)": 65.61,\n    "OPP(t)": 307,\n    "IMP": 129,\n    "IMP/ OPP": 0.42,\n    "DMTR": "0.34",\n    "CAR": 32,\n    "ruYDS": 210,\n    "YPC": 6.56,\n    "ruTD": 4,\n    "ru1D": 11,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 275,\n    "REC": 193,\n    "recYDS": 2283,\n    "recTD": 21,\n    "rec1D": 93,\n    "YPRR": 2.32,\n    "YPR": 11.8,\n    "YAC/R": 7.26,\n    "Tier": 4\n  },\n  {\n    "RK": 14,\n    "PLAYER": "Jayden Higgins",\n    "POS": "WR",\n    "TM": "HOU",\n    "OVR GRADE": 86,\n    "ADP [pos]": 6,\n    "Rook ADP": 15,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "34",\n    "NCAA": "ISU",\n    "AGE": 22.6,\n    "HT": "6\'4\\"",\n    "WT": 214,\n    "40": 4.47,\n    "ATHL": 91,\n    "CL": 4,\n    "FL": 2.5,\n    "PRD GRADE": 83.6,\n    "EFF GRADE": 90.2,\n    "RR GRD": 87.8,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 80,\n    "G": 36,\n    "SOS": "83",\n    "YDS(t)": 2562,\n    "TD(t)": 28,\n    "1D(t)": 160,\n    "YpG(t)": 71.17,\n    "OPP(t)": 264,\n    "IMP": 188,\n    "IMP/ OPP": 0.71,\n    "DMTR": "0.331",\n    "CAR": 0,\n    "ruYDS": 0,\n    "YPC": "NA",\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 264,\n    "REC": 169,\n    "recYDS": 2562,\n    "recTD": 28,\n    "rec1D": 160,\n    "YPRR": 2.37,\n    "YPR": 14.6,\n    "YAC/R": 4.64,\n    "Tier": 4\n  },\n  {\n    "RK": 15,\n    "PLAYER": "Cameron Skattebo",\n    "POS": "RB",\n    "TM": "NYG",\n    "OVR GRADE": 87,\n    "ADP [pos]": 7,\n    "Rook ADP": 13,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "105",\n    "NCAA": "ARIZST",\n    "AGE": 23.4,\n    "HT": "5\'10\\"",\n    "WT": 219,\n    "40": "NA",\n    "ATHL": 77,\n    "CL": 4,\n    "FL": 3,\n    "PRD GRADE": 94.9,\n    "EFF GRADE": 86.9,\n    "RR GRD": "NA",\n    "ELU GRADE": 92.7,\n    "FILM GRADE": 85,\n    "G": 47,\n    "SOS": "81",\n    "YDS(t)": 5710,\n    "TD(t)": 51,\n    "1D(t)": 120,\n    "YpG(t)": 121.5,\n    "OPP(t)": 855,\n    "IMP": 363,\n    "IMP/ OPP": 0.43,\n    "DMTR": "0.285",\n    "CAR": 711,\n    "ruYDS": 4387,\n    "YPC": 6.2,\n    "ruTD": 43,\n    "ru1D": 258,\n    "MTF/ A": "0.366",\n    "YACO/A": "3.95",\n    "ELU": "0.662",\n    "TGT": 144,\n    "REC": 111,\n    "recYDS": 1323,\n    "recTD": 8,\n    "rec1D": 54,\n    "YPRR": 1.56,\n    "YPR": 12,\n    "YAC/R": "NA",\n    "Tier": 4\n  },\n  {\n    "RK": 16,\n    "PLAYER": "Tre Harris",\n    "POS": "WR",\n    "TM": "LAC",\n    "OVR GRADE": 86,\n    "ADP [pos]": 7,\n    "Rook ADP": 16,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "55",\n    "NCAA": "MISS",\n    "AGE": 23.3,\n    "HT": "6\'2\\"",\n    "WT": 205,\n    "40": 4.54,\n    "ATHL": 76,\n    "CL": 4,\n    "FL": 3,\n    "PRD GRADE": 94.4,\n    "EFF GRADE": 98,\n    "RR GRD": 83.1,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 80,\n    "G": 46,\n    "SOS": "90.1",\n    "YDS(t)": 3567,\n    "TD(t)": 29,\n    "1D(t)": 147,\n    "YpG(t)": 77.54,\n    "OPP(t)": 333,\n    "IMP": 176,\n    "IMP/ OPP": 0.53,\n    "DMTR": "0.289",\n    "CAR": 5,\n    "ruYDS": 22,\n    "YPC": 4.4,\n    "ruTD": 0,\n    "ru1D": 1,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 328,\n    "REC": 220,\n    "recYDS": 3545,\n    "recTD": 29,\n    "rec1D": 146,\n    "YPRR": 3,\n    "YPR": 16.1,\n    "YAC/R": 6.44,\n    "Tier": 4\n  },\n  {\n    "RK": 17,\n    "PLAYER": "Jack Bech",\n    "POS": "WR",\n    "TM": "LV",\n    "OVR GRADE": 86,\n    "ADP [pos]": 8,\n    "Rook ADP": 17,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "58",\n    "NCAA": "TCU",\n    "AGE": 22.6,\n    "HT": "6\'1\\"",\n    "WT": 214,\n    "40": "NA",\n    "ATHL": 77,\n    "CL": 3.5,\n    "FL": 3.5,\n    "PRD GRADE": 65.7,\n    "EFF GRADE": 72.9,\n    "RR GRD": 88.5,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 82,\n    "G": 45,\n    "SOS": "78.3",\n    "YDS(t)": 1866,\n    "TD(t)": 13,\n    "1D(t)": 87,\n    "YpG(t)": 41.47,\n    "OPP(t)": 203,\n    "IMP": 100,\n    "IMP/ OPP": 0.49,\n    "DMTR": "0.14",\n    "CAR": 3,\n    "ruYDS": -3,\n    "YPC": -1,\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 200,\n    "REC": 133,\n    "recYDS": 1869,\n    "recTD": 13,\n    "rec1D": 87,\n    "YPRR": 1.86,\n    "YPR": 14.1,\n    "YAC/R": 5.5,\n    "Tier": 4\n  },\n  {\n    "RK": 18,\n    "PLAYER": "Kyle Williams",\n    "POS": "WR",\n    "TM": "NE",\n    "OVR GRADE": 87,\n    "ADP [pos]": 9,\n    "Rook ADP": 20,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "69",\n    "NCAA": "WSU",\n    "AGE": 22.7,\n    "HT": "5\'11\\"",\n    "WT": 190,\n    "40": 4.4,\n    "ATHL": 85,\n    "CL": 3.5,\n    "FL": 3,\n    "PRD GRADE": 92.4,\n    "EFF GRADE": 86,\n    "RR GRD": 88.1,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 50,\n    "SOS": "77.4",\n    "YDS(t)": 3678,\n    "TD(t)": 29,\n    "1D(t)": 160,\n    "YpG(t)": 73.56,\n    "OPP(t)": 393,\n    "IMP": 189,\n    "IMP/ OPP": 0.48,\n    "DMTR": "0.318",\n    "CAR": 17,\n    "ruYDS": 72,\n    "YPC": 4.24,\n    "ruTD": 0,\n    "ru1D": 5,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 376,\n    "REC": 248,\n    "recYDS": 3606,\n    "recTD": 29,\n    "rec1D": 155,\n    "YPRR": 2.07,\n    "YPR": 14.5,\n    "YAC/R": 6.35,\n    "Tier": 4\n  },\n  {\n    "RK": 19,\n    "PLAYER": "Bhayshul Tuten",\n    "POS": "RB",\n    "TM": "JAX",\n    "OVR GRADE": 80,\n    "ADP [pos]": 8,\n    "Rook ADP": 19,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "104",\n    "NCAA": "VT",\n    "AGE": 22.4,\n    "HT": "5\'9\\"",\n    "WT": 206,\n    "40": 4.32,\n    "ATHL": 94,\n    "CL": 4,\n    "FL": 2,\n    "PRD GRADE": 61.9,\n    "EFF GRADE": 75.3,\n    "RR GRD": "NA",\n    "ELU GRADE": 90.2,\n    "FILM GRADE": 79,\n    "G": 45,\n    "SOS": "77",\n    "YDS(t)": 4449,\n    "TD(t)": 49,\n    "1D(t)": 152,\n    "YpG(t)": 98.9,\n    "OPP(t)": 718,\n    "IMP": 241,\n    "IMP/ OPP": 0.34,\n    "DMTR": "0.313",\n    "CAR": 600,\n    "ruYDS": 3584,\n    "YPC": 6,\n    "ruTD": 40,\n    "ru1D": 162,\n    "MTF/ A": "0.362",\n    "YACO/A": "4.18",\n    "ELU": "0.676",\n    "TGT": 118,\n    "REC": 87,\n    "recYDS": 865,\n    "recTD": 9,\n    "rec1D": 30,\n    "YPRR": 1.27,\n    "YPR": 10,\n    "YAC/R": "NA",\n    "Tier": 5\n  },\n  {\n    "RK": 20,\n    "PLAYER": "Jaylin Noel",\n    "POS": "WR",\n    "TM": "HOU",\n    "OVR GRADE": 86,\n    "ADP [pos]": 10,\n    "Rook ADP": 22,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "79",\n    "NCAA": "ISU",\n    "AGE": 22.8,\n    "HT": "5\'10\\"",\n    "WT": 194,\n    "40": 4.39,\n    "ATHL": 92,\n    "CL": 3.5,\n    "FL": 3,\n    "PRD GRADE": 92.4,\n    "EFF GRADE": 82.8,\n    "RR GRD": 87.7,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 79,\n    "G": 51,\n    "SOS": "83.6",\n    "YDS(t)": 2938,\n    "TD(t)": 18,\n    "1D(t)": 128,\n    "YpG(t)": 57.61,\n    "OPP(t)": 362,\n    "IMP": 146,\n    "IMP/ OPP": 0.4,\n    "DMTR": "0.212",\n    "CAR": 13,\n    "ruYDS": 84,\n    "YPC": 6.46,\n    "ruTD": 0,\n    "ru1D": 5,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 349,\n    "REC": 245,\n    "recYDS": 2854,\n    "recTD": 18,\n    "rec1D": 123,\n    "YPRR": 2.07,\n    "YPR": 11.6,\n    "YAC/R": 5.58,\n    "Tier": 5\n  },\n  {\n    "RK": 21,\n    "PLAYER": "Mason Taylor",\n    "POS": "TE",\n    "TM": "NYG",\n    "OVR GRADE": 75,\n    "ADP [pos]": 3,\n    "Rook ADP": 21,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "42",\n    "NCAA": "LSU",\n    "AGE": 21.2,\n    "HT": "6\'5\\"",\n    "WT": 251,\n    "40": "NA",\n    "ATHL": 86,\n    "CL": 3,\n    "FL": 3,\n    "PRD GRADE": 67.7,\n    "EFF GRADE": 58.5,\n    "RR GRD": 83.2,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 38,\n    "SOS": "90.7",\n    "YDS(t)": 1308,\n    "TD(t)": 6,\n    "1D(t)": 72,\n    "YpG(t)": 34.42,\n    "OPP(t)": 181,\n    "IMP": 78,\n    "IMP/ OPP": 0.43,\n    "DMTR": "0.089",\n    "CAR": 0,\n    "ruYDS": 0,\n    "YPC": "NA",\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 181,\n    "REC": 129,\n    "recYDS": 1308,\n    "recTD": 6,\n    "rec1D": 72,\n    "YPRR": 1.09,\n    "YPR": 10.1,\n    "YAC/R": 5.36,\n    "Tier": 5\n  },\n  {\n    "RK": 22,\n    "PLAYER": "Jaydon Blue",\n    "POS": "RB",\n    "TM": "DAL",\n    "OVR GRADE": 74,\n    "ADP [pos]": 9,\n    "Rook ADP": 20,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "149",\n    "NCAA": "TEX",\n    "AGE": 21.5,\n    "HT": "5\'9\\"",\n    "WT": 196,\n    "40": 4.38,\n    "ATHL": 89,\n    "CL": 3,\n    "FL": 2.5,\n    "PRD GRADE": 57.5,\n    "EFF GRADE": 68.8,\n    "RR GRD": "NA",\n    "ELU GRADE": 76.5,\n    "FILM GRADE": "NA",\n    "G": 31,\n    "SOS": "91",\n    "YDS(t)": 1659,\n    "TD(t)": 18,\n    "1D(t)": 85,\n    "YpG(t)": 53.5,\n    "OPP(t)": 289,\n    "IMP": 101,\n    "IMP/ OPP": 0.35,\n    "DMTR": "0.131",\n    "CAR": 215,\n    "ruYDS": 1159,\n    "YPC": 5.4,\n    "ruTD": 11,\n    "ru1D": 56,\n    "MTF/ A": "0.260",\n    "YACO/A": "3.48",\n    "ELU": "0.521",\n    "TGT": 74,\n    "REC": 55,\n    "recYDS": 500,\n    "recTD": 7,\n    "rec1D": 27,\n    "YPRR": 1.59,\n    "YPR": 9,\n    "YAC/R": "NA",\n    "Tier": 5\n  },\n  {\n    "RK": 23,\n    "PLAYER": "Terrance Ferguson",\n    "POS": "TE",\n    "TM": "LAC",\n    "OVR GRADE": 77,\n    "ADP [pos]": 4,\n    "Rook ADP": 25,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "46",\n    "NCAA": "ORE",\n    "AGE": 22.4,\n    "HT": "6\'5\\"",\n    "WT": 247,\n    "40": 4.63,\n    "ATHL": 85,\n    "CL": 3.5,\n    "FL": 3,\n    "PRD GRADE": 72.7,\n    "EFF GRADE": 73.6,\n    "RR GRD": 75.8,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 53,\n    "SOS": "88.9",\n    "YDS(t)": 1537,\n    "TD(t)": 16,\n    "1D(t)": 85,\n    "YpG(t)": 29,\n    "OPP(t)": 183,\n    "IMP": 101,\n    "IMP/ OPP": 0.55,\n    "DMTR": "0.116",\n    "CAR": 0,\n    "ruYDS": 0,\n    "YPC": "NA",\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 183,\n    "REC": 134,\n    "recYDS": 1537,\n    "recTD": 16,\n    "rec1D": 85,\n    "YPRR": 1.51,\n    "YPR": 11.5,\n    "YAC/R": 7.02,\n    "Tier": 5\n  },\n  {\n    "RK": 24,\n    "PLAYER": "Dylan Sampson",\n    "POS": "RB",\n    "TM": "CLE",\n    "OVR GRADE": 82,\n    "ADP [pos]": 10,\n    "Rook ADP": 24,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "126",\n    "NCAA": "TENN",\n    "AGE": 20.8,\n    "HT": "5\'8\\"",\n    "WT": 200,\n    "40": "NA",\n    "ATHL": 80,\n    "CL": 2.5,\n    "FL": 2,\n    "PRD GRADE": 70.4,\n    "EFF GRADE": 85.4,\n    "RR GRD": "NA",\n    "ELU GRADE": 82.5,\n    "FILM GRADE": 85,\n    "G": 34,\n    "SOS": "91.5",\n    "YDS(t)": 2823,\n    "TD(t)": 36,\n    "1D(t)": 160,\n    "YpG(t)": 83,\n    "OPP(t)": 473,\n    "IMP": 185,\n    "IMP/ OPP": 0.39,\n    "DMTR": "0.203",\n    "CAR": 423,\n    "ruYDS": 2481,\n    "YPC": 5.9,\n    "ruTD": 35,\n    "ru1D": 131,\n    "MTF/ A": "0.262",\n    "YACO/A": "3.64",\n    "ELU": "0.535",\n    "TGT": 50,\n    "REC": 40,\n    "recYDS": 342,\n    "recTD": 1,\n    "rec1D": 18,\n    "YPRR": 1.06,\n    "YPR": 9,\n    "YAC/R": "NA",\n    "Tier": 5\n  },\n  {\n    "RK": 25,\n    "PLAYER": "Elijah Arroyo",\n    "POS": "TE",\n    "TM": "SEA",\n    "OVR GRADE": 74,\n    "ADP [pos]": 5,\n    "Rook ADP": 27,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "50",\n    "NCAA": "MIA",\n    "AGE": 22.3,\n    "HT": "6\'5\\"",\n    "WT": 250,\n    "40": "NA",\n    "ATHL": 85,\n    "CL": 4,\n    "FL": 2,\n    "PRD GRADE": 55.7,\n    "EFF GRADE": 68.3,\n    "RR GRD": 83.4,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 34,\n    "SOS": "82.9",\n    "YDS(t)": 747,\n    "TD(t)": 8,\n    "1D(t)": 31,\n    "YpG(t)": 21.97,\n    "OPP(t)": 63,\n    "IMP": 39,\n    "IMP/ OPP": 0.62,\n    "DMTR": "0.09",\n    "CAR": 0,\n    "ruYDS": 0,\n    "YPC": "NA",\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 63,\n    "REC": 46,\n    "recYDS": 747,\n    "recTD": 8,\n    "rec1D": 31,\n    "YPRR": 1.61,\n    "YPR": 16.2,\n    "YAC/R": 8.8,\n    "Tier": 5\n  },\n  {\n    "RK": 26,\n    "PLAYER": "Pat Bryant",\n    "POS": "WR",\n    "TM": "DEN",\n    "OVR GRADE": 80,\n    "ADP [pos]": 12,\n    "Rook ADP": 28,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "74",\n    "NCAA": "ILL",\n    "AGE": 22.6,\n    "HT": "6\'2\\"",\n    "WT": 204,\n    "40": 4.61,\n    "ATHL": 72,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 81.9,\n    "EFF GRADE": 82.8,\n    "RR GRD": 81.7,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 45,\n    "SOS": "88.4",\n    "YDS(t)": 2108,\n    "TD(t)": 19,\n    "1D(t)": 96,\n    "YpG(t)": 46.84,\n    "OPP(t)": 214,\n    "IMP": 115,\n    "IMP/ OPP": 0.54,\n    "DMTR": "0.255",\n    "CAR": 6,\n    "ruYDS": 17,\n    "YPC": 2.83,\n    "ruTD": 0,\n    "ru1D": 1,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 208,\n    "REC": 136,\n    "recYDS": 2091,\n    "recTD": 19,\n    "rec1D": 95,\n    "YPRR": 2.12,\n    "YPR": 15.4,\n    "YAC/R": 4.7,\n    "Tier": 5\n  },\n  {\n    "RK": 27,\n    "PLAYER": "Harold Fannin Jr.",\n    "POS": "TE",\n    "TM": "CLE",\n    "OVR GRADE": 86,\n    "ADP [pos]": 6,\n    "Rook ADP": 32,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "67",\n    "NCAA": "BGSU",\n    "AGE": 22,\n    "HT": "6\'3\\"",\n    "WT": 241,\n    "40": 4.71,\n    "ATHL": 79,\n    "CL": 4.5,\n    "FL": 1,\n    "PRD GRADE": 92,\n    "EFF GRADE": 94.6,\n    "RR GRD": 88.9,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 81,\n    "G": 36,\n    "SOS": "74.9",\n    "YDS(t)": 2555,\n    "TD(t)": 22,\n    "1D(t)": 123,\n    "YpG(t)": 70.97,\n    "OPP(t)": 265,\n    "IMP": 145,\n    "IMP/ OPP": 0.55,\n    "DMTR": "0.299",\n    "CAR": 33,\n    "ruYDS": 159,\n    "YPC": 4.82,\n    "ruTD": 5,\n    "ru1D": 15,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 232,\n    "REC": 180,\n    "recYDS": 2396,\n    "recTD": 17,\n    "rec1D": 108,\n    "YPRR": 2.99,\n    "YPR": 13.3,\n    "YAC/R": 8.1,\n    "Tier": 6\n  },\n  {\n    "RK": 28,\n    "PLAYER": "Devin Neal",\n    "POS": "RB",\n    "TM": "NO",\n    "OVR GRADE": 81,\n    "ADP [pos]": 11,\n    "Rook ADP": 25,\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>⑥</span>",\n    "PK#": "184",\n    "NCAA": "KU",\n    "AGE": 21.9,\n    "HT": "5\'11\\"",\n    "WT": 213,\n    "40": 4.58,\n    "ATHL": 68,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 92.1,\n    "EFF GRADE": 80.8,\n    "RR GRD": "NA",\n    "ELU GRADE": 68.2,\n    "FILM GRADE": 78,\n    "G": 49,\n    "SOS": "81",\n    "YDS(t)": 5063,\n    "TD(t)": 53,\n    "1D(t)": 96,\n    "YpG(t)": 103.3,\n    "OPP(t)": 860,\n    "IMP": 297,\n    "IMP/ OPP": 0.35,\n    "DMTR": "0.267",\n    "CAR": 759,\n    "ruYDS": 4340,\n    "YPC": 5.7,\n    "ruTD": 49,\n    "ru1D": 211,\n    "MTF/ A": "0.225",\n    "YACO/A": "3.33",\n    "ELU": "0.475",\n    "TGT": 101,\n    "REC": 79,\n    "recYDS": 723,\n    "recTD": 4,\n    "rec1D": 33,\n    "YPRR": 0.97,\n    "YPR": 9,\n    "YAC/R": "NA",\n    "Tier": 6\n  },\n  {\n    "RK": 29,\n    "PLAYER": "Jalen Royals",\n    "POS": "WR",\n    "TM": "KC",\n    "OVR GRADE": 85,\n    "ADP [pos]": 11,\n    "Rook ADP": 26,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "133",\n    "NCAA": "USU",\n    "AGE": 22.4,\n    "HT": "6\'0\\"",\n    "WT": 205,\n    "40": 4.42,\n    "ATHL": 89,\n    "CL": 3.5,\n    "FL": 1.5,\n    "PRD GRADE": 78.8,\n    "EFF GRADE": 90.9,\n    "RR GRD": 86.1,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 80,\n    "G": 27,\n    "SOS": "70",\n    "YDS(t)": 1926,\n    "TD(t)": 21,\n    "1D(t)": 75,\n    "YpG(t)": 71.33,\n    "OPP(t)": 185,\n    "IMP": 96,\n    "IMP/ OPP": 0.52,\n    "DMTR": "0.333",\n    "CAR": 1,\n    "ruYDS": 3,\n    "YPC": 3,\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 184,\n    "REC": 125,\n    "recYDS": 1923,\n    "recTD": 21,\n    "rec1D": 75,\n    "YPRR": 2.42,\n    "YPR": 15.4,\n    "YAC/R": 6.81,\n    "Tier": 6\n  },\n  {\n    "RK": 30,\n    "PLAYER": "Elic Ayomanor",\n    "POS": "WR",\n    "TM": "TEN",\n    "OVR GRADE": 78,\n    "ADP [pos]": 13,\n    "Rook ADP": 29,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "136",\n    "NCAA": "STAN",\n    "AGE": 22.1,\n    "HT": "6\'2\\"",\n    "WT": 206,\n    "40": 4.44,\n    "ATHL": 83,\n    "CL": 3,\n    "FL": 1.5,\n    "PRD GRADE": 76.7,\n    "EFF GRADE": 76.4,\n    "RR GRD": 75.1,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 77,\n    "G": 24,\n    "SOS": "81.7",\n    "YDS(t)": 1853,\n    "TD(t)": 12,\n    "1D(t)": 82,\n    "YpG(t)": 77.21,\n    "OPP(t)": 216,\n    "IMP": 94,\n    "IMP/ OPP": 0.44,\n    "DMTR": "0.389",\n    "CAR": 0,\n    "ruYDS": 0,\n    "YPC": "NA",\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 216,\n    "REC": 126,\n    "recYDS": 1853,\n    "recTD": 12,\n    "rec1D": 82,\n    "YPRR": 2.12,\n    "YPR": 14.7,\n    "YAC/R": 4.49,\n    "Tier": 6\n  },\n  {\n    "RK": 31,\n    "PLAYER": "DJ Giddens",\n    "POS": "RB",\n    "TM": "IND",\n    "OVR GRADE": 81,\n    "ADP [pos]": 13,\n    "Rook ADP": 34,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "151",\n    "NCAA": "KSU",\n    "AGE": 21.8,\n    "HT": "6\'0\\"",\n    "WT": 212,\n    "40": 4.43,\n    "ATHL": 85,\n    "CL": 3.5,\n    "FL": 2,\n    "PRD GRADE": 73.9,\n    "EFF GRADE": 82.7,\n    "RR GRD": "NA",\n    "ELU GRADE": 86.9,\n    "FILM GRADE": 70,\n    "G": 39,\n    "SOS": "82.5",\n    "YDS(t)": 3770,\n    "TD(t)": 27,\n    "1D(t)": 104,\n    "YpG(t)": 96.7,\n    "OPP(t)": 601,\n    "IMP": 209,\n    "IMP/ OPP": 0.35,\n    "DMTR": "0.196",\n    "CAR": 518,\n    "ruYDS": 3088,\n    "YPC": 6,\n    "ruTD": 23,\n    "ru1D": 156,\n    "MTF/ A": "0.284",\n    "YACO/A": "3.72",\n    "ELU": "0.563",\n    "TGT": 83,\n    "REC": 58,\n    "recYDS": 682,\n    "recTD": 4,\n    "rec1D": 26,\n    "YPRR": 1.24,\n    "YPR": 12,\n    "YAC/R": "NA",\n    "Tier": 6\n  },\n  {\n    "RK": 32,\n    "PLAYER": "Trevor Etienne",\n    "POS": "RB",\n    "TM": "CAR",\n    "OVR GRADE": 80,\n    "ADP [pos]": 14,\n    "Rook ADP": 35,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "114",\n    "NCAA": "UGA",\n    "AGE": 21,\n    "HT": "5\'9\\"",\n    "WT": 198,\n    "40": 4.42,\n    "ATHL": 83,\n    "CL": 2.5,\n    "FL": 1.5,\n    "PRD GRADE": 63.4,\n    "EFF GRADE": 71.9,\n    "RR GRD": "NA",\n    "ELU GRADE": 86.7,\n    "FILM GRADE": 79,\n    "G": 34,\n    "SOS": "93.5",\n    "YDS(t)": 2510,\n    "TD(t)": 24,\n    "1D(t)": 153,\n    "YpG(t)": 73.8,\n    "OPP(t)": 433,\n    "IMP": 147,\n    "IMP/ OPP": 0.34,\n    "DMTR": "0.184",\n    "CAR": 370,\n    "ruYDS": 2078,\n    "YPC": 5.6,\n    "ruTD": 23,\n    "ru1D": 103,\n    "MTF/ A": "0.265",\n    "YACO/A": "3.80",\n    "ELU": "0.550",\n    "TGT": 63,\n    "REC": 62,\n    "recYDS": 432,\n    "recTD": 1,\n    "rec1D": 20,\n    "YPRR": 0.99,\n    "YPR": 7,\n    "YAC/R": "NA",\n    "Tier": 6\n  },\n  {\n    "RK": 33,\n    "PLAYER": "Ollie Gordon",\n    "POS": "RB",\n    "TM": "MIA",\n    "OVR GRADE": 74,\n    "ADP [pos]": 12,\n    "Rook ADP": 32,\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>⑥</span>",\n    "PK#": "179",\n    "NCAA": "OKST",\n    "AGE": 21.5,\n    "HT": "6\'1\\"",\n    "WT": 226,\n    "40": 4.61,\n    "ATHL": 70,\n    "CL": 2.5,\n    "FL": 3,\n    "PRD GRADE": 81.9,\n    "EFF GRADE": 70.8,\n    "RR GRD": "NA",\n    "ELU GRADE": 64.9,\n    "FILM GRADE": 78,\n    "G": 39,\n    "SOS": "82",\n    "YDS(t)": 3495,\n    "TD(t)": 40,\n    "1D(t)": 96,\n    "YpG(t)": 89.6,\n    "OPP(t)": 638,\n    "IMP": 217,\n    "IMP/ OPP": 0.34,\n    "DMTR": "0.26",\n    "CAR": 535,\n    "ruYDS": 2891,\n    "YPC": 5.4,\n    "ruTD": 35,\n    "ru1D": 142,\n    "MTF/ A": "0.234",\n    "YACO/A": "3.47",\n    "ELU": "0.494",\n    "TGT": 103,\n    "REC": 81,\n    "recYDS": 604,\n    "recTD": 5,\n    "rec1D": 35,\n    "YPRR": 0.82,\n    "YPR": 8,\n    "YAC/R": "NA",\n    "Tier": 6\n  },\n  {\n    "RK": 34,\n    "PLAYER": "Jarquez Hunter",\n    "POS": "RB",\n    "TM": "LAR",\n    "OVR GRADE": 76,\n    "ADP [pos]": 16,\n    "Rook ADP": 38,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "117",\n    "NCAA": "AUB",\n    "AGE": 22.5,\n    "HT": "5\'9\\"",\n    "WT": 204,\n    "40": 4.44,\n    "ATHL": 76,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 79.1,\n    "EFF GRADE": 80.3,\n    "RR GRD": "NA",\n    "ELU GRADE": 90.1,\n    "FILM GRADE": "NA",\n    "G": 49,\n    "SOS": "92",\n    "YDS(t)": 3931,\n    "TD(t)": 29,\n    "1D(t)": 147,\n    "YpG(t)": 80.2,\n    "OPP(t)": 629,\n    "IMP": 219,\n    "IMP/ OPP": 0.35,\n    "DMTR": "0.196",\n    "CAR": 539,\n    "ruYDS": 3373,\n    "YPC": 6.3,\n    "ruTD": 25,\n    "ru1D": 166,\n    "MTF/ A": "0.304",\n    "YACO/A": "3.94",\n    "ELU": "0.600",\n    "TGT": 90,\n    "REC": 68,\n    "recYDS": 558,\n    "recTD": 4,\n    "rec1D": 24,\n    "YPRR": 0.89,\n    "YPR": 8,\n    "YAC/R": "NA",\n    "Tier": 6\n  },\n  {\n    "RK": 35,\n    "PLAYER": "Jordan James",\n    "POS": "RB",\n    "TM": "SF",\n    "OVR GRADE": 76,\n    "ADP [pos]": 15,\n    "Rook ADP": 36,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "147",\n    "NCAA": "ORE",\n    "AGE": 21.3,\n    "HT": "5\'10\\"",\n    "WT": 205,\n    "40": 4.55,\n    "ATHL": 71,\n    "CL": 3.5,\n    "FL": 1.5,\n    "PRD GRADE": 78.3,\n    "EFF GRADE": 81.4,\n    "RR GRD": "NA",\n    "ELU GRADE": 69.9,\n    "FILM GRADE": "NA",\n    "G": 37,\n    "SOS": "90",\n    "YDS(t)": 2568,\n    "TD(t)": 32,\n    "1D(t)": 160,\n    "YpG(t)": 69.4,\n    "OPP(t)": 439,\n    "IMP": 197,\n    "IMP/ OPP": 0.45,\n    "DMTR": "0.156",\n    "CAR": 386,\n    "ruYDS": 2223,\n    "YPC": 5.8,\n    "ruTD": 31,\n    "ru1D": 148,\n    "MTF/ A": "0.251",\n    "YACO/A": "3.32",\n    "ELU": "0.500",\n    "TGT": 53,\n    "REC": 42,\n    "recYDS": 345,\n    "recTD": 1,\n    "rec1D": 17,\n    "YPRR": 0.95,\n    "YPR": 8,\n    "YAC/R": "NA",\n    "Tier": 6\n  },\n  {\n    "RK": 36,\n    "PLAYER": "Isaac TeSlaa",\n    "POS": "WR",\n    "TM": "DET",\n    "OVR GRADE": 75,\n    "ADP [pos]": 14,\n    "Rook ADP": 36,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "70",\n    "NCAA": "ARK",\n    "AGE": 23.4,\n    "HT": "6\'4\\"",\n    "WT": 214,\n    "40": 4.43,\n    "ATHL": 91,\n    "CL": 4,\n    "FL": 1,\n    "PRD GRADE": 58.5,\n    "EFF GRADE": 65.5,\n    "RR GRD": 74.7,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 25,\n    "SOS": "NA",\n    "YDS(t)": 883,\n    "TD(t)": 5,\n    "1D(t)": 36,\n    "YpG(t)": 35.32,\n    "OPP(t)": 101,\n    "IMP": 41,\n    "IMP/ OPP": 0.41,\n    "DMTR": "0.142",\n    "CAR": 1,\n    "ruYDS": 0,\n    "YPC": 0,\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 100,\n    "REC": 62,\n    "recYDS": 883,\n    "recTD": 5,\n    "rec1D": 36,\n    "YPRR": 1.45,\n    "YPR": 14.2,\n    "YAC/R": 4.97,\n    "Tier": 6\n  },\n  {\n    "RK": 37,\n    "PLAYER": "Brashard Smith",\n    "POS": "RB",\n    "TM": "KC",\n    "OVR GRADE": 73,\n    "ADP [pos]": 17,\n    "Rook ADP": 42,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "228",\n    "NCAA": "SMU",\n    "AGE": 22.3,\n    "HT": "5\'10\\"",\n    "WT": 194,\n    "40": 4.39,\n    "ATHL": 79,\n    "CL": 3.5,\n    "FL": 2,\n    "PRD GRADE": 66.6,\n    "EFF GRADE": 81.8,\n    "RR GRD": "NA",\n    "ELU GRADE": 60.3,\n    "FILM GRADE": "NA",\n    "G": 46,\n    "SOS": "78",\n    "YDS(t)": 2616,\n    "TD(t)": 23,\n    "1D(t)": 72,\n    "YpG(t)": 56.9,\n    "OPP(t)": 392,\n    "IMP": 149,\n    "IMP/ OPP": 0.38,\n    "DMTR": "0.135",\n    "CAR": 252,\n    "ruYDS": 1516,\n    "YPC": 6,\n    "ruTD": 15,\n    "ru1D": 76,\n    "MTF/ A": "0.226",\n    "YACO/A": "3.30",\n    "ELU": "0.474",\n    "TGT": 140,\n    "REC": 109,\n    "recYDS": 1100,\n    "recTD": 8,\n    "rec1D": 50,\n    "YPRR": 1.9,\n    "YPR": 10,\n    "YAC/R": "NA",\n    "Tier": 6\n  },\n  {\n    "RK": 38,\n    "PLAYER": "Tory Horton",\n    "POS": "WR",\n    "TM": "SEA",\n    "OVR GRADE": 84,\n    "ADP [pos]": 15,\n    "Rook ADP": 38,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "166",\n    "NCAA": "CSU",\n    "AGE": 22.6,\n    "HT": "6\'2\\"",\n    "WT": 196,\n    "40": 4.41,\n    "ATHL": 87,\n    "CL": 3.5,\n    "FL": 2,\n    "PRD GRADE": 90.7,\n    "EFF GRADE": 87.3,\n    "RR GRD": 82.9,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 50,\n    "SOS": "75.1",\n    "YDS(t)": 3632,\n    "TD(t)": 27,\n    "1D(t)": 153,\n    "YpG(t)": 72.64,\n    "OPP(t)": 381,\n    "IMP": 180,\n    "IMP/ OPP": 0.47,\n    "DMTR": "0.267",\n    "CAR": 2,\n    "ruYDS": 31,\n    "YPC": 15.5,\n    "ruTD": 0,\n    "ru1D": 1,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 379,\n    "REC": 264,\n    "recYDS": 3601,\n    "recTD": 27,\n    "rec1D": 152,\n    "YPRR": 2.46,\n    "YPR": 13.6,\n    "YAC/R": 5.83,\n    "Tier": 6\n  },\n  {\n    "RK": 39,\n    "PLAYER": "Jo\'quavious Marks",\n    "POS": "RB",\n    "TM": "HOU",\n    "OVR GRADE": 70,\n    "ADP [pos]": 18,\n    "Rook ADP": 44,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "116",\n    "NCAA": "USC",\n    "AGE": 24.5,\n    "HT": "5\'10\\"",\n    "WT": 207,\n    "40": 4.54,\n    "ATHL": 76,\n    "CL": 2.5,\n    "FL": 1.5,\n    "PRD GRADE": 85.4,\n    "EFF GRADE": 59.2,\n    "RR GRD": "NA",\n    "ELU GRADE": 55.1,\n    "FILM GRADE": "NA",\n    "G": 57,\n    "SOS": "NA",\n    "YDS(t)": 4561,\n    "TD(t)": 36,\n    "1D(t)": 87,\n    "YpG(t)": 80,\n    "OPP(t)": 912,\n    "IMP": 288,\n    "IMP/ OPP": 0.32,\n    "DMTR": "0.199",\n    "CAR": 611,\n    "ruYDS": 3057,\n    "YPC": 5,\n    "ruTD": 31,\n    "ru1D": 182,\n    "MTF/ A": "0.155",\n    "YACO/A": "2.76",\n    "ELU": "0.362",\n    "TGT": 301,\n    "REC": 257,\n    "recYDS": 1504,\n    "recTD": 5,\n    "rec1D": 70,\n    "YPRR": 1.12,\n    "YPR": 6,\n    "YAC/R": "NA",\n    "Tier": 6\n  },\n  {\n    "RK": 40,\n    "PLAYER": "Oronde Gadsden II",\n    "POS": "TE",\n    "TM": "LAC",\n    "OVR GRADE": 79,\n    "ADP [pos]": 7,\n    "Rook ADP": 43,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "165",\n    "NCAA": "SYR",\n    "AGE": 22,\n    "HT": "6\'5\\"",\n    "WT": 243,\n    "40": "NA",\n    "ATHL": 75,\n    "CL": 3.5,\n    "FL": 2,\n    "PRD GRADE": 82,\n    "EFF GRADE": 82.7,\n    "RR GRD": 75.2,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 34,\n    "SOS": "80.9",\n    "YDS(t)": 2003,\n    "TD(t)": 14,\n    "1D(t)": 107,\n    "YpG(t)": 58.91,\n    "OPP(t)": 210,\n    "IMP": 121,\n    "IMP/ OPP": 0.58,\n    "DMTR": "0.257",\n    "CAR": 1,\n    "ruYDS": 12,\n    "YPC": 12,\n    "ruTD": 0,\n    "ru1D": 1,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 209,\n    "REC": 143,\n    "recYDS": 1991,\n    "recTD": 14,\n    "rec1D": 106,\n    "YPRR": 2.04,\n    "YPR": 13.9,\n    "YAC/R": 3.69,\n    "Tier": 6\n  },\n  {\n    "RK": 41,\n    "PLAYER": "Kyle Monangai",\n    "POS": "RB",\n    "TM": "CHI",\n    "OVR GRADE": 74,\n    "ADP [pos]": 19,\n    "Rook ADP": 45,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "233",\n    "NCAA": "RUT",\n    "AGE": 23.3,\n    "HT": "5\'8\\"",\n    "WT": 211,\n    "40": 4.6,\n    "ATHL": 70,\n    "CL": 2,\n    "FL": 2.5,\n    "PRD GRADE": 74,\n    "EFF GRADE": 64.4,\n    "RR GRD": "NA",\n    "ELU GRADE": 84.5,\n    "FILM GRADE": "NA",\n    "G": 47,\n    "SOS": "NA",\n    "YDS(t)": 3466,\n    "TD(t)": 28,\n    "1D(t)": 123,\n    "YpG(t)": 73.7,\n    "OPP(t)": 721,\n    "IMP": 225,\n    "IMP/ OPP": 0.31,\n    "DMTR": "0.227",\n    "CAR": 670,\n    "ruYDS": 3225,\n    "YPC": 4.8,\n    "ruTD": 27,\n    "ru1D": 190,\n    "MTF/ A": "0.258",\n    "YACO/A": "3.33",\n    "ELU": "0.508",\n    "TGT": 51,\n    "REC": 36,\n    "recYDS": 241,\n    "recTD": 1,\n    "rec1D": 7,\n    "YPRR": 0.52,\n    "YPR": 7,\n    "YAC/R": "NA",\n    "Tier": 6\n  },\n  {\n    "RK": 42,\n    "PLAYER": "Dont\'e Thornton",\n    "POS": "WR",\n    "TM": "LV",\n    "OVR GRADE": 74,\n    "ADP [pos]": 16,\n    "Rook ADP": 41,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "108",\n    "NCAA": "TENN",\n    "AGE": 22.6,\n    "HT": "6\'5\\"",\n    "WT": 205,\n    "40": 4.3,\n    "ATHL": 95,\n    "CL": 4,\n    "FL": 1,\n    "PRD GRADE": 59.5,\n    "EFF GRADE": 75.6,\n    "RR GRD": 69.8,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 42,\n    "SOS": "90.7",\n    "YDS(t)": 1433,\n    "TD(t)": 10,\n    "1D(t)": 43,\n    "YpG(t)": 34.12,\n    "OPP(t)": 95,\n    "IMP": 53,\n    "IMP/ OPP": 0.56,\n    "DMTR": "0.139",\n    "CAR": 1,\n    "ruYDS": 9,\n    "YPC": 9,\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 94,\n    "REC": 65,\n    "recYDS": 1424,\n    "recTD": 10,\n    "rec1D": 43,\n    "YPRR": 2.8,\n    "YPR": 21.9,\n    "YAC/R": 8.94,\n    "Tier": 6\n  },\n  {\n    "RK": 43,\n    "PLAYER": "Tahj Brooks",\n    "POS": "RB",\n    "TM": "CIN",\n    "OVR GRADE": 81,\n    "ADP [pos]": 21,\n    "Rook ADP": 50,\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>⑥</span>",\n    "PK#": "193",\n    "NCAA": "TTU",\n    "AGE": 23.2,\n    "HT": "5\'9\\"",\n    "WT": 214,\n    "40": 4.52,\n    "ATHL": 86,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 91.9,\n    "EFF GRADE": 63.7,\n    "RR GRD": "NA",\n    "ELU GRADE": 87.9,\n    "FILM GRADE": "NA",\n    "G": 53,\n    "SOS": "83",\n    "YDS(t)": 5136,\n    "TD(t)": 47,\n    "1D(t)": 45,\n    "YpG(t)": 96.9,\n    "OPP(t)": 1001,\n    "IMP": 332,\n    "IMP/ OPP": 0.33,\n    "DMTR": "0.226",\n    "CAR": 883,\n    "ruYDS": 4590,\n    "YPC": 5.2,\n    "ruTD": 45,\n    "ru1D": 263,\n    "MTF/ A": "0.266",\n    "YACO/A": "3.18",\n    "ELU": "0.505",\n    "TGT": 118,\n    "REC": 101,\n    "recYDS": 546,\n    "recTD": 2,\n    "rec1D": 22,\n    "YPRR": 0.54,\n    "YPR": 5,\n    "YAC/R": "NA",\n    "Tier": 7\n  },\n  {\n    "RK": 44,\n    "PLAYER": "Tai Felton",\n    "POS": "WR",\n    "TM": "MIN",\n    "OVR GRADE": 82,\n    "ADP [pos]": 18,\n    "Rook ADP": 46,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "102",\n    "NCAA": "MD",\n    "AGE": 22.3,\n    "HT": "6\'1\\"",\n    "WT": 183,\n    "40": 4.37,\n    "ATHL": 86,\n    "CL": 3.5,\n    "FL": 2,\n    "PRD GRADE": 87.8,\n    "EFF GRADE": 74.7,\n    "RR GRD": 78.2,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 43,\n    "SOS": "92.6",\n    "YDS(t)": 2250,\n    "TD(t)": 17,\n    "1D(t)": 108,\n    "YpG(t)": 52.33,\n    "OPP(t)": 267,\n    "IMP": 125,\n    "IMP/ OPP": 0.47,\n    "DMTR": "0.197",\n    "CAR": 3,\n    "ruYDS": 39,\n    "YPC": 13,\n    "ruTD": 0,\n    "ru1D": 2,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 264,\n    "REC": 172,\n    "recYDS": 2211,\n    "recTD": 17,\n    "rec1D": 106,\n    "YPRR": 1.86,\n    "YPR": 12.9,\n    "YAC/R": 6.19,\n    "Tier": 7\n  },\n  {\n    "RK": 45,\n    "PLAYER": "Savion Williams",\n    "POS": "WR",\n    "TM": "GB",\n    "OVR GRADE": 78,\n    "ADP [pos]": 19,\n    "Rook ADP": 49,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "87",\n    "NCAA": "TCU",\n    "AGE": 23.6,\n    "HT": "6\'4\\"",\n    "WT": 222,\n    "40": 4.48,\n    "ATHL": 87,\n    "CL": 3.5,\n    "FL": 1.5,\n    "PRD GRADE": 82.2,\n    "EFF GRADE": 76.6,\n    "RR GRD": 68.8,\n    "ELU GRADE": "NA",\n    "FILM GRADE": 77,\n    "G": 50,\n    "SOS": "78.3",\n    "YDS(t)": 2053,\n    "TD(t)": 20,\n    "1D(t)": 104,\n    "YpG(t)": 41.06,\n    "OPP(t)": 272,\n    "IMP": 124,\n    "IMP/ OPP": 0.46,\n    "DMTR": "0.135",\n    "CAR": 62,\n    "ruYDS": 384,\n    "YPC": 6.19,\n    "ruTD": 6,\n    "ru1D": 22,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 210,\n    "REC": 138,\n    "recYDS": 1669,\n    "recTD": 14,\n    "rec1D": 82,\n    "YPRR": 1.55,\n    "YPR": 12.1,\n    "YAC/R": 5.41,\n    "Tier": 7\n  },\n  {\n    "RK": 46,\n    "PLAYER": "Damien Martinez",\n    "POS": "RB",\n    "TM": "SEA",\n    "OVR GRADE": 81,\n    "ADP [pos]": 22,\n    "Rook ADP": 54,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "223",\n    "NCAA": "MIA",\n    "AGE": 21.4,\n    "HT": "5\'12\\"",\n    "WT": 217,\n    "40": 4.51,\n    "ATHL": 73,\n    "CL": 2,\n    "FL": 2.5,\n    "PRD GRADE": 72.8,\n    "EFF GRADE": 85,\n    "RR GRD": "NA",\n    "ELU GRADE": 88.8,\n    "FILM GRADE": "NA",\n    "G": 38,\n    "SOS": "86.5",\n    "YDS(t)": 3564,\n    "TD(t)": 26,\n    "1D(t)": 144,\n    "YpG(t)": 93.8,\n    "OPP(t)": 566,\n    "IMP": 214,\n    "IMP/ OPP": 0.38,\n    "DMTR": "0.179",\n    "CAR": 516,\n    "ruYDS": 3173,\n    "YPC": 6.1,\n    "ruTD": 26,\n    "ru1D": 172,\n    "MTF/ A": "0.269",\n    "YACO/A": "3.91",\n    "ELU": "0.562",\n    "TGT": 50,\n    "REC": 32,\n    "recYDS": 391,\n    "recTD": 0,\n    "rec1D": 16,\n    "YPRR": 0.73,\n    "YPR": 12,\n    "YAC/R": "NA",\n    "Tier": 7\n  },\n  {\n    "RK": 47,\n    "PLAYER": "Jacory Croskey-Merritt",\n    "POS": "RB",\n    "TM": "WAS",\n    "OVR GRADE": 72,\n    "ADP [pos]": 20,\n    "Rook ADP": 47,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "245",\n    "NCAA": "ARIZ",\n    "AGE": 24.3,\n    "HT": "5\'11\\"",\n    "WT": 208,\n    "40": 4.45,\n    "ATHL": 75,\n    "CL": "2.5",\n    "FL": "1.5",\n    "PRD GRADE": 69.4,\n    "EFF GRADE": 65.3,\n    "RR GRD": "NA",\n    "ELU GRADE": 68.2,\n    "FILM GRADE": "NA",\n    "G": 43,\n    "SOS": "NA",\n    "YDS(t)": 2753,\n    "TD(t)": 31,\n    "1D(t)": 72,\n    "YpG(t)": 64,\n    "OPP(t)": 558,\n    "IMP": 190,\n    "IMP/ OPP": 0.34,\n    "DMTR": "0.227",\n    "CAR": 513,\n    "ruYDS": 2440,\n    "YPC": 4.8,\n    "ruTD": 29,\n    "ru1D": 143,\n    "MTF/ A": "0.250",\n    "YACO/A": "3.23",\n    "ELU": "0.492",\n    "TGT": 45,\n    "REC": 34,\n    "recYDS": 313,\n    "recTD": 2,\n    "rec1D": 16,\n    "YPRR": 0.79,\n    "YPR": 9,\n    "YAC/R": "NA",\n    "Tier": 7\n  },\n  {\n    "RK": 48,\n    "PLAYER": "Jimmy Horn Jr.",\n    "POS": "WR",\n    "TM": "CAR",\n    "OVR GRADE": 72,\n    "ADP [pos]": 17,\n    "Rook ADP": 44,\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>⑥</span>",\n    "PK#": "208",\n    "NCAA": "COLO",\n    "AGE": 22.8,\n    "HT": "5\'8\\"",\n    "WT": 174,\n    "40": 4.46,\n    "ATHL": 71,\n    "CL": 2,\n    "FL": 2,\n    "PRD GRADE": 74.2,\n    "EFF GRADE": 67.2,\n    "RR GRD": 77.3,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 46,\n    "SOS": "NA",\n    "YDS(t)": 2092,\n    "TD(t)": 12,\n    "1D(t)": 92,\n    "YpG(t)": 45.48,\n    "OPP(t)": 258,\n    "IMP": 104,\n    "IMP/ OPP": 0.4,\n    "DMTR": "0.151",\n    "CAR": 16,\n    "ruYDS": 112,\n    "YPC": 7,\n    "ruTD": 1,\n    "ru1D": 7,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 242,\n    "REC": 163,\n    "recYDS": 1980,\n    "recTD": 11,\n    "rec1D": 85,\n    "YPRR": 1.55,\n    "YPR": 12.1,\n    "YAC/R": 7.02,\n    "Tier": 7\n  },\n  {\n    "RK": 49,\n    "PLAYER": "Gunnar Helm",\n    "POS": "TE",\n    "TM": "TEN",\n    "OVR GRADE": 71,\n    "ADP [pos]": 8,\n    "Rook ADP": 48,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "120",\n    "NCAA": "TEX",\n    "AGE": 22.8,\n    "HT": "6\'5\\"",\n    "WT": 241,\n    "40": 4.84,\n    "ATHL": 71,\n    "CL": 3.5,\n    "FL": 3.5,\n    "PRD GRADE": 61.6,\n    "EFF GRADE": 64.9,\n    "RR GRD": 80.4,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 43,\n    "SOS": "89.7",\n    "YDS(t)": 1022,\n    "TD(t)": 9,\n    "1D(t)": 45,\n    "YpG(t)": 23.77,\n    "OPP(t)": 95,\n    "IMP": 54,\n    "IMP/ OPP": 0.57,\n    "DMTR": "0.096",\n    "CAR": 0,\n    "ruYDS": 0,\n    "YPC": "NA",\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 95,\n    "REC": 79,\n    "recYDS": 1022,\n    "recTD": 9,\n    "rec1D": 45,\n    "YPRR": 1.38,\n    "YPR": 12.9,\n    "YAC/R": 6.85,\n    "Tier": 7\n  },\n  {\n    "RK": 50,\n    "PLAYER": "Keandre Lambert-Smith",\n    "POS": "WR",\n    "TM": "LAC",\n    "OVR GRADE": 80,\n    "ADP [pos]": 24,\n    "Rook ADP": 55,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "158",\n    "NCAA": "AUB",\n    "AGE": 22.9,\n    "HT": "6\'1\\"",\n    "WT": 190,\n    "40": 4.37,\n    "ATHL": 87,\n    "CL": 4,\n    "FL": 1.5,\n    "PRD GRADE": 80.1,\n    "EFF GRADE": 80.1,\n    "RR GRD": 71.5,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 58,\n    "SOS": "94.3",\n    "YDS(t)": 2704,\n    "TD(t)": 19,\n    "1D(t)": 115,\n    "YpG(t)": 46.62,\n    "OPP(t)": 285,\n    "IMP": 134,\n    "IMP/ OPP": 0.47,\n    "DMTR": "0.17",\n    "CAR": 1,\n    "ruYDS": 2,\n    "YPC": 2,\n    "ruTD": 0,\n    "ru1D": 1,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 284,\n    "REC": 176,\n    "recYDS": 2702,\n    "recTD": 19,\n    "rec1D": 114,\n    "YPRR": 1.77,\n    "YPR": 15.4,\n    "YAC/R": 7.03,\n    "Tier": 7\n  },\n  {\n    "RK": 51,\n    "PLAYER": "Jaylin Lane",\n    "POS": "WR",\n    "TM": "WAS",\n    "OVR GRADE": 77,\n    "ADP [pos]": 20,\n    "Rook ADP": 50,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "125",\n    "NCAA": "VT",\n    "AGE": 23.2,\n    "HT": "5\'10\\"",\n    "WT": 191,\n    "40": 4.34,\n    "ATHL": 94,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 83,\n    "EFF GRADE": 78.2,\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 54,\n    "SOS": "80.4",\n    "YDS(t)": 2804,\n    "TD(t)": 21,\n    "1D(t)": 133,\n    "YpG(t)": 51.93,\n    "OPP(t)": 340,\n    "IMP": 154,\n    "IMP/ OPP": 0.45,\n    "DMTR": "0.206",\n    "CAR": 46,\n    "ruYDS": 264,\n    "YPC": 5.74,\n    "ruTD": 3,\n    "ru1D": 14,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 294,\n    "REC": 203,\n    "recYDS": 2540,\n    "recTD": 18,\n    "rec1D": 119,\n    "YPRR": 2.01,\n    "YPR": 12.5,\n    "YAC/R": 8.06,\n    "Tier": 8\n  },\n  {\n    "RK": 52,\n    "PLAYER": "Chimere Dike",\n    "POS": "WR",\n    "TM": "TEN",\n    "OVR GRADE": 76,\n    "ADP [pos]": 21,\n    "Rook ADP": 52,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "103",\n    "NCAA": "FLA",\n    "AGE": 23.6,\n    "HT": "6\'1\\"",\n    "WT": 196,\n    "40": 4.34,\n    "ATHL": 91,\n    "CL": 2.5,\n    "FL": 2.5,\n    "PRD GRADE": 72,\n    "EFF GRADE": 65.8,\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 57,\n    "SOS": "91.9",\n    "YDS(t)": 2360,\n    "TD(t)": 12,\n    "1D(t)": 100,\n    "YpG(t)": 41.4,\n    "OPP(t)": 251,\n    "IMP": 112,\n    "IMP/ OPP": 0.45,\n    "DMTR": "0.179",\n    "CAR": 14,\n    "ruYDS": 99,\n    "YPC": 7.07,\n    "ruTD": 1,\n    "ru1D": 5,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 237,\n    "REC": 139,\n    "recYDS": 2261,\n    "recTD": 11,\n    "rec1D": 95,\n    "YPRR": 1.72,\n    "YPR": 16.3,\n    "YAC/R": 5.42,\n    "Tier": 8\n  },\n  {\n    "RK": 53,\n    "PLAYER": "Arian Smith",\n    "POS": "WR",\n    "TM": "NYG",\n    "OVR GRADE": 71,\n    "ADP [pos]": 22,\n    "Rook ADP": 53,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "110",\n    "NCAA": "UGA",\n    "AGE": 22.8,\n    "HT": "6\'0\\"",\n    "WT": 179,\n    "40": 4.36,\n    "ATHL": 88,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 60.3,\n    "EFF GRADE": 65.2,\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 45,\n    "SOS": "NA",\n    "YDS(t)": 1428,\n    "TD(t)": 10,\n    "1D(t)": 49,\n    "YpG(t)": 31.73,\n    "OPP(t)": 121,\n    "IMP": 59,\n    "IMP/ OPP": 0.49,\n    "DMTR": "0.105",\n    "CAR": 9,\n    "ruYDS": 88,\n    "YPC": 9.78,\n    "ruTD": 0,\n    "ru1D": 4,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 112,\n    "REC": 68,\n    "recYDS": 1340,\n    "recTD": 10,\n    "rec1D": 45,\n    "YPRR": 2.27,\n    "YPR": 19.7,\n    "YAC/R": 7.87,\n    "Tier": 8\n  },\n  {\n    "RK": 54,\n    "PLAYER": "Phil Mafah",\n    "POS": "RB",\n    "TM": "DAL",\n    "OVR GRADE": 68,\n    "ADP [pos]": 23,\n    "Rook ADP": 58,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "239",\n    "NCAA": "CLEM",\n    "AGE": 22.7,\n    "HT": "6\'1\\"",\n    "WT": 234,\n    "40": "NA",\n    "ATHL": 75,\n    "CL": "1.5",\n    "FL": "1.0",\n    "PRD GRADE": 72.2,\n    "EFF GRADE": 67.8,\n    "RR GRD": "NA",\n    "ELU GRADE": 61.6,\n    "FILM GRADE": "NA",\n    "G": 50,\n    "SOS": "NA",\n    "YDS(t)": 3204,\n    "TD(t)": 28,\n    "1D(t)": 36,\n    "YpG(t)": 64.1,\n    "OPP(t)": 635,\n    "IMP": 205,\n    "IMP/ OPP": 0.32,\n    "DMTR": "0.153",\n    "CAR": 559,\n    "ruYDS": 2895,\n    "YPC": 5.2,\n    "ruTD": 28,\n    "ru1D": 164,\n    "MTF/ A": "0.199",\n    "YACO/A": "3.47",\n    "ELU": "0.459",\n    "TGT": 76,\n    "REC": 58,\n    "recYDS": 309,\n    "recTD": 0,\n    "rec1D": 13,\n    "YPRR": 0.45,\n    "YPR": 5,\n    "YAC/R": "NA",\n    "Tier": 8\n  },\n  {\n    "RK": 55,\n    "PLAYER": "LeQuint Allen",\n    "POS": "RB",\n    "TM": "JAX",\n    "OVR GRADE": 67,\n    "ADP [pos]": 25,\n    "Rook ADP": 70,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "236",\n    "NCAA": "SYR",\n    "AGE": 20.9,\n    "HT": "6\'0\\"",\n    "WT": 204,\n    "40": "NA",\n    "ATHL": 70,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 76,\n    "EFF GRADE": 58.6,\n    "RR GRD": "NA",\n    "ELU GRADE": 58.3,\n    "FILM GRADE": "NA",\n    "G": 38,\n    "SOS": "78",\n    "YDS(t)": 3232,\n    "TD(t)": 32,\n    "1D(t)": 128,\n    "YpG(t)": 85.1,\n    "OPP(t)": 660,\n    "IMP": 204,\n    "IMP/ OPP": 0.31,\n    "DMTR": "0.227",\n    "CAR": 513,\n    "ruYDS": 2366,\n    "YPC": 4.6,\n    "ruTD": 26,\n    "ru1D": 126,\n    "MTF/ A": "0.234",\n    "YACO/A": "3.19",\n    "ELU": "0.473",\n    "TGT": 147,\n    "REC": 121,\n    "recYDS": 866,\n    "recTD": 6,\n    "rec1D": 46,\n    "YPRR": 1.14,\n    "YPR": 7,\n    "YAC/R": "NA",\n    "Tier": 8\n  },\n  {\n    "RK": 56,\n    "PLAYER": "Tez Johnson",\n    "POS": "WR",\n    "TM": "TB",\n    "OVR GRADE": 80,\n    "ADP [pos]": 23,\n    "Rook ADP": 54,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "235",\n    "NCAA": "ORE",\n    "AGE": 23.2,\n    "HT": "5\'10\\"",\n    "WT": 154,\n    "40": 4.51,\n    "ATHL": 74,\n    "CL": 2,\n    "FL": 1.5,\n    "PRD GRADE": 95.9,\n    "EFF GRADE": 96.3,\n    "RR GRD": 88.8,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 62,\n    "SOS": "88.9",\n    "YDS(t)": 3925,\n    "TD(t)": 29,\n    "1D(t)": 181,\n    "YpG(t)": 63.31,\n    "OPP(t)": 416,\n    "IMP": 210,\n    "IMP/ OPP": 0.5,\n    "DMTR": "0.22",\n    "CAR": 12,\n    "ruYDS": 66,\n    "YPC": 5.5,\n    "ruTD": 1,\n    "ru1D": 3,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 404,\n    "REC": 307,\n    "recYDS": 3859,\n    "recTD": 28,\n    "rec1D": 178,\n    "YPRR": 2.85,\n    "YPR": 12.6,\n    "YAC/R": 7.92,\n    "Tier": 8\n  },\n  {\n    "RK": 57,\n    "PLAYER": "Mitchell Evans",\n    "POS": "TE",\n    "TM": "CAR",\n    "OVR GRADE": 70,\n    "ADP [pos]": 9,\n    "Rook ADP": 58,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "163",\n    "NCAA": "ND",\n    "AGE": 22.3,\n    "HT": "6\'5\\"",\n    "WT": 258,\n    "40": 4.74,\n    "ATHL": 77,\n    "CL": 2,\n    "FL": 2,\n    "PRD GRADE": 59.7,\n    "EFF GRADE": 59.5,\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 42,\n    "SOS": "90.1",\n    "YDS(t)": 913,\n    "TD(t)": 6,\n    "1D(t)": 56,\n    "YpG(t)": 21.74,\n    "OPP(t)": 117,\n    "IMP": 62,\n    "IMP/ OPP": 0.53,\n    "DMTR": "0.076",\n    "CAR": 9,\n    "ruYDS": 13,\n    "YPC": 1.44,\n    "ruTD": 1,\n    "ru1D": 7,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 108,\n    "REC": 77,\n    "recYDS": 900,\n    "recTD": 5,\n    "rec1D": 49,\n    "YPRR": 1.45,\n    "YPR": 11.7,\n    "YAC/R": 4.95,\n    "Tier": 8\n  },\n  {\n    "RK": 58,\n    "PLAYER": "Ricky White",\n    "POS": "WR",\n    "TM": "SEA",\n    "OVR GRADE": 79,\n    "ADP [pos]": 25,\n    "Rook ADP": 59,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "238",\n    "NCAA": "UNLV",\n    "AGE": 23.4,\n    "HT": "6\'1\\"",\n    "WT": 184,\n    "40": 4.61,\n    "ATHL": 69,\n    "CL": 1.5,\n    "FL": 2,\n    "PRD GRADE": 95.9,\n    "EFF GRADE": 88.6,\n    "RR GRD": 82.7,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 43,\n    "SOS": "NA",\n    "YDS(t)": 3369,\n    "TD(t)": 24,\n    "1D(t)": 137,\n    "YpG(t)": 78.35,\n    "OPP(t)": 363,\n    "IMP": 161,\n    "IMP/ OPP": 0.44,\n    "DMTR": "0.377",\n    "CAR": 3,\n    "ruYDS": 5,\n    "YPC": 1.67,\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 360,\n    "REC": 227,\n    "recYDS": 3364,\n    "recTD": 24,\n    "rec1D": 137,\n    "YPRR": 2.69,\n    "YPR": 14.8,\n    "YAC/R": 6.03,\n    "Tier": 8\n  },\n  {\n    "RK": 59,\n    "PLAYER": "Moliki Matavao",\n    "POS": "TE",\n    "TM": "NO",\n    "OVR GRADE": 63,\n    "ADP [pos]": 10,\n    "Rook ADP": 60,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "248",\n    "NCAA": "UCLA",\n    "AGE": 22.3,\n    "HT": "6\'6\\"",\n    "WT": 260,\n    "40": 4.81,\n    "ATHL": 71,\n    "CL": 1.5,\n    "FL": 1.5,\n    "PRD GRADE": 58.1,\n    "EFF GRADE": 58.7,\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 50,\n    "SOS": "NA",\n    "YDS(t)": 1001,\n    "TD(t)": 7,\n    "1D(t)": 46,\n    "YpG(t)": 20.02,\n    "OPP(t)": 111,\n    "IMP": 53,\n    "IMP/ OPP": 0.48,\n    "DMTR": "0.076",\n    "CAR": 1,\n    "ruYDS": 3,\n    "YPC": 3,\n    "ruTD": 1,\n    "ru1D": 1,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 110,\n    "REC": 74,\n    "recYDS": 998,\n    "recTD": 6,\n    "rec1D": 45,\n    "YPRR": 1.5,\n    "YPR": 13.5,\n    "YAC/R": 6.69,\n    "Tier": 8\n  },\n  {\n    "RK": 60,\n    "PLAYER": "Thomas Fidone III",\n    "POS": "TE",\n    "TM": "NYG",\n    "OVR GRADE": 70,\n    "ADP [pos]": 11,\n    "Rook ADP": 62,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "219",\n    "NCAA": "NEB",\n    "AGE": 22.8,\n    "HT": "6\'5\\"",\n    "WT": 243,\n    "40": 4.7,\n    "ATHL": 81,\n    "CL": 2.5,\n    "FL": 2,\n    "PRD GRADE": 55,\n    "EFF GRADE": 55,\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 25,\n    "SOS": "86.6",\n    "YDS(t)": 633,\n    "TD(t)": 4,\n    "1D(t)": 26,\n    "YpG(t)": 25.32,\n    "OPP(t)": 88,\n    "IMP": 30,\n    "IMP/ OPP": 0.34,\n    "DMTR": "0.14",\n    "CAR": 0,\n    "ruYDS": 0,\n    "YPC": "NA",\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 88,\n    "REC": 61,\n    "recYDS": 633,\n    "recTD": 4,\n    "rec1D": 26,\n    "YPRR": 1.32,\n    "YPR": 10.4,\n    "YAC/R": 3.95,\n    "Tier": 8\n  },\n  {\n    "RK": 61,\n    "PLAYER": "Kaden Prather",\n    "POS": "WR",\n    "TM": "BUF",\n    "OVR GRADE": 73,\n    "ADP [pos]": 26,\n    "Rook ADP": 63,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "240",\n    "NCAA": "MD",\n    "AGE": 22.8,\n    "HT": "6\'4\\"",\n    "WT": 204,\n    "40": 4.46,\n    "ATHL": 76,\n    "CL": 1.5,\n    "FL": 1,\n    "PRD GRADE": 80,\n    "EFF GRADE": 66.3,\n    "RR GRD": 69.5,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 45,\n    "SOS": "90.6",\n    "YDS(t)": 1997,\n    "TD(t)": 12,\n    "1D(t)": 103,\n    "YpG(t)": 44.38,\n    "OPP(t)": 258,\n    "IMP": 115,\n    "IMP/ OPP": 0.45,\n    "DMTR": "0.161",\n    "CAR": 2,\n    "ruYDS": 35,\n    "YPC": 17.5,\n    "ruTD": 0,\n    "ru1D": 1,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 256,\n    "REC": 162,\n    "recYDS": 1962,\n    "recTD": 12,\n    "rec1D": 102,\n    "YPRR": 1.52,\n    "YPR": 12.1,\n    "YAC/R": 4.51,\n    "Tier": 8\n  },\n  {\n    "RK": 62,\n    "PLAYER": "LaJohntay Wester",\n    "POS": "WR",\n    "TM": "BAL",\n    "OVR GRADE": 74,\n    "ADP [pos]": 27,\n    "Rook ADP": 64,\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>⑥</span>",\n    "PK#": "203",\n    "NCAA": "COLO",\n    "AGE": 23.3,\n    "HT": "5\'10\\"",\n    "WT": 163,\n    "40": 4.46,\n    "ATHL": 72,\n    "CL": 1.5,\n    "FL": 1,\n    "PRD GRADE": 98,\n    "EFF GRADE": 86.8,\n    "RR GRD": "NA",\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 57,\n    "SOS": "NA",\n    "YDS(t)": 3810,\n    "TD(t)": 33,\n    "1D(t)": 184,\n    "YpG(t)": 66.84,\n    "OPP(t)": 498,\n    "IMP": 217,\n    "IMP/ OPP": 0.44,\n    "DMTR": "0.278",\n    "CAR": 37,\n    "ruYDS": 215,\n    "YPC": 5.81,\n    "ruTD": 2,\n    "ru1D": 11,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 461,\n    "REC": 324,\n    "recYDS": 3595,\n    "recTD": 31,\n    "rec1D": 173,\n    "YPRR": 2.03,\n    "YPR": 11.1,\n    "YAC/R": 5.64,\n    "Tier": 8\n  },\n  {\n    "RK": 63,\n    "PLAYER": "Luke Lachey",\n    "POS": "TE",\n    "TM": "HOU",\n    "OVR GRADE": 69,\n    "ADP [pos]": 12,\n    "Rook ADP": 65,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "255",\n    "NCAA": "IOWA",\n    "AGE": 24,\n    "HT": "6\'6\\"",\n    "WT": 251,\n    "40": "NA",\n    "ATHL": 64,\n    "CL": 2,\n    "FL": 3.5,\n    "PRD GRADE": 57.2,\n    "EFF GRADE": 57.1,\n    "RR GRD": 69.7,\n    "ELU GRADE": "NA",\n    "FILM GRADE": "NA",\n    "G": 41,\n    "SOS": "91.1",\n    "YDS(t)": 877,\n    "TD(t)": 4,\n    "1D(t)": 48,\n    "YpG(t)": 21.39,\n    "OPP(t)": 111,\n    "IMP": 52,\n    "IMP/ OPP": 0.47,\n    "DMTR": "0.142",\n    "CAR": 0,\n    "ruYDS": 0,\n    "YPC": "NA",\n    "ruTD": 0,\n    "ru1D": 0,\n    "MTF/ A": "NA",\n    "YACO/A": "NA",\n    "ELU": "NA",\n    "TGT": 111,\n    "REC": 74,\n    "recYDS": 877,\n    "recTD": 4,\n    "rec1D": 48,\n    "YPRR": 1.37,\n    "YPR": 11.9,\n    "YAC/R": 4.72,\n    "Tier": 8\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicColumnProperties={{ formatByIndex: "auto", labelByIndex: "f" }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      headerTextWrap={true}
      linkedFilterId=""
      primaryKeyColumnId="3220b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      style={{
        headerFontFamily: "Michroma",
        fontWeight: "100",
        border: "rgba(130, 138, 179, 0.2)",
        hoverRowBackground: "rgba(87, 0, 255, 0.4)",
        alternateRowBackground: "rgba(26, 26, 50, 1)",
        background: "rgba(23, 23, 44, 1)",
        cellText: "rgba(255, 255, 255, 1)",
        fontSize: "12px",
        fontFamily: "Product Sans",
        headerFontWeight: "400",
        headerText: "#ffffffff",
        headerBackground: "#141a32",
        headerFontSize: "10px",
      }}
    >
      <Column
        id="d6166"
        alignment="center"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RK"
        label="RK"
        placeholder="Enter value"
        position="left"
        size={51.140625}
        summaryAggregationMode="none"
      />
      <Column
        id="3220b"
        alignment="left"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="PLAYER"
        label="PLAYER"
        placeholder="Enter value"
        position="left"
        size={132.859375}
        summaryAggregationMode="none"
        textColor="{{ currentSourceRow.POS === 'RB' ? '#E9ffE9'
  : currentSourceRow.POS === 'TE' ? '#eedcff'
  : currentSourceRow.POS === 'WR' ? '#d1dfff'
  : '' }}"
      />
      <Column
        id="a5b57"
        alignment="center"
        editableOptions={{ showStepper: true, allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="sum"
        key="Tier"
        label="TIER"
        optionList={{
          manualData: [
            {
              value: 1,
              label: "| Tier 1",
              color: "rgba(0, 0, 0, 0)",
              textColor: "#dfcd87",
              icon: "bold/interface-award-crown",
              caption: "",
            },
            { map: { value: 2 } },
            { map: { value: 3 } },
            { map: { value: 4 } },
            { map: { value: 5 } },
            { map: { value: 6 } },
            { map: { value: 7 } },
            {
              value: 8,
              label: "| Tier 8",
              icon: "bold/interface-delete-bin-2",
              caption: "",
              textColor: "#ff6fe1",
              color: "rgba(72, 72, 72, 0)",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="center"
        size={88}
        summaryAggregationMode="none"
      />
      <Column
        id="f83ae"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              ordered: [
                { value: "QB" },
                { color: "#ff2a6d" },
                { textColor: "rgba(18, 18, 18, 1)" },
                { icon: "" },
                { label: "" },
              ],
            },
            {
              value: "WR",
              color: "rgba(88, 167, 255, 0)",
              textColor: "#58a7ff",
              icon: "bold/computer-connection-usb-port",
            },
            {
              value: "RB",
              icon: "bold/travel-transportation-bus",
              color: "rgba(34, 228, 176, 0)",
              textColor: "#22e4b0",
            },
            {
              value: "TE",
              textColor: "#8300ff",
              color: "rgba(0, 0, 0, 0)",
              icon: "bold/interface-security-shield-4",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="left"
        size={66.859375}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="50caa"
        alignment="center"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="none"
        key="TM"
        label="TM"
        optionList={{
          mode: "mapped",
          mappedData:
            '[\n  { value: "ARI", color: "#97233F", textColor: "#FFB612" },  // red ⟡ yellow :contentReference[oaicite:0]{index=0}\n  { value: "ATL", color: "#A71930", textColor: "#000000" },  // red ⟡ black :contentReference[oaicite:1]{index=1}\n  { value: "BAL", color: "#241773", textColor: "#9E7C0C" },  // purple ⟡ gold :contentReference[oaicite:2]{index=2}\n  { value: "BUF", color: "#00338D", textColor: "#C60C30" },  // royal ⟡ red :contentReference[oaicite:3]{index=3}\n  { value: "CAR", color: "#0085CA", textColor: "#000000" },  // blue ⟡ black :contentReference[oaicite:4]{index=4}\n  { value: "CHI", color: "#0B162A", textColor: "#F63F00" },  // navy ⟡ orange :contentReference[oaicite:5]{index=5}\n  { value: "CIN", color: "#FB3F14", textColor: "#000000" },  // orange ⟡ black :contentReference[oaicite:6]{index=6}\n  { value: "CLE", color: "#DF3C20", textColor: "#101010" },  // orange ⟡ brown :contentReference[oaicite:7]{index=7}\n  { value: "DAL", color: "#003594", textColor: "#A5ACAF" },  // navy ⟡ silver :contentReference[oaicite:8]{index=8}\n  { value: "DEN", color: "#FB2F14", textColor: "#102274" },  // orange ⟡ navy :contentReference[oaicite:9]{index=9}\n  { value: "DET", color: "#0076B6", textColor: "#B0B7BC" },  // honolulu ⟡ silver :contentReference[oaicite:10]{index=10}\n  { value: "GB",  color: "#203731", textColor: "#FFB612" },  // green ⟡ gold :contentReference[oaicite:11]{index=11}\n  { value: "HOU", color: "#03202F", textColor: "#D71930" },  // deep blue ⟡ red :contentReference[oaicite:12]{index=12}\n  { value: "IND", color: "#002C5F", textColor: "#F2FAFD" },  // royal ⟡ gray :contentReference[oaicite:13]{index=13}\n  { value: "JAX", color: "#006778", textColor: "#D7A22A" },  // teal ⟡ gold :contentReference[oaicite:14]{index=14}\n  { value: "KC",  color: "#E31837", textColor: "#FFB612" },  // red ⟡ gold :contentReference[oaicite:15]{index=15}\n  { value: "LAC", color: "#0080C6", textColor: "#FFC20E" },  // powder ⟡ sunshine :contentReference[oaicite:16]{index=16}\n  { value: "LAR", color: "#003594", textColor: "#FFA300" },  // royal ⟡ sol :contentReference[oaicite:17]{index=17}\n  { value: "LV",  color: "#000000", textColor: "#A5ACAF" },  // black ⟡ silver :contentReference[oaicite:18]{index=18}\n  { value: "MIA", color: "#008E87", textColor: "#FC5C02" },  // aqua ⟡ orange :contentReference[oaicite:19]{index=19}\n  { value: "MIN", color: "#4F2683", textColor: "#FFC62F" },  // purple ⟡ gold :contentReference[oaicite:20]{index=20}\n  { value: "NE",  color: "#041E62", textColor: "#D60F51" },  // blue ⟡ red :contentReference[oaicite:21]{index=21}\n  { value: "NO",  color: "#D3BC8D", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:22]{index=22}\n  { value: "NYG", color: "#0B2265", textColor: "#DFDFDF" },  // blue ⟡ red :contentReference[oaicite:23]{index=23}\n  { value: "NYJ", color: "#125740", textColor: "#FFFFFF" },  // green ⟡ white :contentReference[oaicite:24]{index=24}\n  { value: "PHI", color: "#004C54", textColor: "#A5ACAF" },  // midnight ⟡ silver :contentReference[oaicite:25]{index=25}\n  { value: "PIT", color: "#FFB612", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:26]{index=26}\n  { value: "SEA", color: "#002244", textColor: "#69BE28" },  // navy ⟡ action-green :contentReference[oaicite:27]{index=27}\n  { value: "SF",  color: "#AA0000", textColor: "#B3995D" },  // scarlet ⟡ gold :contentReference[oaicite:28]{index=28}\n  { value: "TB",  color: "#D50A0A", textColor: "#0A0A08" },  // red ⟡ pewter :contentReference[oaicite:29]{index=29}\n  { value: "TEN", color: "#0C2340", textColor: "#4B92DB" },  // navy ⟡ titan-blue :contentReference[oaicite:30]{index=30}\n  { value: "WAS", color: "#5A1414", textColor: "#FFB612" },  // burgundy ⟡ gold :contentReference[oaicite:31]{index=31}\n  { value: "UDF", color: "#9E9E9E", textColor: "#FFFFFF" }  // neutral grey\n]',
          valueByIndex: "{{ item.value }}",
          labelByIndex: "{{ item.value }}",
          colorByIndex: "{{ item.color }}",
          textColorByIndex: "{{ item.textColor }}",
        }}
        placeholder="Select option"
        position="left"
        size={62.390625}
        summaryAggregationMode="none"
      />
      <Column
        id="a80e8"
        alignment="center"
        backgroundColor="rgba(75, 0, 255, 0.15)"
        cellTooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 12px #000000 ;\n">\n  Overall Grade<br> ⌁ <b>{{ (() => {\n    const map = {\n      "Ashton Jeanty": 95.7,\n      "Travis Hunter": 93.5,\n      "Omarion Hampton": 89.7,\n      "Tetairoa McMillan": 90.5,\n      "TreVeyon Henderson": 88.1,\n      "Quinshon Judkins": 87.5,\n      "Emeka Egbuka": 89.1,\n      "Tyler Warren": 88.9,\n      "Colston Loveland": 90.1,\n      "R.J. Harvey": 86.2,\n      "Kaleb Johnson": 85.6,\n      "Matthew Golden": 87.1,\n      "Luther Burden": 86.9,\n      "Jayden Higgins": 86.3,\n      "Tre Harris": 86.3,\n      "Jack Bech": 85.7,\n      "Cameron Skattebo": 87.3,\n      "Kyle Williams": 86.9,\n      "Mason Taylor": 74.8,\n      "Bhayshul Tuten": 79.8,\n      "Jaylin Noel": 85.6,\n      "Terrance Ferguson": 77.3,\n      "Jaydon Blue": 74.0,\n      "Elijah Arroyo": 74.1,\n      "Pat Bryant": 79.6,\n      "Dylan Sampson": 81.6,\n      "Harold Fannin Jr.": 86.5,\n      "Jalen Royals": 84.8,\n      "Devin Neal": 81.4,\n      "Trevor Etienne": 79.8,\n      "Elic Ayomanor": 78.0,\n      "Jarquez Hunter": 76.1,\n      "DJ Giddens": 80.7,\n      "Isaac TeSlaa": 74.9,\n      "Jordan James": 76.1,\n      "Ollie Gordon": 73.7,\n      "Jo\'quavious Marks": 69.9,\n      "Dont\'e Thornton": 74.5,\n      "Tory Horton": 84.1,\n      "Brashard Smith": 72.8,\n      "Oronde Gadsden II": 78.7,\n      "Savion Williams": 78.3,\n      "Tahj Brooks": 81.4,\n      "Kyle Monangai": 74.2,\n      "Tai Felton": 81.7,\n      "Chimere Dike": 76.3,\n      "Gunnar Helm": 71.3,\n      "Jaylin Lane": 77.2,\n      "Damien Martinez": 80.9,\n      "Jimmy Horn Jr.": 72.4,\n      "Jacory Croskey-Merritt": 72.1,\n      "Arian Smith": 71.2,\n      "Keandre Lambert-Smith": 79.7,\n      "Tez Johnson": 79.9,\n      "Phil Mafah": 68.0,\n      "LeQuint Allen": 66.7,\n      "Mitchell Evans": 70.5,\n      "Thomas Fidone III": 70.4,\n      "LaJohntay Wester": 74.2,\n      "Ricky White": 79.2,\n      "Moliki Matavao": 62.6,\n      "Kaden Prather": 72.9,\n      "Luke Lachey": 69.2\n    };\n    const v = map[currentSourceRow.PLAYER];\n    return v ?? item;    // Fallback to the cell value if name mismatch\n  })() }}</b> ⌁ \n</div>\n'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "60",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "79",
        }}
        groupAggregationMode="average"
        key="OVR GRADE"
        label="OVR GRD"
        optionList={{
          iconByIndex: "",
          mode: "manual",
          textColorByIndex: "",
          labelByIndex: "",
          valueByIndex: "",
          fallbackTextByIndex: "",
          hiddenByIndex: "",
          captionByIndex: "",
          colorByIndex: "",
          mappedData: "[]",
        }}
        placeholder="Enter value"
        position="center"
        size={106.34375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item >89}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(231, 255, 248, 0.03)",
              tooltip: "",
            },
            {
              showWhen: "{{item >80}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(0, 109, 242, 0.03)",
            },
            {
              showWhen: "{{item >75}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(124, 83, 204, 0.03)",
            },
            {
              showWhen: "true",
              label: "{{ item }}",
              icon: "",
              color: "rgba(68, 76, 87, 0.03)",
            },
          ],
        }}
        summaryAggregationMode="none"
      />
      <Column
        id="8d7b5"
        alignment="center"
        backgroundColor="rgba(198, 104, 242, 0.06)"
        format="string"
        groupAggregationMode="none"
        headerBackgroundColor="rgb(44, 33, 68)"
        key="ADP [pos]"
        label="R–ADP ⌊ʀᴏᴏᴋɪᴇ⌉"
        placeholder="Enter value"
        position="center"
        size={83.84375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nRookie ADP by Position\n</div>'
        }
      />
      <Column
        id="328dc"
        alignment="center"
        backgroundColor="rgba(198, 104, 242, 0.06)"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(44, 33, 68)"
        key="Rook ADP"
        label="ADP Ⓡ   "
        placeholder="Enter value"
        position="center"
        size={63.21875}
        summaryAggregationMode="none"
      />
      <Column
        id="62082"
        alignment="center"
        backgroundColor="rgba(104, 141, 243, 0.05)"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RD"
        label="RD 📶"
        placeholder="Enter value"
        position="center"
        size={54.9375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "",
              label: "",
              color: "rgba(135, 230, 179, 1)",
              icon: "bold/interface-arrows-up-alternate",
            },
            {
              showWhen: "{{ item < 7 }}",
              label: "",
              color: "#F8DBD8",
              icon: "bold/money-graph-arrow-decrease",
            },
            {
              showWhen: "{{ item > 6 }}",
              label: "",
              color: "rgba(236, 116, 154, 1)",
              icon: "bold/interface-arrows-down-alternate",
            },
            {
              showWhen: "{{ item < 5 }}",
              label: "",
              color: "#D7EAE0",
              icon: "bold/money-graph-arrow-increase",
            },
          ],
        }}
        summaryAggregationMode="none"
      />
      <Column
        id="95105"
        alignment="center"
        backgroundColor="rgba(104, 141, 243, 0.05)"
        cellTooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n   font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 12px #000000 ;\n">\nPick Drafted<br> ⌁ <b>{{item}}</b> ⌁ \n</div>\n\n'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "", color: "" }}
        groupAggregationMode="sum"
        key="PK#"
        label="PK"
        placeholder="Enter value"
        position="center"
        size={69.9375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item <33}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(196, 253, 234, 0.15)",
              tooltip: "",
            },
            {
              showWhen: "{{item < 68}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(186, 255, 255, 0.15)",
            },
            {
              showWhen: "{{item < 90}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(186, 243, 255, 0.15)",
            },
            {
              showWhen: "{{item < 130}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(229, 205, 255, 0.3)",
            },
            {
              showWhen: "{{item >190}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(251, 164, 234, 1)",
            },
            {
              showWhen: "{{item >130}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(232, 177, 250, 0.5)",
              tooltip: "",
            },
            { showWhen: "{{item}}", label: "UD", icon: "" },
          ],
        }}
        summaryAggregationMode="none"
        textColor="{{ theme.danger }}"
      />
      <Column
        id="41f3f"
        alignment="center"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="NCAA"
        label="NCAA"
        placeholder="Enter value"
        position="center"
        size={61.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="53da5"
        alignment="center"
        editable="false"
        format="multilineString"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
        textColor="rgba(255, 255, 255, 1)"
      />
      <Column
        id="7a71b"
        alignment="center"
        format="string"
        formatOptions={{ automaticColors: true, notation: "standard" }}
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={46.03125}
        summaryAggregationMode="none"
      />
      <Column
        id="f718d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={47.875}
        summaryAggregationMode="none"
      />
      <Column
        id="05e56"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="40"
        label="40"
        placeholder="Enter value"
        position="center"
        size={46.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="cf84f"
        alignment="left"
        backgroundColor="rgba(0, 224, 255, 0.03)"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\nAthletic Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="average"
        key="ATHL"
        label="ATHL GRD"
        placeholder="Enter value"
        position="center"
        size={78.6875}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item > 85}}",
              label: "{{ item }}",
              icon: "bold/shopping-business-startup",
              color: "rgba(190, 254, 234, 0.17)",
            },
            {
              showWhen: "{{item < 76}}",
              label: "{{item}}",
              icon: "bold/phone-signal-low",
              color: "rgba(255, 178, 214, 0.15)",
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{item}}",
              icon: "bold/mail-send-email",
              color: "rgba(224, 245, 255, 0.2)",
            },
          ],
        }}
        summaryAggregationMode="none"
      />
      <Column
        id="4bffd"
        alignment="center"
        backgroundColor="rgba(63, 1, 255, 0.1)"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nCEILING ⌁ <b>{{item}}/5</b> \n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="rating"
        formatOptions={{ icon: "", size: "small", icons: "stars" }}
        groupAggregationMode="average"
        key="CL"
        label="CEILING"
        placeholder="Enter value"
        position="center"
        size={109}
        summaryAggregationMode="none"
      />
      <Column
        id="5b01a"
        alignment="center"
        backgroundColor="rgba(131, 0, 255, 0.1)"
        cellTooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nFLOOR ⌁ <b>{{item}}/5</b>\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="rating"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          size: "small",
          icons: "stars",
        }}
        groupAggregationMode="sum"
        key="FL"
        label="FLOOR"
        placeholder="Enter value"
        position="center"
        size={107.25}
        summaryAggregationMode="none"
      />
      <Column
        id="93ad9"
        alignment="center"
        backgroundColor="rgba(0, 224, 255, 0.03)"
        caption="• {{ item }} •"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProduction Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "55",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "75",
        }}
        groupAggregationMode="average"
        key="PRD GRADE"
        label="PRD GRD"
        placeholder="Enter value"
        position="center"
        size={67.09375}
        summaryAggregationMode="none"
      />
      <Column
        id="d91e6"
        alignment="center"
        backgroundColor="rgba(0, 224, 255, 0.03)"
        caption="• {{ item }} •"
        cellTooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nEfficiency Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "50",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "75",
        }}
        groupAggregationMode="average"
        key="EFF GRADE"
        label="EFF GRD"
        placeholder="Enter value"
        position="center"
        size={69.671875}
        summaryAggregationMode="none"
      />
      <Column
        id="bf9a4"
        alignment="left"
        cellTooltip="{{ item }}"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="sum"
        key="ELU GRADE"
        label="ELU GRD"
        placeholder="Enter value"
        position="center"
        size={80.890625}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{ item > 85}}",
              label: "{{ item }}",
              icon: "bold/nature-ecology-comet",
              color: "rgba(190, 254, 234, 0.17)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nElusiveness Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{ item }}",
              icon: "bold/interface-arrows-shuffle",
              color: "rgba(224, 245, 255, 0.2)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nElusiveness Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item < 75}}",
              label: "{{ item }}",
              icon: "bold/interface-weather-humidity-none",
              color: "rgba(255, 178, 214, 0.15)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nElusiveness Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "true",
              label: "{{item}}",
              icon: "bold/interface-block",
              color: "rgba(224, 224, 224, 0.1)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\n <b>N/A</b> ⌁ [RB–ONLY Metric]\n</div>',
            },
          ],
        }}
        summaryAggregationMode="none"
      />
      <Column
        id="a6c5e"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        key="RR GRD"
        label="RR GRD"
        placeholder="Enter value"
        position="center"
        size={82}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{ item > 85}} ",
              label: "{{item}}",
              icon: "bold/interface-arrows-bend-up-right-1-alternate",
              color: "rgba(190, 254, 234, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{item}}",
              icon: "bold/interface-arrows-bend-up-right-2-alternate",
              color: "rgba(224, 245, 255, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item < 75}}",
              label: "{{item}}",
              icon: "bold/interface-arrows-up-alternate",
              color: "rgba(255, 178, 214, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{ item == 'NA' }}",
              label: "{{ item }}",
              icon: "bold/interface-block",
              color: "rgba(160, 160, 160, 0.1)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\n <b>N/A</b> ⌁ [WR/TE–ONLY Metric]\n</div>',
            },
          ],
        }}
        summaryAggregationMode="none"
      />
      <Column
        id="65b64"
        alignment="left"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="sum"
        key="FILM GRADE"
        label="FILM 
GRD"
        placeholder="Enter value"
        position="center"
        size={77.609375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item > 85}}",
              label: "{{ item }}",
              icon: "bold/entertainment-camera-video",
              color: "rgba(190, 254, 234, 0.17)",
            },
            {
              showWhen: "{{  item > 78}}",
              label: "{{ item }}",
              icon: "bold/computer-connection-video-camera",
              color: "rgba(224, 245, 255, 0.2)",
            },
            {
              showWhen: "{{item < 79}}",
              label: "{{ item }}",
              icon: "bold/entertainment-recording-tape-1",
              color: "rgba(255, 178, 214, 0.15)",
            },
            {
              showWhen: "true",
              label: "{{item}}",
              icon: "bold/interface-page-controller-loading-half",
              color: "rgba(227, 223, 223, 0.1)",
            },
          ],
        }}
        summaryAggregationMode="none"
      />
      <Column
        id="6beae"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="G"
        label="G"
        placeholder="Enter value"
        position="center"
        size={37.6875}
        summaryAggregationMode="none"
      />
      <Column
        id="571eb"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="SOS"
        label="SOS"
        placeholder="Enter value"
        position="center"
        size={53}
        summaryAggregationMode="none"
      />
      <Column
        id="e9438"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(32, 20, 75)"
        key="YDS(t)"
        label="YDS ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={64.734375}
        summaryAggregationMode="none"
      />
      <Column
        id="37293"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(32, 20, 75)"
        key="TD(t)"
        label="TD
 ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={50.25}
        summaryAggregationMode="none"
      />
      <Column
        id="7ab93"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#20144b"
        key="1D(t)"
        label="1D
⌈t⌋"
        placeholder="Enter value"
        position="center"
        size={55}
        summaryAggregationMode="none"
      />
      <Column
        id="25637"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#20144b"
        key="YpG(t)"
        label="YpG 
⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={58.453125}
        summaryAggregationMode="none"
      />
      <Column
        id="00b31"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(32, 20, 75)"
        key="OPP(t)"
        label="OPP"
        placeholder="Enter value"
        position="center"
        size={58.15625}
        summaryAggregationMode="none"
      />
      <Column
        id="45011"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#20144b"
        key="IMP"
        label="IMP"
        placeholder="Enter value"
        position="center"
        size={57.484375}
        summaryAggregationMode="none"
      />
      <Column
        id="3ce33"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#20144b"
        key="IMP/ OPP"
        label="IMP/OPP"
        placeholder="Enter value"
        position="center"
        size={83.84375}
        summaryAggregationMode="none"
      />
      <Column
        id="4c58c"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="DMTR"
        label="DMTR"
        placeholder="Enter value"
        position="center"
        size={66.890625}
        summaryAggregationMode="none"
      />
      <Column
        id="89a9d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="CAR"
        label="CAR"
        placeholder="Enter value"
        position="center"
        size={52.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="1ed57"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="ruYDS"
        label="YDS ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={58.3125}
        summaryAggregationMode="none"
      />
      <Column
        id="c7beb"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        key="YPC"
        label="YPC"
        placeholder="Enter value"
        position="center"
        size={51.71875}
        summaryAggregationMode="none"
      />
      <Column
        id="bb829"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="ruTD"
        label="TD  ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={59.953125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nRushing Touchdowns\n</div>'
        }
      />
      <Column
        id="3dd7a"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="ru1D"
        label="1D ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={53.515625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nRushing First Downs\n</div>'
        }
      />
      <Column
        id="8a9ca"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "3",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        key="MTF/ A"
        label="MTF/A"
        placeholder="Enter value"
        position="center"
        size={65.984375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nMissed Tackles Forced per Attempt\n</div>'
        }
      />
      <Column
        id="bc182"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        key="YACO/A"
        label="YACO/A"
        placeholder="Enter value"
        position="center"
        size={73.953125}
        summaryAggregationMode="none"
      />
      <Column
        id="76cd8"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "3",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        key="ELU"
        label="ELU"
        placeholder="Enter value"
        position="center"
        size={51.78125}
        summaryAggregationMode="none"
      />
      <Column
        id="3620d"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(21, 36, 66)"
        key="TGT"
        label="TGT"
        placeholder="Enter value"
        position="center"
        size={56}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTargets\n</div>'
        }
      />
      <Column
        id="38694"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#152442"
        key="REC"
        label="REC"
        placeholder="Enter value"
        position="center"
        size={59}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nReceptions\n</div>'
        }
      />
      <Column
        id="db7c4"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(21, 36, 66)"
        key="recYDS"
        label="YDS
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={51.140625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [Receiving]\n</div>'
        }
      />
      <Column
        id="e7cf5"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(21, 36, 66)"
        key="recTD"
        label="TD
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={50.9375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [Receiving]\n</div>'
        }
      />
      <Column
        id="23e31"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#152442"
        key="rec1D"
        label="1D
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={67}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nFirst Downs [Receiving]\n</div>'
        }
      />
      <Column
        id="c40d1"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#152442"
        key="YPRR"
        label="YPRR"
        placeholder="Enter value"
        position="center"
        size={68}
        summaryAggregationMode="none"
        textColor="{{
(() => {
 const v = parseFloat(String(item).replace(/[^0-9.-]/g, ''));
 if (!isFinite(v)) return null;
 const rules = [
  [2.7, '#00ffc4'],
  [2.4, '#85fff3'],
  [2.3, '#7dd1ff'],
  [2.1, '#957cff'],
  [1.9, '#a642ff'],
  [1.7, '#cf60ff'],
  [1.5, '#ff6fe1'],
 ];
 for (const [t, c] of rules) if (v >= t) return c;
 return '#ff2eb2';
})()
}}"
      />
      <Column
        id="fe787"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#152442"
        key="YPR"
        label="YPR"
        placeholder="Enter value"
        position="center"
        size={69}
        summaryAggregationMode="none"
      />
      <Column
        id="fd480"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#152442"
        key="YAC/R"
        label="YAC/REC"
        placeholder="Enter value"
        position="center"
        size={83}
        summaryAggregationMode="none"
      />
      <Event
        event="selectRow"
        method=""
        params={{}}
        pluginId=""
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Table>
  </View>
  <View
    id="87617"
    disabled={false}
    hidden={false}
    icon="bold/travel-map-location-target-1"
    iconPosition="left"
    viewKey="QB"
  >
    <Table
      id="table72"
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "RK": "1",\n    "PLAYER": "Ashton Jeanty",\n    "POS": "RB",\n    "NFL": "LV",\n    "PK#": "6",\n    "RD": "1",\n    "NCAA": "BOIS",\n    "AGE": "21.3",\n    "HT": "5\'8\\"",\n    "WT": "211",\n    "ATHL": "89.00",\n    "40": null,\n    "PRD GRADE": "95.09",\n    "EFF GRADE": "94.33",\n    "ELU GRADE": "98.11",\n    "FILM GRADE": "98.0",\n    "OVR GRADE": "95.7",\n    "G": "40",\n    "YDS(t)": "5631",\n    "YpG(t)": "141",\n    "OPP(t)": "847",\n    "TD(t)": "56",\n    "1D(t)": "268"\n  },\n  {\n    "RK": "2",\n    "PLAYER": "Omarion Hampton",\n    "POS": "RB",\n    "NFL": "LAC",\n    "PK#": "22",\n    "RD": "1",\n    "NCAA": "UNC",\n    "AGE": "22.0",\n    "HT": "5\'12\\"",\n    "WT": "221",\n    "ATHL": "89.00",\n    "40": "4.46",\n    "PRD GRADE": "86.21",\n    "EFF GRADE": "82.77",\n    "ELU GRADE": "86.42",\n    "FILM GRADE": "86.0",\n    "OVR GRADE": "89.7",\n    "G": "38",\n    "YDS(t)": "4200",\n    "YpG(t)": "111",\n    "OPP(t)": "702",\n    "TD(t)": "40",\n    "1D(t)": "208"\n  },\n  {\n    "RK": "3",\n    "PLAYER": "TreVeyon Henderson",\n    "POS": "RB",\n    "NFL": "NE",\n    "PK#": "38",\n    "RD": "2",\n    "NCAA": "OSU",\n    "AGE": "22.4",\n    "HT": "5\'10\\"",\n    "WT": "202",\n    "ATHL": "94.00",\n    "40": "4.43",\n    "PRD GRADE": "89.56",\n    "EFF GRADE": "88.27",\n    "ELU GRADE": "76.15",\n    "FILM GRADE": "84.0",\n    "OVR GRADE": "87.7",\n    "G": "47",\n    "YDS(t)": "4614",\n    "YpG(t)": "98",\n    "OPP(t)": "678",\n    "TD(t)": "48",\n    "1D(t)": "200"\n  },\n  {\n    "RK": "4",\n    "PLAYER": "Cam Skattebo",\n    "POS": "RB",\n    "NFL": "NYG",\n    "PK#": "105",\n    "RD": "4",\n    "NCAA": "ARIZST",\n    "AGE": "23.1",\n    "HT": "5\'10\\"",\n    "WT": "219",\n    "ATHL": "77.00",\n    "40": null,\n    "PRD GRADE": "94.89",\n    "EFF GRADE": "86.87",\n    "ELU GRADE": "92.69",\n    "FILM GRADE": "85.0",\n    "OVR GRADE": "88.3",\n    "G": "46",\n    "YDS(t)": "5772",\n    "YpG(t)": "125",\n    "OPP(t)": "794",\n    "TD(t)": "51",\n    "1D(t)": "187"\n  },\n  {\n    "RK": "5",\n    "PLAYER": "Quinshon Judkins",\n    "POS": "RB",\n    "NFL": "CLE",\n    "PK#": "36",\n    "RD": "2",\n    "NCAA": "OSU",\n    "AGE": "21.4",\n    "HT": "5\'12\\"",\n    "WT": "221",\n    "ATHL": "95.00",\n    "40": "4.48",\n    "PRD GRADE": "89.33",\n    "EFF GRADE": "87.30",\n    "ELU GRADE": "76.01",\n    "FILM GRADE": "82.0",\n    "OVR GRADE": "86.9",\n    "G": "42",\n    "YDS(t)": "4227",\n    "YpG(t)": "101",\n    "OPP(t)": "808",\n    "TD(t)": "50",\n    "1D(t)": "244"\n  },\n  {\n    "RK": "6",\n    "PLAYER": "Kaleb Johnson",\n    "POS": "RB",\n    "NFL": "PIT",\n    "PK#": "83",\n    "RD": "3",\n    "NCAA": "IOWA",\n    "AGE": "21.6",\n    "HT": "6\'1\\"",\n    "WT": "224",\n    "ATHL": "79.00",\n    "40": "4.57",\n    "PRD GRADE": "67.64",\n    "EFF GRADE": "70.00",\n    "ELU GRADE": "82.11",\n    "FILM GRADE": "76.0",\n    "OVR GRADE": "81.6",\n    "G": "35",\n    "YDS(t)": "3019",\n    "YpG(t)": "86",\n    "OPP(t)": "543",\n    "TD(t)": "32",\n    "1D(t)": "124"\n  },\n  {\n    "RK": "7",\n    "PLAYER": "Devin Neal",\n    "POS": "RB",\n    "NFL": "NO",\n    "PK#": "184",\n    "RD": "6",\n    "NCAA": "KU",\n    "AGE": "21.6",\n    "HT": "5\'11\\"",\n    "WT": "213",\n    "ATHL": "68.00",\n    "40": "4.58",\n    "PRD GRADE": "92.11",\n    "EFF GRADE": "80.78",\n    "ELU GRADE": "68.23",\n    "FILM GRADE": "78.0",\n    "OVR GRADE": "81.4",\n    "G": "49",\n    "YDS(t)": "5054",\n    "YpG(t)": "103",\n    "OPP(t)": "861",\n    "TD(t)": "53",\n    "1D(t)": "244"\n  },\n  {\n    "RK": "8",\n    "PLAYER": "RJ Harvey",\n    "POS": "RB",\n    "NFL": "DEN",\n    "PK#": "60",\n    "RD": "2",\n    "NCAA": "UCF",\n    "AGE": "24.1",\n    "HT": "5\'8\\"",\n    "WT": "205",\n    "ATHL": "89.00",\n    "40": "4.4",\n    "PRD GRADE": "88.32",\n    "EFF GRADE": "90.23",\n    "ELU GRADE": "89.60",\n    "FILM GRADE": "79.0",\n    "OVR GRADE": "84.2",\n    "G": "41",\n    "YDS(t)": "4512",\n    "YpG(t)": "110",\n    "OPP(t)": "657",\n    "TD(t)": "47",\n    "1D(t)": "225"\n  },\n  {\n    "RK": "9",\n    "PLAYER": "DJ Giddens",\n    "POS": "RB",\n    "NFL": "IND",\n    "PK#": "151",\n    "RD": "5",\n    "NCAA": "KSU",\n    "AGE": "21.6",\n    "HT": "6\'0\\"",\n    "WT": "212",\n    "ATHL": "85.00",\n    "40": "4.43",\n    "PRD GRADE": "73.92",\n    "EFF GRADE": "82.65",\n    "ELU GRADE": "86.94",\n    "FILM GRADE": "70.0",\n    "OVR GRADE": "80.7",\n    "G": "39",\n    "YDS(t)": "3766",\n    "YpG(t)": "97",\n    "OPP(t)": "600",\n    "TD(t)": "27",\n    "1D(t)": "182"\n  },\n  {\n    "RK": "10",\n    "PLAYER": "Dylan Sampson",\n    "POS": "RB",\n    "NFL": "CLE",\n    "PK#": "126",\n    "RD": "4",\n    "NCAA": "TENN",\n    "AGE": "20.5",\n    "HT": "5\'8\\"",\n    "WT": "200",\n    "ATHL": "80.00",\n    "40": null,\n    "PRD GRADE": "70.41",\n    "EFF GRADE": "85.35",\n    "ELU GRADE": "82.46",\n    "FILM GRADE": "85.0",\n    "OVR GRADE": "81.6",\n    "G": "35",\n    "YDS(t)": "2834",\n    "YpG(t)": "81",\n    "OPP(t)": "472",\n    "TD(t)": "36",\n    "1D(t)": "149"\n  },\n  {\n    "RK": "11",\n    "PLAYER": "Damien Martinez",\n    "POS": "RB",\n    "NFL": "SEA",\n    "PK#": "223",\n    "RD": "7",\n    "NCAA": "MIA",\n    "AGE": "21.2",\n    "HT": "5\'12\\"",\n    "WT": "217",\n    "ATHL": "73.00",\n    "40": "4.51",\n    "PRD GRADE": "72.78",\n    "EFF GRADE": "84.99",\n    "ELU GRADE": "88.83",\n    "FILM GRADE": null,\n    "OVR GRADE": "80.9",\n    "G": "38",\n    "YDS(t)": "3560",\n    "YpG(t)": "94",\n    "OPP(t)": "564",\n    "TD(t)": "26",\n    "1D(t)": "188"\n  },\n  {\n    "RK": "12",\n    "PLAYER": "Tahj Brooks",\n    "POS": "RB",\n    "NFL": "CIN",\n    "PK#": "193",\n    "RD": "6",\n    "NCAA": "TTU",\n    "AGE": "22.9",\n    "HT": "5\'9\\"",\n    "WT": "214",\n    "ATHL": "86.00",\n    "40": "4.52",\n    "PRD GRADE": "91.90",\n    "EFF GRADE": "63.67",\n    "ELU GRADE": "87.90",\n    "FILM GRADE": null,\n    "OVR GRADE": "81.4",\n    "G": "56",\n    "YDS(t)": "5105",\n    "YpG(t)": "91",\n    "OPP(t)": "982",\n    "TD(t)": "47",\n    "1D(t)": "264"\n  },\n  {\n    "RK": "13",\n    "PLAYER": "Bhayshul Tuten",\n    "POS": "RB",\n    "NFL": "JAX",\n    "PK#": "104",\n    "RD": "4",\n    "NCAA": "VT",\n    "AGE": "22.1",\n    "HT": "5\'9\\"",\n    "WT": "206",\n    "ATHL": "94.00",\n    "40": "4.32",\n    "PRD GRADE": "61.92",\n    "EFF GRADE": "75.27",\n    "ELU GRADE": "90.20",\n    "FILM GRADE": "79.0",\n    "OVR GRADE": "79.8",\n    "G": "24",\n    "YDS(t)": "2342",\n    "YpG(t)": "98",\n    "OPP(t)": "422",\n    "TD(t)": "29",\n    "1D(t)": "103"\n  },\n  {\n    "RK": "14",\n    "PLAYER": "Trevor Etienne",\n    "POS": "RB",\n    "NFL": "CAR",\n    "PK#": "114",\n    "RD": "4",\n    "NCAA": "UGA",\n    "AGE": "20.7",\n    "HT": "5\'9\\"",\n    "WT": "198",\n    "ATHL": "83.00",\n    "40": "4.42",\n    "PRD GRADE": "63.40",\n    "EFF GRADE": "71.87",\n    "ELU GRADE": "86.73",\n    "FILM GRADE": "79.0",\n    "OVR GRADE": "79.8",\n    "G": "34",\n    "YDS(t)": "2513",\n    "YpG(t)": "74",\n    "OPP(t)": "434",\n    "TD(t)": "24",\n    "1D(t)": "123"\n  },\n  {\n    "RK": "15",\n    "PLAYER": "Ollie Gordon II",\n    "POS": "RB",\n    "NFL": "MIA",\n    "PK#": "179",\n    "RD": "6",\n    "NCAA": "OKST",\n    "AGE": "21.2",\n    "HT": "6\'1\\"",\n    "WT": "226",\n    "ATHL": "68.00",\n    "40": "4.61",\n    "PRD GRADE": "81.90",\n    "EFF GRADE": "70.82",\n    "ELU GRADE": "64.92",\n    "FILM GRADE": "78.0",\n    "OVR GRADE": "73.7",\n    "G": "39",\n    "YDS(t)": "3505",\n    "YpG(t)": "90",\n    "OPP(t)": "640",\n    "TD(t)": "40",\n    "1D(t)": "177"\n  },\n  {\n    "RK": "16",\n    "PLAYER": "Jordan James",\n    "POS": "RB",\n    "NFL": "SF",\n    "PK#": "147",\n    "RD": "5",\n    "NCAA": "ORE",\n    "AGE": "21.0",\n    "HT": "5\'10\\"",\n    "WT": "205",\n    "ATHL": "71.00",\n    "40": "4.55",\n    "PRD GRADE": "78.25",\n    "EFF GRADE": "81.36",\n    "ELU GRADE": "69.89",\n    "FILM GRADE": null,\n    "OVR GRADE": "76.1",\n    "G": "38",\n    "YDS(t)": "2562",\n    "YpG(t)": "67",\n    "OPP(t)": "439",\n    "TD(t)": "32",\n    "1D(t)": "165"\n  },\n  {\n    "RK": "17",\n    "PLAYER": "Brashard Smith",\n    "POS": "RB",\n    "NFL": "KC",\n    "PK#": "228",\n    "RD": "7",\n    "NCAA": "SMU",\n    "AGE": "22.0",\n    "HT": "5\'10\\"",\n    "WT": "194",\n    "ATHL": "79.00",\n    "40": "4.39",\n    "PRD GRADE": "66.55",\n    "EFF GRADE": "81.83",\n    "ELU GRADE": "59.96",\n    "FILM GRADE": null,\n    "OVR GRADE": "72.8",\n    "G": "49",\n    "YDS(t)": "2606",\n    "YpG(t)": "53",\n    "OPP(t)": "393",\n    "TD(t)": "23",\n    "1D(t)": "126"\n  },\n  {\n    "RK": "18",\n    "PLAYER": "Jaydon Blue",\n    "POS": "RB",\n    "NFL": "DAL",\n    "PK#": "149",\n    "RD": "5",\n    "NCAA": "TEX",\n    "AGE": "21.2",\n    "HT": "5\'9\\"",\n    "WT": "196",\n    "ATHL": "89.00",\n    "40": "4.38",\n    "PRD GRADE": "57.50",\n    "EFF GRADE": "68.83",\n    "ELU GRADE": "76.50",\n    "FILM GRADE": null,\n    "OVR GRADE": "74.0",\n    "G": "38",\n    "YDS(t)": "1664",\n    "YpG(t)": "44",\n    "OPP(t)": "288",\n    "TD(t)": "18",\n    "1D(t)": "83"\n  },\n  {\n    "RK": "19",\n    "PLAYER": "LeQuint Allen",\n    "POS": "RB",\n    "NFL": "JAX",\n    "PK#": "236",\n    "RD": "7",\n    "NCAA": "SYR",\n    "AGE": "20.6",\n    "HT": "6\'0\\"",\n    "WT": "204",\n    "ATHL": "70.00",\n    "40": null,\n    "PRD GRADE": "75.97",\n    "EFF GRADE": "58.63",\n    "ELU GRADE": "58.31",\n    "FILM GRADE": null,\n    "OVR GRADE": "66.7",\n    "G": "39",\n    "YDS(t)": "3207",\n    "YpG(t)": "82",\n    "OPP(t)": "660",\n    "TD(t)": "32",\n    "1D(t)": "172"\n  },\n  {\n    "RK": "20",\n    "PLAYER": "Raheim Sanders",\n    "POS": "RB",\n    "NFL": null,\n    "PK#": null,\n    "RD": null,\n    "NCAA": "SCAR",\n    "AGE": "21.8",\n    "HT": "6\'0\\"",\n    "WT": "217",\n    "ATHL": "71.00",\n    "40": "4.46",\n    "PRD GRADE": "82.28",\n    "EFF GRADE": "70.82",\n    "ELU GRADE": "81.13",\n    "FILM GRADE": null,\n    "OVR GRADE": "77.3",\n    "G": "44",\n    "YDS(t)": "3882",\n    "YpG(t)": "88",\n    "OPP(t)": "667",\n    "TD(t)": "33",\n    "1D(t)": "199"\n  },\n  {\n    "RK": "21",\n    "PLAYER": "Jarquez Hunter",\n    "POS": "RB",\n    "NFL": "LAR",\n    "PK#": "117",\n    "RD": "4",\n    "NCAA": "AUB",\n    "AGE": "22.3",\n    "HT": "5\'9\\"",\n    "WT": "204",\n    "ATHL": "71.00",\n    "40": "4.44",\n    "PRD GRADE": "79.06",\n    "EFF GRADE": "80.31",\n    "ELU GRADE": "90.10",\n    "FILM GRADE": null,\n    "OVR GRADE": "76.1",\n    "G": "49",\n    "YDS(t)": "3929",\n    "YpG(t)": "80",\n    "OPP(t)": "629",\n    "TD(t)": "29",\n    "1D(t)": "190"\n  },\n  {\n    "RK": "22",\n    "PLAYER": "Woody Marks",\n    "POS": "RB",\n    "NFL": "HOU",\n    "PK#": "116",\n    "RD": "4",\n    "NCAA": "USC",\n    "AGE": "24.2",\n    "HT": "5\'10\\"",\n    "WT": "207",\n    "ATHL": "76.00",\n    "40": "4.54",\n    "PRD GRADE": "85.40",\n    "EFF GRADE": "59.22",\n    "ELU GRADE": "55.00",\n    "FILM GRADE": null,\n    "OVR GRADE": "69.9",\n    "G": "57",\n    "YDS(t)": "4562",\n    "YpG(t)": "80",\n    "OPP(t)": "840",\n    "TD(t)": "36",\n    "1D(t)": "218"\n  },\n  {\n    "RK": "23",\n    "PLAYER": "Kyle Monangai",\n    "POS": "RB",\n    "NFL": "CHI",\n    "PK#": "233",\n    "RD": "7",\n    "NCAA": "RUT",\n    "AGE": "23.0",\n    "HT": "5\'8\\"",\n    "WT": "211",\n    "ATHL": "70.00",\n    "40": "4.6",\n    "PRD GRADE": "73.96",\n    "EFF GRADE": "64.40",\n    "ELU GRADE": "84.52",\n    "FILM GRADE": null,\n    "OVR GRADE": "74.2",\n    "G": "52",\n    "YDS(t)": "3474",\n    "YpG(t)": "67",\n    "OPP(t)": "720",\n    "TD(t)": "28",\n    "1D(t)": "197"\n  },\n  {\n    "RK": "24",\n    "PLAYER": "Kalel Mullings",\n    "POS": "RB",\n    "NFL": "TEN",\n    "PK#": "188",\n    "RD": "6",\n    "NCAA": "MICH",\n    "AGE": "22.5",\n    "HT": "6\'2\\"",\n    "WT": "226",\n    "ATHL": "78.00",\n    "40": null,\n    "PRD GRADE": "55.00",\n    "EFF GRADE": "60.86",\n    "ELU GRADE": "63.27",\n    "FILM GRADE": null,\n    "OVR GRADE": "65.3",\n    "G": "56",\n    "YDS(t)": "1268",\n    "YpG(t)": "23",\n    "OPP(t)": "245",\n    "TD(t)": "16",\n    "1D(t)": "84"\n  },\n  {\n    "RK": "25",\n    "PLAYER": "Donovan Edwards",\n    "POS": "RB",\n    "NFL": "NYJ",\n    "PK#": null,\n    "RD": null,\n    "NCAA": "MICH",\n    "AGE": "22.1",\n    "HT": "5\'11\\"",\n    "WT": "205",\n    "ATHL": "94.00",\n    "40": "4.44",\n    "PRD GRADE": "67.00",\n    "EFF GRADE": "62.15",\n    "ELU GRADE": "56.66",\n    "FILM GRADE": null,\n    "OVR GRADE": "71.0",\n    "G": "50",\n    "YDS(t)": "3048",\n    "YpG(t)": "61",\n    "OPP(t)": "528",\n    "TD(t)": "23",\n    "1D(t)": "121"\n  },\n  {\n    "RK": "26",\n    "PLAYER": "Montrell Johnson Jr.",\n    "POS": "RB",\n    "NFL": null,\n    "PK#": null,\n    "RD": null,\n    "NCAA": "FLA",\n    "AGE": "22.5",\n    "HT": "5\'11\\"",\n    "WT": "212",\n    "ATHL": "82.00",\n    "40": "4.41",\n    "PRD GRADE": "77.42",\n    "EFF GRADE": "65.31",\n    "ELU GRADE": "61.62",\n    "FILM GRADE": null,\n    "OVR GRADE": "69.2",\n    "G": "49",\n    "YDS(t)": "3500",\n    "YpG(t)": "71",\n    "OPP(t)": "652",\n    "TD(t)": "35",\n    "1D(t)": "185"\n  },\n  {\n    "RK": "27",\n    "PLAYER": "Ja\'Quinden Jackson",\n    "POS": "RB",\n    "NFL": null,\n    "PK#": null,\n    "RD": null,\n    "NCAA": "ARK",\n    "AGE": "23.5",\n    "HT": "6\'2\\"",\n    "WT": "229",\n    "ATHL": "55.00",\n    "40": null,\n    "PRD GRADE": "63.98",\n    "EFF GRADE": "72.69",\n    "ELU GRADE": "79.81",\n    "FILM GRADE": null,\n    "OVR GRADE": "61.3",\n    "G": "37",\n    "YDS(t)": "2348",\n    "YpG(t)": "63",\n    "OPP(t)": "423",\n    "TD(t)": "29",\n    "1D(t)": "149"\n  }\n]\n'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicColumnProperties={{ formatByIndex: "auto" }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      headerTextWrap={true}
      linkedFilterId=""
      primaryKeyColumnId="3220b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      style={{
        headerFontFamily: "h6Font",
        fontWeight: "500",
        border: "rgba(18, 23, 48, 1)",
        alternateRowBackground: "#1c1f37",
        background: "#141627",
        fontSize: "13px",
        fontFamily: "Quicksand",
        headerFontWeight: "h6Font",
        headerText: "#ffffffff",
        headerBackground: "rgba(1, 9, 23, 1)",
        headerFontSize: "h6Font",
      }}
    >
      <Column
        id="d6166"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RK"
        label="Rk"
        placeholder="Enter value"
        position="center"
        size={41.46875}
        summaryAggregationMode="none"
      />
      <Column
        id="3220b"
        alignment="left"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="PLAYER"
        label="Player"
        placeholder="Enter value"
        position="center"
        size={132.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="f83ae"
        alignment="center"
        editable={false}
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              ordered: [
                { value: "QB" },
                { color: "#ff2a6d" },
                { textColor: "rgba(18, 18, 18, 1)" },
                { icon: "" },
                { label: "" },
              ],
            },
            { ordered: [{ value: "WR" }, { color: "#58a7ff" }] },
            { ordered: [{ value: "RB" }] },
            { ordered: [{ value: "TE" }] },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="85342"
        alignment="center"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="NFL"
        label="TM"
        optionList={{
          mode: "manual",
          mappedData: "{{  }}",
          manualData: [
            { value: "LV", color: "rgba(13, 13, 13, 1)" },
            { value: "LAC", color: "rgba(3, 159, 196, 1)" },
            {
              value: "NE",
              color: "rgba(6, 6, 81, 1)",
              textColor: "rgba(245, 14, 14, 1)",
            },
            { value: "NYG", color: "rgba(3, 54, 236, 1)" },
            { value: "CLE", color: "rgba(70, 60, 60, 1)" },
            {
              value: "PIT",
              color: "rgba(0, 0, 0, 1)",
              textColor: "rgba(255, 243, 6, 1)",
            },
            {
              value: "NO",
              color: "rgba(0, 0, 0, 1)",
              textColor: "rgba(167, 147, 75, 1)",
            },
            {
              value: "DEN",
              color: "rgba(20, 14, 89, 1)",
              textColor: "rgba(247, 101, 16, 1)",
            },
            { map: { value: "IND" } },
            { map: { value: "SEA" } },
            { map: { value: "CIN" } },
            { map: { value: "JAX" } },
            { map: { value: "CAR" } },
            { map: { value: "MIA" } },
            { map: { value: "SF" } },
            { map: { value: "KC" } },
            { map: { value: "DAL" } },
            { map: { value: "LAR" } },
            { map: { value: "HOU" } },
            { map: { value: "CHI" } },
            { map: { value: "Option 21" } },
            { map: { value: "Option 22" } },
            { map: { value: "Option 23" } },
            { map: { value: "Option 24" } },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={72.1875}
        summaryAggregationMode="none"
      />
      <Column
        id="6beae"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="G"
        label="G"
        placeholder="Enter value"
        position="center"
        size={48.453125}
        summaryAggregationMode="none"
      />
      <Column
        id="e9438"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="YDS(t)"
        label="YDS(t)"
        placeholder="Enter value"
        position="center"
        size={71.125}
        summaryAggregationMode="none"
      />
      <Column
        id="37293"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="TD(t)"
        label="TD(t)"
        placeholder="Enter value"
        position="center"
        size={71.90625}
        summaryAggregationMode="none"
      />
      <Column
        id="1cd6c"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="1D(t)"
        label="1D(t)"
        placeholder="Enter value"
        position="center"
        size={62.109375}
        summaryAggregationMode="none"
      />
      <Column
        id="05e56"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="40"
        label="40"
        placeholder="Enter value"
        position="center"
        size={51.09375}
        summaryAggregationMode="none"
      />
      <Column
        id="95105"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="PK#"
        label="Pk"
        placeholder="Enter value"
        position="center"
        size={44.578125}
        summaryAggregationMode="none"
      />
      <Column
        id="62082"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RD"
        label="Rd"
        placeholder="Enter value"
        position="center"
        size={46.265625}
        summaryAggregationMode="none"
      />
      <Column
        id="41f3f"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="NCAA"
        label="Ncaa"
        placeholder="Enter value"
        position="center"
        size={56.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="53da5"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="Age"
        placeholder="Enter value"
        position="center"
        size={51.5}
        summaryAggregationMode="none"
      />
      <Column
        id="7a71b"
        alignment="center"
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="HT"
        label="Ht"
        placeholder="Select option"
        position="center"
        size={50.125}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="f718d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="Wt"
        placeholder="Enter value"
        position="center"
        size={51.921875}
        summaryAggregationMode="none"
      />
      <Column
        id="cf84f"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="ATHL"
        label="Athl"
        placeholder="Enter value"
        position="center"
        size={60.34375}
        summaryAggregationMode="none"
      />
      <Column
        id="93ad9"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="PRD GRADE"
        label="Prd grade"
        placeholder="Enter value"
        position="center"
        size={71.34375}
        summaryAggregationMode="none"
      />
      <Column
        id="d91e6"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="EFF GRADE"
        label="EFF GRD"
        placeholder="Enter value"
        position="center"
        size={78.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="e5243"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="ELU GRADE"
        label="Elu grade"
        placeholder="Enter value"
        position="center"
        size={68.890625}
        summaryAggregationMode="none"
      />
      <Column
        id="a88c0"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={75.609375}
        summaryAggregationMode="none"
      />
      <Column
        id="a80e8"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="OVR GRADE"
        label="Ovr grade"
        placeholder="Enter value"
        position="center"
        size={72.703125}
        summaryAggregationMode="none"
      />
      <Column
        id="25637"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="YpG(t)"
        label="Yp g t"
        placeholder="Enter value"
        position="center"
        size={59.84375}
        summaryAggregationMode="none"
      />
      <Column
        id="00b31"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="OPP(t)"
        label="Opp t"
        placeholder="Enter value"
        position="center"
        size={61.09375}
        summaryAggregationMode="none"
      />
    </Table>
  </View>
  <View
    id="3eee2"
    disabled={false}
    hidden={false}
    icon="bold/travel-transportation-bus"
    iconPosition="left"
    label="RB"
    viewKey="RB"
  >
    <Table
      id="table90"
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "40": "NA",\n    "RK": 1,\n    "PLAYER": "Ashton Jeanty",\n    "POS": "RB",\n    "TM": "LV",\n    "PK#": 6,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>\\u2460</span>",\n    "NCAA": "BOIS",\n    "AGE": 21.6,\n    "HT": "5\'8",\n    "WT": 211,\n    "ATHL": 89,\n    "PRD GRADE": 95,\n    "EFF GRADE": 94.3,\n    "ELU GRADE": 98,\n    "FILM GRADE": 98,\n    "OVR GRADE": 96,\n    "G": 40,\n    "YDS(t)": 5637,\n    "TD(t)": 56,\n    "YpG(t)": 140.9,\n    "OPP(t)": 845,\n    "IMP": 324,\n    "IMP/ OPP": 0.383,\n    "DMTR": 0.34,\n    "CAR": 748,\n    "ruYDS": 4760,\n    "YPC": 6.4,\n    "ruTD": 50,\n    "ru1D": 232,\n    "YCO": 3557,\n    "YACO/A": 4.76,\n    "MTF": 283,\n    "MTF/ A": 0.378,\n    "ELU": 0.735,\n    "REC": 82,\n    "recYDS": 877,\n    "TGT": 97,\n    "recTD": 6,\n    "SOS": 75,\n    "CL": 5,\n    "FL": 4.5,\n    "truADP": 7.7,\n    "Rook ADP": 1,\n    "Tier": 1\n  },\n  {\n    "40": 4.46,\n    "RK": 2,\n    "PLAYER": "Omarion Hampton",\n    "POS": "RB",\n    "TM": "LAC",\n    "PK#": 22,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>\\u2460</span>",\n    "NCAA": "UNC",\n    "AGE": 22.3,\n    "HT": "5\'12",\n    "WT": 221,\n    "ATHL": 89,\n    "PRD GRADE": 86,\n    "EFF GRADE": 82.8,\n    "ELU GRADE": 86,\n    "FILM GRADE": 86,\n    "OVR GRADE": 90,\n    "G": 38,\n    "YDS(t)": 4194,\n    "TD(t)": 40,\n    "YpG(t)": 110.4,\n    "OPP(t)": 704,\n    "IMP": 248,\n    "IMP/ OPP": 0.352,\n    "DMTR": 0.253,\n    "CAR": 624,\n    "ruYDS": 3563,\n    "YPC": 5.7,\n    "ruTD": 37,\n    "ru1D": 183,\n    "YCO": 2505,\n    "YACO/A": 4.01,\n    "MTF": 154,\n    "MTF/ A": 0.247,\n    "ELU": 0.548,\n    "REC": 72,\n    "recYDS": 631,\n    "TGT": 80,\n    "recTD": 3,\n    "SOS": 80,\n    "CL": 4.5,\n    "FL": 4,\n    "truADP": 23.7,\n    "Rook ADP": 2,\n    "Tier": 2\n  },\n  {\n    "40": 4.43,\n    "RK": 3,\n    "PLAYER": "TreVeyon Henderson",\n    "POS": "RB",\n    "TM": "NE",\n    "PK#": 38,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>\\u2461</span>",\n    "NCAA": "OSU",\n    "AGE": 22.7,\n    "HT": "5\'10",\n    "WT": 202,\n    "ATHL": 94,\n    "PRD GRADE": 90,\n    "EFF GRADE": 88.3,\n    "ELU GRADE": 76,\n    "FILM GRADE": 84,\n    "OVR GRADE": 88,\n    "G": 47,\n    "YDS(t)": 4609,\n    "TD(t)": 48,\n    "YpG(t)": 98.1,\n    "OPP(t)": 678,\n    "IMP": 248,\n    "IMP/ OPP": 0.366,\n    "DMTR": 0.213,\n    "CAR": 590,\n    "ruYDS": 3759,\n    "YPC": 6.4,\n    "ruTD": 42,\n    "ru1D": 168,\n    "YCO": 2293,\n    "YACO/A": 3.89,\n    "MTF": 130,\n    "MTF/ A": 0.22,\n    "ELU": 0.512,\n    "REC": 76,\n    "recYDS": 850,\n    "TGT": 88,\n    "recTD": 6,\n    "SOS": 93.5,\n    "CL": 4.5,\n    "FL": 3.5,\n    "truADP": 39.7,\n    "Rook ADP": 5,\n    "Tier": 2\n  },\n  {\n    "40": 4.48,\n    "RK": 4,\n    "PLAYER": "Quinshon Judkins",\n    "POS": "RB",\n    "TM": "CLE",\n    "PK#": 36,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>\\u2461</span>",\n    "NCAA": "OSU",\n    "AGE": 21.7,\n    "HT": "5\'12",\n    "WT": 221,\n    "ATHL": 95,\n    "PRD GRADE": 89,\n    "EFF GRADE": 87.3,\n    "ELU GRADE": 76,\n    "FILM GRADE": 82,\n    "OVR GRADE": 87,\n    "G": 42,\n    "YDS(t)": 4228,\n    "TD(t)": 50,\n    "YpG(t)": 100.7,\n    "OPP(t)": 808,\n    "IMP": 294,\n    "IMP/ OPP": 0.364,\n    "DMTR": 0.247,\n    "CAR": 739,\n    "ruYDS": 3786,\n    "YPC": 5.1,\n    "ruTD": 45,\n    "ru1D": 222,\n    "YCO": 2387,\n    "YACO/A": 3.23,\n    "MTF": 197,\n    "MTF/ A": 0.267,\n    "ELU": 0.509,\n    "REC": 59,\n    "recYDS": 442,\n    "TGT": 69,\n    "recTD": 5,\n    "SOS": 93,\n    "CL": 4,\n    "FL": 3,\n    "truADP": 43.6,\n    "Rook ADP": 6,\n    "Tier": 2\n  },\n  {\n    "40": 4.4,\n    "RK": 5,\n    "PLAYER": "R.J. Harvey",\n    "POS": "RB",\n    "TM": "DEN",\n    "PK#": 60,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>\\u2461</span>",\n    "NCAA": "UCF",\n    "AGE": 24.4,\n    "HT": "5\'8",\n    "WT": 205,\n    "ATHL": 89,\n    "PRD GRADE": 88,\n    "EFF GRADE": 90.2,\n    "ELU GRADE": 90,\n    "FILM GRADE": 79,\n    "OVR GRADE": 84,\n    "G": 39,\n    "YDS(t)": 4510,\n    "TD(t)": 48,\n    "YpG(t)": 115.6,\n    "OPP(t)": 652,\n    "IMP": 273,\n    "IMP/ OPP": 0.419,\n    "DMTR": 0.292,\n    "CAR": 574,\n    "ruYDS": 3788,\n    "YPC": 6.6,\n    "ruTD": 43,\n    "ru1D": 196,\n    "YCO": 2115,\n    "YACO/A": 3.68,\n    "MTF": 181,\n    "MTF/ A": 0.315,\n    "ELU": 0.591,\n    "REC": 62,\n    "recYDS": 722,\n    "TGT": 78,\n    "recTD": 5,\n    "SOS": 79,\n    "CL": 4.5,\n    "FL": 2.5,\n    "truADP": 50.6,\n    "Rook ADP": 7,\n    "Tier": 3\n  },\n  {\n    "40": 4.57,\n    "RK": 6,\n    "PLAYER": "Kaleb Johnson",\n    "POS": "RB",\n    "TM": "PIT",\n    "PK#": 83,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>\\u2462</span>",\n    "NCAA": "IOWA",\n    "AGE": 20.8,\n    "HT": "6\'1",\n    "WT": 224,\n    "ATHL": 79,\n    "PRD GRADE": 68,\n    "EFF GRADE": 70,\n    "ELU GRADE": 82,\n    "FILM GRADE": 76,\n    "OVR GRADE": 82,\n    "G": 35,\n    "YDS(t)": 3017,\n    "TD(t)": 32,\n    "YpG(t)": 86.2,\n    "OPP(t)": 543,\n    "IMP": 156,\n    "IMP/ OPP": 0.287,\n    "DMTR": 0.386,\n    "CAR": 508,\n    "ruYDS": 2775,\n    "YPC": 5.5,\n    "ruTD": 30,\n    "ru1D": 116,\n    "YCO": 1870,\n    "YACO/A": 3.68,\n    "MTF": 135,\n    "MTF/ A": 0.266,\n    "ELU": 0.542,\n    "REC": 29,\n    "recYDS": 242,\n    "TGT": 35,\n    "recTD": 2,\n    "SOS": 91.5,\n    "CL": 3.5,\n    "FL": 4,\n    "truADP": 55.2,\n    "Rook ADP": 9,\n    "Tier": 3\n  },\n  {\n    "40": "NA",\n    "RK": 7,\n    "PLAYER": "Cameron Skattebo",\n    "POS": "RB",\n    "TM": "NYG",\n    "PK#": 105,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "NCAA": "ARIZST",\n    "AGE": 23.4,\n    "HT": "5\'10",\n    "WT": 219,\n    "ATHL": 77,\n    "PRD GRADE": 95,\n    "EFF GRADE": 86.9,\n    "ELU GRADE": 93,\n    "FILM GRADE": 85,\n    "OVR GRADE": 88,\n    "G": 47,\n    "YDS(t)": 5710,\n    "TD(t)": 51,\n    "YpG(t)": 121.5,\n    "OPP(t)": 855,\n    "IMP": 363,\n    "IMP/ OPP": 0.425,\n    "DMTR": 0.397,\n    "CAR": 711,\n    "ruYDS": 4387,\n    "YPC": 6.2,\n    "ruTD": 43,\n    "ru1D": 258,\n    "YCO": 2807,\n    "YACO/A": 3.95,\n    "MTF": 260,\n    "MTF/ A": 0.366,\n    "ELU": 0.662,\n    "REC": 111,\n    "recYDS": 1323,\n    "TGT": 144,\n    "recTD": 8,\n    "SOS": 81,\n    "CL": 4,\n    "FL": 3,\n    "truADP": 76.3,\n    "Rook ADP": 13,\n    "Tier": 4\n  },\n  {\n    "40": 4.32,\n    "RK": 8,\n    "PLAYER": "Bhayshul Tuten",\n    "POS": "RB",\n    "TM": "JAX",\n    "PK#": 104,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "NCAA": "VT",\n    "AGE": 22.4,\n    "HT": "5\'9",\n    "WT": 206,\n    "ATHL": 94,\n    "PRD GRADE": 62,\n    "EFF GRADE": 75.3,\n    "ELU GRADE": 90,\n    "FILM GRADE": 79,\n    "OVR GRADE": 80,\n    "G": 45,\n    "YDS(t)": 4449,\n    "TD(t)": 49,\n    "YpG(t)": 98.9,\n    "OPP(t)": 718,\n    "IMP": 241,\n    "IMP/ OPP": 0.336,\n    "DMTR": 0.31,\n    "CAR": 600,\n    "ruYDS": 3584,\n    "YPC": 6,\n    "ruTD": 40,\n    "ru1D": 162,\n    "YCO": 2505,\n    "YACO/A": 4.18,\n    "MTF": 217,\n    "MTF/ A": 0.362,\n    "ELU": 0.676,\n    "REC": 87,\n    "recYDS": 865,\n    "TGT": 118,\n    "recTD": 9,\n    "SOS": 77,\n    "CL": 4,\n    "FL": 2,\n    "truADP": 121.7,\n    "Rook ADP": 20,\n    "Tier": 5\n  },\n  {\n    "40": 4.38,\n    "RK": 9,\n    "PLAYER": "Jaydon Blue",\n    "POS": "RB",\n    "TM": "DAL",\n    "PK#": 149,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>\\u2464</span>",\n    "NCAA": "TEX",\n    "AGE": 21.5,\n    "HT": "5\'9",\n    "WT": 196,\n    "ATHL": 89,\n    "PRD GRADE": 58,\n    "EFF GRADE": 68.8,\n    "ELU GRADE": 77,\n    "FILM GRADE": "NA",\n    "OVR GRADE": 74,\n    "G": 31,\n    "YDS(t)": 1659,\n    "TD(t)": 18,\n    "YpG(t)": 53.5,\n    "OPP(t)": 289,\n    "IMP": 101,\n    "IMP/ OPP": 0.349,\n    "DMTR": 0.132,\n    "CAR": 215,\n    "ruYDS": 1159,\n    "YPC": 5.4,\n    "ruTD": 11,\n    "ru1D": 56,\n    "YCO": 749,\n    "YACO/A": 3.48,\n    "MTF": 56,\n    "MTF/ A": 0.26,\n    "ELU": 0.521,\n    "REC": 55,\n    "recYDS": 500,\n    "TGT": 74,\n    "recTD": 7,\n    "SOS": 91,\n    "CL": 3,\n    "FL": 2.5,\n    "truADP": 118.4,\n    "Rook ADP": 19,\n    "Tier": 5\n  },\n  {\n    "40": "NA",\n    "RK": 10,\n    "PLAYER": "Dylan Sampson",\n    "POS": "RB",\n    "TM": "CLE",\n    "PK#": 126,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "NCAA": "TENN",\n    "AGE": 20.8,\n    "HT": "5\'8",\n    "WT": 200,\n    "ATHL": 80,\n    "PRD GRADE": 70,\n    "EFF GRADE": 85.4,\n    "ELU GRADE": 82,\n    "FILM GRADE": 85,\n    "OVR GRADE": 82,\n    "G": 34,\n    "YDS(t)": 2823,\n    "TD(t)": 36,\n    "YpG(t)": 83,\n    "OPP(t)": 473,\n    "IMP": 185,\n    "IMP/ OPP": 0.391,\n    "DMTR": 0.208,\n    "CAR": 423,\n    "ruYDS": 2481,\n    "YPC": 5.9,\n    "ruTD": 35,\n    "ru1D": 131,\n    "YCO": 1541,\n    "YACO/A": 3.64,\n    "MTF": 111,\n    "MTF/ A": 0.262,\n    "ELU": 0.535,\n    "REC": 40,\n    "recYDS": 342,\n    "TGT": 50,\n    "recTD": 1,\n    "SOS": 91.5,\n    "CL": 2.5,\n    "FL": 2,\n    "truADP": 143.7,\n    "Rook ADP": 23,\n    "Tier": 5\n  },\n  {\n    "40": 4.58,\n    "RK": 11,\n    "PLAYER": "Devin Neal",\n    "POS": "RB",\n    "TM": "NO",\n    "PK#": 184,\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>\\u2465</span>",\n    "NCAA": "KU",\n    "AGE": 21.9,\n    "HT": "5\'11",\n    "WT": 213,\n    "ATHL": 68,\n    "PRD GRADE": 92,\n    "EFF GRADE": 80.8,\n    "ELU GRADE": 68,\n    "FILM GRADE": 78,\n    "OVR GRADE": 81,\n    "G": 49,\n    "YDS(t)": 5063,\n    "TD(t)": 53,\n    "YpG(t)": 103.3,\n    "OPP(t)": 860,\n    "IMP": 297,\n    "IMP/ OPP": 0.345,\n    "DMTR": 0.266,\n    "CAR": 759,\n    "ruYDS": 4340,\n    "YPC": 5.7,\n    "ruTD": 49,\n    "ru1D": 211,\n    "YCO": 2526,\n    "YACO/A": 3.33,\n    "MTF": 171,\n    "MTF/ A": 0.225,\n    "ELU": 0.475,\n    "REC": 79,\n    "recYDS": 723,\n    "TGT": 101,\n    "recTD": 4,\n    "SOS": 81,\n    "CL": 3,\n    "FL": 2,\n    "truADP": 148,\n    "Rook ADP": 25,\n    "Tier": 6\n  },\n  {\n    "40": 4.43,\n    "RK": 12,\n    "PLAYER": "DJ Giddens",\n    "POS": "RB",\n    "TM": "IND",\n    "PK#": 151,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>\\u2464</span>",\n    "NCAA": "KSU",\n    "AGE": 21.8,\n    "HT": "6\'0",\n    "WT": 212,\n    "ATHL": 85,\n    "PRD GRADE": 74,\n    "EFF GRADE": 82.7,\n    "ELU GRADE": 87,\n    "FILM GRADE": 70,\n    "OVR GRADE": 81,\n    "G": 39,\n    "YDS(t)": 3770,\n    "TD(t)": 27,\n    "YpG(t)": 96.7,\n    "OPP(t)": 601,\n    "IMP": 209,\n    "IMP/ OPP": 0.348,\n    "DMTR": 0.198,\n    "CAR": 518,\n    "ruYDS": 3088,\n    "YPC": 6,\n    "ruTD": 23,\n    "ru1D": 156,\n    "YCO": 1929,\n    "YACO/A": 3.72,\n    "MTF": 147,\n    "MTF/ A": 0.284,\n    "ELU": 0.563,\n    "REC": 58,\n    "recYDS": 682,\n    "TGT": 83,\n    "recTD": 4,\n    "SOS": 82.5,\n    "CL": 3.5,\n    "FL": 2,\n    "truADP": 176.3,\n    "Rook ADP": 33,\n    "Tier": 6\n  },\n  {\n    "40": 4.42,\n    "RK": 13,\n    "PLAYER": "Trevor Etienne",\n    "POS": "RB",\n    "TM": "CAR",\n    "PK#": 114,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "NCAA": "UGA",\n    "AGE": 21,\n    "HT": "5\'9",\n    "WT": 198,\n    "ATHL": 83,\n    "PRD GRADE": 63,\n    "EFF GRADE": 71.9,\n    "ELU GRADE": 87,\n    "FILM GRADE": 79,\n    "OVR GRADE": 80,\n    "G": 34,\n    "YDS(t)": 2510,\n    "TD(t)": 24,\n    "YpG(t)": 73.8,\n    "OPP(t)": 433,\n    "IMP": 147,\n    "IMP/ OPP": 0.339,\n    "DMTR": 0.187,\n    "CAR": 370,\n    "ruYDS": 2078,\n    "YPC": 5.6,\n    "ruTD": 23,\n    "ru1D": 103,\n    "YCO": 1406,\n    "YACO/A": 3.8,\n    "MTF": 98,\n    "MTF/ A": 0.265,\n    "ELU": 0.55,\n    "REC": 62,\n    "recYDS": 432,\n    "TGT": 63,\n    "recTD": 1,\n    "SOS": 93.5,\n    "CL": 2.5,\n    "FL": 1.5,\n    "truADP": 183,\n    "Rook ADP": 35,\n    "Tier": 6\n  },\n  {\n    "40": 4.61,\n    "RK": 14,\n    "PLAYER": "Ollie Gordon",\n    "POS": "RB",\n    "TM": "MIA",\n    "PK#": 179,\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>\\u2465</span>",\n    "NCAA": "OKST",\n    "AGE": 21.5,\n    "HT": "6\'1",\n    "WT": 226,\n    "ATHL": 68,\n    "PRD GRADE": 82,\n    "EFF GRADE": 70.8,\n    "ELU GRADE": 65,\n    "FILM GRADE": 78,\n    "OVR GRADE": 74,\n    "G": 39,\n    "YDS(t)": 3495,\n    "TD(t)": 40,\n    "YpG(t)": 89.6,\n    "OPP(t)": 638,\n    "IMP": 217,\n    "IMP/ OPP": 0.34,\n    "DMTR": 0.263,\n    "CAR": 535,\n    "ruYDS": 2891,\n    "YPC": 5.4,\n    "ruTD": 35,\n    "ru1D": 142,\n    "YCO": 1854,\n    "YACO/A": 3.47,\n    "MTF": 125,\n    "MTF/ A": 0.234,\n    "ELU": 0.494,\n    "REC": 81,\n    "recYDS": 604,\n    "TGT": 103,\n    "recTD": 5,\n    "SOS": 82,\n    "CL": 2.5,\n    "FL": 3,\n    "truADP": 173.7,\n    "Rook ADP": 32,\n    "Tier": 6\n  },\n  {\n    "40": 4.44,\n    "RK": 15,\n    "PLAYER": "Jarquez Hunter",\n    "POS": "RB",\n    "TM": "LAR",\n    "PK#": 117,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "NCAA": "AUB",\n    "AGE": 22.5,\n    "HT": "5\'9",\n    "WT": 204,\n    "ATHL": 71,\n    "PRD GRADE": 79,\n    "EFF GRADE": 80.3,\n    "ELU GRADE": 90,\n    "FILM GRADE": "NA",\n    "OVR GRADE": 76,\n    "G": 49,\n    "YDS(t)": 3931,\n    "TD(t)": 29,\n    "YpG(t)": 80.2,\n    "OPP(t)": 629,\n    "IMP": 219,\n    "IMP/ OPP": 0.348,\n    "DMTR": 0.199,\n    "CAR": 539,\n    "ruYDS": 3373,\n    "YPC": 6.3,\n    "ruTD": 25,\n    "ru1D": 166,\n    "YCO": 2123,\n    "YACO/A": 3.94,\n    "MTF": 164,\n    "MTF/ A": 0.304,\n    "ELU": 0.6,\n    "REC": 68,\n    "recYDS": 558,\n    "TGT": 90,\n    "recTD": 4,\n    "SOS": 92,\n    "CL": 3,\n    "FL": 2,\n    "truADP": 193.8,\n    "Rook ADP": 38,\n    "Tier": 6\n  },\n  {\n    "40": 4.55,\n    "RK": 16,\n    "PLAYER": "Jordan James",\n    "POS": "RB",\n    "TM": "SF",\n    "PK#": 147,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>\\u2464</span>",\n    "NCAA": "ORE",\n    "AGE": 21.3,\n    "HT": "5\'10",\n    "WT": 205,\n    "ATHL": 71,\n    "PRD GRADE": 78,\n    "EFF GRADE": 81.4,\n    "ELU GRADE": 70,\n    "FILM GRADE": "NA",\n    "OVR GRADE": 76,\n    "G": 37,\n    "YDS(t)": 2568,\n    "TD(t)": 32,\n    "YpG(t)": 69.4,\n    "OPP(t)": 439,\n    "IMP": 197,\n    "IMP/ OPP": 0.449,\n    "DMTR": 0.157,\n    "CAR": 386,\n    "ruYDS": 2223,\n    "YPC": 5.8,\n    "ruTD": 31,\n    "ru1D": 148,\n    "YCO": 1281,\n    "YACO/A": 3.32,\n    "MTF": 97,\n    "MTF/ A": 0.251,\n    "ELU": 0.5,\n    "REC": 42,\n    "recYDS": 345,\n    "TGT": 53,\n    "recTD": 1,\n    "SOS": 90,\n    "CL": 3.5,\n    "FL": 1.5,\n    "truADP": 185.7,\n    "Rook ADP": 36,\n    "Tier": 6\n  },\n  {\n    "40": 4.39,\n    "RK": 17,\n    "PLAYER": "Brashard Smith",\n    "POS": "RB",\n    "TM": "KC",\n    "PK#": 228,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>\\u2466</span>",\n    "NCAA": "SMU",\n    "AGE": 22.3,\n    "HT": "5\'10",\n    "WT": 194,\n    "ATHL": 79,\n    "PRD GRADE": 67,\n    "EFF GRADE": 81.8,\n    "ELU GRADE": 60,\n    "FILM GRADE": "NA",\n    "OVR GRADE": 73,\n    "G": 46,\n    "YDS(t)": 2616,\n    "TD(t)": 23,\n    "YpG(t)": 56.9,\n    "OPP(t)": 392,\n    "IMP": 149,\n    "IMP/ OPP": 0.38,\n    "DMTR": 0.137,\n    "CAR": 252,\n    "ruYDS": 1516,\n    "YPC": 6,\n    "ruTD": 15,\n    "ru1D": 76,\n    "YCO": 832,\n    "YACO/A": 3.3,\n    "MTF": 57,\n    "MTF/ A": 0.226,\n    "ELU": 0.474,\n    "REC": 109,\n    "recYDS": 1100,\n    "TGT": 140,\n    "recTD": 8,\n    "SOS": 78,\n    "CL": 3.5,\n    "FL": 2,\n    "truADP": 197.8,\n    "Rook ADP": 41,\n    "Tier": 6\n  },\n  {\n    "40": 4.54,\n    "RK": 18,\n    "PLAYER": "Jo\'quavious Marks",\n    "POS": "RB",\n    "TM": "HOU",\n    "PK#": 116,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "NCAA": "USC",\n    "AGE": 24.5,\n    "HT": "5\'10",\n    "WT": 207,\n    "ATHL": 76,\n    "PRD GRADE": 85,\n    "EFF GRADE": 59.2,\n    "ELU GRADE": 55,\n    "FILM GRADE": "NA",\n    "OVR GRADE": 70,\n    "G": 57,\n    "YDS(t)": 4561,\n    "TD(t)": 36,\n    "YpG(t)": 80,\n    "OPP(t)": 912,\n    "IMP": 288,\n    "IMP/ OPP": 0.316,\n    "DMTR": 0.212,\n    "CAR": 611,\n    "ruYDS": 3057,\n    "YPC": 5,\n    "ruTD": 31,\n    "ru1D": 182,\n    "YCO": 1689,\n    "YACO/A": 2.76,\n    "MTF": 95,\n    "MTF/ A": 0.155,\n    "ELU": 0.362,\n    "REC": 257,\n    "recYDS": 1504,\n    "TGT": 301,\n    "recTD": 5,\n    "SOS": "NA",\n    "CL": 2.5,\n    "FL": 1.5,\n    "truADP": 211.3,\n    "Rook ADP": 45,\n    "Tier": 6\n  },\n  {\n    "40": 4.6,\n    "RK": 19,\n    "PLAYER": "Kyle Monangai",\n    "POS": "RB",\n    "TM": "CHI",\n    "PK#": 233,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>\\u2466</span>",\n    "NCAA": "RUT",\n    "AGE": 23.3,\n    "HT": "5\'8",\n    "WT": 211,\n    "ATHL": 70,\n    "PRD GRADE": 74,\n    "EFF GRADE": 64.4,\n    "ELU GRADE": 85,\n    "FILM GRADE": "NA",\n    "OVR GRADE": 74,\n    "G": 47,\n    "YDS(t)": 3466,\n    "TD(t)": 28,\n    "YpG(t)": 73.7,\n    "OPP(t)": 721,\n    "IMP": 225,\n    "IMP/ OPP": 0.312,\n    "DMTR": 0.233,\n    "CAR": 670,\n    "ruYDS": 3225,\n    "YPC": 4.8,\n    "ruTD": 27,\n    "ru1D": 190,\n    "YCO": 2231,\n    "YACO/A": 3.33,\n    "MTF": 173,\n    "MTF/ A": 0.258,\n    "ELU": 0.508,\n    "REC": 36,\n    "recYDS": 241,\n    "TGT": 51,\n    "recTD": 1,\n    "SOS": "NA",\n    "CL": 2,\n    "FL": 2.5,\n    "truADP": 207.6,\n    "Rook ADP": 44,\n    "Tier": 6\n  },\n  {\n    "40": 4.52,\n    "RK": 20,\n    "PLAYER": "Tahj Brooks",\n    "POS": "RB",\n    "TM": "CIN",\n    "PK#": 193,\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>\\u2465</span>",\n    "NCAA": "TTU",\n    "AGE": 23.2,\n    "HT": "5\'9",\n    "WT": 214,\n    "ATHL": 86,\n    "PRD GRADE": 92,\n    "EFF GRADE": 63.7,\n    "ELU GRADE": 88,\n    "FILM GRADE": "NA",\n    "OVR GRADE": 81,\n    "G": 53,\n    "YDS(t)": 5136,\n    "TD(t)": 47,\n    "YpG(t)": 96.9,\n    "OPP(t)": 1001,\n    "IMP": 332,\n    "IMP/ OPP": 0.332,\n    "DMTR": 0.243,\n    "CAR": 883,\n    "ruYDS": 4590,\n    "YPC": 5.2,\n    "ruTD": 45,\n    "ru1D": 263,\n    "YCO": 2809,\n    "YACO/A": 3.18,\n    "MTF": 235,\n    "MTF/ A": 0.266,\n    "ELU": 0.505,\n    "REC": 101,\n    "recYDS": 546,\n    "TGT": 118,\n    "recTD": 2,\n    "SOS": 83,\n    "CL": 3,\n    "FL": 2,\n    "truADP": 245.6,\n    "Rook ADP": 50,\n    "Tier": 7\n  },\n  {\n    "40": 4.45,\n    "RK": 21,\n    "PLAYER": "Jacory Croskey-Merritt",\n    "POS": "RB",\n    "TM": "WAS",\n    "PK#": 245,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>\\u2466</span>",\n    "NCAA": "ARIZ",\n    "AGE": 24.3,\n    "HT": "5\'11",\n    "WT": 208,\n    "ATHL": 73,\n    "PRD GRADE": 69.4,\n    "EFF GRADE": 65.3,\n    "ELU GRADE": 68,\n    "FILM GRADE": "NA",\n    "OVR GRADE": 69,\n    "G": 43,\n    "YDS(t)": 2753,\n    "TD(t)": 31,\n    "YpG(t)": 64,\n    "OPP(t)": 558,\n    "IMP": 190,\n    "IMP/ OPP": 0.341,\n    "DMTR": 0.227,\n    "CAR": 513,\n    "ruYDS": 2440,\n    "YPC": 4.8,\n    "ruTD": 29,\n    "ru1D": 143,\n    "YCO": 1659,\n    "YACO/A": 3.23,\n    "MTF": 128,\n    "MTF/ A": 0.25,\n    "ELU": 0.492,\n    "REC": 34,\n    "recYDS": 313,\n    "TGT": 45,\n    "recTD": 2,\n    "SOS": "NA",\n    "CL": 2.5,\n    "FL": 1.5,\n    "truADP": 236.6,\n    "Rook ADP": 47,\n    "Tier": 7\n  },\n  {\n    "40": 4.51,\n    "RK": 22,\n    "PLAYER": "Damien Martinez",\n    "POS": "RB",\n    "TM": "SEA",\n    "PK#": 223,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>\\u2466</span>",\n    "NCAA": "MIA",\n    "AGE": 21.4,\n    "HT": "5\'12",\n    "WT": 217,\n    "ATHL": 73,\n    "PRD GRADE": 73,\n    "EFF GRADE": 85,\n    "ELU GRADE": 89,\n    "FILM GRADE": "NA",\n    "OVR GRADE": 81,\n    "G": 38,\n    "YDS(t)": 3564,\n    "TD(t)": 26,\n    "YpG(t)": 93.8,\n    "OPP(t)": 566,\n    "IMP": 214,\n    "IMP/ OPP": 0.378,\n    "DMTR": 0.181,\n    "CAR": 516,\n    "ruYDS": 3173,\n    "YPC": 6.1,\n    "ruTD": 26,\n    "ru1D": 172,\n    "YCO": 2018,\n    "YACO/A": 3.91,\n    "MTF": 139,\n    "MTF/ A": 0.269,\n    "ELU": 0.562,\n    "REC": 32,\n    "recYDS": 391,\n    "TGT": 50,\n    "recTD": 0,\n    "SOS": 86.5,\n    "CL": 2,\n    "FL": 2.5,\n    "truADP": 260.8,\n    "Rook ADP": 56,\n    "Tier": 7\n  },\n  {\n    "40": "NA",\n    "RK": 23,\n    "PLAYER": "Phil Mafah",\n    "POS": "RB",\n    "TM": "DAL",\n    "PK#": 239,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>\\u2466</span>",\n    "NCAA": "CLEM",\n    "AGE": 22.7,\n    "HT": "6\'1",\n    "WT": 234,\n    "ATHL": 73,\n    "PRD GRADE": 72.2,\n    "EFF GRADE": 67.8,\n    "ELU GRADE": 62,\n    "FILM GRADE": "NA",\n    "OVR GRADE": 68,\n    "G": 50,\n    "YDS(t)": 3204,\n    "TD(t)": 28,\n    "YpG(t)": 64.1,\n    "OPP(t)": 635,\n    "IMP": 205,\n    "IMP/ OPP": 0.323,\n    "DMTR": 0.153,\n    "CAR": 559,\n    "ruYDS": 2895,\n    "YPC": 5.2,\n    "ruTD": 28,\n    "ru1D": 164,\n    "YCO": 1940,\n    "YACO/A": 3.47,\n    "MTF": 111,\n    "MTF/ A": 0.199,\n    "ELU": 0.459,\n    "REC": 58,\n    "recYDS": 309,\n    "TGT": 76,\n    "recTD": 0,\n    "SOS": "NA",\n    "CL": 1.5,\n    "FL": 1,\n    "truADP": 280.6,\n    "Rook ADP": 58,\n    "Tier": 8\n  },\n  {\n    "40": "NA",\n    "RK": 24,\n    "PLAYER": "LeQuint Allen",\n    "POS": "RB",\n    "TM": "JAX",\n    "PK#": 236,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>\\u2466</span>",\n    "NCAA": "SYR",\n    "AGE": 20.9,\n    "HT": "6\'0",\n    "WT": 204,\n    "ATHL": 70,\n    "PRD GRADE": 76,\n    "EFF GRADE": 58.6,\n    "ELU GRADE": 58,\n    "FILM GRADE": "NA",\n    "OVR GRADE": 67,\n    "G": 38,\n    "YDS(t)": 3232,\n    "TD(t)": 32,\n    "YpG(t)": 85.1,\n    "OPP(t)": 660,\n    "IMP": 204,\n    "IMP/ OPP": 0.309,\n    "DMTR": 0.231,\n    "CAR": 513,\n    "ruYDS": 2366,\n    "YPC": 4.6,\n    "ruTD": 26,\n    "ru1D": 126,\n    "YCO": 1635,\n    "YACO/A": 3.19,\n    "MTF": 120,\n    "MTF/ A": 0.234,\n    "ELU": 0.473,\n    "REC": 121,\n    "recYDS": 866,\n    "TGT": 147,\n    "recTD": 6,\n    "SOS": 78,\n    "CL": 3,\n    "FL": 1,\n    "truADP": 326.4,\n    "Rook ADP": 69,\n    "Tier": 8\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicColumnProperties={{ formatByIndex: "auto", labelByIndex: "f" }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      headerTextWrap={true}
      linkedFilterId=""
      primaryKeyColumnId="3220b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      style={{
        headerFontFamily: "Michroma",
        fontWeight: "100",
        rowSeparator: "rgba(130, 138, 179, 0.04)",
        border: "rgba(130, 138, 179, 0.2)",
        hoverRowBackground: "rgba(87, 0, 255, 0.4)",
        alternateRowBackground: "rgba(26, 26, 50, 1)",
        background: "rgba(23, 23, 44, 1)",
        cellText: "rgba(255, 255, 255, 1)",
        fontSize: "12px",
        fontFamily: "Product Sans",
        headerFontWeight: "400",
        headerBackground: "#141a32",
        headerFontSize: "10px",
      }}
    >
      <Column
        id="d6166"
        alignment="center"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RK"
        label="RK"
        placeholder="Enter value"
        position="left"
        size={51.140625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRank\n</div>'
        }
      />
      <Column
        id="3220b"
        alignment="left"
        editable={false}
        format="string"
        groupAggregationMode="none"
        key="PLAYER"
        label="PLAYER"
        placeholder="Enter value"
        position="left"
        size={141.859375}
        summaryAggregationMode="none"
        textColor="{{ currentSourceRow.POS === 'RB' ? '#EaffEa'
  : currentSourceRow.POS === 'TE' ? '#ffefff'
  : currentSourceRow.POS === 'WR' ? '#e1ffff'
  : '' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPlayer Name\n</div>'
        }
      />
      <Column
        id="f83ae"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              ordered: [
                { value: "QB" },
                { color: "#ff2a6d" },
                { textColor: "rgba(18, 18, 18, 1)" },
                { icon: "" },
                { label: "" },
              ],
            },
            {
              value: "WR",
              color: "rgba(88, 167, 255, 0)",
              textColor: "#58a7ff",
              icon: "bold/computer-connection-usb-port",
            },
            {
              value: "RB",
              icon: "bold/travel-transportation-bus",
              color: "rgba(34, 228, 176, 0)",
              textColor: "#22e4b0",
            },
            {
              value: "TE",
              textColor: "#8300ff",
              color: "rgba(0, 0, 0, 0)",
              icon: "bold/interface-security-shield-4",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="left"
        size={66.859375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPosition\n</div>'
        }
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="50caa"
        alignment="center"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="none"
        key="TM"
        label="TM"
        optionList={{
          mode: "mapped",
          mappedData:
            '[\n  { value: "ARI", color: "#97233F", textColor: "#FFB612" },  // red ⟡ yellow :contentReference[oaicite:0]{index=0}\n  { value: "ATL", color: "#A71930", textColor: "#000000" },  // red ⟡ black :contentReference[oaicite:1]{index=1}\n  { value: "BAL", color: "#241773", textColor: "#9E7C0C" },  // purple ⟡ gold :contentReference[oaicite:2]{index=2}\n  { value: "BUF", color: "#00338D", textColor: "#C60C30" },  // royal ⟡ red :contentReference[oaicite:3]{index=3}\n  { value: "CAR", color: "#0085CA", textColor: "#000000" },  // blue ⟡ black :contentReference[oaicite:4]{index=4}\n  { value: "CHI", color: "#0B162A", textColor: "#F63F00" },  // navy ⟡ orange :contentReference[oaicite:5]{index=5}\n  { value: "CIN", color: "#FB3F14", textColor: "#000000" },  // orange ⟡ black :contentReference[oaicite:6]{index=6}\n  { value: "CLE", color: "#DF3C20", textColor: "#101010" },  // orange ⟡ brown :contentReference[oaicite:7]{index=7}\n  { value: "DAL", color: "#003594", textColor: "#A5ACAF" },  // navy ⟡ silver :contentReference[oaicite:8]{index=8}\n  { value: "DEN", color: "#FB2F14", textColor: "#102274" },  // orange ⟡ navy :contentReference[oaicite:9]{index=9}\n  { value: "DET", color: "#0076B6", textColor: "#B0B7BC" },  // honolulu ⟡ silver :contentReference[oaicite:10]{index=10}\n  { value: "GB",  color: "#203731", textColor: "#FFB612" },  // green ⟡ gold :contentReference[oaicite:11]{index=11}\n  { value: "HOU", color: "#03202F", textColor: "#D71930" },  // deep blue ⟡ red :contentReference[oaicite:12]{index=12}\n  { value: "IND", color: "#002C5F", textColor: "#F2FAFD" },  // royal ⟡ gray :contentReference[oaicite:13]{index=13}\n  { value: "JAX", color: "#006778", textColor: "#D7A22A" },  // teal ⟡ gold :contentReference[oaicite:14]{index=14}\n  { value: "KC",  color: "#E31837", textColor: "#FFB612" },  // red ⟡ gold :contentReference[oaicite:15]{index=15}\n  { value: "LAC", color: "#0080C6", textColor: "#FFC20E" },  // powder ⟡ sunshine :contentReference[oaicite:16]{index=16}\n  { value: "LAR", color: "#003594", textColor: "#FFA300" },  // royal ⟡ sol :contentReference[oaicite:17]{index=17}\n  { value: "LV",  color: "#000000", textColor: "#A5ACAF" },  // black ⟡ silver :contentReference[oaicite:18]{index=18}\n  { value: "MIA", color: "#008E87", textColor: "#FC5C02" },  // aqua ⟡ orange :contentReference[oaicite:19]{index=19}\n  { value: "MIN", color: "#4F2683", textColor: "#FFC62F" },  // purple ⟡ gold :contentReference[oaicite:20]{index=20}\n  { value: "NE",  color: "#041E62", textColor: "#D60F51" },  // blue ⟡ red :contentReference[oaicite:21]{index=21}\n  { value: "NO",  color: "#D3BC8D", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:22]{index=22}\n  { value: "NYG", color: "#0B2265", textColor: "#DFDFDF" },  // blue ⟡ red :contentReference[oaicite:23]{index=23}\n  { value: "NYJ", color: "#125740", textColor: "#FFFFFF" },  // green ⟡ white :contentReference[oaicite:24]{index=24}\n  { value: "PHI", color: "#004C54", textColor: "#A5ACAF" },  // midnight ⟡ silver :contentReference[oaicite:25]{index=25}\n  { value: "PIT", color: "#FFB612", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:26]{index=26}\n  { value: "SEA", color: "#002244", textColor: "#69BE28" },  // navy ⟡ action-green :contentReference[oaicite:27]{index=27}\n  { value: "SF",  color: "#AA0000", textColor: "#B3995D" },  // scarlet ⟡ gold :contentReference[oaicite:28]{index=28}\n  { value: "TB",  color: "#D50A0A", textColor: "#0A0A08" },  // red ⟡ pewter :contentReference[oaicite:29]{index=29}\n  { value: "TEN", color: "#0C2340", textColor: "#4B92DB" },  // navy ⟡ titan-blue :contentReference[oaicite:30]{index=30}\n  { value: "WAS", color: "#5A1414", textColor: "#FFB612" },  // burgundy ⟡ gold :contentReference[oaicite:31]{index=31}\n  { value: "UDF", color: "#9E9E9E", textColor: "#FFFFFF" }  // neutral grey\n]',
          valueByIndex: "{{ item.value }}",
          labelByIndex: "{{ item.value }}",
          colorByIndex: "{{ item.color }}",
          textColorByIndex: "{{ item.textColor }}",
        }}
        placeholder="Select option"
        position="left"
        size={62.390625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTeam [NFL]\n</div>'
        }
      />
      <Column
        id="a5b57"
        alignment="center"
        backgroundColor="{{
    currentSourceRow.Tier == 8 ? '#f3f00f' :
  currentSourceRow.Tier == 7 ? '#f300f0' :
  currentSourceRow.Tier == 6 ? '#03f0ff' :
  currentSourceRow.Tier == 5 ? '#33007f' :
  currentSourceRow.Tier == 4 ? '#35407f' :
  currentSourceRow.Tier == 3 ? '#33007f' :
  currentSourceRow.Tier == 2 ? '#33007f' :
  currentSourceRow.Tier ==  1 ? '#7300ff10; :
  '#33007f'
}}"
        editableOptions={{ showStepper: true, allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="sum"
        headerTextColor="rgba(23, 92, 97, 1)"
        key="Tier"
        label="TIER"
        optionList={{
          manualData: [
            {
              value: "1",
              label: "| Tier 1",
              color: "rgba(0, 0, 0, 0)",
              textColor: "#dfcd87",
              icon: "bold/interface-award-crown",
              caption: "",
            },
            {
              value: 2,
              label: "| Tier 2",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(196, 198, 218, 1)",
              icon: "bold/shopping-jewelry-diamond-2",
            },
            {
              value: 3,
              label: "| Tier 3",
              icon: "bold/interface-favorite-star",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(125, 170, 222, 1)",
            },
            {
              value: 4,
              label: "| Tier 4",
              icon: "bold/money-graph-arrow-increase",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(127, 111, 242, 1)",
            },
            {
              value: 5,
              label: "| Tier 5",
              icon: "bold/interface-hierarchy-9",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(186, 106, 255, 1)",
            },
            {
              value: 6,
              icon: "bold/interface-weather-rain-1",
              label: "| Tier 6",
              color: "rgba(0, 0, 0, 0)",
              textColor: "#ff89f6",
              fallbackText: "",
            },
            {
              value: 7,
              icon: "bold/money-graph-bar-decrease",
              label: "| Tier 7",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(255, 86, 238, 1)",
            },
            {
              value: 8,
              label: "| Tier 8",
              icon: "bold/interface-delete-bin-2",
              caption: "",
              textColor: "rgba(255, 62, 151, 1)",
              color: "rgba(72, 72, 72, 0)",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="left"
        size={80.84375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTier\n</div>'
        }
      />
      <Column
        id="a80e8"
        alignment="center"
        backgroundColor="rgba(75, 0, 255, 0.15)"
        cellTooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 12px #000000 ;\n">\n  Overall Grade<br> ⌁ <b>{{ (() => {\n    const map = {\n      "Ashton Jeanty": 95.7,\n      "Travis Hunter": 93.5,\n      "Omarion Hampton": 89.7,\n      "Tetairoa McMillan": 90.5,\n      "TreVeyon Henderson": 88.1,\n      "Quinshon Judkins": 87.5,\n      "Emeka Egbuka": 89.1,\n      "Tyler Warren": 88.9,\n      "Colston Loveland": 90.1,\n      "R.J. Harvey": 86.2,\n      "Kaleb Johnson": 85.6,\n      "Matthew Golden": 87.1,\n      "Luther Burden": 86.9,\n      "Jayden Higgins": 86.3,\n      "Tre Harris": 86.3,\n      "Jack Bech": 85.7,\n      "Cameron Skattebo": 87.3,\n      "Kyle Williams": 86.9,\n      "Mason Taylor": 74.8,\n      "Bhayshul Tuten": 79.8,\n      "Jaylin Noel": 85.6,\n      "Terrance Ferguson": 77.3,\n      "Jaydon Blue": 74.0,\n      "Elijah Arroyo": 74.1,\n      "Pat Bryant": 79.6,\n      "Dylan Sampson": 81.6,\n      "Harold Fannin Jr.": 86.5,\n      "Jalen Royals": 84.8,\n      "Devin Neal": 81.4,\n      "Trevor Etienne": 79.8,\n      "Elic Ayomanor": 78.0,\n      "Jarquez Hunter": 76.1,\n      "DJ Giddens": 80.7,\n      "Isaac TeSlaa": 74.9,\n      "Jordan James": 76.1,\n      "Ollie Gordon": 73.7,\n      "Jo\'quavious Marks": 69.9,\n      "Dont\'e Thornton": 74.5,\n      "Tory Horton": 84.1,\n      "Brashard Smith": 72.8,\n      "Oronde Gadsden II": 78.7,\n      "Savion Williams": 78.3,\n      "Tahj Brooks": 81.4,\n      "Kyle Monangai": 74.2,\n      "Tai Felton": 81.7,\n      "Chimere Dike": 76.3,\n      "Gunnar Helm": 71.3,\n      "Jaylin Lane": 77.2,\n      "Damien Martinez": 80.9,\n      "Jimmy Horn Jr.": 72.4,\n      "Jacory Croskey-Merritt": 72.1,\n      "Arian Smith": 71.2,\n      "Keandre Lambert-Smith": 79.7,\n      "Tez Johnson": 79.9,\n      "Phil Mafah": 68.0,\n      "LeQuint Allen": 66.7,\n      "Mitchell Evans": 70.5,\n      "Thomas Fidone III": 70.4,\n      "LaJohntay Wester": 74.2,\n      "Ricky White": 79.2,\n      "Moliki Matavao": 62.6,\n      "Kaden Prather": 72.9,\n      "Luke Lachey": 69.2\n    };\n    const v = map[currentSourceRow.PLAYER];\n    return v ?? item;    // Fallback to the cell value if name mismatch\n  })() }}</b> ⌁ \n</div>\n'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "60",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "79",
        }}
        groupAggregationMode="average"
        key="OVR GRADE"
        label="OVR GRD"
        optionList={{
          iconByIndex: "",
          mode: "manual",
          textColorByIndex: "",
          labelByIndex: "",
          valueByIndex: "",
          fallbackTextByIndex: "",
          hiddenByIndex: "",
          captionByIndex: "",
          colorByIndex: "",
          mappedData: "[]",
        }}
        placeholder="Enter value"
        position="center"
        size={102.34375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item >89}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(231, 255, 248, 0.03)",
              tooltip: "",
            },
            {
              showWhen: "{{item >80}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(0, 109, 242, 0.03)",
            },
            {
              showWhen: "{{item >75}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(124, 83, 204, 0.03)",
            },
            {
              showWhen: "true",
              label: "{{ item }}",
              icon: "",
              color: "rgba(68, 76, 87, 0.03)",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nOverall Grade\n</div>'
        }
      />
      <Column
        id="05ab0"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(20, 26, 50)"
        headerTextColor="#ffffff"
        key="truADP"
        label="ADP"
        optionList={{
          iconByIndex: "",
          mode: "manual",
          textColorByIndex: "",
          labelByIndex: "",
          valueByIndex: "",
          fallbackTextByIndex: "",
          hiddenByIndex: "",
          captionByIndex: "",
          colorByIndex: "",
          mappedData: "",
        }}
        placeholder="Enter value"
        position="center"
        size={82}
        summaryAggregationMode="none"
        textColor="{{ 
  currentSourceRow.truADP < 53.9 ? '#00FFAA':
  currentSourceRow.truADP < 90 ? '#00FfFF':
     currentSourceRow.truADP < 130 ? '#90B8FC':
     currentSourceRow.truADP < 165 ? '#80B3FF':
     currentSourceRow.truADP < 200 ? '#a34fff':
   currentSourceRow.truADP < 250 ? '#ff91Fd':
    currentSourceRow.truADP < 300 ? '#ff91cd':
    currentSourceRow.truADP < 350 ? '#ff91cd':
     currentSourceRow.truADP < 699 ? '#FF00FF':'' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nAverage Draft Position\n</div>'
        }
        valueOverride="［ {{item}} ］"
      />
      <Column
        id="328dc"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="Rook ADP"
        label="ROOKIE ADP  "
        placeholder="Enter value"
        position="center"
        size={75.21875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRookie Average Draft Position\n</div>'
        }
      />
      <Column
        id="62082"
        alignment="center"
        backgroundColor="rgba(104, 141, 243, 0.03)"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RD"
        label="RD 📶"
        placeholder="Enter value"
        position="center"
        size={54.9375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "",
              label: "",
              color: "rgba(135, 230, 179, 1)",
              icon: "bold/interface-arrows-up-alternate",
            },
            {
              showWhen: "{{ item < 7 }}",
              label: "",
              color: "#F8DBD8",
              icon: "bold/money-graph-arrow-decrease",
            },
            {
              showWhen: "{{ item > 6 }}",
              label: "",
              color: "rgba(236, 116, 154, 1)",
              icon: "bold/interface-arrows-down-alternate",
            },
            {
              showWhen: "{{ item < 5 }}",
              label: "",
              color: "#D7EAE0",
              icon: "bold/money-graph-arrow-increase",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRound Drafted\n</div>'
        }
      />
      <Column
        id="95105"
        alignment="center"
        backgroundColor="rgba(104, 141, 243, 0.03)"
        cellTooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -10px;\n   font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 12px #000000 ;\n">\nPick Drafted<br> ⌁ <b>{{item}}</b> ⌁ \n</div>\n\n'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "", color: "" }}
        groupAggregationMode="sum"
        key="PK#"
        label="PK"
        placeholder="Enter value"
        position="center"
        size={69.9375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item <33}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(196, 253, 234, 0.15)",
              tooltip: "",
            },
            {
              showWhen: "{{item < 68}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(186, 255, 255, 0.15)",
            },
            {
              showWhen: "{{item < 90}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(186, 243, 255, 0.15)",
            },
            {
              showWhen: "{{item < 130}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(229, 205, 255, 0.3)",
            },
            {
              showWhen: "{{item >190}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(251, 164, 234, 1)",
            },
            {
              showWhen: "{{item >130}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(232, 177, 250, 0.5)",
              tooltip: "",
            },
            { showWhen: "{{item}}", label: "UD", icon: "" },
          ],
        }}
        summaryAggregationMode="none"
        textColor="{{ theme.danger }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPick Drafted [Overall]\n</div>'
        }
      />
      <Column
        id="41f3f"
        alignment="center"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="NCAA"
        label="NCAA"
        placeholder="Enter value"
        position="center"
        size={61.515625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTeam [NCAA]\n</div>'
        }
      />
      <Column
        id="53da5"
        alignment="center"
        editable="false"
        format="multilineString"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
        textColor="rgba(255, 255, 255, 1)"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nAge\n</div>'
        }
      />
      <Column
        id="7a71b"
        alignment="center"
        format="string"
        formatOptions={{ automaticColors: true, notation: "standard" }}
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={46.03125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nHeight\n</div>'
        }
      />
      <Column
        id="f718d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={47.875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nWeight\n</div>'
        }
      />
      <Column
        id="05e56"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="40"
        label="40"
        placeholder="Enter value"
        position="center"
        size={46.515625}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow[\"40\"] == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n40 Yard Dash\n</div>'
        }
      />
      <Column
        id="cf84f"
        alignment="left"
        backgroundColor="rgba(185, 190, 209, 0.03)"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\nAthletic Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(198, 203, 231, 1)"
        key="ATHL"
        label="ATHL GRD"
        placeholder="Enter value"
        position="center"
        size={78.6875}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item > 91.9}}",
              label: "{{ item }}",
              icon: "bold/image-flash-1",
              color: "rgba(120, 210, 171, 1)",
            },
            {
              showWhen: "{{item > 87}}",
              label: "{{ item }}",
              icon: "bold/image-flash-2",
              color: "rgba(190, 254, 234, 0.17)",
            },
            {
              showWhen: "{{ item > 82.9 }}",
              label: "{{ item }}",
              icon: "bold/shopping-business-startup",
              color: "rgba(138, 255, 255, 0.13)",
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{item}}",
              icon: "bold/mail-send-email",
              color: "rgba(185, 223, 255, 0.13)",
            },
            {
              showWhen: "{{item > 76}}",
              label: "{{ item }}",
              icon: "bold/mail-send-email",
            },
            {
              showWhen: "{{item < 76}}",
              label: "{{item}}",
              icon: "bold/phone-signal-low",
              color: "rgba(255, 178, 214, 0.15)",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nAthletic Grade\n</div>'
        }
      />
      <Column
        id="4bffd"
        alignment="center"
        backgroundColor="rgba(63, 1, 255, 0.05)"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.9em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nCEILING ⌁ <b>{{item}}/5</b> \n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="rating"
        formatOptions={{ icon: "", size: "small", icons: "stars" }}
        groupAggregationMode="average"
        key="CL"
        label="CEILING"
        placeholder="Enter value"
        position="center"
        size={98}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProjected Ceiling\n</div>'
        }
      />
      <Column
        id="5b01a"
        alignment="center"
        backgroundColor="rgba(131, 0, 255, 0.05)"
        cellTooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.9em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nFLOOR ⌁ <b>{{item}}/5</b>\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="rating"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          size: "small",
          icons: "stars",
        }}
        groupAggregationMode="sum"
        key="FL"
        label="FLOOR"
        placeholder="Enter value"
        position="center"
        size={101.5}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProjected Floor\n</div>'
        }
      />
      <Column
        id="93ad9"
        alignment="center"
        backgroundColor="rgba(185, 190, 209, 0.03)"
        caption="• {{ item }} •"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProduction Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "55",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "75",
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#141a32"
        headerTextColor="rgba(183, 190, 223, 1)"
        key="PRD GRADE"
        label="PRD GRD"
        placeholder="Enter value"
        position="center"
        size={67.09375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProduction Grade\n</div>'
        }
      />
      <Column
        id="d91e6"
        alignment="center"
        backgroundColor="rgba(185, 190, 209, 0.03)"
        caption="• {{ item }} •"
        cellTooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nEfficiency Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "50",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "75",
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#141a32"
        headerTextColor="#aeb9ea"
        key="EFF GRADE"
        label="EFF GRD"
        placeholder="Enter value"
        position="center"
        size={69.671875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nEfficiency Grade\n</div>'
        }
      />
      <Column
        id="bf9a4"
        alignment="center"
        backgroundColor="rgba(178, 255, 249, 0.03)"
        cellTooltip="{{ item }}"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(178, 255, 249, 1)"
        key="ELU GRADE"
        label="ELU GRD💥"
        placeholder="Enter value"
        position="center"
        size={85.890625}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{ item > 85}}",
              label: "{{ item }}",
              icon: "bold/nature-ecology-comet",
              color: "rgba(190, 254, 234, 0.17)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nElusiveness Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{ item }}",
              icon: "bold/interface-arrows-shuffle",
              color: "rgba(224, 245, 255, 0.2)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nElusiveness Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item < 75}}",
              label: "{{ item }}",
              icon: "bold/interface-weather-humidity-none",
              color: "rgba(255, 178, 214, 0.15)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nElusiveness Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "true",
              label: "{{item}}",
              icon: "bold/interface-block",
              color: "rgba(224, 224, 224, 0.1)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\n <b>N/A</b> ⌁ [RB–ONLY Metric]\n</div>',
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nElusiveness Grade\n</div>'
        }
      />
      <Column
        id="65b64"
        alignment="left"
        backgroundColor="rgba(182, 184, 193, 0.03)"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b7bedf"
        key="FILM GRADE"
        label="FILM 
GRD"
        placeholder="Enter value"
        position="center"
        size={77.609375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item > 85}}",
              label: "{{ item }}",
              icon: "bold/entertainment-camera-video",
              color: "rgba(190, 254, 234, 0.17)",
            },
            {
              showWhen: "{{  item > 78}}",
              label: "{{ item }}",
              icon: "bold/computer-connection-video-camera",
              color: "rgba(224, 245, 255, 0.2)",
            },
            {
              showWhen: "{{item < 79}}",
              label: "{{ item }}",
              icon: "bold/entertainment-recording-tape-1",
              color: "rgba(255, 178, 214, 0.15)",
            },
            {
              showWhen: "true",
              label: "{{item}}",
              icon: "bold/interface-page-controller-loading-half",
              color: "rgba(227, 223, 223, 0.1)",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nFilm Grade\n</div>'
        }
      />
      <Column
        id="6beae"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="G"
        label="G"
        placeholder="Enter value"
        position="center"
        size={37.6875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nGames Played\n</div>'
        }
      />
      <Column
        id="571eb"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="SOS"
        label="SOS"
        placeholder="Enter value"
        position="center"
        size={53}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow.SOS == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nNCAA Strength of Schedule [Career Avg.]\n</div>'
        }
      />
      <Column
        id="e9438"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(181, 161, 254, 1)"
        key="YDS(t)"
        label="YDS ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={64.734375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [Total]\n</div>'
        }
      />
      <Column
        id="37293"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="TD(t)"
        label="TD
 ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={50.25}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [Total]\n</div>'
        }
      />
      <Column
        id="25637"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="YpG(t)"
        label="YpG 
⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={58.453125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards per Game [Total]\n</div>'
        }
      />
      <Column
        id="00b31"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="OPP(t)"
        label="OPP"
        placeholder="Enter value"
        position="center"
        size={58.15625}
        summaryAggregationMode="none"
        textColor="#ffffff"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nOpportunities [CAR+TGT]\n</div>'
        }
      />
      <Column
        id="45011"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="IMP"
        label="IMP"
        placeholder="Enter value"
        position="center"
        size={57.484375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nImpact Plays [TD+1D]\n</div>'
        }
      />
      <Column
        id="3ce33"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "0",
          padDecimal: false,
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="IMP/ OPP"
        label="IMP/OPP"
        placeholder="Enter value"
        position="center"
        size={81.84375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nImpact Plays per Opportunity\n</div>'
        }
      />
      <Column
        id="4c58c"
        alignment="center"
        backgroundColor="rgba(110, 137, 245, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "3",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        key="DMTR"
        label="DMTR"
        placeholder="Enter value"
        position="center"
        size={66.890625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nDominator Rating\n</div>'
        }
      />
      <Column
        id="89a9d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="CAR"
        label="CAR"
        placeholder="Enter value"
        position="center"
        size={52.640625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nCarries\n</div>'
        }
      />
      <Column
        id="1ed57"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="ruYDS"
        label="YDS ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={58.3125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nYards [Rushing]\n</div>'
        }
      />
      <Column
        id="c7beb"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="YPC"
        label="YPC"
        placeholder="Enter value"
        position="center"
        size={51.71875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nYards per Carry\n</div>'
        }
      />
      <Column
        id="bb829"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="ruTD"
        label="TD  ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={59.953125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTouchdowns [Rushing]\n</div>'
        }
      />
      <Column
        id="3dd7a"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="ru1D"
        label="1D ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={53.515625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nFirst Downs [Rushing]\n</div>'
        }
      />
      <Column
        id="9cfdb"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="MTF"
        label="MTF"
        placeholder="Enter value"
        position="center"
        size={64}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nMissed Tackles Forced\n</div>'
        }
      />
      <Column
        id="8a9ca"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "3",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="MTF/ A"
        label="MTF/A"
        placeholder="Enter value"
        position="center"
        size={64.78125}
        summaryAggregationMode="none"
        textColor={
          "{{ currentSourceRow[\"MTF/ A\"] == \"NA\" ? '#8F8F8F':'' }}"
        }
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nMissed Tackles Forced per Attempt\n</div>'
        }
      />
      <Column
        id="af47e"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="YCO"
        label="YCO"
        placeholder="Enter value"
        position="center"
        size={51.78125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n Yards after Contact\n</div>'
        }
      />
      <Column
        id="bc182"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="YACO/A"
        label="YCO/A"
        placeholder="Enter value"
        position="center"
        size={74}
        summaryAggregationMode="none"
        textColor={
          "{{ currentSourceRow[\"YACO/A\"] == \"NA\" ? '#8F8F8F':'' }}"
        }
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nYards after Contact\nper Attempt\n</div>'
        }
      />
      <Column
        id="76cd8"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "3",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="rgba(198, 255, 232, 1)"
        key="ELU"
        label="•ELU•"
        placeholder="Enter value"
        position="center"
        size={68}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow.ELU == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nElusiveness Rating\n</div>'
        }
      />
      <Column
        id="3620d"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="TGT"
        label="TGT"
        placeholder="Enter value"
        position="center"
        size={56}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTargets\n</div>'
        }
      />
      <Column
        id="38694"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="REC"
        label="REC"
        placeholder="Enter value"
        position="center"
        size={59}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nReceptions\n</div>'
        }
      />
      <Column
        id="db7c4"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="recYDS"
        label="YDS
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={51.140625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [Receiving]\n</div>'
        }
      />
      <Column
        id="e7cf5"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="rgba(153, 205, 255, 1)"
        key="recTD"
        label="TD
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={50.9375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [Receiving]\n</div>'
        }
      />
      <Event
        event="selectRow"
        method=""
        params={{}}
        pluginId=""
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Table>
  </View>
  <View
    id="da965"
    disabled={false}
    hidden={false}
    icon="bold/computer-connection-usb-port"
    iconPosition="left"
    label="WR"
    viewKey="WR2"
  >
    <Table
      id="table92"
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "RK": 1,\n    "PLAYER": "Travis Hunter",\n    "POS": "WR",\n    "TM": "JAX",\n    "OVR GRADE": 94,\n    "truADP": 33.2,\n    "Rook ADP": 3,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>\\u2460</span>",\n    "PK#": "2",\n    "NCAA": "COLO",\n    "AGE": 22.2,\n    "HT": "6\'0\\"",\n    "WT": 188,\n    "40": "NA",\n    "ATHL": 96,\n    "CL": 5,\n    "FL": 3.5,\n    "PRD GRADE": 88.7,\n    "EFF GRADE": 96.3,\n    "RR GRD": 93.4,\n    "FILM GRADE": 93,\n    "G": 29,\n    "SOS": "82.6",\n    "YDS(t)": 2161,\n    "TD(t)": 25,\n    "YpG(t)": 74.52,\n    "OPP(t)": 220,\n    "IMP": 122,\n    "IMP/ OPP": 0.55,\n    "DMTR": "0.269",\n    "CAR": 3,\n    "ruYDS": -5,\n    "ruTD": 1,\n    "TGT": 217,\n    "REC": 170,\n    "recYDS": 2166,\n    "recTD": 24,\n    "rec1D": 96,\n    "YPRR": 2.42,\n    "YPR": 12.7,\n    "YAC/R": 4.38,\n    "Tier": 1,\n    "1DRR": 0.107\n  },\n  {\n    "RK": 2,\n    "PLAYER": "Tetairoa McMillan",\n    "POS": "WR",\n    "TM": "CAR",\n    "OVR GRADE": 90,\n    "truADP": 35.4,\n    "Rook ADP": 4,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>\\u2460</span>",\n    "PK#": "8",\n    "NCAA": "ARIZ",\n    "AGE": 22.3,\n    "HT": "6\'4\\"",\n    "WT": 219,\n    "40": "NA",\n    "ATHL": 87,\n    "CL": 4.5,\n    "FL": 4,\n    "PRD GRADE": 97.7,\n    "EFF GRADE": 89.8,\n    "RR GRD": 89.1,\n    "FILM GRADE": 88,\n    "G": 37,\n    "SOS": "81.4",\n    "YDS(t)": 3417,\n    "TD(t)": 26,\n    "YpG(t)": 92.35,\n    "OPP(t)": 342,\n    "IMP": 178,\n    "IMP/ OPP": 0.52,\n    "DMTR": "0.32",\n    "CAR": 1,\n    "ruYDS": 3,\n    "ruTD": 0,\n    "TGT": 341,\n    "REC": 213,\n    "recYDS": 3414,\n    "recTD": 26,\n    "rec1D": 152,\n    "YPRR": 2.37,\n    "YPR": 16,\n    "YAC/R": 5.45,\n    "Tier": 2,\n    "1DRR": 0.106\n  },\n  {\n    "RK": 3,\n    "PLAYER": "Emeka Egbuka",\n    "POS": "WR",\n    "TM": "TB",\n    "OVR GRADE": 89,\n    "truADP": 59.4,\n    "Rook ADP": 10,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>\\u2460</span>",\n    "PK#": "19",\n    "NCAA": "OSU",\n    "AGE": 22.8,\n    "HT": "6\'1\\"",\n    "WT": 202,\n    "40": "4.50",\n    "ATHL": 87,\n    "CL": 3.5,\n    "FL": 4,\n    "PRD GRADE": 95.7,\n    "EFF GRADE": 93.5,\n    "RR GRD": 91.1,\n    "FILM GRADE": 86,\n    "G": 47,\n    "SOS": "95.7",\n    "YDS(t)": 3017,\n    "TD(t)": 26,\n    "YpG(t)": 64.19,\n    "OPP(t)": 305,\n    "IMP": 170,\n    "IMP/ OPP": 0.56,\n    "DMTR": "0.195",\n    "CAR": 23,\n    "ruYDS": 150,\n    "ruTD": 2,\n    "TGT": 282,\n    "REC": 205,\n    "recYDS": 2867,\n    "recTD": 24,\n    "rec1D": 138,\n    "YPRR": 2.6,\n    "YPR": 14,\n    "YAC/R": 6.64,\n    "Tier": 3,\n    "1DRR": 0.125\n  },\n  {\n    "RK": 4,\n    "PLAYER": "Matthew Golden",\n    "POS": "WR",\n    "TM": "GB",\n    "OVR GRADE": 87,\n    "truADP": 70.8,\n    "Rook ADP": 12,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>\\u2460</span>",\n    "PK#": "23",\n    "NCAA": "TEX",\n    "AGE": 21.9,\n    "HT": "5\'11\\"",\n    "WT": 191,\n    "40": "4.29",\n    "ATHL": 94,\n    "CL": 4.5,\n    "FL": 2,\n    "PRD GRADE": 83.9,\n    "EFF GRADE": 81.3,\n    "RR GRD": 87.5,\n    "FILM GRADE": 86,\n    "G": 36,\n    "SOS": "88.3",\n    "YDS(t)": 1990,\n    "TD(t)": 22,\n    "YpG(t)": 55.28,\n    "OPP(t)": 202,\n    "IMP": 118,\n    "IMP/ OPP": 0.58,\n    "DMTR": "0.22",\n    "CAR": 0,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 202,\n    "REC": 135,\n    "recYDS": 1990,\n    "recTD": 22,\n    "rec1D": 96,\n    "YPRR": 1.85,\n    "YPR": 14.7,\n    "YAC/R": 5.64,\n    "Tier": 4,\n    "1DRR": 0.089\n  },\n  {\n    "RK": 5,\n    "PLAYER": "Luther Burden",\n    "POS": "WR",\n    "TM": "CHI",\n    "OVR GRADE": 87,\n    "truADP": 88.4,\n    "Rook ADP": 14,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>\\u2461</span>",\n    "PK#": "39",\n    "NCAA": "MIZZ",\n    "AGE": 21.6,\n    "HT": "6\'0\\"",\n    "WT": 206,\n    "40": "4.41",\n    "ATHL": 88,\n    "CL": 5,\n    "FL": 2,\n    "PRD GRADE": 92.6,\n    "EFF GRADE": 87.6,\n    "RR GRD": 84.1,\n    "FILM GRADE": 83,\n    "G": 38,\n    "SOS": "89.4",\n    "YDS(t)": 2493,\n    "TD(t)": 25,\n    "YpG(t)": 65.61,\n    "OPP(t)": 307,\n    "IMP": 129,\n    "IMP/ OPP": 0.42,\n    "DMTR": "0.34",\n    "CAR": 32,\n    "ruYDS": 210,\n    "ruTD": 4,\n    "TGT": 275,\n    "REC": 193,\n    "recYDS": 2283,\n    "recTD": 21,\n    "rec1D": 93,\n    "YPRR": 2.32,\n    "YPR": 11.8,\n    "YAC/R": 7.26,\n    "Tier": 4,\n    "1DRR": 0.095\n  },\n  {\n    "RK": 6,\n    "PLAYER": "Jayden Higgins",\n    "POS": "WR",\n    "TM": "HOU",\n    "OVR GRADE": 86,\n    "truADP": 91.1,\n    "Rook ADP": 15,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>\\u2461</span>",\n    "PK#": "34",\n    "NCAA": "ISU",\n    "AGE": 22.6,\n    "HT": "6\'4\\"",\n    "WT": 214,\n    "40": "4.47",\n    "ATHL": 91,\n    "CL": 4,\n    "FL": 2.5,\n    "PRD GRADE": 83.6,\n    "EFF GRADE": 90.2,\n    "RR GRD": 87.8,\n    "FILM GRADE": 80,\n    "G": 36,\n    "SOS": "83.0",\n    "YDS(t)": 2562,\n    "TD(t)": 28,\n    "YpG(t)": 71.17,\n    "OPP(t)": 264,\n    "IMP": 188,\n    "IMP/ OPP": 0.71,\n    "DMTR": "0.331",\n    "CAR": 0,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 264,\n    "REC": 169,\n    "recYDS": 2562,\n    "recTD": 28,\n    "rec1D": 160,\n    "YPRR": 2.37,\n    "YPR": 14.6,\n    "YAC/R": 4.64,\n    "Tier": 4,\n    "1DRR": 0.148\n  },\n  {\n    "RK": 7,\n    "PLAYER": "Tre Harris",\n    "POS": "WR",\n    "TM": "LAC",\n    "OVR GRADE": 86,\n    "truADP": 94.3,\n    "Rook ADP": 16,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>\\u2461</span>",\n    "PK#": "55",\n    "NCAA": "MISS",\n    "AGE": 23.3,\n    "HT": "6\'2\\"",\n    "WT": 205,\n    "40": "4.54",\n    "ATHL": 76,\n    "CL": 4,\n    "FL": 3,\n    "PRD GRADE": 94.4,\n    "EFF GRADE": 98,\n    "RR GRD": 83.1,\n    "FILM GRADE": 80,\n    "G": 46,\n    "SOS": "90.1",\n    "YDS(t)": 3567,\n    "TD(t)": 29,\n    "YpG(t)": 77.54,\n    "OPP(t)": 333,\n    "IMP": 176,\n    "IMP/ OPP": 0.53,\n    "DMTR": "0.289",\n    "CAR": 5,\n    "ruYDS": 22,\n    "ruTD": 0,\n    "TGT": 328,\n    "REC": 220,\n    "recYDS": 3545,\n    "recTD": 29,\n    "rec1D": 146,\n    "YPRR": 3,\n    "YPR": 16.1,\n    "YAC/R": 6.44,\n    "Tier": 4,\n    "1DRR": 0.124\n  },\n  {\n    "RK": 8,\n    "PLAYER": "Jack Bech",\n    "POS": "WR",\n    "TM": "LV",\n    "OVR GRADE": 86,\n    "truADP": 116.5,\n    "Rook ADP": 17,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>\\u2461</span>",\n    "PK#": "58",\n    "NCAA": "TCU",\n    "AGE": 22.6,\n    "HT": "6\'1\\"",\n    "WT": 214,\n    "40": "NA",\n    "ATHL": 77,\n    "CL": 3.5,\n    "FL": 3.5,\n    "PRD GRADE": 65.7,\n    "EFF GRADE": 72.9,\n    "RR GRD": 88.5,\n    "FILM GRADE": 82,\n    "G": 45,\n    "SOS": "78.3",\n    "YDS(t)": 1866,\n    "TD(t)": 13,\n    "YpG(t)": 41.47,\n    "OPP(t)": 203,\n    "IMP": 100,\n    "IMP/ OPP": 0.49,\n    "DMTR": "0.14",\n    "CAR": 3,\n    "ruYDS": -3,\n    "ruTD": 0,\n    "TGT": 200,\n    "REC": 133,\n    "recYDS": 1869,\n    "recTD": 13,\n    "rec1D": 87,\n    "YPRR": 1.86,\n    "YPR": 14.1,\n    "YAC/R": 5.5,\n    "Tier": 4,\n    "1DRR": 0.086\n  },\n  {\n    "RK": 9,\n    "PLAYER": "Kyle Williams",\n    "POS": "WR",\n    "TM": "NE",\n    "OVR GRADE": 87,\n    "truADP": 127.6,\n    "Rook ADP": 20,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>\\u2462</span>",\n    "PK#": "69",\n    "NCAA": "WSU",\n    "AGE": 22.7,\n    "HT": "5\'11\\"",\n    "WT": 190,\n    "40": "4.40",\n    "ATHL": 85,\n    "CL": 3.5,\n    "FL": 3,\n    "PRD GRADE": 92.4,\n    "EFF GRADE": 86,\n    "RR GRD": 88.1,\n    "FILM GRADE": "NA",\n    "G": 50,\n    "SOS": "77.4",\n    "YDS(t)": 3678,\n    "TD(t)": 29,\n    "YpG(t)": 73.56,\n    "OPP(t)": 393,\n    "IMP": 189,\n    "IMP/ OPP": 0.48,\n    "DMTR": "0.318",\n    "CAR": 17,\n    "ruYDS": 72,\n    "ruTD": 0,\n    "TGT": 376,\n    "REC": 248,\n    "recYDS": 3606,\n    "recTD": 29,\n    "rec1D": 155,\n    "YPRR": 2.07,\n    "YPR": 14.5,\n    "YAC/R": 6.35,\n    "Tier": 4,\n    "1DRR": 0.089\n  },\n  {\n    "RK": 10,\n    "PLAYER": "Jaylin Noel",\n    "POS": "WR",\n    "TM": "HOU",\n    "OVR GRADE": 86,\n    "truADP": 141.7,\n    "Rook ADP": 22,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>\\u2462</span>",\n    "PK#": "79",\n    "NCAA": "ISU",\n    "AGE": 22.8,\n    "HT": "5\'10\\"",\n    "WT": 194,\n    "40": "4.39",\n    "ATHL": 92,\n    "CL": 3.5,\n    "FL": 3,\n    "PRD GRADE": 92.4,\n    "EFF GRADE": 82.8,\n    "RR GRD": 87.7,\n    "FILM GRADE": 79,\n    "G": 51,\n    "SOS": "83.6",\n    "YDS(t)": 2938,\n    "TD(t)": 18,\n    "YpG(t)": 57.61,\n    "OPP(t)": 362,\n    "IMP": 146,\n    "IMP/ OPP": 0.4,\n    "DMTR": "0.212",\n    "CAR": 13,\n    "ruYDS": 84,\n    "ruTD": 0,\n    "TGT": 349,\n    "REC": 245,\n    "recYDS": 2854,\n    "recTD": 18,\n    "rec1D": 123,\n    "YPRR": 2.07,\n    "YPR": 11.6,\n    "YAC/R": 5.58,\n    "Tier": 5,\n    "1DRR": 0.089\n  },\n  {\n    "RK": 11,\n    "PLAYER": "Pat Bryant",\n    "POS": "WR",\n    "TM": "DEN",\n    "OVR GRADE": 80,\n    "truADP": 169.5,\n    "Rook ADP": 28,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>\\u2462</span>",\n    "PK#": "74",\n    "NCAA": "ILL",\n    "AGE": 22.6,\n    "HT": "6\'2\\"",\n    "WT": 204,\n    "40": "4.61",\n    "ATHL": 72,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 81.9,\n    "EFF GRADE": 82.8,\n    "RR GRD": 81.7,\n    "FILM GRADE": "NA",\n    "G": 45,\n    "SOS": "88.4",\n    "YDS(t)": 2108,\n    "TD(t)": 19,\n    "YpG(t)": 46.84,\n    "OPP(t)": 214,\n    "IMP": 115,\n    "IMP/ OPP": 0.54,\n    "DMTR": "0.255",\n    "CAR": 6,\n    "ruYDS": 17,\n    "ruTD": 0,\n    "TGT": 208,\n    "REC": 136,\n    "recYDS": 2091,\n    "recTD": 19,\n    "rec1D": 95,\n    "YPRR": 2.12,\n    "YPR": 15.4,\n    "YAC/R": 4.7,\n    "Tier": 5,\n    "1DRR": 0.096\n  },\n  {\n    "RK": 12,\n    "PLAYER": "Jalen Royals",\n    "POS": "WR",\n    "TM": "KC",\n    "OVR GRADE": 85,\n    "truADP": 161.9,\n    "Rook ADP": 26,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "PK#": "133",\n    "NCAA": "USU",\n    "AGE": 22.4,\n    "HT": "6\'0\\"",\n    "WT": 205,\n    "40": "4.42",\n    "ATHL": 89,\n    "CL": 3.5,\n    "FL": 1.5,\n    "PRD GRADE": 78.8,\n    "EFF GRADE": 90.9,\n    "RR GRD": 86.1,\n    "FILM GRADE": 80,\n    "G": 27,\n    "SOS": "70.0",\n    "YDS(t)": 1926,\n    "TD(t)": 21,\n    "YpG(t)": 71.33,\n    "OPP(t)": 185,\n    "IMP": 96,\n    "IMP/ OPP": 0.52,\n    "DMTR": "0.333",\n    "CAR": 1,\n    "ruYDS": 3,\n    "ruTD": 0,\n    "TGT": 184,\n    "REC": 125,\n    "recYDS": 1923,\n    "recTD": 21,\n    "rec1D": 75,\n    "YPRR": 2.42,\n    "YPR": 15.4,\n    "YAC/R": 6.81,\n    "Tier": 6,\n    "1DRR": 0.094\n  },\n  {\n    "RK": 13,\n    "PLAYER": "Elic Ayomanor",\n    "POS": "WR",\n    "TM": "TEN",\n    "OVR GRADE": 78,\n    "truADP": 170.5,\n    "Rook ADP": 29,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "PK#": "136",\n    "NCAA": "STAN",\n    "AGE": 22.1,\n    "HT": "6\'2\\"",\n    "WT": 206,\n    "40": "4.44",\n    "ATHL": 83,\n    "CL": 3,\n    "FL": 1.5,\n    "PRD GRADE": 76.7,\n    "EFF GRADE": 76.4,\n    "RR GRD": 75.1,\n    "FILM GRADE": 77,\n    "G": 24,\n    "SOS": "81.7",\n    "YDS(t)": 1853,\n    "TD(t)": 12,\n    "YpG(t)": 77.21,\n    "OPP(t)": 216,\n    "IMP": 94,\n    "IMP/ OPP": 0.44,\n    "DMTR": "0.389",\n    "CAR": 0,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 216,\n    "REC": 126,\n    "recYDS": 1853,\n    "recTD": 12,\n    "rec1D": 82,\n    "YPRR": 2.12,\n    "YPR": 14.7,\n    "YAC/R": 4.49,\n    "Tier": 6,\n    "1DRR": 0.094\n  },\n  {\n    "RK": 14,\n    "PLAYER": "Isaac TeSlaa",\n    "POS": "WR",\n    "TM": "DET",\n    "OVR GRADE": 75,\n    "truADP": 195.0,\n    "Rook ADP": 36,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>\\u2462</span>",\n    "PK#": "70",\n    "NCAA": "ARK",\n    "AGE": 23.4,\n    "HT": "6\'4\\"",\n    "WT": 214,\n    "40": "4.43",\n    "ATHL": 91,\n    "CL": 4,\n    "FL": 1,\n    "PRD GRADE": 58.5,\n    "EFF GRADE": 65.5,\n    "RR GRD": 74.7,\n    "FILM GRADE": "NA",\n    "G": 25,\n    "SOS": "NA",\n    "YDS(t)": 883,\n    "TD(t)": 5,\n    "YpG(t)": 35.32,\n    "OPP(t)": 101,\n    "IMP": 41,\n    "IMP/ OPP": 0.41,\n    "DMTR": "0.142",\n    "CAR": 1,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 100,\n    "REC": 62,\n    "recYDS": 883,\n    "recTD": 5,\n    "rec1D": 36,\n    "YPRR": 1.45,\n    "YPR": 14.2,\n    "YAC/R": 4.97,\n    "Tier": 6,\n    "1DRR": 0.059\n  },\n  {\n    "RK": 15,\n    "PLAYER": "Tory Horton",\n    "POS": "WR",\n    "TM": "SEA",\n    "OVR GRADE": 84,\n    "truADP": 197.9,\n    "Rook ADP": 38,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>\\u2464</span>",\n    "PK#": "166",\n    "NCAA": "CSU",\n    "AGE": 22.6,\n    "HT": "6\'2\\"",\n    "WT": 196,\n    "40": "4.41",\n    "ATHL": 87,\n    "CL": 3.5,\n    "FL": 2,\n    "PRD GRADE": 90.7,\n    "EFF GRADE": 87.3,\n    "RR GRD": 82.9,\n    "FILM GRADE": "NA",\n    "G": 50,\n    "SOS": "75.1",\n    "YDS(t)": 3632,\n    "TD(t)": 27,\n    "YpG(t)": 72.64,\n    "OPP(t)": 381,\n    "IMP": 180,\n    "IMP/ OPP": 0.47,\n    "DMTR": "0.267",\n    "CAR": 2,\n    "ruYDS": 31,\n    "ruTD": 0,\n    "TGT": 379,\n    "REC": 264,\n    "recYDS": 3601,\n    "recTD": 27,\n    "rec1D": 152,\n    "YPRR": 2.46,\n    "YPR": 13.6,\n    "YAC/R": 5.83,\n    "Tier": 6,\n    "1DRR": 0.104\n  },\n  {\n    "RK": 16,\n    "PLAYER": "Dont\'e Thornton",\n    "POS": "WR",\n    "TM": "LV",\n    "OVR GRADE": 74,\n    "truADP": 235.5,\n    "Rook ADP": 41,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "PK#": "108",\n    "NCAA": "TENN",\n    "AGE": 22.6,\n    "HT": "6\'5\\"",\n    "WT": 205,\n    "40": "4.30",\n    "ATHL": 95,\n    "CL": 4,\n    "FL": 1,\n    "PRD GRADE": 59.5,\n    "EFF GRADE": 75.6,\n    "RR GRD": 69.8,\n    "FILM GRADE": "NA",\n    "G": 42,\n    "SOS": "90.7",\n    "YDS(t)": 1433,\n    "TD(t)": 10,\n    "YpG(t)": 34.12,\n    "OPP(t)": 95,\n    "IMP": 53,\n    "IMP/ OPP": 0.56,\n    "DMTR": "0.139",\n    "CAR": 1,\n    "ruYDS": 9,\n    "ruTD": 0,\n    "TGT": 94,\n    "REC": 65,\n    "recYDS": 1424,\n    "recTD": 10,\n    "rec1D": 43,\n    "YPRR": 2.8,\n    "YPR": 21.9,\n    "YAC/R": 8.94,\n    "Tier": 6,\n    "1DRR": 0.085\n  },\n  {\n    "RK": 17,\n    "PLAYER": "Tai Felton",\n    "POS": "WR",\n    "TM": "MIN",\n    "OVR GRADE": 82,\n    "truADP": 247.5,\n    "Rook ADP": 46,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>\\u2462</span>",\n    "PK#": "102",\n    "NCAA": "MD",\n    "AGE": 22.3,\n    "HT": "6\'1\\"",\n    "WT": 183,\n    "40": "4.37",\n    "ATHL": 86,\n    "CL": 3.5,\n    "FL": 2,\n    "PRD GRADE": 87.8,\n    "EFF GRADE": 74.7,\n    "RR GRD": 78.2,\n    "FILM GRADE": "NA",\n    "G": 43,\n    "SOS": "92.6",\n    "YDS(t)": 2250,\n    "TD(t)": 17,\n    "YpG(t)": 52.33,\n    "OPP(t)": 267,\n    "IMP": 125,\n    "IMP/ OPP": 0.47,\n    "DMTR": "0.197",\n    "CAR": 3,\n    "ruYDS": 39,\n    "ruTD": 0,\n    "TGT": 264,\n    "REC": 172,\n    "recYDS": 2211,\n    "recTD": 17,\n    "rec1D": 106,\n    "YPRR": 1.86,\n    "YPR": 12.9,\n    "YAC/R": 6.19,\n    "Tier": 7,\n    "1DRR": 0.089\n  },\n  {\n    "RK": 18,\n    "PLAYER": "Savion Williams",\n    "POS": "WR",\n    "TM": "GB",\n    "OVR GRADE": 78,\n    "truADP": 259.5,\n    "Rook ADP": 49,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>\\u2462</span>",\n    "PK#": "87",\n    "NCAA": "TCU",\n    "AGE": 23.6,\n    "HT": "6\'4\\"",\n    "WT": 222,\n    "40": "4.48",\n    "ATHL": 87,\n    "CL": 3.5,\n    "FL": 1.5,\n    "PRD GRADE": 82.2,\n    "EFF GRADE": 76.6,\n    "RR GRD": 68.8,\n    "FILM GRADE": 77,\n    "G": 50,\n    "SOS": "78.3",\n    "YDS(t)": 2053,\n    "TD(t)": 20,\n    "YpG(t)": 41.06,\n    "OPP(t)": 272,\n    "IMP": 124,\n    "IMP/ OPP": 0.46,\n    "DMTR": "0.135",\n    "CAR": 62,\n    "ruYDS": 384,\n    "ruTD": 6,\n    "TGT": 210,\n    "REC": 138,\n    "recYDS": 1669,\n    "recTD": 14,\n    "rec1D": 82,\n    "YPRR": 1.55,\n    "YPR": 12.1,\n    "YAC/R": 5.41,\n    "Tier": 7,\n    "1DRR": 0.076\n  },\n  {\n    "RK": 19,\n    "PLAYER": "Jimmy Horn Jr.",\n    "POS": "WR",\n    "TM": "CAR",\n    "OVR GRADE": 72,\n    "truADP": 244.4,\n    "Rook ADP": 44,\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>\\u2465</span>",\n    "PK#": "208",\n    "NCAA": "COLO",\n    "AGE": 22.8,\n    "HT": "5\'8\\"",\n    "WT": 174,\n    "40": "4.46",\n    "ATHL": 71,\n    "CL": 2,\n    "FL": 2,\n    "PRD GRADE": 74.2,\n    "EFF GRADE": 67.2,\n    "RR GRD": 77.3,\n    "FILM GRADE": "NA",\n    "G": 46,\n    "SOS": "NA",\n    "YDS(t)": 2092,\n    "TD(t)": 12,\n    "YpG(t)": 45.48,\n    "OPP(t)": 258,\n    "IMP": 104,\n    "IMP/ OPP": 0.4,\n    "DMTR": "0.151",\n    "CAR": 16,\n    "ruYDS": 112,\n    "ruTD": 1,\n    "TGT": 242,\n    "REC": 163,\n    "recYDS": 1980,\n    "recTD": 11,\n    "rec1D": 85,\n    "YPRR": 1.55,\n    "YPR": 12.1,\n    "YAC/R": 7.02,\n    "Tier": 7,\n    "1DRR": 0.067\n  },\n  {\n    "RK": 20,\n    "PLAYER": "Keandre Lambert-Smith",\n    "POS": "WR",\n    "TM": "LAC",\n    "OVR GRADE": 80,\n    "truADP": 317.8,\n    "Rook ADP": 55,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>\\u2464</span>",\n    "PK#": "158",\n    "NCAA": "AUB",\n    "AGE": 22.9,\n    "HT": "6\'1\\"",\n    "WT": 190,\n    "40": "4.37",\n    "ATHL": 87,\n    "CL": 4,\n    "FL": 1.5,\n    "PRD GRADE": 80.1,\n    "EFF GRADE": 80.1,\n    "RR GRD": 71.5,\n    "FILM GRADE": "NA",\n    "G": 58,\n    "SOS": "94.3",\n    "YDS(t)": 2704,\n    "TD(t)": 19,\n    "YpG(t)": 46.62,\n    "OPP(t)": 285,\n    "IMP": 134,\n    "IMP/ OPP": 0.47,\n    "DMTR": "0.17",\n    "CAR": 1,\n    "ruYDS": 2,\n    "ruTD": 0,\n    "TGT": 284,\n    "REC": 176,\n    "recYDS": 2702,\n    "recTD": 19,\n    "rec1D": 114,\n    "YPRR": 1.77,\n    "YPR": 15.4,\n    "YAC/R": 7.03,\n    "Tier": 7,\n    "1DRR": 0.075\n  },\n  {\n    "RK": 21,\n    "PLAYER": "Jaylin Lane",\n    "POS": "WR",\n    "TM": "WAS",\n    "OVR GRADE": 77,\n    "truADP": 281.6,\n    "Rook ADP": 50,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "PK#": "125",\n    "NCAA": "VT",\n    "AGE": 23.2,\n    "HT": "5\'10\\"",\n    "WT": 191,\n    "40": "4.34",\n    "ATHL": 94,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 83,\n    "EFF GRADE": 78.2,\n    "RR GRD": "NA",\n    "FILM GRADE": "NA",\n    "G": 54,\n    "SOS": "80.4",\n    "YDS(t)": 2804,\n    "TD(t)": 21,\n    "YpG(t)": 51.93,\n    "OPP(t)": 340,\n    "IMP": 154,\n    "IMP/ OPP": 0.45,\n    "DMTR": "0.206",\n    "CAR": 46,\n    "ruYDS": 264,\n    "ruTD": 3,\n    "TGT": 294,\n    "REC": 203,\n    "recYDS": 2540,\n    "recTD": 18,\n    "rec1D": 119,\n    "YPRR": 2.01,\n    "YPR": 12.5,\n    "YAC/R": 8.06,\n    "Tier": 8,\n    "1DRR": 0.094\n  },\n  {\n    "RK": 22,\n    "PLAYER": "Chimere Dike",\n    "POS": "WR",\n    "TM": "TEN",\n    "OVR GRADE": 76,\n    "truADP": 285.4,\n    "Rook ADP": 52,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "PK#": "103",\n    "NCAA": "FLA",\n    "AGE": 23.6,\n    "HT": "6\'1\\"",\n    "WT": 196,\n    "40": "4.34",\n    "ATHL": 91,\n    "CL": 2.5,\n    "FL": 2.5,\n    "PRD GRADE": 72,\n    "EFF GRADE": 65.8,\n    "RR GRD": "NA",\n    "FILM GRADE": "NA",\n    "G": 57,\n    "SOS": "91.9",\n    "YDS(t)": 2360,\n    "TD(t)": 12,\n    "YpG(t)": 41.4,\n    "OPP(t)": 251,\n    "IMP": 112,\n    "IMP/ OPP": 0.45,\n    "DMTR": "0.179",\n    "CAR": 14,\n    "ruYDS": 99,\n    "ruTD": 1,\n    "TGT": 237,\n    "REC": 139,\n    "recYDS": 2261,\n    "recTD": 11,\n    "rec1D": 95,\n    "YPRR": 1.72,\n    "YPR": 16.3,\n    "YAC/R": 5.42,\n    "Tier": 8,\n    "1DRR": 0.072\n  },\n  {\n    "RK": 23,\n    "PLAYER": "Arian Smith",\n    "POS": "WR",\n    "TM": "NYG",\n    "OVR GRADE": 71,\n    "truADP": 286.0,\n    "Rook ADP": 53,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "PK#": "110",\n    "NCAA": "UGA",\n    "AGE": 22.8,\n    "HT": "6\'0\\"",\n    "WT": 179,\n    "40": "4.36",\n    "ATHL": 88,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 60.3,\n    "EFF GRADE": 65.2,\n    "RR GRD": "NA",\n    "FILM GRADE": "NA",\n    "G": 45,\n    "SOS": "NA",\n    "YDS(t)": 1428,\n    "TD(t)": 10,\n    "YpG(t)": 31.73,\n    "OPP(t)": 121,\n    "IMP": 59,\n    "IMP/ OPP": 0.49,\n    "DMTR": "0.105",\n    "CAR": 9,\n    "ruYDS": 88,\n    "ruTD": 0,\n    "TGT": 112,\n    "REC": 68,\n    "recYDS": 1340,\n    "recTD": 10,\n    "rec1D": 45,\n    "YPRR": 2.27,\n    "YPR": 19.7,\n    "YAC/R": 7.87,\n    "Tier": 8,\n    "1DRR": 0.076\n  },\n  {\n    "RK": 24,\n    "PLAYER": "Tez Johnson",\n    "POS": "WR",\n    "TM": "TB",\n    "OVR GRADE": 80,\n    "truADP": 299.5,\n    "Rook ADP": 54,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>\\u2466</span>",\n    "PK#": "235",\n    "NCAA": "ORE",\n    "AGE": 23.2,\n    "HT": "5\'10\\"",\n    "WT": 154,\n    "40": "4.51",\n    "ATHL": 74,\n    "CL": 2,\n    "FL": 1.5,\n    "PRD GRADE": 95.9,\n    "EFF GRADE": 96.3,\n    "RR GRD": 88.8,\n    "FILM GRADE": "NA",\n    "G": 62,\n    "SOS": "88.9",\n    "YDS(t)": 3925,\n    "TD(t)": 29,\n    "YpG(t)": 63.31,\n    "OPP(t)": 416,\n    "IMP": 210,\n    "IMP/ OPP": 0.5,\n    "DMTR": "0.22",\n    "CAR": 12,\n    "ruYDS": 66,\n    "ruTD": 1,\n    "TGT": 404,\n    "REC": 307,\n    "recYDS": 3859,\n    "recTD": 28,\n    "rec1D": 178,\n    "YPRR": 2.85,\n    "YPR": 12.6,\n    "YAC/R": 7.92,\n    "Tier": 8,\n    "1DRR": 0.131\n  },\n  {\n    "RK": 25,\n    "PLAYER": "Ricky White",\n    "POS": "WR",\n    "TM": "SEA",\n    "OVR GRADE": 79,\n    "truADP": 347.1,\n    "Rook ADP": 59,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>\\u2466</span>",\n    "PK#": "238",\n    "NCAA": "UNLV",\n    "AGE": 23.4,\n    "HT": "6\'1\\"",\n    "WT": 184,\n    "40": "4.61",\n    "ATHL": 69,\n    "CL": 1.5,\n    "FL": 2,\n    "PRD GRADE": 95.9,\n    "EFF GRADE": 88.6,\n    "RR GRD": 82.7,\n    "FILM GRADE": "NA",\n    "G": 43,\n    "SOS": "NA",\n    "YDS(t)": 3369,\n    "TD(t)": 24,\n    "YpG(t)": 78.35,\n    "OPP(t)": 363,\n    "IMP": 161,\n    "IMP/ OPP": 0.44,\n    "DMTR": "0.377",\n    "CAR": 3,\n    "ruYDS": 5,\n    "ruTD": 0,\n    "TGT": 360,\n    "REC": 227,\n    "recYDS": 3364,\n    "recTD": 24,\n    "rec1D": 137,\n    "YPRR": 2.69,\n    "YPR": 14.8,\n    "YAC/R": 6.03,\n    "Tier": 8,\n    "1DRR": 0.11\n  },\n  {\n    "RK": 26,\n    "PLAYER": "Kaden Prather",\n    "POS": "WR",\n    "TM": "BUF",\n    "OVR GRADE": 73,\n    "truADP": 667.1,\n    "Rook ADP": 63,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>\\u2466</span>",\n    "PK#": "240",\n    "NCAA": "MD",\n    "AGE": 22.8,\n    "HT": "6\'4\\"",\n    "WT": 204,\n    "40": "4.46",\n    "ATHL": 76,\n    "CL": 1.5,\n    "FL": 1,\n    "PRD GRADE": 80,\n    "EFF GRADE": 66.3,\n    "RR GRD": 69.5,\n    "FILM GRADE": "NA",\n    "G": 45,\n    "SOS": "90.6",\n    "YDS(t)": 1997,\n    "TD(t)": 12,\n    "YpG(t)": 44.38,\n    "OPP(t)": 258,\n    "IMP": 115,\n    "IMP/ OPP": 0.45,\n    "DMTR": "0.161",\n    "CAR": 2,\n    "ruYDS": 35,\n    "ruTD": 0,\n    "TGT": 256,\n    "REC": 162,\n    "recYDS": 1962,\n    "recTD": 12,\n    "rec1D": 102,\n    "YPRR": 1.52,\n    "YPR": 12.1,\n    "YAC/R": 4.51,\n    "Tier": 8,\n    "1DRR": 0.079\n  },\n  {\n    "RK": 27,\n    "PLAYER": "LaJohntay Wester",\n    "POS": "WR",\n    "TM": "BAL",\n    "OVR GRADE": 74,\n    "truADP": 686.9,\n    "Rook ADP": 64,\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>\\u2465</span>",\n    "PK#": "203",\n    "NCAA": "COLO",\n    "AGE": 23.3,\n    "HT": "5\'10\\"",\n    "WT": 163,\n    "40": "4.46",\n    "ATHL": 72,\n    "CL": 1.5,\n    "FL": 1,\n    "PRD GRADE": 98,\n    "EFF GRADE": 86.8,\n    "RR GRD": "NA",\n    "FILM GRADE": "NA",\n    "G": 57,\n    "SOS": "NA",\n    "YDS(t)": 3810,\n    "TD(t)": 33,\n    "YpG(t)": 66.84,\n    "OPP(t)": 498,\n    "IMP": 217,\n    "IMP/ OPP": 0.44,\n    "DMTR": "0.278",\n    "CAR": 37,\n    "ruYDS": 215,\n    "ruTD": 2,\n    "TGT": 461,\n    "REC": 324,\n    "recYDS": 3595,\n    "recTD": 31,\n    "rec1D": 173,\n    "YPRR": 2.03,\n    "YPR": 11.1,\n    "YAC/R": 5.64,\n    "Tier": 8,\n    "1DRR": 0.098\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicColumnProperties={{ formatByIndex: "auto", labelByIndex: "f" }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      headerTextWrap={true}
      linkedFilterId=""
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      style={{
        headerFontFamily: "Michroma",
        fontWeight: "100",
        rowSeparator: "rgba(130, 138, 179, 0.04)",
        border: "rgba(130, 138, 179, 0.2)",
        hoverRowBackground: "rgba(87, 0, 255, 0.4)",
        alternateRowBackground: "rgba(26, 26, 50, 1)",
        background: "rgba(23, 23, 44, 1)",
        cellText: "rgba(255, 255, 255, 1)",
        fontSize: "12px",
        fontFamily: "Product Sans",
        headerFontWeight: "400",
        headerBackground: "#141a32",
        headerFontSize: "10px",
      }}
    >
      <Column
        id="d6166"
        alignment="center"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RK"
        label="RK"
        placeholder="Enter value"
        position="left"
        size={51.140625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRank\n</div>'
        }
      />
      <Column
        id="3220b"
        alignment="left"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="PLAYER"
        label="PLAYER"
        placeholder="Enter value"
        position="left"
        size={140.859375}
        summaryAggregationMode="none"
        textColor="{{ currentSourceRow.POS === 'RB' ? '#EaffEa'
  : currentSourceRow.POS === 'TE' ? '#ffefff'
  : currentSourceRow.POS === 'WR' ? '#e1ffff'
  : '' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPlayer Name\n</div>'
        }
      />
      <Column
        id="f83ae"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              ordered: [
                { value: "QB" },
                { color: "#ff2a6d" },
                { textColor: "rgba(18, 18, 18, 1)" },
                { icon: "" },
                { label: "" },
              ],
            },
            {
              value: "WR",
              color: "rgba(88, 167, 255, 0)",
              textColor: "#58a7ff",
              icon: "bold/computer-connection-usb-port",
            },
            {
              value: "RB",
              icon: "bold/travel-transportation-bus",
              color: "rgba(34, 228, 176, 0)",
              textColor: "#22e4b0",
            },
            {
              value: "TE",
              textColor: "#8300ff",
              color: "rgba(0, 0, 0, 0)",
              icon: "bold/interface-security-shield-4",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="left"
        size={66.859375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPosition\n</div>'
        }
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="50caa"
        alignment="center"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="none"
        key="TM"
        label="TM"
        optionList={{
          mode: "mapped",
          mappedData:
            '[\n  { value: "ARI", color: "#97233F", textColor: "#FFB612" },  // red ⟡ yellow :contentReference[oaicite:0]{index=0}\n  { value: "ATL", color: "#A71930", textColor: "#000000" },  // red ⟡ black :contentReference[oaicite:1]{index=1}\n  { value: "BAL", color: "#241773", textColor: "#9E7C0C" },  // purple ⟡ gold :contentReference[oaicite:2]{index=2}\n  { value: "BUF", color: "#00338D", textColor: "#C60C30" },  // royal ⟡ red :contentReference[oaicite:3]{index=3}\n  { value: "CAR", color: "#0085CA", textColor: "#000000" },  // blue ⟡ black :contentReference[oaicite:4]{index=4}\n  { value: "CHI", color: "#0B162A", textColor: "#F63F00" },  // navy ⟡ orange :contentReference[oaicite:5]{index=5}\n  { value: "CIN", color: "#FB3F14", textColor: "#000000" },  // orange ⟡ black :contentReference[oaicite:6]{index=6}\n  { value: "CLE", color: "#DF3C20", textColor: "#101010" },  // orange ⟡ brown :contentReference[oaicite:7]{index=7}\n  { value: "DAL", color: "#003594", textColor: "#A5ACAF" },  // navy ⟡ silver :contentReference[oaicite:8]{index=8}\n  { value: "DEN", color: "#FB2F14", textColor: "#102274" },  // orange ⟡ navy :contentReference[oaicite:9]{index=9}\n  { value: "DET", color: "#0076B6", textColor: "#B0B7BC" },  // honolulu ⟡ silver :contentReference[oaicite:10]{index=10}\n  { value: "GB",  color: "#203731", textColor: "#FFB612" },  // green ⟡ gold :contentReference[oaicite:11]{index=11}\n  { value: "HOU", color: "#03202F", textColor: "#D71930" },  // deep blue ⟡ red :contentReference[oaicite:12]{index=12}\n  { value: "IND", color: "#002C5F", textColor: "#F2FAFD" },  // royal ⟡ gray :contentReference[oaicite:13]{index=13}\n  { value: "JAX", color: "#006778", textColor: "#D7A22A" },  // teal ⟡ gold :contentReference[oaicite:14]{index=14}\n  { value: "KC",  color: "#E31837", textColor: "#FFB612" },  // red ⟡ gold :contentReference[oaicite:15]{index=15}\n  { value: "LAC", color: "#0080C6", textColor: "#FFC20E" },  // powder ⟡ sunshine :contentReference[oaicite:16]{index=16}\n  { value: "LAR", color: "#003594", textColor: "#FFA300" },  // royal ⟡ sol :contentReference[oaicite:17]{index=17}\n  { value: "LV",  color: "#000000", textColor: "#A5ACAF" },  // black ⟡ silver :contentReference[oaicite:18]{index=18}\n  { value: "MIA", color: "#008E87", textColor: "#FC5C02" },  // aqua ⟡ orange :contentReference[oaicite:19]{index=19}\n  { value: "MIN", color: "#4F2683", textColor: "#FFC62F" },  // purple ⟡ gold :contentReference[oaicite:20]{index=20}\n  { value: "NE",  color: "#041E62", textColor: "#D60F51" },  // blue ⟡ red :contentReference[oaicite:21]{index=21}\n  { value: "NO",  color: "#D3BC8D", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:22]{index=22}\n  { value: "NYG", color: "#0B2265", textColor: "#DFDFDF" },  // blue ⟡ red :contentReference[oaicite:23]{index=23}\n  { value: "NYJ", color: "#125740", textColor: "#FFFFFF" },  // green ⟡ white :contentReference[oaicite:24]{index=24}\n  { value: "PHI", color: "#004C54", textColor: "#A5ACAF" },  // midnight ⟡ silver :contentReference[oaicite:25]{index=25}\n  { value: "PIT", color: "#FFB612", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:26]{index=26}\n  { value: "SEA", color: "#002244", textColor: "#69BE28" },  // navy ⟡ action-green :contentReference[oaicite:27]{index=27}\n  { value: "SF",  color: "#AA0000", textColor: "#B3995D" },  // scarlet ⟡ gold :contentReference[oaicite:28]{index=28}\n  { value: "TB",  color: "#D50A0A", textColor: "#0A0A08" },  // red ⟡ pewter :contentReference[oaicite:29]{index=29}\n  { value: "TEN", color: "#0C2340", textColor: "#4B92DB" },  // navy ⟡ titan-blue :contentReference[oaicite:30]{index=30}\n  { value: "WAS", color: "#5A1414", textColor: "#FFB612" },  // burgundy ⟡ gold :contentReference[oaicite:31]{index=31}\n  { value: "UDF", color: "#9E9E9E", textColor: "#FFFFFF" }  // neutral grey\n]',
          valueByIndex: "{{ item.value }}",
          labelByIndex: "{{ item.value }}",
          colorByIndex: "{{ item.color }}",
          textColorByIndex: "{{ item.textColor }}",
        }}
        placeholder="Select option"
        position="left"
        size={62.390625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTeam [NFL]\n</div>'
        }
      />
      <Column
        id="a5b57"
        alignment="center"
        backgroundColor="{{
    currentSourceRow.Tier == 8 ? '#f3f00f' :
  currentSourceRow.Tier == 7 ? '#f300f0' :
  currentSourceRow.Tier == 6 ? '#03f0ff' :
  currentSourceRow.Tier == 5 ? '#33007f' :
  currentSourceRow.Tier == 4 ? '#35407f' :
  currentSourceRow.Tier == 3 ? '#33007f' :
  currentSourceRow.Tier == 2 ? '#33007f' :
  currentSourceRow.Tier ==  1 ? '#7300ff10; :
  '#33007f'
}}"
        editableOptions={{ showStepper: true, allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="sum"
        headerTextColor="rgba(23, 92, 97, 1)"
        key="Tier"
        label="TIER"
        optionList={{
          manualData: [
            {
              value: "1",
              label: "| Tier 1",
              color: "rgba(0, 0, 0, 0)",
              textColor: "#dfcd87",
              icon: "bold/interface-award-crown",
              caption: "",
            },
            {
              value: 2,
              label: "| Tier 2",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(196, 198, 218, 1)",
              icon: "bold/shopping-jewelry-diamond-2",
            },
            {
              value: 3,
              label: "| Tier 3",
              icon: "bold/interface-favorite-star",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(125, 170, 222, 1)",
            },
            {
              value: 4,
              label: "| Tier 4",
              icon: "bold/money-graph-arrow-increase",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(127, 111, 242, 1)",
            },
            {
              value: 5,
              label: "| Tier 5",
              icon: "bold/interface-hierarchy-9",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(186, 106, 255, 1)",
            },
            {
              value: 6,
              icon: "bold/interface-weather-rain-1",
              label: "| Tier 6",
              color: "rgba(0, 0, 0, 0)",
              textColor: "#ff89f6",
              fallbackText: "",
            },
            {
              value: 7,
              icon: "bold/money-graph-bar-decrease",
              label: "| Tier 7",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(255, 86, 238, 1)",
            },
            {
              value: 8,
              label: "| Tier 8",
              icon: "bold/interface-delete-bin-2",
              caption: "",
              textColor: "rgba(255, 62, 151, 1)",
              color: "rgba(72, 72, 72, 0)",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="left"
        size={80.84375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTier\n</div>'
        }
      />
      <Column
        id="a80e8"
        alignment="center"
        backgroundColor="rgba(75, 0, 255, 0.15)"
        cellTooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 12px #000000 ;\n">\n  Overall Grade<br> ⌁ <b>{{ (() => {\n    const map = {\n      "Ashton Jeanty": 95.7,\n      "Travis Hunter": 93.5,\n      "Omarion Hampton": 89.7,\n      "Tetairoa McMillan": 90.5,\n      "TreVeyon Henderson": 88.1,\n      "Quinshon Judkins": 87.5,\n      "Emeka Egbuka": 89.1,\n      "Tyler Warren": 88.9,\n      "Colston Loveland": 90.1,\n      "R.J. Harvey": 86.2,\n      "Kaleb Johnson": 85.6,\n      "Matthew Golden": 87.1,\n      "Luther Burden": 86.9,\n      "Jayden Higgins": 86.3,\n      "Tre Harris": 86.3,\n      "Jack Bech": 85.7,\n      "Cameron Skattebo": 87.3,\n      "Kyle Williams": 86.9,\n      "Mason Taylor": 74.8,\n      "Bhayshul Tuten": 79.8,\n      "Jaylin Noel": 85.6,\n      "Terrance Ferguson": 77.3,\n      "Jaydon Blue": 74.0,\n      "Elijah Arroyo": 74.1,\n      "Pat Bryant": 79.6,\n      "Dylan Sampson": 81.6,\n      "Harold Fannin Jr.": 86.5,\n      "Jalen Royals": 84.8,\n      "Devin Neal": 81.4,\n      "Trevor Etienne": 79.8,\n      "Elic Ayomanor": 78.0,\n      "Jarquez Hunter": 76.1,\n      "DJ Giddens": 80.7,\n      "Isaac TeSlaa": 74.9,\n      "Jordan James": 76.1,\n      "Ollie Gordon": 73.7,\n      "Jo\'quavious Marks": 69.9,\n      "Dont\'e Thornton": 74.5,\n      "Tory Horton": 84.1,\n      "Brashard Smith": 72.8,\n      "Oronde Gadsden II": 78.7,\n      "Savion Williams": 78.3,\n      "Tahj Brooks": 81.4,\n      "Kyle Monangai": 74.2,\n      "Tai Felton": 81.7,\n      "Chimere Dike": 76.3,\n      "Gunnar Helm": 71.3,\n      "Jaylin Lane": 77.2,\n      "Damien Martinez": 80.9,\n      "Jimmy Horn Jr.": 72.4,\n      "Jacory Croskey-Merritt": 72.1,\n      "Arian Smith": 71.2,\n      "Keandre Lambert-Smith": 79.7,\n      "Tez Johnson": 79.9,\n      "Phil Mafah": 68.0,\n      "LeQuint Allen": 66.7,\n      "Mitchell Evans": 70.5,\n      "Thomas Fidone III": 70.4,\n      "LaJohntay Wester": 74.2,\n      "Ricky White": 79.2,\n      "Moliki Matavao": 62.6,\n      "Kaden Prather": 72.9,\n      "Luke Lachey": 69.2\n    };\n    const v = map[currentSourceRow.PLAYER];\n    return v ?? item;    // Fallback to the cell value if name mismatch\n  })() }}</b> ⌁ \n</div>\n'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "60",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "79",
        }}
        groupAggregationMode="average"
        key="OVR GRADE"
        label="OVR GRD"
        optionList={{
          iconByIndex: "",
          mode: "manual",
          textColorByIndex: "",
          labelByIndex: "",
          valueByIndex: "",
          fallbackTextByIndex: "",
          hiddenByIndex: "",
          captionByIndex: "",
          colorByIndex: "",
          mappedData: "[]",
        }}
        placeholder="Enter value"
        position="center"
        size={102.34375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item >89}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(231, 255, 248, 0.03)",
              tooltip: "",
            },
            {
              showWhen: "{{item >80}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(0, 109, 242, 0.03)",
            },
            {
              showWhen: "{{item >75}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(124, 83, 204, 0.03)",
            },
            {
              showWhen: "true",
              label: "{{ item }}",
              icon: "",
              color: "rgba(68, 76, 87, 0.03)",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nOverall Grade\n</div>'
        }
      />
      <Column
        id="05ab0"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(20, 26, 50)"
        headerTextColor="#ffffff"
        key="truADP"
        label="ADP"
        optionList={{
          iconByIndex: "",
          mode: "manual",
          textColorByIndex: "",
          labelByIndex: "",
          valueByIndex: "",
          fallbackTextByIndex: "",
          hiddenByIndex: "",
          captionByIndex: "",
          colorByIndex: "",
          mappedData: "",
        }}
        placeholder="Enter value"
        position="center"
        size={82}
        summaryAggregationMode="none"
        textColor="{{ 
  currentSourceRow.truADP < 53.9 ? '#00FFAA':
  currentSourceRow.truADP < 90 ? '#00FfFF':
     currentSourceRow.truADP < 130 ? '#90B8FC':
     currentSourceRow.truADP < 165 ? '#80B3FF':
     currentSourceRow.truADP < 200 ? '#a34fff':
   currentSourceRow.truADP < 250 ? '#ff91Fd':
    currentSourceRow.truADP < 300 ? '#ff91cd':
    currentSourceRow.truADP < 350 ? '#ff91cd':
     currentSourceRow.truADP < 699 ? '#FF00FF':'' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nAverage Draft Position\n</div>'
        }
        valueOverride="［ {{item}} ］"
      />
      <Column
        id="328dc"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="Rook ADP"
        label="ROOKIE ADP  "
        placeholder="Enter value"
        position="center"
        size={75.21875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRookie Average Draft Position\n</div>'
        }
      />
      <Column
        id="62082"
        alignment="center"
        backgroundColor="rgba(104, 141, 243, 0.03)"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RD"
        label="RD 📶"
        placeholder="Enter value"
        position="center"
        size={54.9375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "",
              label: "",
              color: "rgba(135, 230, 179, 1)",
              icon: "bold/interface-arrows-up-alternate",
            },
            {
              showWhen: "{{ item < 7 }}",
              label: "",
              color: "#F8DBD8",
              icon: "bold/money-graph-arrow-decrease",
            },
            {
              showWhen: "{{ item > 6 }}",
              label: "",
              color: "rgba(236, 116, 154, 1)",
              icon: "bold/interface-arrows-down-alternate",
            },
            {
              showWhen: "{{ item < 5 }}",
              label: "",
              color: "#D7EAE0",
              icon: "bold/money-graph-arrow-increase",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRound Drafted\n</div>'
        }
      />
      <Column
        id="95105"
        alignment="center"
        backgroundColor="rgba(104, 141, 243, 0.03)"
        cellTooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -10px;\n   font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 12px #000000 ;\n">\nPick Drafted<br> ⌁ <b>{{item}}</b> ⌁ \n</div>\n\n'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "", color: "" }}
        groupAggregationMode="sum"
        key="PK#"
        label="PK"
        placeholder="Enter value"
        position="center"
        size={69.9375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item <33}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(196, 253, 234, 0.15)",
              tooltip: "",
            },
            {
              showWhen: "{{item < 68}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(186, 255, 255, 0.15)",
            },
            {
              showWhen: "{{item < 90}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(186, 243, 255, 0.15)",
            },
            {
              showWhen: "{{item < 130}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(229, 205, 255, 0.3)",
            },
            {
              showWhen: "{{item >190}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(251, 164, 234, 1)",
            },
            {
              showWhen: "{{item >130}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(232, 177, 250, 0.5)",
              tooltip: "",
            },
            { showWhen: "{{item}}", label: "UD", icon: "" },
          ],
        }}
        summaryAggregationMode="none"
        textColor="{{ theme.danger }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPick Drafted [Overall]\n</div>'
        }
      />
      <Column
        id="41f3f"
        alignment="center"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="NCAA"
        label="NCAA"
        placeholder="Enter value"
        position="center"
        size={61.515625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTeam [NCAA]\n</div>'
        }
      />
      <Column
        id="53da5"
        alignment="center"
        editable="false"
        format="multilineString"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
        textColor="rgba(255, 255, 255, 1)"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nAge\n</div>'
        }
      />
      <Column
        id="7a71b"
        alignment="center"
        format="string"
        formatOptions={{ automaticColors: true, notation: "standard" }}
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={46.03125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nHeight\n</div>'
        }
      />
      <Column
        id="f718d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={47.875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nWeight\n</div>'
        }
      />
      <Column
        id="05e56"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="40"
        label="40"
        placeholder="Enter value"
        position="center"
        size={46.515625}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow[\"40\"] == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n40 Yard Dash\n</div>'
        }
      />
      <Column
        id="cf84f"
        alignment="left"
        backgroundColor="rgba(185, 190, 209, 0.03)"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\nAthletic Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(198, 203, 231, 1)"
        key="ATHL"
        label="ATHL GRD"
        placeholder="Enter value"
        position="center"
        size={78.6875}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item > 91.9}}",
              label: "{{ item }}",
              icon: "bold/image-flash-1",
              color: "rgba(120, 210, 171, 1)",
            },
            {
              showWhen: "{{item > 87}}",
              label: "{{ item }}",
              icon: "bold/image-flash-2",
              color: "rgba(190, 254, 234, 0.17)",
            },
            {
              showWhen: "{{ item > 82.9 }}",
              label: "{{ item }}",
              icon: "bold/shopping-business-startup",
              color: "rgba(138, 255, 255, 0.13)",
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{item}}",
              icon: "bold/mail-send-email",
              color: "rgba(185, 223, 255, 0.13)",
            },
            {
              showWhen: "{{item > 76}}",
              label: "{{ item }}",
              icon: "bold/mail-send-email",
            },
            {
              showWhen: "{{item < 76}}",
              label: "{{item}}",
              icon: "bold/phone-signal-low",
              color: "rgba(255, 178, 214, 0.15)",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nAthletic Grade\n</div>'
        }
      />
      <Column
        id="4bffd"
        alignment="center"
        backgroundColor="rgba(63, 1, 255, 0.05)"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.9em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nCEILING ⌁ <b>{{item}}/5</b> \n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="rating"
        formatOptions={{ icon: "", size: "small", icons: "stars" }}
        groupAggregationMode="average"
        key="CL"
        label="CEILING"
        placeholder="Enter value"
        position="center"
        size={98}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProjected Ceiling\n</div>'
        }
      />
      <Column
        id="5b01a"
        alignment="center"
        backgroundColor="rgba(131, 0, 255, 0.05)"
        cellTooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.9em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nFLOOR ⌁ <b>{{item}}/5</b>\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="rating"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          size: "small",
          icons: "stars",
        }}
        groupAggregationMode="sum"
        key="FL"
        label="FLOOR"
        placeholder="Enter value"
        position="center"
        size={101.5}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProjected Floor\n</div>'
        }
      />
      <Column
        id="93ad9"
        alignment="center"
        backgroundColor="rgba(185, 190, 209, 0.03)"
        caption="• {{ item }} •"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProduction Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "55",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "75",
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#141a32"
        headerTextColor="rgba(183, 190, 223, 1)"
        key="PRD GRADE"
        label="PRD GRD"
        placeholder="Enter value"
        position="center"
        size={67.09375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProduction Grade\n</div>'
        }
      />
      <Column
        id="d91e6"
        alignment="center"
        backgroundColor="rgba(185, 190, 209, 0.03)"
        caption="• {{ item }} •"
        cellTooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nEfficiency Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "50",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "75",
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#141a32"
        headerTextColor="#aeb9ea"
        key="EFF GRADE"
        label="EFF GRD"
        placeholder="Enter value"
        position="center"
        size={69.671875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nEfficiency Grade\n</div>'
        }
      />
      <Column
        id="a6c5e"
        alignment="center"
        backgroundColor="rgba(154, 186, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(154, 186, 255, 1)"
        key="RR GRD"
        label="RR GRD  ↰↱"
        placeholder="Enter value"
        position="center"
        size={82}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{ item > 85}} ",
              label: "{{item}}",
              icon: "bold/interface-arrows-bend-up-right-1-alternate",
              color: "rgba(190, 254, 234, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{item}}",
              icon: "bold/interface-arrows-bend-up-right-2-alternate",
              color: "rgba(224, 245, 255, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item < 75}}",
              label: "{{item}}",
              icon: "bold/interface-arrows-up-alternate",
              color: "rgba(255, 178, 214, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{ item == 'NA' }}",
              label: "{{ item }}",
              icon: "bold/interface-block",
              color: "rgba(160, 160, 160, 0.1)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\n <b>N/A</b> ⌁ [WR/TE–ONLY Metric]\n</div>',
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nSeperation / Route Running Grade\n</div>'
        }
      />
      <Column
        id="65b64"
        alignment="left"
        backgroundColor="rgba(182, 184, 193, 0.03)"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b7bedf"
        key="FILM GRADE"
        label="FILM 
GRD"
        placeholder="Enter value"
        position="center"
        size={77.609375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item > 85}}",
              label: "{{ item }}",
              icon: "bold/entertainment-camera-video",
              color: "rgba(190, 254, 234, 0.17)",
            },
            {
              showWhen: "{{  item > 78}}",
              label: "{{ item }}",
              icon: "bold/computer-connection-video-camera",
              color: "rgba(224, 245, 255, 0.2)",
            },
            {
              showWhen: "{{item < 79}}",
              label: "{{ item }}",
              icon: "bold/entertainment-recording-tape-1",
              color: "rgba(255, 178, 214, 0.15)",
            },
            {
              showWhen: "true",
              label: "{{item}}",
              icon: "bold/interface-page-controller-loading-half",
              color: "rgba(227, 223, 223, 0.1)",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nFilm Grade\n</div>'
        }
      />
      <Column
        id="6beae"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="G"
        label="G"
        placeholder="Enter value"
        position="center"
        size={37.6875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nGames Played\n</div>'
        }
      />
      <Column
        id="571eb"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="SOS"
        label="SOS"
        placeholder="Enter value"
        position="center"
        size={53}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow.SOS == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nNCAA Strength of Schedule [Career Avg.]\n</div>'
        }
      />
      <Column
        id="e9438"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(181, 161, 254, 1)"
        key="YDS(t)"
        label="YDS ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={64.734375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [Total]\n</div>'
        }
      />
      <Column
        id="37293"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="TD(t)"
        label="TD
 ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={50.25}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [Total]\n</div>'
        }
      />
      <Column
        id="25637"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="YpG(t)"
        label="YpG 
⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={58.453125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards per Game [Total]\n</div>'
        }
      />
      <Column
        id="00b31"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="OPP(t)"
        label="OPP"
        placeholder="Enter value"
        position="center"
        size={58.15625}
        summaryAggregationMode="none"
        textColor="#ffffff"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nOpportunities [CAR+TGT]\n</div>'
        }
      />
      <Column
        id="45011"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="IMP"
        label="IMP"
        placeholder="Enter value"
        position="center"
        size={57.484375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nImpact Plays [TD+1D]\n</div>'
        }
      />
      <Column
        id="3ce33"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "0",
          padDecimal: false,
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="IMP/ OPP"
        label="IMP/OPP"
        placeholder="Enter value"
        position="center"
        size={81.84375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nImpact Plays per Opportunity\n</div>'
        }
      />
      <Column
        id="4c58c"
        alignment="center"
        backgroundColor="rgba(110, 137, 245, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "3",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        key="DMTR"
        label="DMTR"
        placeholder="Enter value"
        position="center"
        size={66.890625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nDominator Rating\n</div>'
        }
      />
      <Column
        id="89a9d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="CAR"
        label="CAR"
        placeholder="Enter value"
        position="center"
        size={52.640625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nCarries\n</div>'
        }
      />
      <Column
        id="1ed57"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="ruYDS"
        label="YDS ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={58.3125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nYards [Rushing]\n</div>'
        }
      />
      <Column
        id="bb829"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="ruTD"
        label="TD  ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={59.953125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTouchdowns [Rushing]\n</div>'
        }
      />
      <Column
        id="3620d"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="TGT"
        label="TGT"
        placeholder="Enter value"
        position="center"
        size={56}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTargets\n</div>'
        }
      />
      <Column
        id="38694"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="REC"
        label="REC"
        placeholder="Enter value"
        position="center"
        size={59}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nReceptions\n</div>'
        }
      />
      <Column
        id="db7c4"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="recYDS"
        label="YDS
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={51.140625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [Receiving]\n</div>'
        }
      />
      <Column
        id="e7cf5"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="rgba(153, 205, 255, 1)"
        key="recTD"
        label="TD
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={50.9375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [Receiving]\n</div>'
        }
      />
      <Column
        id="23e31"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="rec1D"
        label="1D
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={67}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nFirst Downs [Receiving]\n</div>'
        }
      />
      <Column
        id="c40d1"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YPRR"
        label="YPRR"
        placeholder="Enter value"
        position="center"
        size={68}
        summaryAggregationMode="none"
        textColor="{{
(() => {
 const v = parseFloat(String(item).replace(/[^0-9.-]/g, ''));
 if (!isFinite(v)) return null;
 const rules = [
  [2.7, '#00ffc4'],
  [2.4, '#85fff3'],
  [2.3, '#7dd1ff'],
  [2.1, '#957cff'],
  [1.9, '#a642ff'],
  [1.7, '#cf60ff'],
  [1.5, '#ff6fe1'],
 ];
 for (const [t, c] of rules) if (v >= t) return c;
 return '#ff2eb2';
})()
}}"
        tooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 15px #000000 ;\n">\nYards per Route Run\n</div>'
        }
      />
      <Column
        id="adcec"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="1DRR"
        label="1DRR"
        placeholder="Enter value"
        position="center"
        size={72}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nFirst Downs per Route Run\n</div>'
        }
      />
      <Column
        id="fe787"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YPR"
        label="YPR"
        placeholder="Enter value"
        position="center"
        size={69}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards per Reception\n</div>'
        }
      />
      <Column
        id="fd480"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YAC/R"
        label="YAC/REC"
        placeholder="Enter value"
        position="center"
        size={83}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards after Catch per Reception\n</div>'
        }
      />
      <Event
        event="selectRow"
        method=""
        params={{}}
        pluginId=""
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Table>
  </View>
  <View
    id="91f98"
    disabled={false}
    hidden={false}
    icon="bold/interface-security-shield-4"
    iconPosition="left"
    viewKey="TE"
  >
    <Table
      id="table91"
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "RK": 1,\n    "PLAYER": "Colston Loveland",\n    "POS": "TE",\n    "TM": "CHI",\n    "OVR GRADE": 90,\n    "truADP": 66.6,\n    "Rook ADP": 11,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>\\u2460</span>",\n    "PK#": "10",\n    "NCAA": "MICH",\n    "AGE": 21.3,\n    "HT": "6\'6\\"",\n    "WT": 248,\n    "40": "NA",\n    "ATHL": 91,\n    "CL": 5,\n    "FL": 4,\n    "PRD GRADE": 71.1,\n    "EFF GRADE": 72.9,\n    "RR GRD": 90.1,\n    "FILM GRADE": 90,\n    "G": 39,\n    "SOS": "94.9",\n    "YDS(t)": 1465,\n    "TD(t)": 11,\n    "YpG(t)": 37.56,\n    "OPP(t)": 171,\n    "IMP": 83,\n    "IMP/ OPP": 0.49,\n    "DMTR": "0.2",\n    "CAR": 1,\n    "ruYDS": -2,\n    "ruTD": 0,\n    "TGT": 170,\n    "REC": 116,\n    "recYDS": 1467,\n    "recTD": 11,\n    "rec1D": 72,\n    "YPRR": 2.22,\n    "YPR": 12.5,\n    "YAC/R": 5.37,\n    "Tier": 3,\n    "1DRR": 0.109\n  },\n  {\n    "RK": 2,\n    "PLAYER": "Tyler Warren",\n    "POS": "TE",\n    "TM": "IND",\n    "OVR GRADE": 89,\n    "truADP": 53.9,\n    "Rook ADP": 9,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>\\u2460</span>",\n    "PK#": "14",\n    "NCAA": "PSU",\n    "AGE": 23.1,\n    "HT": "6\'6\\"",\n    "WT": 256,\n    "40": "NA",\n    "ATHL": 90,\n    "CL": 4.5,\n    "FL": 4.5,\n    "PRD GRADE": 87.8,\n    "EFF GRADE": 88.8,\n    "RR GRD": 86.7,\n    "FILM GRADE": 90,\n    "G": 53,\n    "SOS": "95.3",\n    "YDS(t)": 2062,\n    "TD(t)": 25,\n    "YpG(t)": 38.91,\n    "OPP(t)": 238,\n    "IMP": 145,\n    "IMP/ OPP": 0.61,\n    "DMTR": "0.159",\n    "CAR": 30,\n    "ruYDS": 225,\n    "ruTD": 6,\n    "TGT": 208,\n    "REC": 154,\n    "recYDS": 1837,\n    "recTD": 19,\n    "rec1D": 104,\n    "YPRR": 1.98,\n    "YPR": 11.9,\n    "YAC/R": 6.58,\n    "Tier": 3,\n    "1DRR": 0.112\n  },\n  {\n    "RK": 3,\n    "PLAYER": "Mason Taylor",\n    "POS": "TE",\n    "TM": "NYG",\n    "OVR GRADE": 75,\n    "truADP": 132.0,\n    "Rook ADP": 21,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>\\u2461</span>",\n    "PK#": "42",\n    "NCAA": "LSU",\n    "AGE": 21.2,\n    "HT": "6\'5\\"",\n    "WT": 251,\n    "40": "NA",\n    "ATHL": 86,\n    "CL": 3,\n    "FL": 3,\n    "PRD GRADE": 67.7,\n    "EFF GRADE": 58.5,\n    "RR GRD": 83.2,\n    "FILM GRADE": "NA",\n    "G": 38,\n    "SOS": "90.7",\n    "YDS(t)": 1308,\n    "TD(t)": 6,\n    "YpG(t)": 34.42,\n    "OPP(t)": 181,\n    "IMP": 78,\n    "IMP/ OPP": 0.43,\n    "DMTR": "0.089",\n    "CAR": 0,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 181,\n    "REC": 129,\n    "recYDS": 1308,\n    "recTD": 6,\n    "rec1D": 72,\n    "YPRR": 1.09,\n    "YPR": 10.1,\n    "YAC/R": 5.36,\n    "Tier": 5,\n    "1DRR": 0.06\n  },\n  {\n    "RK": 4,\n    "PLAYER": "Terrance Ferguson",\n    "POS": "TE",\n    "TM": "LAC",\n    "OVR GRADE": 77,\n    "truADP": 161.5,\n    "Rook ADP": 25,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>\\u2461</span>",\n    "PK#": "46",\n    "NCAA": "ORE",\n    "AGE": 22.4,\n    "HT": "6\'5\\"",\n    "WT": 247,\n    "40": 4.63,\n    "ATHL": 85,\n    "CL": 3.5,\n    "FL": 3,\n    "PRD GRADE": 72.7,\n    "EFF GRADE": 73.6,\n    "RR GRD": 75.8,\n    "FILM GRADE": "NA",\n    "G": 53,\n    "SOS": "88.9",\n    "YDS(t)": 1537,\n    "TD(t)": 16,\n    "YpG(t)": 29,\n    "OPP(t)": 183,\n    "IMP": 101,\n    "IMP/ OPP": 0.55,\n    "DMTR": "0.116",\n    "CAR": 0,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 183,\n    "REC": 134,\n    "recYDS": 1537,\n    "recTD": 16,\n    "rec1D": 85,\n    "YPRR": 1.51,\n    "YPR": 11.5,\n    "YAC/R": 7.02,\n    "Tier": 5,\n    "1DRR": 0.083\n  },\n  {\n    "RK": 5,\n    "PLAYER": "Elijah Arroyo",\n    "POS": "TE",\n    "TM": "SEA",\n    "OVR GRADE": 74,\n    "truADP": 167.0,\n    "Rook ADP": 27,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>\\u2461</span>",\n    "PK#": "50",\n    "NCAA": "MIA",\n    "AGE": 22.3,\n    "HT": "6\'5\\"",\n    "WT": 250,\n    "40": "NA",\n    "ATHL": 85,\n    "CL": 4,\n    "FL": 2,\n    "PRD GRADE": 55.7,\n    "EFF GRADE": 68.3,\n    "RR GRD": 83.4,\n    "FILM GRADE": "NA",\n    "G": 34,\n    "SOS": "82.9",\n    "YDS(t)": 747,\n    "TD(t)": 8,\n    "YpG(t)": 21.97,\n    "OPP(t)": 63,\n    "IMP": 39,\n    "IMP/ OPP": 0.62,\n    "DMTR": "0.09",\n    "CAR": 0,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 63,\n    "REC": 46,\n    "recYDS": 747,\n    "recTD": 8,\n    "rec1D": 31,\n    "YPRR": 1.61,\n    "YPR": 16.2,\n    "YAC/R": 8.8,\n    "Tier": 5,\n    "1DRR": 0.067\n  },\n  {\n    "RK": 6,\n    "PLAYER": "Harold Fannin Jr.",\n    "POS": "TE",\n    "TM": "CLE",\n    "OVR GRADE": 86,\n    "truADP": 176.9,\n    "Rook ADP": 32,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>\\u2462</span>",\n    "PK#": "67",\n    "NCAA": "BGSU",\n    "AGE": 22,\n    "HT": "6\'3\\"",\n    "WT": 241,\n    "40": 4.71,\n    "ATHL": 79,\n    "CL": 4.5,\n    "FL": 1,\n    "PRD GRADE": 92,\n    "EFF GRADE": 94.6,\n    "RR GRD": 88.9,\n    "FILM GRADE": 81,\n    "G": 36,\n    "SOS": "74.9",\n    "YDS(t)": 2555,\n    "TD(t)": 22,\n    "YpG(t)": 70.97,\n    "OPP(t)": 265,\n    "IMP": 145,\n    "IMP/ OPP": 0.55,\n    "DMTR": "0.299",\n    "CAR": 33,\n    "ruYDS": 159,\n    "ruTD": 5,\n    "TGT": 232,\n    "REC": 180,\n    "recYDS": 2396,\n    "recTD": 17,\n    "rec1D": 108,\n    "YPRR": 2.99,\n    "YPR": 13.3,\n    "YAC/R": 8.1,\n    "Tier": 6,\n    "1DRR": 0.135\n  },\n  {\n    "RK": 7,\n    "PLAYER": "Oronde Gadsden II",\n    "POS": "TE",\n    "TM": "LAC",\n    "OVR GRADE": 79,\n    "truADP": 240.4,\n    "Rook ADP": 43,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>\\u2464</span>",\n    "PK#": "165",\n    "NCAA": "SYR",\n    "AGE": 22,\n    "HT": "6\'5\\"",\n    "WT": 243,\n    "40": "NA",\n    "ATHL": 75,\n    "CL": 3.5,\n    "FL": 2,\n    "PRD GRADE": 82,\n    "EFF GRADE": 82.7,\n    "RR GRD": 75.2,\n    "FILM GRADE": "NA",\n    "G": 34,\n    "SOS": "80.9",\n    "YDS(t)": 2003,\n    "TD(t)": 14,\n    "YpG(t)": 58.91,\n    "OPP(t)": 210,\n    "IMP": 121,\n    "IMP/ OPP": 0.58,\n    "DMTR": "0.257",\n    "CAR": 1,\n    "ruYDS": 12,\n    "ruTD": 0,\n    "TGT": 209,\n    "REC": 143,\n    "recYDS": 1991,\n    "recTD": 14,\n    "rec1D": 106,\n    "YPRR": 2.04,\n    "YPR": 13.9,\n    "YAC/R": 3.69,\n    "Tier": 6,\n    "1DRR": 0.108\n  },\n  {\n    "RK": 8,\n    "PLAYER": "Gunnar Helm",\n    "POS": "TE",\n    "TM": "TEN",\n    "OVR GRADE": 71,\n    "truADP": 258.5,\n    "Rook ADP": 48,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>\\u2463</span>",\n    "PK#": "120",\n    "NCAA": "TEX",\n    "AGE": 22.8,\n    "HT": "6\'5\\"",\n    "WT": 241,\n    "40": 4.84,\n    "ATHL": 71,\n    "CL": 3.5,\n    "FL": 3.5,\n    "PRD GRADE": 61.6,\n    "EFF GRADE": 64.9,\n    "RR GRD": 80.4,\n    "FILM GRADE": "NA",\n    "G": 43,\n    "SOS": "89.7",\n    "YDS(t)": 1022,\n    "TD(t)": 9,\n    "YpG(t)": 23.77,\n    "OPP(t)": 95,\n    "IMP": 54,\n    "IMP/ OPP": 0.57,\n    "DMTR": "0.096",\n    "CAR": 0,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 95,\n    "REC": 79,\n    "recYDS": 1022,\n    "recTD": 9,\n    "rec1D": 45,\n    "YPRR": 1.38,\n    "YPR": 12.9,\n    "YAC/R": 6.85,\n    "Tier": 7,\n    "1DRR": 0.061\n  },\n  {\n    "RK": 9,\n    "PLAYER": "Mitchell Evans",\n    "POS": "TE",\n    "TM": "CAR",\n    "OVR GRADE": 70,\n    "truADP": 338.0,\n    "Rook ADP": 58,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>\\u2464</span>",\n    "PK#": "163",\n    "NCAA": "ND",\n    "AGE": 22.3,\n    "HT": "6\'5\\"",\n    "WT": 258,\n    "40": 4.74,\n    "ATHL": 77,\n    "CL": 2,\n    "FL": 2,\n    "PRD GRADE": 59.7,\n    "EFF GRADE": 59.5,\n    "RR GRD": "NA",\n    "FILM GRADE": "NA",\n    "G": 42,\n    "SOS": "90.1",\n    "YDS(t)": 913,\n    "TD(t)": 6,\n    "YpG(t)": 21.74,\n    "OPP(t)": 117,\n    "IMP": 62,\n    "IMP/ OPP": 0.53,\n    "DMTR": "0.076",\n    "CAR": 9,\n    "ruYDS": 13,\n    "ruTD": 1,\n    "TGT": 108,\n    "REC": 77,\n    "recYDS": 900,\n    "recTD": 5,\n    "rec1D": 49,\n    "YPRR": 1.45,\n    "YPR": 11.7,\n    "YAC/R": 4.95,\n    "Tier": 8,\n    "1DRR": 0.079\n  },\n  {\n    "RK": 10,\n    "PLAYER": "Moliki Matavao",\n    "POS": "TE",\n    "TM": "NO",\n    "OVR GRADE": 63,\n    "truADP": 376.0,\n    "Rook ADP": 60,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>\\u2466</span>",\n    "PK#": "248",\n    "NCAA": "UCLA",\n    "AGE": 22.3,\n    "HT": "6\'6\\"",\n    "WT": 260,\n    "40": 4.81,\n    "ATHL": 71,\n    "CL": 1.5,\n    "FL": 1.5,\n    "PRD GRADE": 58.1,\n    "EFF GRADE": 58.7,\n    "RR GRD": "NA",\n    "FILM GRADE": "NA",\n    "G": 50,\n    "SOS": "NA",\n    "YDS(t)": 1001,\n    "TD(t)": 7,\n    "YpG(t)": 20.02,\n    "OPP(t)": 111,\n    "IMP": 53,\n    "IMP/ OPP": 0.48,\n    "DMTR": "0.076",\n    "CAR": 1,\n    "ruYDS": 3,\n    "ruTD": 1,\n    "TGT": 110,\n    "REC": 74,\n    "recYDS": 998,\n    "recTD": 6,\n    "rec1D": 45,\n    "YPRR": 1.5,\n    "YPR": 13.5,\n    "YAC/R": 6.69,\n    "Tier": 8,\n    "1DRR": 0.067\n  },\n  {\n    "RK": 11,\n    "PLAYER": "Thomas Fidone III",\n    "POS": "TE",\n    "TM": "NYG",\n    "OVR GRADE": 70,\n    "truADP": 552.9,\n    "Rook ADP": 62,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>\\u2466</span>",\n    "PK#": "219",\n    "NCAA": "NEB",\n    "AGE": 22.8,\n    "HT": "6\'5\\"",\n    "WT": 243,\n    "40": "4.70",\n    "ATHL": 81,\n    "CL": 2.5,\n    "FL": 2,\n    "PRD GRADE": 55,\n    "EFF GRADE": 55,\n    "RR GRD": "NA",\n    "FILM GRADE": "NA",\n    "G": 25,\n    "SOS": "86.6",\n    "YDS(t)": 633,\n    "TD(t)": 4,\n    "YpG(t)": 25.32,\n    "OPP(t)": 88,\n    "IMP": 30,\n    "IMP/ OPP": 0.34,\n    "DMTR": "0.14",\n    "CAR": 0,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 88,\n    "REC": 61,\n    "recYDS": 633,\n    "recTD": 4,\n    "rec1D": 26,\n    "YPRR": 1.32,\n    "YPR": 10.4,\n    "YAC/R": 3.95,\n    "Tier": 8,\n    "1DRR": 0.054\n  },\n  {\n    "RK": 12,\n    "PLAYER": "Luke Lachey",\n    "POS": "TE",\n    "TM": "HOU",\n    "OVR GRADE": 69,\n    "truADP": 690.0,\n    "Rook ADP": 65,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>\\u2466</span>",\n    "PK#": "255",\n    "NCAA": "IOWA",\n    "AGE": 24,\n    "HT": "6\'6\\"",\n    "WT": 251,\n    "40": "NA",\n    "ATHL": 64,\n    "CL": 2,\n    "FL": 3.5,\n    "PRD GRADE": 57.2,\n    "EFF GRADE": 57.1,\n    "RR GRD": 69.7,\n    "FILM GRADE": "NA",\n    "G": 41,\n    "SOS": "91.1",\n    "YDS(t)": 877,\n    "TD(t)": 4,\n    "YpG(t)": 21.39,\n    "OPP(t)": 111,\n    "IMP": 52,\n    "IMP/ OPP": 0.47,\n    "DMTR": "0.142",\n    "CAR": 0,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 111,\n    "REC": 74,\n    "recYDS": 877,\n    "recTD": 4,\n    "rec1D": 48,\n    "YPRR": 1.37,\n    "YPR": 11.9,\n    "YAC/R": 4.72,\n    "Tier": 8,\n    "1DRR": 0.075\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicColumnProperties={{ formatByIndex: "auto", labelByIndex: "f" }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      headerTextWrap={true}
      linkedFilterId=""
      rowBackgroundColor=""
      rowHeight="medium"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      style={{
        headerFontFamily: "Michroma",
        fontWeight: "100",
        rowSeparator: "rgba(130, 138, 179, 0.04)",
        border: "rgba(130, 138, 179, 0.2)",
        hoverRowBackground: "rgba(87, 0, 255, 0.4)",
        alternateRowBackground: "rgba(26, 26, 50, 1)",
        background: "rgba(23, 23, 44, 1)",
        cellText: "rgba(255, 255, 255, 1)",
        fontSize: "12px",
        fontFamily: "Product Sans",
        headerFontWeight: "400",
        headerBackground: "#141a32",
        headerFontSize: "10px",
      }}
    >
      <Column
        id="d6166"
        alignment="center"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RK"
        label="RK"
        placeholder="Enter value"
        position="left"
        size={51.140625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRank\n</div>'
        }
      />
      <Column
        id="3220b"
        alignment="left"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="PLAYER"
        label="PLAYER"
        placeholder="Enter value"
        position="left"
        size={123.859375}
        summaryAggregationMode="none"
        textColor="{{ currentSourceRow.POS === 'RB' ? '#EaffEa'
  : currentSourceRow.POS === 'TE' ? '#ffefff'
  : currentSourceRow.POS === 'WR' ? '#e1ffff'
  : '' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPlayer Name\n</div>'
        }
      />
      <Column
        id="f83ae"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              ordered: [
                { value: "QB" },
                { color: "#ff2a6d" },
                { textColor: "rgba(18, 18, 18, 1)" },
                { icon: "" },
                { label: "" },
              ],
            },
            {
              value: "WR",
              color: "rgba(88, 167, 255, 0)",
              textColor: "#58a7ff",
              icon: "bold/computer-connection-usb-port",
            },
            {
              value: "RB",
              icon: "bold/travel-transportation-bus",
              color: "rgba(34, 228, 176, 0)",
              textColor: "#22e4b0",
            },
            {
              value: "TE",
              textColor: "#8300ff",
              color: "rgba(0, 0, 0, 0)",
              icon: "bold/interface-security-shield-4",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="left"
        size={66.859375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPosition\n</div>'
        }
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="50caa"
        alignment="center"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="none"
        key="TM"
        label="TM"
        optionList={{
          mode: "mapped",
          mappedData:
            '[\n  { value: "ARI", color: "#97233F", textColor: "#FFB612" },  // red ⟡ yellow :contentReference[oaicite:0]{index=0}\n  { value: "ATL", color: "#A71930", textColor: "#000000" },  // red ⟡ black :contentReference[oaicite:1]{index=1}\n  { value: "BAL", color: "#241773", textColor: "#9E7C0C" },  // purple ⟡ gold :contentReference[oaicite:2]{index=2}\n  { value: "BUF", color: "#00338D", textColor: "#C60C30" },  // royal ⟡ red :contentReference[oaicite:3]{index=3}\n  { value: "CAR", color: "#0085CA", textColor: "#000000" },  // blue ⟡ black :contentReference[oaicite:4]{index=4}\n  { value: "CHI", color: "#0B162A", textColor: "#F63F00" },  // navy ⟡ orange :contentReference[oaicite:5]{index=5}\n  { value: "CIN", color: "#FB3F14", textColor: "#000000" },  // orange ⟡ black :contentReference[oaicite:6]{index=6}\n  { value: "CLE", color: "#DF3C20", textColor: "#101010" },  // orange ⟡ brown :contentReference[oaicite:7]{index=7}\n  { value: "DAL", color: "#003594", textColor: "#A5ACAF" },  // navy ⟡ silver :contentReference[oaicite:8]{index=8}\n  { value: "DEN", color: "#FB2F14", textColor: "#102274" },  // orange ⟡ navy :contentReference[oaicite:9]{index=9}\n  { value: "DET", color: "#0076B6", textColor: "#B0B7BC" },  // honolulu ⟡ silver :contentReference[oaicite:10]{index=10}\n  { value: "GB",  color: "#203731", textColor: "#FFB612" },  // green ⟡ gold :contentReference[oaicite:11]{index=11}\n  { value: "HOU", color: "#03202F", textColor: "#D71930" },  // deep blue ⟡ red :contentReference[oaicite:12]{index=12}\n  { value: "IND", color: "#002C5F", textColor: "#F2FAFD" },  // royal ⟡ gray :contentReference[oaicite:13]{index=13}\n  { value: "JAX", color: "#006778", textColor: "#D7A22A" },  // teal ⟡ gold :contentReference[oaicite:14]{index=14}\n  { value: "KC",  color: "#E31837", textColor: "#FFB612" },  // red ⟡ gold :contentReference[oaicite:15]{index=15}\n  { value: "LAC", color: "#0080C6", textColor: "#FFC20E" },  // powder ⟡ sunshine :contentReference[oaicite:16]{index=16}\n  { value: "LAR", color: "#003594", textColor: "#FFA300" },  // royal ⟡ sol :contentReference[oaicite:17]{index=17}\n  { value: "LV",  color: "#000000", textColor: "#A5ACAF" },  // black ⟡ silver :contentReference[oaicite:18]{index=18}\n  { value: "MIA", color: "#008E87", textColor: "#FC5C02" },  // aqua ⟡ orange :contentReference[oaicite:19]{index=19}\n  { value: "MIN", color: "#4F2683", textColor: "#FFC62F" },  // purple ⟡ gold :contentReference[oaicite:20]{index=20}\n  { value: "NE",  color: "#041E62", textColor: "#D60F51" },  // blue ⟡ red :contentReference[oaicite:21]{index=21}\n  { value: "NO",  color: "#D3BC8D", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:22]{index=22}\n  { value: "NYG", color: "#0B2265", textColor: "#DFDFDF" },  // blue ⟡ red :contentReference[oaicite:23]{index=23}\n  { value: "NYJ", color: "#125740", textColor: "#FFFFFF" },  // green ⟡ white :contentReference[oaicite:24]{index=24}\n  { value: "PHI", color: "#004C54", textColor: "#A5ACAF" },  // midnight ⟡ silver :contentReference[oaicite:25]{index=25}\n  { value: "PIT", color: "#FFB612", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:26]{index=26}\n  { value: "SEA", color: "#002244", textColor: "#69BE28" },  // navy ⟡ action-green :contentReference[oaicite:27]{index=27}\n  { value: "SF",  color: "#AA0000", textColor: "#B3995D" },  // scarlet ⟡ gold :contentReference[oaicite:28]{index=28}\n  { value: "TB",  color: "#D50A0A", textColor: "#0A0A08" },  // red ⟡ pewter :contentReference[oaicite:29]{index=29}\n  { value: "TEN", color: "#0C2340", textColor: "#4B92DB" },  // navy ⟡ titan-blue :contentReference[oaicite:30]{index=30}\n  { value: "WAS", color: "#5A1414", textColor: "#FFB612" },  // burgundy ⟡ gold :contentReference[oaicite:31]{index=31}\n  { value: "UDF", color: "#9E9E9E", textColor: "#FFFFFF" }  // neutral grey\n]',
          valueByIndex: "{{ item.value }}",
          labelByIndex: "{{ item.value }}",
          colorByIndex: "{{ item.color }}",
          textColorByIndex: "{{ item.textColor }}",
        }}
        placeholder="Select option"
        position="left"
        size={62.390625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTeam [NFL]\n</div>'
        }
      />
      <Column
        id="a5b57"
        alignment="center"
        backgroundColor="{{
    currentSourceRow.Tier == 8 ? '#f3f00f' :
  currentSourceRow.Tier == 7 ? '#f300f0' :
  currentSourceRow.Tier == 6 ? '#03f0ff' :
  currentSourceRow.Tier == 5 ? '#33007f' :
  currentSourceRow.Tier == 4 ? '#35407f' :
  currentSourceRow.Tier == 3 ? '#33007f' :
  currentSourceRow.Tier == 2 ? '#33007f' :
  currentSourceRow.Tier ==  1 ? '#7300ff10; :
  '#33007f'
}}"
        editableOptions={{ showStepper: true, allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="sum"
        headerTextColor="rgba(23, 92, 97, 1)"
        key="Tier"
        label="TIER"
        optionList={{
          manualData: [
            {
              value: "1",
              label: "| Tier 1",
              color: "rgba(0, 0, 0, 0)",
              textColor: "#dfcd87",
              icon: "bold/interface-award-crown",
              caption: "",
            },
            {
              value: 2,
              label: "| Tier 2",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(196, 198, 218, 1)",
              icon: "bold/shopping-jewelry-diamond-2",
            },
            {
              value: 3,
              label: "| Tier 3",
              icon: "bold/interface-favorite-star",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(125, 170, 222, 1)",
            },
            {
              value: 4,
              label: "| Tier 4",
              icon: "bold/money-graph-arrow-increase",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(127, 111, 242, 1)",
            },
            {
              value: 5,
              label: "| Tier 5",
              icon: "bold/interface-hierarchy-9",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(186, 106, 255, 1)",
            },
            {
              value: 6,
              icon: "bold/interface-weather-rain-1",
              label: "| Tier 6",
              color: "rgba(0, 0, 0, 0)",
              textColor: "#ff89f6",
              fallbackText: "",
            },
            {
              value: 7,
              icon: "bold/money-graph-bar-decrease",
              label: "| Tier 7",
              color: "rgba(0, 0, 0, 0)",
              textColor: "rgba(255, 86, 238, 1)",
            },
            {
              value: 8,
              label: "| Tier 8",
              icon: "bold/interface-delete-bin-2",
              caption: "",
              textColor: "rgba(255, 62, 151, 1)",
              color: "rgba(72, 72, 72, 0)",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="left"
        size={80.84375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTier\n</div>'
        }
      />
      <Column
        id="a80e8"
        alignment="center"
        backgroundColor="rgba(75, 0, 255, 0.15)"
        cellTooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 12px #000000 ;\n">\n  Overall Grade<br> ⌁ <b>{{ (() => {\n    const map = {\n      "Ashton Jeanty": 95.7,\n      "Travis Hunter": 93.5,\n      "Omarion Hampton": 89.7,\n      "Tetairoa McMillan": 90.5,\n      "TreVeyon Henderson": 88.1,\n      "Quinshon Judkins": 87.5,\n      "Emeka Egbuka": 89.1,\n      "Tyler Warren": 88.9,\n      "Colston Loveland": 90.1,\n      "R.J. Harvey": 86.2,\n      "Kaleb Johnson": 85.6,\n      "Matthew Golden": 87.1,\n      "Luther Burden": 86.9,\n      "Jayden Higgins": 86.3,\n      "Tre Harris": 86.3,\n      "Jack Bech": 85.7,\n      "Cameron Skattebo": 87.3,\n      "Kyle Williams": 86.9,\n      "Mason Taylor": 74.8,\n      "Bhayshul Tuten": 79.8,\n      "Jaylin Noel": 85.6,\n      "Terrance Ferguson": 77.3,\n      "Jaydon Blue": 74.0,\n      "Elijah Arroyo": 74.1,\n      "Pat Bryant": 79.6,\n      "Dylan Sampson": 81.6,\n      "Harold Fannin Jr.": 86.5,\n      "Jalen Royals": 84.8,\n      "Devin Neal": 81.4,\n      "Trevor Etienne": 79.8,\n      "Elic Ayomanor": 78.0,\n      "Jarquez Hunter": 76.1,\n      "DJ Giddens": 80.7,\n      "Isaac TeSlaa": 74.9,\n      "Jordan James": 76.1,\n      "Ollie Gordon": 73.7,\n      "Jo\'quavious Marks": 69.9,\n      "Dont\'e Thornton": 74.5,\n      "Tory Horton": 84.1,\n      "Brashard Smith": 72.8,\n      "Oronde Gadsden II": 78.7,\n      "Savion Williams": 78.3,\n      "Tahj Brooks": 81.4,\n      "Kyle Monangai": 74.2,\n      "Tai Felton": 81.7,\n      "Chimere Dike": 76.3,\n      "Gunnar Helm": 71.3,\n      "Jaylin Lane": 77.2,\n      "Damien Martinez": 80.9,\n      "Jimmy Horn Jr.": 72.4,\n      "Jacory Croskey-Merritt": 72.1,\n      "Arian Smith": 71.2,\n      "Keandre Lambert-Smith": 79.7,\n      "Tez Johnson": 79.9,\n      "Phil Mafah": 68.0,\n      "LeQuint Allen": 66.7,\n      "Mitchell Evans": 70.5,\n      "Thomas Fidone III": 70.4,\n      "LaJohntay Wester": 74.2,\n      "Ricky White": 79.2,\n      "Moliki Matavao": 62.6,\n      "Kaden Prather": 72.9,\n      "Luke Lachey": 69.2\n    };\n    const v = map[currentSourceRow.PLAYER];\n    return v ?? item;    // Fallback to the cell value if name mismatch\n  })() }}</b> ⌁ \n</div>\n'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "60",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "79",
        }}
        groupAggregationMode="average"
        key="OVR GRADE"
        label="OVR GRD"
        optionList={{
          iconByIndex: "",
          mode: "manual",
          textColorByIndex: "",
          labelByIndex: "",
          valueByIndex: "",
          fallbackTextByIndex: "",
          hiddenByIndex: "",
          captionByIndex: "",
          colorByIndex: "",
          mappedData: "[]",
        }}
        placeholder="Enter value"
        position="center"
        size={102.34375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item >89}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(231, 255, 248, 0.03)",
              tooltip: "",
            },
            {
              showWhen: "{{item >80}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(0, 109, 242, 0.03)",
            },
            {
              showWhen: "{{item >75}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(124, 83, 204, 0.03)",
            },
            {
              showWhen: "true",
              label: "{{ item }}",
              icon: "",
              color: "rgba(68, 76, 87, 0.03)",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nOverall Grade\n</div>'
        }
      />
      <Column
        id="05ab0"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(20, 26, 50)"
        headerTextColor="#ffffff"
        key="truADP"
        label="ADP"
        optionList={{
          iconByIndex: "",
          mode: "manual",
          textColorByIndex: "",
          labelByIndex: "",
          valueByIndex: "",
          fallbackTextByIndex: "",
          hiddenByIndex: "",
          captionByIndex: "",
          colorByIndex: "",
          mappedData: "",
        }}
        placeholder="Enter value"
        position="center"
        size={82}
        summaryAggregationMode="none"
        textColor="{{ 
  currentSourceRow.truADP < 53.9 ? '#00FFAA':
  currentSourceRow.truADP < 90 ? '#00FfFF':
     currentSourceRow.truADP < 130 ? '#90B8FC':
     currentSourceRow.truADP < 165 ? '#80B3FF':
     currentSourceRow.truADP < 200 ? '#a34fff':
   currentSourceRow.truADP < 250 ? '#ff91Fd':
    currentSourceRow.truADP < 300 ? '#ff91cd':
    currentSourceRow.truADP < 350 ? '#ff91cd':
     currentSourceRow.truADP < 699 ? '#FF00FF':'' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nAverage Draft Position\n</div>'
        }
        valueOverride="［ {{item}} ］"
      />
      <Column
        id="328dc"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="Rook ADP"
        label="ROOKIE ADP  "
        placeholder="Enter value"
        position="center"
        size={75.21875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRookie Average Draft Position\n</div>'
        }
      />
      <Column
        id="62082"
        alignment="center"
        backgroundColor="rgba(104, 141, 243, 0.03)"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RD"
        label="RD 📶"
        placeholder="Enter value"
        position="center"
        size={54.9375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "",
              label: "",
              color: "rgba(135, 230, 179, 1)",
              icon: "bold/interface-arrows-up-alternate",
            },
            {
              showWhen: "{{ item < 7 }}",
              label: "",
              color: "#F8DBD8",
              icon: "bold/money-graph-arrow-decrease",
            },
            {
              showWhen: "{{ item > 6 }}",
              label: "",
              color: "rgba(236, 116, 154, 1)",
              icon: "bold/interface-arrows-down-alternate",
            },
            {
              showWhen: "{{ item < 5 }}",
              label: "",
              color: "#D7EAE0",
              icon: "bold/money-graph-arrow-increase",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRound Drafted\n</div>'
        }
      />
      <Column
        id="95105"
        alignment="center"
        backgroundColor="rgba(104, 141, 243, 0.03)"
        cellTooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -10px;\n   font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 12px #000000 ;\n">\nPick Drafted<br> ⌁ <b>{{item}}</b> ⌁ \n</div>\n\n'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "", color: "" }}
        groupAggregationMode="sum"
        key="PK#"
        label="PK"
        placeholder="Enter value"
        position="center"
        size={69.9375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item <33}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(196, 253, 234, 0.15)",
              tooltip: "",
            },
            {
              showWhen: "{{item < 68}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(186, 255, 255, 0.15)",
            },
            {
              showWhen: "{{item < 90}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(186, 243, 255, 0.15)",
            },
            {
              showWhen: "{{item < 130}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(229, 205, 255, 0.3)",
            },
            {
              showWhen: "{{item >190}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(251, 164, 234, 1)",
            },
            {
              showWhen: "{{item >130}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(232, 177, 250, 0.5)",
              tooltip: "",
            },
            { showWhen: "{{item}}", label: "UD", icon: "" },
          ],
        }}
        summaryAggregationMode="none"
        textColor="{{ theme.danger }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPick Drafted [Overall]\n</div>'
        }
      />
      <Column
        id="41f3f"
        alignment="center"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="NCAA"
        label="NCAA"
        placeholder="Enter value"
        position="center"
        size={61.515625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTeam [NCAA]\n</div>'
        }
      />
      <Column
        id="53da5"
        alignment="center"
        editable="false"
        format="multilineString"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
        textColor="rgba(255, 255, 255, 1)"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nAge\n</div>'
        }
      />
      <Column
        id="7a71b"
        alignment="center"
        format="string"
        formatOptions={{ automaticColors: true, notation: "standard" }}
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={46.03125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nHeight\n</div>'
        }
      />
      <Column
        id="f718d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={47.875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nWeight\n</div>'
        }
      />
      <Column
        id="05e56"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="40"
        label="40"
        placeholder="Enter value"
        position="center"
        size={46.515625}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow[\"40\"] == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n40 Yard Dash\n</div>'
        }
      />
      <Column
        id="cf84f"
        alignment="left"
        backgroundColor="rgba(185, 190, 209, 0.03)"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\nAthletic Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(198, 203, 231, 1)"
        key="ATHL"
        label="ATHL GRD"
        placeholder="Enter value"
        position="center"
        size={78.6875}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item > 91.9}}",
              label: "{{ item }}",
              icon: "bold/image-flash-1",
              color: "rgba(120, 210, 171, 1)",
            },
            {
              showWhen: "{{item > 87}}",
              label: "{{ item }}",
              icon: "bold/image-flash-2",
              color: "rgba(190, 254, 234, 0.17)",
            },
            {
              showWhen: "{{ item > 82.9 }}",
              label: "{{ item }}",
              icon: "bold/shopping-business-startup",
              color: "rgba(138, 255, 255, 0.13)",
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{item}}",
              icon: "bold/mail-send-email",
              color: "rgba(185, 223, 255, 0.13)",
            },
            {
              showWhen: "{{item > 76}}",
              label: "{{ item }}",
              icon: "bold/mail-send-email",
            },
            {
              showWhen: "{{item < 76}}",
              label: "{{item}}",
              icon: "bold/phone-signal-low",
              color: "rgba(255, 178, 214, 0.15)",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nAthletic Grade\n</div>'
        }
      />
      <Column
        id="4bffd"
        alignment="center"
        backgroundColor="rgba(63, 1, 255, 0.05)"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.9em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nCEILING ⌁ <b>{{item}}/5</b> \n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="rating"
        formatOptions={{ icon: "", size: "small", icons: "stars" }}
        groupAggregationMode="average"
        key="CL"
        label="CEILING"
        placeholder="Enter value"
        position="center"
        size={98}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProjected Ceiling\n</div>'
        }
      />
      <Column
        id="5b01a"
        alignment="center"
        backgroundColor="rgba(131, 0, 255, 0.05)"
        cellTooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.9em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nFLOOR ⌁ <b>{{item}}/5</b>\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="rating"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          size: "small",
          icons: "stars",
        }}
        groupAggregationMode="sum"
        key="FL"
        label="FLOOR"
        placeholder="Enter value"
        position="center"
        size={101.5}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProjected Floor\n</div>'
        }
      />
      <Column
        id="93ad9"
        alignment="center"
        backgroundColor="rgba(185, 190, 209, 0.03)"
        caption="• {{ item }} •"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProduction Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "55",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "75",
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#141a32"
        headerTextColor="rgba(183, 190, 223, 1)"
        key="PRD GRADE"
        label="PRD GRD"
        placeholder="Enter value"
        position="center"
        size={67.09375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProduction Grade\n</div>'
        }
      />
      <Column
        id="d91e6"
        alignment="center"
        backgroundColor="rgba(185, 190, 209, 0.03)"
        caption="• {{ item }} •"
        cellTooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nEfficiency Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "50",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "75",
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#141a32"
        headerTextColor="#aeb9ea"
        key="EFF GRADE"
        label="EFF GRD"
        placeholder="Enter value"
        position="center"
        size={69.671875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nEfficiency Grade\n</div>'
        }
      />
      <Column
        id="a6c5e"
        alignment="center"
        backgroundColor="rgba(154, 186, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(154, 186, 255, 1)"
        key="RR GRD"
        label="RR GRD  ↰↱"
        placeholder="Enter value"
        position="center"
        size={82}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{ item > 85}} ",
              label: "{{item}}",
              icon: "bold/interface-arrows-bend-up-right-1-alternate",
              color: "rgba(190, 254, 234, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{item}}",
              icon: "bold/interface-arrows-bend-up-right-2-alternate",
              color: "rgba(224, 245, 255, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item < 75}}",
              label: "{{item}}",
              icon: "bold/interface-arrows-up-alternate",
              color: "rgba(255, 178, 214, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{ item == 'NA' }}",
              label: "{{ item }}",
              icon: "bold/interface-block",
              color: "rgba(160, 160, 160, 0.1)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\n <b>N/A</b> ⌁ [WR/TE–ONLY Metric]\n</div>',
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nSeperation / Route Running Grade\n</div>'
        }
      />
      <Column
        id="65b64"
        alignment="left"
        backgroundColor="rgba(182, 184, 193, 0.03)"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b7bedf"
        key="FILM GRADE"
        label="FILM 
GRD"
        placeholder="Enter value"
        position="center"
        size={77.609375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item > 85}}",
              label: "{{ item }}",
              icon: "bold/entertainment-camera-video",
              color: "rgba(190, 254, 234, 0.17)",
            },
            {
              showWhen: "{{  item > 78}}",
              label: "{{ item }}",
              icon: "bold/computer-connection-video-camera",
              color: "rgba(224, 245, 255, 0.2)",
            },
            {
              showWhen: "{{item < 79}}",
              label: "{{ item }}",
              icon: "bold/entertainment-recording-tape-1",
              color: "rgba(255, 178, 214, 0.15)",
            },
            {
              showWhen: "true",
              label: "{{item}}",
              icon: "bold/interface-page-controller-loading-half",
              color: "rgba(227, 223, 223, 0.1)",
            },
          ],
        }}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nFilm Grade\n</div>'
        }
      />
      <Column
        id="6beae"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="G"
        label="G"
        placeholder="Enter value"
        position="center"
        size={37.6875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nGames Played\n</div>'
        }
      />
      <Column
        id="571eb"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="SOS"
        label="SOS"
        placeholder="Enter value"
        position="center"
        size={53}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow.SOS == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nNCAA Strength of Schedule [Career Avg.]\n</div>'
        }
      />
      <Column
        id="e9438"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(181, 161, 254, 1)"
        key="YDS(t)"
        label="YDS ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={64.734375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [Total]\n</div>'
        }
      />
      <Column
        id="37293"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="TD(t)"
        label="TD
 ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={50.25}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [Total]\n</div>'
        }
      />
      <Column
        id="25637"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="YpG(t)"
        label="YpG 
⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={58.453125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards per Game [Total]\n</div>'
        }
      />
      <Column
        id="00b31"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="OPP(t)"
        label="OPP"
        placeholder="Enter value"
        position="center"
        size={58.15625}
        summaryAggregationMode="none"
        textColor="#ffffff"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nOpportunities [CAR+TGT]\n</div>'
        }
      />
      <Column
        id="45011"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="IMP"
        label="IMP"
        placeholder="Enter value"
        position="center"
        size={57.484375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nImpact Plays [TD+1D]\n</div>'
        }
      />
      <Column
        id="3ce33"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "0",
          padDecimal: false,
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="IMP/ OPP"
        label="IMP/OPP"
        placeholder="Enter value"
        position="center"
        size={81.84375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nImpact Plays per Opportunity\n</div>'
        }
      />
      <Column
        id="4c58c"
        alignment="center"
        backgroundColor="rgba(110, 137, 245, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "3",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        key="DMTR"
        label="DMTR"
        placeholder="Enter value"
        position="center"
        size={66.890625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nDominator Rating\n</div>'
        }
      />
      <Column
        id="89a9d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="CAR"
        label="CAR"
        placeholder="Enter value"
        position="center"
        size={52.640625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nCarries\n</div>'
        }
      />
      <Column
        id="1ed57"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="ruYDS"
        label="YDS ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={58.3125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nYards [Rushing]\n</div>'
        }
      />
      <Column
        id="bb829"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="ruTD"
        label="TD  ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={59.953125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTouchdowns [Rushing]\n</div>'
        }
      />
      <Column
        id="3620d"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="TGT"
        label="TGT"
        placeholder="Enter value"
        position="center"
        size={56}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTargets\n</div>'
        }
      />
      <Column
        id="38694"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="REC"
        label="REC"
        placeholder="Enter value"
        position="center"
        size={59}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nReceptions\n</div>'
        }
      />
      <Column
        id="db7c4"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="recYDS"
        label="YDS
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={51.140625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [Receiving]\n</div>'
        }
      />
      <Column
        id="e7cf5"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="rgba(153, 205, 255, 1)"
        key="recTD"
        label="TD
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={50.9375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [Receiving]\n</div>'
        }
      />
      <Column
        id="23e31"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="rec1D"
        label="1D
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={67}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nFirst Downs [Receiving]\n</div>'
        }
      />
      <Column
        id="c40d1"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YPRR"
        label="YPRR"
        placeholder="Enter value"
        position="center"
        size={68}
        summaryAggregationMode="none"
        textColor="{{
(() => {
 const v = parseFloat(String(item).replace(/[^0-9.-]/g, ''));
 if (!isFinite(v)) return null;
 const rules = [
  [2.7, '#00ffc4'],
  [2.4, '#85fff3'],
  [2.3, '#7dd1ff'],
  [2.1, '#957cff'],
  [1.9, '#a642ff'],
  [1.7, '#cf60ff'],
  [1.5, '#ff6fe1'],
 ];
 for (const [t, c] of rules) if (v >= t) return c;
 return '#ff2eb2';
})()
}}"
        tooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 15px #000000 ;\n">\nYards per Route Run\n</div>'
        }
      />
      <Column
        id="5d154"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="1DRR"
        label="1DRR"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nFirst Downs per Route Run\n</div>'
        }
      />
      <Column
        id="fe787"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YPR"
        label="YPR"
        placeholder="Enter value"
        position="center"
        size={69}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards per Reception\n</div>'
        }
      />
      <Column
        id="fd480"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YAC/R"
        label="YAC/REC"
        placeholder="Enter value"
        position="center"
        size={83}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards after Catch per Reception\n</div>'
        }
      />
      <Event
        event="selectRow"
        method=""
        params={{}}
        pluginId=""
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Table>
  </View>
  <View
    id="c73c1"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="tbd"
    viewKey="WR3"
  >
    <Table
      id="table89"
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "RK": 1,\n    "PLAYER": "Travis Hunter",\n    "POS": "WR",\n    "TM": "JAX",\n    "OVR GRADE": 94,\n    "truADP": 33.2,\n    "Rook ADP": 3,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "2",\n    "NCAA": "COLO",\n    "AGE": 22.2,\n    "HT": "6\'0\\"",\n    "WT": 188,\n    "40": "NA",\n    "ATHL": 96,\n    "CL": 5,\n    "FL": 3.5,\n    "PRD GRADE": 88.7,\n    "EFF GRADE": 96.3,\n    "RR GRD": 93.4,\n    "FILM GRADE": 93,\n    "G": 29,\n    "SOS": "82.6",\n    "YDS(t)": 2161,\n    "TD(t)": 25,\n    "YpG(t)": 74.52,\n    "OPP(t)": 220,\n    "IMP": 122,\n    "IMP/ OPP": 0.55,\n    "DMTR": "0.269",\n    "CAR": 3,\n    "ruYDS": -5,\n    "ruTD": 1,\n    "TGT": 217,\n    "REC": 170,\n    "recYDS": 2166,\n    "recTD": 24,\n    "rec1D": 96,\n    "YPRR": 2.42,\n    "YPR": 12.7,\n    "YAC/R": 4.38,\n    "Tier": 1\n  },\n  {\n    "RK": 2,\n    "PLAYER": "Tetairoa McMillan",\n    "POS": "WR",\n    "TM": "CAR",\n    "OVR GRADE": 90,\n    "truADP": 35.4,\n    "Rook ADP": 4,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "8",\n    "NCAA": "ARIZ",\n    "AGE": 22.3,\n    "HT": "6\'4\\"",\n    "WT": 219,\n    "40": "NA",\n    "ATHL": 87,\n    "CL": 4.5,\n    "FL": 4,\n    "PRD GRADE": 97.7,\n    "EFF GRADE": 89.8,\n    "RR GRD": 89.1,\n    "FILM GRADE": 88,\n    "G": 37,\n    "SOS": "81.4",\n    "YDS(t)": 3417,\n    "TD(t)": 26,\n    "YpG(t)": 92.35,\n    "OPP(t)": 342,\n    "IMP": 178,\n    "IMP/ OPP": 0.52,\n    "DMTR": "0.32",\n    "CAR": 1,\n    "ruYDS": 3,\n    "ruTD": 0,\n    "TGT": 341,\n    "REC": 213,\n    "recYDS": 3414,\n    "recTD": 26,\n    "rec1D": 152,\n    "YPRR": 2.37,\n    "YPR": 16,\n    "YAC/R": 5.45,\n    "Tier": 2\n  },\n  {\n    "RK": 3,\n    "PLAYER": "Emeka Egbuka",\n    "POS": "WR",\n    "TM": "TB",\n    "OVR GRADE": 89,\n    "truADP": 59.4,\n    "Rook ADP": 10,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "19",\n    "NCAA": "OSU",\n    "AGE": 22.8,\n    "HT": "6\'1\\"",\n    "WT": 202,\n    "40": 4.5,\n    "ATHL": 87,\n    "CL": 3.5,\n    "FL": 4,\n    "PRD GRADE": 95.7,\n    "EFF GRADE": 93.5,\n    "RR GRD": 91.1,\n    "FILM GRADE": 86,\n    "G": 47,\n    "SOS": "95.7",\n    "YDS(t)": 3017,\n    "TD(t)": 26,\n    "YpG(t)": 64.19,\n    "OPP(t)": 305,\n    "IMP": 170,\n    "IMP/ OPP": 0.56,\n    "DMTR": "0.195",\n    "CAR": 23,\n    "ruYDS": 150,\n    "ruTD": 2,\n    "TGT": 282,\n    "REC": 205,\n    "recYDS": 2867,\n    "recTD": 24,\n    "rec1D": 138,\n    "YPRR": 2.6,\n    "YPR": 14,\n    "YAC/R": 6.64,\n    "Tier": 3\n  },\n  {\n    "RK": 4,\n    "PLAYER": "Matthew Golden",\n    "POS": "WR",\n    "TM": "GB",\n    "OVR GRADE": 87,\n    "truADP": 70.8,\n    "Rook ADP": 12,\n    "RD": "<span style=\'color:#41fab8; font-size:0.9em; font-weight:500;\'>①</span>",\n    "PK#": "23",\n    "NCAA": "TEX",\n    "AGE": 21.9,\n    "HT": "5\'11\\"",\n    "WT": 191,\n    "40": 4.29,\n    "ATHL": 94,\n    "CL": 4.5,\n    "FL": 2,\n    "PRD GRADE": 83.9,\n    "EFF GRADE": 81.3,\n    "RR GRD": 87.5,\n    "FILM GRADE": 86,\n    "G": 36,\n    "SOS": "88.3",\n    "YDS(t)": 1990,\n    "TD(t)": 22,\n    "YpG(t)": 55.28,\n    "OPP(t)": 202,\n    "IMP": 118,\n    "IMP/ OPP": 0.58,\n    "DMTR": "0.22",\n    "CAR": 0,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 202,\n    "REC": 135,\n    "recYDS": 1990,\n    "recTD": 22,\n    "rec1D": 96,\n    "YPRR": 1.85,\n    "YPR": 14.7,\n    "YAC/R": 5.64,\n    "Tier": 4\n  },\n  {\n    "RK": 5,\n    "PLAYER": "Luther Burden",\n    "POS": "WR",\n    "TM": "CHI",\n    "OVR GRADE": 87,\n    "truADP": 88.4,\n    "Rook ADP": 14,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "39",\n    "NCAA": "MIZZ",\n    "AGE": 21.6,\n    "HT": "6\'0\\"",\n    "WT": 206,\n    "40": 4.41,\n    "ATHL": 88,\n    "CL": 5,\n    "FL": 2,\n    "PRD GRADE": 92.6,\n    "EFF GRADE": 87.6,\n    "RR GRD": 84.1,\n    "FILM GRADE": 83,\n    "G": 38,\n    "SOS": "89.4",\n    "YDS(t)": 2493,\n    "TD(t)": 25,\n    "YpG(t)": 65.61,\n    "OPP(t)": 307,\n    "IMP": 129,\n    "IMP/ OPP": 0.42,\n    "DMTR": "0.34",\n    "CAR": 32,\n    "ruYDS": 210,\n    "ruTD": 4,\n    "TGT": 275,\n    "REC": 193,\n    "recYDS": 2283,\n    "recTD": 21,\n    "rec1D": 93,\n    "YPRR": 2.32,\n    "YPR": 11.8,\n    "YAC/R": 7.26,\n    "Tier": 4\n  },\n  {\n    "RK": 6,\n    "PLAYER": "Jayden Higgins",\n    "POS": "WR",\n    "TM": "HOU",\n    "OVR GRADE": 86,\n    "truADP": 91.1,\n    "Rook ADP": 15,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "34",\n    "NCAA": "ISU",\n    "AGE": 22.6,\n    "HT": "6\'4\\"",\n    "WT": 214,\n    "40": 4.47,\n    "ATHL": 91,\n    "CL": 4,\n    "FL": 2.5,\n    "PRD GRADE": 83.6,\n    "EFF GRADE": 90.2,\n    "RR GRD": 87.8,\n    "FILM GRADE": 80,\n    "G": 36,\n    "SOS": "83",\n    "YDS(t)": 2562,\n    "TD(t)": 28,\n    "YpG(t)": 71.17,\n    "OPP(t)": 264,\n    "IMP": 188,\n    "IMP/ OPP": 0.71,\n    "DMTR": "0.331",\n    "CAR": 0,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 264,\n    "REC": 169,\n    "recYDS": 2562,\n    "recTD": 28,\n    "rec1D": 160,\n    "YPRR": 2.37,\n    "YPR": 14.6,\n    "YAC/R": 4.64,\n    "Tier": 4\n  },\n  {\n    "RK": 7,\n    "PLAYER": "Tre Harris",\n    "POS": "WR",\n    "TM": "LAC",\n    "OVR GRADE": 86,\n    "truADP": 94.3,\n    "Rook ADP": 16,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "55",\n    "NCAA": "MISS",\n    "AGE": 23.3,\n    "HT": "6\'2\\"",\n    "WT": 205,\n    "40": 4.54,\n    "ATHL": 76,\n    "CL": 4,\n    "FL": 3,\n    "PRD GRADE": 94.4,\n    "EFF GRADE": 98,\n    "RR GRD": 83.1,\n    "FILM GRADE": 80,\n    "G": 46,\n    "SOS": "90.1",\n    "YDS(t)": 3567,\n    "TD(t)": 29,\n    "YpG(t)": 77.54,\n    "OPP(t)": 333,\n    "IMP": 176,\n    "IMP/ OPP": 0.53,\n    "DMTR": "0.289",\n    "CAR": 5,\n    "ruYDS": 22,\n    "ruTD": 0,\n    "TGT": 328,\n    "REC": 220,\n    "recYDS": 3545,\n    "recTD": 29,\n    "rec1D": 146,\n    "YPRR": 3,\n    "YPR": 16.1,\n    "YAC/R": 6.44,\n    "Tier": 4\n  },\n  {\n    "RK": 8,\n    "PLAYER": "Jack Bech",\n    "POS": "WR",\n    "TM": "LV",\n    "OVR GRADE": 86,\n    "truADP": 116.5,\n    "Rook ADP": 17,\n    "RD": "<span style=\'color:#33b8b8; font-size:0.9em; font-weight:500;\'>②</span>",\n    "PK#": "58",\n    "NCAA": "TCU",\n    "AGE": 22.6,\n    "HT": "6\'1\\"",\n    "WT": 214,\n    "40": "NA",\n    "ATHL": 77,\n    "CL": 3.5,\n    "FL": 3.5,\n    "PRD GRADE": 65.7,\n    "EFF GRADE": 72.9,\n    "RR GRD": 88.5,\n    "FILM GRADE": 82,\n    "G": 45,\n    "SOS": "78.3",\n    "YDS(t)": 1866,\n    "TD(t)": 13,\n    "YpG(t)": 41.47,\n    "OPP(t)": 203,\n    "IMP": 100,\n    "IMP/ OPP": 0.49,\n    "DMTR": "0.14",\n    "CAR": 3,\n    "ruYDS": -3,\n    "ruTD": 0,\n    "TGT": 200,\n    "REC": 133,\n    "recYDS": 1869,\n    "recTD": 13,\n    "rec1D": 87,\n    "YPRR": 1.86,\n    "YPR": 14.1,\n    "YAC/R": 5.5,\n    "Tier": 4\n  },\n  {\n    "RK": 9,\n    "PLAYER": "Kyle Williams",\n    "POS": "WR",\n    "TM": "NE",\n    "OVR GRADE": 87,\n    "truADP": 127.6,\n    "Rook ADP": 20,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "69",\n    "NCAA": "WSU",\n    "AGE": 22.7,\n    "HT": "5\'11\\"",\n    "WT": 190,\n    "40": 4.4,\n    "ATHL": 85,\n    "CL": 3.5,\n    "FL": 3,\n    "PRD GRADE": 92.4,\n    "EFF GRADE": 86,\n    "RR GRD": 88.1,\n    "FILM GRADE": "NA",\n    "G": 50,\n    "SOS": "77.4",\n    "YDS(t)": 3678,\n    "TD(t)": 29,\n    "YpG(t)": 73.56,\n    "OPP(t)": 393,\n    "IMP": 189,\n    "IMP/ OPP": 0.48,\n    "DMTR": "0.318",\n    "CAR": 17,\n    "ruYDS": 72,\n    "ruTD": 0,\n    "TGT": 376,\n    "REC": 248,\n    "recYDS": 3606,\n    "recTD": 29,\n    "rec1D": 155,\n    "YPRR": 2.07,\n    "YPR": 14.5,\n    "YAC/R": 6.35,\n    "Tier": 4\n  },\n  {\n    "RK": 10,\n    "PLAYER": "Jaylin Noel",\n    "POS": "WR",\n    "TM": "HOU",\n    "OVR GRADE": 86,\n    "truADP": 141.7,\n    "Rook ADP": 22,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "79",\n    "NCAA": "ISU",\n    "AGE": 22.8,\n    "HT": "5\'10\\"",\n    "WT": 194,\n    "40": 4.39,\n    "ATHL": 92,\n    "CL": 3.5,\n    "FL": 3,\n    "PRD GRADE": 92.4,\n    "EFF GRADE": 82.8,\n    "RR GRD": 87.7,\n    "FILM GRADE": 79,\n    "G": 51,\n    "SOS": "83.6",\n    "YDS(t)": 2938,\n    "TD(t)": 18,\n    "YpG(t)": 57.61,\n    "OPP(t)": 362,\n    "IMP": 146,\n    "IMP/ OPP": 0.4,\n    "DMTR": "0.212",\n    "CAR": 13,\n    "ruYDS": 84,\n    "ruTD": 0,\n    "TGT": 349,\n    "REC": 245,\n    "recYDS": 2854,\n    "recTD": 18,\n    "rec1D": 123,\n    "YPRR": 2.07,\n    "YPR": 11.6,\n    "YAC/R": 5.58,\n    "Tier": 5\n  },\n  {\n    "RK": 11,\n    "PLAYER": "Pat Bryant",\n    "POS": "WR",\n    "TM": "DEN",\n    "OVR GRADE": 80,\n    "truADP": 169.5,\n    "Rook ADP": 28,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "74",\n    "NCAA": "ILL",\n    "AGE": 22.6,\n    "HT": "6\'2\\"",\n    "WT": 204,\n    "40": 4.61,\n    "ATHL": 72,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 81.9,\n    "EFF GRADE": 82.8,\n    "RR GRD": 81.7,\n    "FILM GRADE": "NA",\n    "G": 45,\n    "SOS": "88.4",\n    "YDS(t)": 2108,\n    "TD(t)": 19,\n    "YpG(t)": 46.84,\n    "OPP(t)": 214,\n    "IMP": 115,\n    "IMP/ OPP": 0.54,\n    "DMTR": "0.255",\n    "CAR": 6,\n    "ruYDS": 17,\n    "ruTD": 0,\n    "TGT": 208,\n    "REC": 136,\n    "recYDS": 2091,\n    "recTD": 19,\n    "rec1D": 95,\n    "YPRR": 2.12,\n    "YPR": 15.4,\n    "YAC/R": 4.7,\n    "Tier": 5\n  },\n  {\n    "RK": 12,\n    "PLAYER": "Jalen Royals",\n    "POS": "WR",\n    "TM": "KC",\n    "OVR GRADE": 85,\n    "truADP": 161.9,\n    "Rook ADP": 26,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "133",\n    "NCAA": "USU",\n    "AGE": 22.4,\n    "HT": "6\'0\\"",\n    "WT": 205,\n    "40": 4.42,\n    "ATHL": 89,\n    "CL": 3.5,\n    "FL": 1.5,\n    "PRD GRADE": 78.8,\n    "EFF GRADE": 90.9,\n    "RR GRD": 86.1,\n    "FILM GRADE": 80,\n    "G": 27,\n    "SOS": "70",\n    "YDS(t)": 1926,\n    "TD(t)": 21,\n    "YpG(t)": 71.33,\n    "OPP(t)": 185,\n    "IMP": 96,\n    "IMP/ OPP": 0.52,\n    "DMTR": "0.333",\n    "CAR": 1,\n    "ruYDS": 3,\n    "ruTD": 0,\n    "TGT": 184,\n    "REC": 125,\n    "recYDS": 1923,\n    "recTD": 21,\n    "rec1D": 75,\n    "YPRR": 2.42,\n    "YPR": 15.4,\n    "YAC/R": 6.81,\n    "Tier": 6\n  },\n  {\n    "RK": 13,\n    "PLAYER": "Elic Ayomanor",\n    "POS": "WR",\n    "TM": "TEN",\n    "OVR GRADE": 78,\n    "truADP": 170.5,\n    "Rook ADP": 29,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "136",\n    "NCAA": "STAN",\n    "AGE": 22.1,\n    "HT": "6\'2\\"",\n    "WT": 206,\n    "40": 4.44,\n    "ATHL": 83,\n    "CL": 3,\n    "FL": 1.5,\n    "PRD GRADE": 76.7,\n    "EFF GRADE": 76.4,\n    "RR GRD": 75.1,\n    "FILM GRADE": 77,\n    "G": 24,\n    "SOS": "81.7",\n    "YDS(t)": 1853,\n    "TD(t)": 12,\n    "YpG(t)": 77.21,\n    "OPP(t)": 216,\n    "IMP": 94,\n    "IMP/ OPP": 0.44,\n    "DMTR": "0.389",\n    "CAR": 0,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 216,\n    "REC": 126,\n    "recYDS": 1853,\n    "recTD": 12,\n    "rec1D": 82,\n    "YPRR": 2.12,\n    "YPR": 14.7,\n    "YAC/R": 4.49,\n    "Tier": 6\n  },\n  {\n    "RK": 14,\n    "PLAYER": "Isaac TeSlaa",\n    "POS": "WR",\n    "TM": "DET",\n    "OVR GRADE": 75,\n    "truADP": 195.0,\n    "Rook ADP": 36,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "70",\n    "NCAA": "ARK",\n    "AGE": 23.4,\n    "HT": "6\'4\\"",\n    "WT": 214,\n    "40": 4.43,\n    "ATHL": 91,\n    "CL": 4,\n    "FL": 1,\n    "PRD GRADE": 58.5,\n    "EFF GRADE": 65.5,\n    "RR GRD": 74.7,\n    "FILM GRADE": "NA",\n    "G": 25,\n    "SOS": "NA",\n    "YDS(t)": 883,\n    "TD(t)": 5,\n    "YpG(t)": 35.32,\n    "OPP(t)": 101,\n    "IMP": 41,\n    "IMP/ OPP": 0.41,\n    "DMTR": "0.142",\n    "CAR": 1,\n    "ruYDS": 0,\n    "ruTD": 0,\n    "TGT": 100,\n    "REC": 62,\n    "recYDS": 883,\n    "recTD": 5,\n    "rec1D": 36,\n    "YPRR": 1.45,\n    "YPR": 14.2,\n    "YAC/R": 4.97,\n    "Tier": 6\n  },\n  {\n    "RK": 15,\n    "PLAYER": "Tory Horton",\n    "POS": "WR",\n    "TM": "SEA",\n    "OVR GRADE": 84,\n    "truADP": 197.9,\n    "Rook ADP": 38,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "166",\n    "NCAA": "CSU",\n    "AGE": 22.6,\n    "HT": "6\'2\\"",\n    "WT": 196,\n    "40": 4.41,\n    "ATHL": 87,\n    "CL": 3.5,\n    "FL": 2,\n    "PRD GRADE": 90.7,\n    "EFF GRADE": 87.3,\n    "RR GRD": 82.9,\n    "FILM GRADE": "NA",\n    "G": 50,\n    "SOS": "75.1",\n    "YDS(t)": 3632,\n    "TD(t)": 27,\n    "YpG(t)": 72.64,\n    "OPP(t)": 381,\n    "IMP": 180,\n    "IMP/ OPP": 0.47,\n    "DMTR": "0.267",\n    "CAR": 2,\n    "ruYDS": 31,\n    "ruTD": 0,\n    "TGT": 379,\n    "REC": 264,\n    "recYDS": 3601,\n    "recTD": 27,\n    "rec1D": 152,\n    "YPRR": 2.46,\n    "YPR": 13.6,\n    "YAC/R": 5.83,\n    "Tier": 6\n  },\n  {\n    "RK": 16,\n    "PLAYER": "Dont\'e Thornton",\n    "POS": "WR",\n    "TM": "LV",\n    "OVR GRADE": 74,\n    "truADP": 235.5,\n    "Rook ADP": 41,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "108",\n    "NCAA": "TENN",\n    "AGE": 22.6,\n    "HT": "6\'5\\"",\n    "WT": 205,\n    "40": 4.3,\n    "ATHL": 95,\n    "CL": 4,\n    "FL": 1,\n    "PRD GRADE": 59.5,\n    "EFF GRADE": 75.6,\n    "RR GRD": 69.8,\n    "FILM GRADE": "NA",\n    "G": 42,\n    "SOS": "90.7",\n    "YDS(t)": 1433,\n    "TD(t)": 10,\n    "YpG(t)": 34.12,\n    "OPP(t)": 95,\n    "IMP": 53,\n    "IMP/ OPP": 0.56,\n    "DMTR": "0.139",\n    "CAR": 1,\n    "ruYDS": 9,\n    "ruTD": 0,\n    "TGT": 94,\n    "REC": 65,\n    "recYDS": 1424,\n    "recTD": 10,\n    "rec1D": 43,\n    "YPRR": 2.8,\n    "YPR": 21.9,\n    "YAC/R": 8.94,\n    "Tier": 6\n  },\n  {\n    "RK": 17,\n    "PLAYER": "Tai Felton",\n    "POS": "WR",\n    "TM": "MIN",\n    "OVR GRADE": 82,\n    "truADP": 247.5,\n    "Rook ADP": 46,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "102",\n    "NCAA": "MD",\n    "AGE": 22.3,\n    "HT": "6\'1\\"",\n    "WT": 183,\n    "40": 4.37,\n    "ATHL": 86,\n    "CL": 3.5,\n    "FL": 2,\n    "PRD GRADE": 87.8,\n    "EFF GRADE": 74.7,\n    "RR GRD": 78.2,\n    "FILM GRADE": "NA",\n    "G": 43,\n    "SOS": "92.6",\n    "YDS(t)": 2250,\n    "TD(t)": 17,\n    "YpG(t)": 52.33,\n    "OPP(t)": 267,\n    "IMP": 125,\n    "IMP/ OPP": 0.47,\n    "DMTR": "0.197",\n    "CAR": 3,\n    "ruYDS": 39,\n    "ruTD": 0,\n    "TGT": 264,\n    "REC": 172,\n    "recYDS": 2211,\n    "recTD": 17,\n    "rec1D": 106,\n    "YPRR": 1.86,\n    "YPR": 12.9,\n    "YAC/R": 6.19,\n    "Tier": 7\n  },\n  {\n    "RK": 18,\n    "PLAYER": "Savion Williams",\n    "POS": "WR",\n    "TM": "GB",\n    "OVR GRADE": 78,\n    "truADP": 259.5,\n    "Rook ADP": 49,\n    "RD": "<span style=\'color:#3c9fe0; font-size:0.9em; font-weight:500;\'>③</span>",\n    "PK#": "87",\n    "NCAA": "TCU",\n    "AGE": 23.6,\n    "HT": "6\'4\\"",\n    "WT": 222,\n    "40": 4.48,\n    "ATHL": 87,\n    "CL": 3.5,\n    "FL": 1.5,\n    "PRD GRADE": 82.2,\n    "EFF GRADE": 76.6,\n    "RR GRD": 68.8,\n    "FILM GRADE": 77,\n    "G": 50,\n    "SOS": "78.3",\n    "YDS(t)": 2053,\n    "TD(t)": 20,\n    "YpG(t)": 41.06,\n    "OPP(t)": 272,\n    "IMP": 124,\n    "IMP/ OPP": 0.46,\n    "DMTR": "0.135",\n    "CAR": 62,\n    "ruYDS": 384,\n    "ruTD": 6,\n    "TGT": 210,\n    "REC": 138,\n    "recYDS": 1669,\n    "recTD": 14,\n    "rec1D": 82,\n    "YPRR": 1.55,\n    "YPR": 12.1,\n    "YAC/R": 5.41,\n    "Tier": 7\n  },\n  {\n    "RK": 19,\n    "PLAYER": "Jimmy Horn Jr.",\n    "POS": "WR",\n    "TM": "CAR",\n    "OVR GRADE": 72,\n    "truADP": 244.4,\n    "Rook ADP": 44,\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>⑥</span>",\n    "PK#": "208",\n    "NCAA": "COLO",\n    "AGE": 22.8,\n    "HT": "5\'8\\"",\n    "WT": 174,\n    "40": 4.46,\n    "ATHL": 71,\n    "CL": 2,\n    "FL": 2,\n    "PRD GRADE": 74.2,\n    "EFF GRADE": 67.2,\n    "RR GRD": 77.3,\n    "FILM GRADE": "NA",\n    "G": 46,\n    "SOS": "NA",\n    "YDS(t)": 2092,\n    "TD(t)": 12,\n    "YpG(t)": 45.48,\n    "OPP(t)": 258,\n    "IMP": 104,\n    "IMP/ OPP": 0.4,\n    "DMTR": "0.151",\n    "CAR": 16,\n    "ruYDS": 112,\n    "ruTD": 1,\n    "TGT": 242,\n    "REC": 163,\n    "recYDS": 1980,\n    "recTD": 11,\n    "rec1D": 85,\n    "YPRR": 1.55,\n    "YPR": 12.1,\n    "YAC/R": 7.02,\n    "Tier": 7\n  },\n  {\n    "RK": 20,\n    "PLAYER": "Keandre Lambert-Smith",\n    "POS": "WR",\n    "TM": "LAC",\n    "OVR GRADE": 80,\n    "truADP": 317.8,\n    "Rook ADP": 55,\n    "RD": "<span style=\'color:#a540fd; font-size:0.9em; font-weight:500;\'>⑤</span>",\n    "PK#": "158",\n    "NCAA": "AUB",\n    "AGE": 22.9,\n    "HT": "6\'1\\"",\n    "WT": 190,\n    "40": 4.37,\n    "ATHL": 87,\n    "CL": 4,\n    "FL": 1.5,\n    "PRD GRADE": 80.1,\n    "EFF GRADE": 80.1,\n    "RR GRD": 71.5,\n    "FILM GRADE": "NA",\n    "G": 58,\n    "SOS": "94.3",\n    "YDS(t)": 2704,\n    "TD(t)": 19,\n    "YpG(t)": 46.62,\n    "OPP(t)": 285,\n    "IMP": 134,\n    "IMP/ OPP": 0.47,\n    "DMTR": "0.17",\n    "CAR": 1,\n    "ruYDS": 2,\n    "ruTD": 0,\n    "TGT": 284,\n    "REC": 176,\n    "recYDS": 2702,\n    "recTD": 19,\n    "rec1D": 114,\n    "YPRR": 1.77,\n    "YPR": 15.4,\n    "YAC/R": 7.03,\n    "Tier": 7\n  },\n  {\n    "RK": 21,\n    "PLAYER": "Jaylin Lane",\n    "POS": "WR",\n    "TM": "WAS",\n    "OVR GRADE": 77,\n    "truADP": 281.6,\n    "Rook ADP": 50,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "125",\n    "NCAA": "VT",\n    "AGE": 23.2,\n    "HT": "5\'10\\"",\n    "WT": 191,\n    "40": 4.34,\n    "ATHL": 94,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 83,\n    "EFF GRADE": 78.2,\n    "RR GRD": "NA",\n    "FILM GRADE": "NA",\n    "G": 54,\n    "SOS": "80.4",\n    "YDS(t)": 2804,\n    "TD(t)": 21,\n    "YpG(t)": 51.93,\n    "OPP(t)": 340,\n    "IMP": 154,\n    "IMP/ OPP": 0.45,\n    "DMTR": "0.206",\n    "CAR": 46,\n    "ruYDS": 264,\n    "ruTD": 3,\n    "TGT": 294,\n    "REC": 203,\n    "recYDS": 2540,\n    "recTD": 18,\n    "rec1D": 119,\n    "YPRR": 2.01,\n    "YPR": 12.5,\n    "YAC/R": 8.06,\n    "Tier": 8\n  },\n  {\n    "RK": 22,\n    "PLAYER": "Chimere Dike",\n    "POS": "WR",\n    "TM": "TEN",\n    "OVR GRADE": 76,\n    "truADP": 285.4,\n    "Rook ADP": 52,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "103",\n    "NCAA": "FLA",\n    "AGE": 23.6,\n    "HT": "6\'1\\"",\n    "WT": 196,\n    "40": 4.34,\n    "ATHL": 91,\n    "CL": 2.5,\n    "FL": 2.5,\n    "PRD GRADE": 72,\n    "EFF GRADE": 65.8,\n    "RR GRD": "NA",\n    "FILM GRADE": "NA",\n    "G": 57,\n    "SOS": "91.9",\n    "YDS(t)": 2360,\n    "TD(t)": 12,\n    "YpG(t)": 41.4,\n    "OPP(t)": 251,\n    "IMP": 112,\n    "IMP/ OPP": 0.45,\n    "DMTR": "0.179",\n    "CAR": 14,\n    "ruYDS": 99,\n    "ruTD": 1,\n    "TGT": 237,\n    "REC": 139,\n    "recYDS": 2261,\n    "recTD": 11,\n    "rec1D": 95,\n    "YPRR": 1.72,\n    "YPR": 16.3,\n    "YAC/R": 5.42,\n    "Tier": 8\n  },\n  {\n    "RK": 23,\n    "PLAYER": "Arian Smith",\n    "POS": "WR",\n    "TM": "NYG",\n    "OVR GRADE": 71,\n    "truADP": 286.0,\n    "Rook ADP": 53,\n    "RD": "<span style=\'color:#8b5bf0; font-size:0.9em; font-weight:500;\'>④</span>",\n    "PK#": "110",\n    "NCAA": "UGA",\n    "AGE": 22.8,\n    "HT": "6\'0\\"",\n    "WT": 179,\n    "40": 4.36,\n    "ATHL": 88,\n    "CL": 3,\n    "FL": 2,\n    "PRD GRADE": 60.3,\n    "EFF GRADE": 65.2,\n    "RR GRD": "NA",\n    "FILM GRADE": "NA",\n    "G": 45,\n    "SOS": "NA",\n    "YDS(t)": 1428,\n    "TD(t)": 10,\n    "YpG(t)": 31.73,\n    "OPP(t)": 121,\n    "IMP": 59,\n    "IMP/ OPP": 0.49,\n    "DMTR": "0.105",\n    "CAR": 9,\n    "ruYDS": 88,\n    "ruTD": 0,\n    "TGT": 112,\n    "REC": 68,\n    "recYDS": 1340,\n    "recTD": 10,\n    "rec1D": 45,\n    "YPRR": 2.27,\n    "YPR": 19.7,\n    "YAC/R": 7.87,\n    "Tier": 8\n  },\n  {\n    "RK": 24,\n    "PLAYER": "Tez Johnson",\n    "POS": "WR",\n    "TM": "TB",\n    "OVR GRADE": 80,\n    "truADP": 299.5,\n    "Rook ADP": 54,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "235",\n    "NCAA": "ORE",\n    "AGE": 23.2,\n    "HT": "5\'10\\"",\n    "WT": 154,\n    "40": 4.51,\n    "ATHL": 74,\n    "CL": 2,\n    "FL": 1.5,\n    "PRD GRADE": 95.9,\n    "EFF GRADE": 96.3,\n    "RR GRD": 88.8,\n    "FILM GRADE": "NA",\n    "G": 62,\n    "SOS": "88.9",\n    "YDS(t)": 3925,\n    "TD(t)": 29,\n    "YpG(t)": 63.31,\n    "OPP(t)": 416,\n    "IMP": 210,\n    "IMP/ OPP": 0.5,\n    "DMTR": "0.22",\n    "CAR": 12,\n    "ruYDS": 66,\n    "ruTD": 1,\n    "TGT": 404,\n    "REC": 307,\n    "recYDS": 3859,\n    "recTD": 28,\n    "rec1D": 178,\n    "YPRR": 2.85,\n    "YPR": 12.6,\n    "YAC/R": 7.92,\n    "Tier": 8\n  },\n  {\n    "RK": 25,\n    "PLAYER": "Ricky White",\n    "POS": "WR",\n    "TM": "SEA",\n    "OVR GRADE": 79,\n    "truADP": 347.1,\n    "Rook ADP": 59,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "238",\n    "NCAA": "UNLV",\n    "AGE": 23.4,\n    "HT": "6\'1\\"",\n    "WT": 184,\n    "40": 4.61,\n    "ATHL": 69,\n    "CL": 1.5,\n    "FL": 2,\n    "PRD GRADE": 95.9,\n    "EFF GRADE": 88.6,\n    "RR GRD": 82.7,\n    "FILM GRADE": "NA",\n    "G": 43,\n    "SOS": "NA",\n    "YDS(t)": 3369,\n    "TD(t)": 24,\n    "YpG(t)": 78.35,\n    "OPP(t)": 363,\n    "IMP": 161,\n    "IMP/ OPP": 0.44,\n    "DMTR": "0.377",\n    "CAR": 3,\n    "ruYDS": 5,\n    "ruTD": 0,\n    "TGT": 360,\n    "REC": 227,\n    "recYDS": 3364,\n    "recTD": 24,\n    "rec1D": 137,\n    "YPRR": 2.69,\n    "YPR": 14.8,\n    "YAC/R": 6.03,\n    "Tier": 8\n  },\n  {\n    "RK": 26,\n    "PLAYER": "Kaden Prather",\n    "POS": "WR",\n    "TM": "BUF",\n    "OVR GRADE": 73,\n    "truADP": 667.1,\n    "Rook ADP": 63,\n    "RD": "<span style=\'color:#f85af2; font-size:0.9em; font-weight:500;\'>⑦</span>",\n    "PK#": "240",\n    "NCAA": "MD",\n    "AGE": 22.8,\n    "HT": "6\'4\\"",\n    "WT": 204,\n    "40": 4.46,\n    "ATHL": 76,\n    "CL": 1.5,\n    "FL": 1,\n    "PRD GRADE": 80,\n    "EFF GRADE": 66.3,\n    "RR GRD": 69.5,\n    "FILM GRADE": "NA",\n    "G": 45,\n    "SOS": "90.6",\n    "YDS(t)": 1997,\n    "TD(t)": 12,\n    "YpG(t)": 44.38,\n    "OPP(t)": 258,\n    "IMP": 115,\n    "IMP/ OPP": 0.45,\n    "DMTR": "0.161",\n    "CAR": 2,\n    "ruYDS": 35,\n    "ruTD": 0,\n    "TGT": 256,\n    "REC": 162,\n    "recYDS": 1962,\n    "recTD": 12,\n    "rec1D": 102,\n    "YPRR": 1.52,\n    "YPR": 12.1,\n    "YAC/R": 4.51,\n    "Tier": 8\n  },\n  {\n    "RK": 27,\n    "PLAYER": "LaJohntay Wester",\n    "POS": "WR",\n    "TM": "BAL",\n    "OVR GRADE": 74,\n    "truADP": 686.9,\n    "Rook ADP": 64,\n    "RD": "<span style=\'color:#cf40fd; font-size:0.9em; font-weight:500;\'>⑥</span>",\n    "PK#": "203",\n    "NCAA": "COLO",\n    "AGE": 23.3,\n    "HT": "5\'10\\"",\n    "WT": 163,\n    "40": 4.46,\n    "ATHL": 72,\n    "CL": 1.5,\n    "FL": 1,\n    "PRD GRADE": 98,\n    "EFF GRADE": 86.8,\n    "RR GRD": "NA",\n    "FILM GRADE": "NA",\n    "G": 57,\n    "SOS": "NA",\n    "YDS(t)": 3810,\n    "TD(t)": 33,\n    "YpG(t)": 66.84,\n    "OPP(t)": 498,\n    "IMP": 217,\n    "IMP/ OPP": 0.44,\n    "DMTR": "0.278",\n    "CAR": 37,\n    "ruYDS": 215,\n    "ruTD": 2,\n    "TGT": 461,\n    "REC": 324,\n    "recYDS": 3595,\n    "recTD": 31,\n    "rec1D": 173,\n    "YPRR": 2.03,\n    "YPR": 11.1,\n    "YAC/R": 5.64,\n    "Tier": 8\n  }\n]\n'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicColumnProperties={{ formatByIndex: "auto", labelByIndex: "f" }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      headerTextWrap={true}
      linkedFilterId=""
      primaryKeyColumnId="3220b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      style={{
        headerFontFamily: "Michroma",
        fontWeight: "100",
        border: "rgba(130, 138, 179, 0.2)",
        hoverRowBackground: "rgba(87, 0, 255, 0.4)",
        alternateRowBackground: "rgba(26, 26, 50, 1)",
        background: "rgba(23, 23, 44, 1)",
        cellText: "rgba(255, 255, 255, 1)",
        fontSize: "12px",
        fontFamily: "Product Sans",
        headerFontWeight: "400",
        headerText: "#ffffffff",
        headerBackground: "#141a32",
        headerFontSize: "10px",
      }}
    >
      <Column
        id="d6166"
        alignment="center"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RK"
        label="RK"
        placeholder="Enter value"
        position="left"
        size={51.140625}
        summaryAggregationMode="none"
      />
      <Column
        id="3220b"
        alignment="left"
        editable={false}
        format="string"
        groupAggregationMode="none"
        key="PLAYER"
        label="PLAYER"
        placeholder="Enter value"
        position="left"
        size={132.859375}
        summaryAggregationMode="none"
        textColor="{{ currentSourceRow.POS === 'RB' ? '#E9ffE9'
  : currentSourceRow.POS === 'TE' ? '#eedcff'
  : currentSourceRow.POS === 'WR' ? '#d1dfff'
  : '' }}"
      />
      <Column
        id="a5b57"
        alignment="center"
        backgroundColor="{{ Number(currentSourceRow.Tier) == 1 ? '#33007f40':
  Number(currentSourceRow.Tier) == 2 ? '#33007f35':
  Number(currentSourceRow.Tier) == 3 ? '#33007f30':
  Number(currentSourceRow.Tier) == 4 ? '#33007f25':
  Number(currentSourceRow.Tier) == 5 ? '#33007f20':
  Number(currentSourceRow.Tier) == 6 ? '#33007f15':
  Number(currentSourceRow.Tier) == 7 ? '#33007f10': '' }}
"
        editableOptions={{ showStepper: true, allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="sum"
        headerTextColor="rgba(174, 23, 23, 1)"
        key="Tier"
        label="TIER"
        optionList={{
          manualData: [
            {
              value: 1,
              label: "| Tier 1",
              color: "rgba(0, 0, 0, 0)",
              textColor: "#dfcd87",
              icon: "bold/interface-award-crown",
              caption: "",
            },
            { map: { value: 2 } },
            { map: { value: 3 } },
            { map: { value: 4 } },
            { map: { value: 5 } },
            { map: { value: 6 } },
            { map: { value: 7 } },
            {
              value: 8,
              label: "| Tier 8",
              icon: "bold/interface-delete-bin-2",
              caption: "",
              textColor: "#ff6fe1",
              color: "rgba(72, 72, 72, 0)",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="center"
        size={88}
        summaryAggregationMode="none"
      />
      <Column
        id="f83ae"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              ordered: [
                { value: "QB" },
                { color: "#ff2a6d" },
                { textColor: "rgba(18, 18, 18, 1)" },
                { icon: "" },
                { label: "" },
              ],
            },
            {
              value: "WR",
              color: "rgba(88, 167, 255, 0)",
              textColor: "#58a7ff",
              icon: "bold/computer-connection-usb-port",
            },
            {
              value: "RB",
              icon: "bold/travel-transportation-bus",
              color: "rgba(34, 228, 176, 0)",
              textColor: "#22e4b0",
            },
            {
              value: "TE",
              textColor: "#8300ff",
              color: "rgba(0, 0, 0, 0)",
              icon: "bold/interface-security-shield-4",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="left"
        size={66.859375}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="50caa"
        alignment="center"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="none"
        key="TM"
        label="TM"
        optionList={{
          mode: "mapped",
          mappedData:
            '[\n  { value: "ARI", color: "#97233F", textColor: "#FFB612" },  // red ⟡ yellow :contentReference[oaicite:0]{index=0}\n  { value: "ATL", color: "#A71930", textColor: "#000000" },  // red ⟡ black :contentReference[oaicite:1]{index=1}\n  { value: "BAL", color: "#241773", textColor: "#9E7C0C" },  // purple ⟡ gold :contentReference[oaicite:2]{index=2}\n  { value: "BUF", color: "#00338D", textColor: "#C60C30" },  // royal ⟡ red :contentReference[oaicite:3]{index=3}\n  { value: "CAR", color: "#0085CA", textColor: "#000000" },  // blue ⟡ black :contentReference[oaicite:4]{index=4}\n  { value: "CHI", color: "#0B162A", textColor: "#F63F00" },  // navy ⟡ orange :contentReference[oaicite:5]{index=5}\n  { value: "CIN", color: "#FB3F14", textColor: "#000000" },  // orange ⟡ black :contentReference[oaicite:6]{index=6}\n  { value: "CLE", color: "#DF3C20", textColor: "#101010" },  // orange ⟡ brown :contentReference[oaicite:7]{index=7}\n  { value: "DAL", color: "#003594", textColor: "#A5ACAF" },  // navy ⟡ silver :contentReference[oaicite:8]{index=8}\n  { value: "DEN", color: "#FB2F14", textColor: "#102274" },  // orange ⟡ navy :contentReference[oaicite:9]{index=9}\n  { value: "DET", color: "#0076B6", textColor: "#B0B7BC" },  // honolulu ⟡ silver :contentReference[oaicite:10]{index=10}\n  { value: "GB",  color: "#203731", textColor: "#FFB612" },  // green ⟡ gold :contentReference[oaicite:11]{index=11}\n  { value: "HOU", color: "#03202F", textColor: "#D71930" },  // deep blue ⟡ red :contentReference[oaicite:12]{index=12}\n  { value: "IND", color: "#002C5F", textColor: "#F2FAFD" },  // royal ⟡ gray :contentReference[oaicite:13]{index=13}\n  { value: "JAX", color: "#006778", textColor: "#D7A22A" },  // teal ⟡ gold :contentReference[oaicite:14]{index=14}\n  { value: "KC",  color: "#E31837", textColor: "#FFB612" },  // red ⟡ gold :contentReference[oaicite:15]{index=15}\n  { value: "LAC", color: "#0080C6", textColor: "#FFC20E" },  // powder ⟡ sunshine :contentReference[oaicite:16]{index=16}\n  { value: "LAR", color: "#003594", textColor: "#FFA300" },  // royal ⟡ sol :contentReference[oaicite:17]{index=17}\n  { value: "LV",  color: "#000000", textColor: "#A5ACAF" },  // black ⟡ silver :contentReference[oaicite:18]{index=18}\n  { value: "MIA", color: "#008E87", textColor: "#FC5C02" },  // aqua ⟡ orange :contentReference[oaicite:19]{index=19}\n  { value: "MIN", color: "#4F2683", textColor: "#FFC62F" },  // purple ⟡ gold :contentReference[oaicite:20]{index=20}\n  { value: "NE",  color: "#041E62", textColor: "#D60F51" },  // blue ⟡ red :contentReference[oaicite:21]{index=21}\n  { value: "NO",  color: "#D3BC8D", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:22]{index=22}\n  { value: "NYG", color: "#0B2265", textColor: "#DFDFDF" },  // blue ⟡ red :contentReference[oaicite:23]{index=23}\n  { value: "NYJ", color: "#125740", textColor: "#FFFFFF" },  // green ⟡ white :contentReference[oaicite:24]{index=24}\n  { value: "PHI", color: "#004C54", textColor: "#A5ACAF" },  // midnight ⟡ silver :contentReference[oaicite:25]{index=25}\n  { value: "PIT", color: "#FFB612", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:26]{index=26}\n  { value: "SEA", color: "#002244", textColor: "#69BE28" },  // navy ⟡ action-green :contentReference[oaicite:27]{index=27}\n  { value: "SF",  color: "#AA0000", textColor: "#B3995D" },  // scarlet ⟡ gold :contentReference[oaicite:28]{index=28}\n  { value: "TB",  color: "#D50A0A", textColor: "#0A0A08" },  // red ⟡ pewter :contentReference[oaicite:29]{index=29}\n  { value: "TEN", color: "#0C2340", textColor: "#4B92DB" },  // navy ⟡ titan-blue :contentReference[oaicite:30]{index=30}\n  { value: "WAS", color: "#5A1414", textColor: "#FFB612" },  // burgundy ⟡ gold :contentReference[oaicite:31]{index=31}\n  { value: "UDF", color: "#9E9E9E", textColor: "#FFFFFF" }  // neutral grey\n]',
          valueByIndex: "{{ item.value }}",
          labelByIndex: "{{ item.value }}",
          colorByIndex: "{{ item.color }}",
          textColorByIndex: "{{ item.textColor }}",
        }}
        placeholder="Select option"
        position="left"
        size={62.390625}
        summaryAggregationMode="none"
      />
      <Column
        id="a80e8"
        alignment="center"
        backgroundColor="rgba(75, 0, 255, 0.15)"
        cellTooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 12px #000000 ;\n">\n  Overall Grade<br> ⌁ <b>{{ (() => {\n    const map = {\n      "Ashton Jeanty": 95.7,\n      "Travis Hunter": 93.5,\n      "Omarion Hampton": 89.7,\n      "Tetairoa McMillan": 90.5,\n      "TreVeyon Henderson": 88.1,\n      "Quinshon Judkins": 87.5,\n      "Emeka Egbuka": 89.1,\n      "Tyler Warren": 88.9,\n      "Colston Loveland": 90.1,\n      "R.J. Harvey": 86.2,\n      "Kaleb Johnson": 85.6,\n      "Matthew Golden": 87.1,\n      "Luther Burden": 86.9,\n      "Jayden Higgins": 86.3,\n      "Tre Harris": 86.3,\n      "Jack Bech": 85.7,\n      "Cameron Skattebo": 87.3,\n      "Kyle Williams": 86.9,\n      "Mason Taylor": 74.8,\n      "Bhayshul Tuten": 79.8,\n      "Jaylin Noel": 85.6,\n      "Terrance Ferguson": 77.3,\n      "Jaydon Blue": 74.0,\n      "Elijah Arroyo": 74.1,\n      "Pat Bryant": 79.6,\n      "Dylan Sampson": 81.6,\n      "Harold Fannin Jr.": 86.5,\n      "Jalen Royals": 84.8,\n      "Devin Neal": 81.4,\n      "Trevor Etienne": 79.8,\n      "Elic Ayomanor": 78.0,\n      "Jarquez Hunter": 76.1,\n      "DJ Giddens": 80.7,\n      "Isaac TeSlaa": 74.9,\n      "Jordan James": 76.1,\n      "Ollie Gordon": 73.7,\n      "Jo\'quavious Marks": 69.9,\n      "Dont\'e Thornton": 74.5,\n      "Tory Horton": 84.1,\n      "Brashard Smith": 72.8,\n      "Oronde Gadsden II": 78.7,\n      "Savion Williams": 78.3,\n      "Tahj Brooks": 81.4,\n      "Kyle Monangai": 74.2,\n      "Tai Felton": 81.7,\n      "Chimere Dike": 76.3,\n      "Gunnar Helm": 71.3,\n      "Jaylin Lane": 77.2,\n      "Damien Martinez": 80.9,\n      "Jimmy Horn Jr.": 72.4,\n      "Jacory Croskey-Merritt": 72.1,\n      "Arian Smith": 71.2,\n      "Keandre Lambert-Smith": 79.7,\n      "Tez Johnson": 79.9,\n      "Phil Mafah": 68.0,\n      "LeQuint Allen": 66.7,\n      "Mitchell Evans": 70.5,\n      "Thomas Fidone III": 70.4,\n      "LaJohntay Wester": 74.2,\n      "Ricky White": 79.2,\n      "Moliki Matavao": 62.6,\n      "Kaden Prather": 72.9,\n      "Luke Lachey": 69.2\n    };\n    const v = map[currentSourceRow.PLAYER];\n    return v ?? item;    // Fallback to the cell value if name mismatch\n  })() }}</b> ⌁ \n</div>\n'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "60",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "79",
        }}
        groupAggregationMode="average"
        key="OVR GRADE"
        label="OVR GRD"
        optionList={{
          iconByIndex: "",
          mode: "manual",
          textColorByIndex: "",
          labelByIndex: "",
          valueByIndex: "",
          fallbackTextByIndex: "",
          hiddenByIndex: "",
          captionByIndex: "",
          colorByIndex: "",
          mappedData: "[]",
        }}
        placeholder="Enter value"
        position="center"
        size={106.34375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item >89}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(231, 255, 248, 0.03)",
              tooltip: "",
            },
            {
              showWhen: "{{item >80}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(0, 109, 242, 0.03)",
            },
            {
              showWhen: "{{item >75}}",
              label: "{{ item }}",
              icon: "",
              color: "rgba(124, 83, 204, 0.03)",
            },
            {
              showWhen: "true",
              label: "{{ item }}",
              icon: "",
              color: "rgba(68, 76, 87, 0.03)",
            },
          ],
        }}
        summaryAggregationMode="none"
      />
      <Column
        id="e0c27"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        key="truADP"
        label="ADP"
        placeholder="Enter value"
        position="center"
        size={73}
        summaryAggregationMode="none"
      />
      <Column
        id="328dc"
        alignment="center"
        backgroundColor="rgba(198, 104, 242, 0.06)"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(44, 33, 68)"
        key="Rook ADP"
        label="ADP [Rookie] "
        placeholder="Enter value"
        position="center"
        size={74.21875}
        summaryAggregationMode="none"
      />
      <Column
        id="62082"
        alignment="center"
        backgroundColor="rgba(104, 141, 243, 0.05)"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RD"
        label="RD 📶"
        placeholder="Enter value"
        position="center"
        size={54.9375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "",
              label: "",
              color: "rgba(135, 230, 179, 1)",
              icon: "bold/interface-arrows-up-alternate",
            },
            {
              showWhen: "{{ item < 7 }}",
              label: "",
              color: "#F8DBD8",
              icon: "bold/money-graph-arrow-decrease",
            },
            {
              showWhen: "{{ item > 6 }}",
              label: "",
              color: "rgba(236, 116, 154, 1)",
              icon: "bold/interface-arrows-down-alternate",
            },
            {
              showWhen: "{{ item < 5 }}",
              label: "",
              color: "#D7EAE0",
              icon: "bold/money-graph-arrow-increase",
            },
          ],
        }}
        summaryAggregationMode="none"
      />
      <Column
        id="95105"
        alignment="center"
        backgroundColor="rgba(104, 141, 243, 0.05)"
        cellTooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n   font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 12px #000000 ;\n">\nPick Drafted<br> ⌁ <b>{{item}}</b> ⌁ \n</div>\n\n'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "", color: "" }}
        groupAggregationMode="sum"
        key="PK#"
        label="PK"
        placeholder="Enter value"
        position="center"
        size={69.9375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item <33}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(196, 253, 234, 0.15)",
              tooltip: "",
            },
            {
              showWhen: "{{item < 68}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(186, 255, 255, 0.15)",
            },
            {
              showWhen: "{{item < 90}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(186, 243, 255, 0.15)",
            },
            {
              showWhen: "{{item < 130}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(229, 205, 255, 0.3)",
            },
            {
              showWhen: "{{item >190}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(251, 164, 234, 1)",
            },
            {
              showWhen: "{{item >130}}",
              label: "{{item}}",
              icon: "",
              color: "rgba(232, 177, 250, 0.5)",
              tooltip: "",
            },
            { showWhen: "{{item}}", label: "UD", icon: "" },
          ],
        }}
        summaryAggregationMode="none"
        textColor="{{ theme.danger }}"
      />
      <Column
        id="41f3f"
        alignment="center"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="NCAA"
        label="NCAA"
        placeholder="Enter value"
        position="center"
        size={61.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="53da5"
        alignment="center"
        editable="false"
        format="multilineString"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
        textColor="rgba(255, 255, 255, 1)"
      />
      <Column
        id="7a71b"
        alignment="center"
        format="string"
        formatOptions={{ automaticColors: true, notation: "standard" }}
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={46.03125}
        summaryAggregationMode="none"
      />
      <Column
        id="f718d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={47.875}
        summaryAggregationMode="none"
      />
      <Column
        id="05e56"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="40"
        label="40"
        placeholder="Enter value"
        position="center"
        size={46.515625}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow[\"40\"] == \"NA\" ? '#8F8F8F':'' }}"}
        valueOverride="{{item }}"
      />
      <Column
        id="cf84f"
        alignment="left"
        backgroundColor="rgba(0, 224, 255, 0.03)"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\nAthletic Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="average"
        key="ATHL"
        label="ATHL GRD"
        placeholder="Enter value"
        position="center"
        size={78.6875}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item > 85}}",
              label: "{{ item }}",
              icon: "bold/shopping-business-startup",
              color: "rgba(190, 254, 234, 0.17)",
            },
            {
              showWhen: "{{item < 76}}",
              label: "{{item}}",
              icon: "bold/phone-signal-low",
              color: "rgba(255, 178, 214, 0.15)",
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{item}}",
              icon: "bold/mail-send-email",
              color: "rgba(224, 245, 255, 0.2)",
            },
          ],
        }}
        summaryAggregationMode="none"
      />
      <Column
        id="4bffd"
        alignment="center"
        backgroundColor="rgba(63, 1, 255, 0.1)"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nCEILING ⌁ <b>{{item}}/5</b> \n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="rating"
        formatOptions={{ icon: "", size: "small", icons: "stars" }}
        groupAggregationMode="average"
        key="CL"
        label="CEILING"
        placeholder="Enter value"
        position="center"
        size={109}
        summaryAggregationMode="none"
      />
      <Column
        id="5b01a"
        alignment="center"
        backgroundColor="rgba(131, 0, 255, 0.1)"
        cellTooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nFLOOR ⌁ <b>{{item}}/5</b>\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="rating"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          size: "small",
          icons: "stars",
        }}
        groupAggregationMode="sum"
        key="FL"
        label="FLOOR"
        placeholder="Enter value"
        position="center"
        size={107.25}
        summaryAggregationMode="none"
      />
      <Column
        id="93ad9"
        alignment="center"
        backgroundColor="rgba(0, 224, 255, 0.03)"
        caption="• {{ item }} •"
        cellTooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nProduction Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "55",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "75",
        }}
        groupAggregationMode="average"
        key="PRD GRADE"
        label="PRD GRD"
        placeholder="Enter value"
        position="center"
        size={67.09375}
        summaryAggregationMode="none"
      />
      <Column
        id="d91e6"
        alignment="center"
        backgroundColor="rgba(0, 224, 255, 0.03)"
        caption="• {{ item }} •"
        cellTooltip={
          '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nEfficiency Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>'
        }
        cellTooltipMode="custom"
        editableOptions={{ showStepper: true }}
        format="progress"
        formatOptions={{
          min: "50",
          max: "96",
          positiveTrend: "85",
          negativeTrend: "75",
        }}
        groupAggregationMode="average"
        key="EFF GRADE"
        label="EFF GRD"
        placeholder="Enter value"
        position="center"
        size={69.671875}
        summaryAggregationMode="none"
      />
      <Column
        id="a6c5e"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        key="RR GRD"
        label="RR GRD"
        placeholder="Enter value"
        position="center"
        size={82}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{ item > 85}} ",
              label: "{{item}}",
              icon: "bold/interface-arrows-bend-up-right-1-alternate",
              color: "rgba(190, 254, 234, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item > 75}}",
              label: "{{item}}",
              icon: "bold/interface-hierarchy-7",
              color: "rgba(224, 245, 255, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{item < 75}}",
              label: "{{item}}",
              icon: "bold/money-graph-arrow-decrease",
              color: "rgba(255, 178, 214, 0.15)",
              tooltip:
                '<div style="\n  background-color: #0c132f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n">\nRoute Running Grade<br>  ⌁ <b>{{item}}</b> ⌁\n</div>',
            },
            {
              showWhen: "{{ item == 'NA' }}",
              label: "{{ item }}",
              icon: "bold/interface-block",
              color: "rgba(160, 160, 160, 0.1)",
              tooltip:
                '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #000000 ;\n">\n <b>N/A</b> ⌁ [WR/TE–ONLY Metric]\n</div>',
            },
          ],
        }}
        summaryAggregationMode="none"
      />
      <Column
        id="65b64"
        alignment="left"
        editableOptions={{ showStepper: true }}
        format="icon"
        formatOptions={{ icon: "" }}
        groupAggregationMode="sum"
        key="FILM GRADE"
        label="FILM 
GRD"
        placeholder="Enter value"
        position="center"
        size={77.609375}
        statusIndicatorOptions={{
          manualData: [
            {
              showWhen: "{{item > 85}}",
              label: "{{ item }}",
              icon: "bold/entertainment-camera-video",
              color: "rgba(190, 254, 234, 0.17)",
            },
            {
              showWhen: "{{  item > 78}}",
              label: "{{ item }}",
              icon: "bold/computer-connection-video-camera",
              color: "rgba(224, 245, 255, 0.2)",
            },
            {
              showWhen: "{{item < 79}}",
              label: "{{ item }}",
              icon: "bold/entertainment-recording-tape-1",
              color: "rgba(255, 178, 214, 0.15)",
            },
            {
              showWhen: "true",
              label: "{{item}}",
              icon: "bold/interface-page-controller-loading-half",
              color: "rgba(227, 223, 223, 0.1)",
            },
          ],
        }}
        summaryAggregationMode="none"
      />
      <Column
        id="6beae"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="G"
        label="G"
        placeholder="Enter value"
        position="center"
        size={37.6875}
        summaryAggregationMode="none"
      />
      <Column
        id="571eb"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="SOS"
        label="SOS"
        placeholder="Enter value"
        position="center"
        size={53}
        summaryAggregationMode="none"
      />
      <Column
        id="e9438"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(32, 20, 75)"
        key="YDS(t)"
        label="YDS ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={64.734375}
        summaryAggregationMode="none"
      />
      <Column
        id="37293"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(32, 20, 75)"
        key="TD(t)"
        label="TD
 ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={50.25}
        summaryAggregationMode="none"
        textColor={
          "{{ \n  currentSourceRow[\"TD(t)\"] > 7000 ? '#03f07f' :\n  currentSourceRow[\"TD(t)\"] > 6000 ? '#33f07f' :\n  currentSourceRow[\"TD(t)\"] > 5000 ? '#73f07f' :\n  currentSourceRow[\"TD(t)\"] > 4000 ? '#a3f07f' :\n  currentSourceRow[\"TD(t)\"] > 3000 ? '#f3f07f' :\n  currentSourceRow[\"TD(t)\"] > 2000 ? '#03f0ff' :\n  Number.currentSourceRow[\"TD(t)\"] > 1001 ? '#a390ff' : ''\n}}"
        }
      />
      <Column
        id="25637"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#20144b"
        key="YpG(t)"
        label="YpG 
⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={58.453125}
        summaryAggregationMode="none"
      />
      <Column
        id="00b31"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(32, 20, 75)"
        key="OPP(t)"
        label="OPP"
        placeholder="Enter value"
        position="center"
        size={58.15625}
        summaryAggregationMode="none"
      />
      <Column
        id="45011"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#20144b"
        key="IMP"
        label="IMP"
        placeholder="Enter value"
        position="center"
        size={57.484375}
        summaryAggregationMode="none"
      />
      <Column
        id="3ce33"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.04)"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#20144b"
        key="IMP/ OPP"
        label="IMP/OPP"
        placeholder="Enter value"
        position="center"
        size={83.84375}
        summaryAggregationMode="none"
      />
      <Column
        id="4c58c"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="DMTR"
        label="DMTR"
        placeholder="Enter value"
        position="center"
        size={66.890625}
        summaryAggregationMode="none"
      />
      <Column
        id="89a9d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="CAR"
        label="CAR"
        placeholder="Enter value"
        position="center"
        size={52.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="1ed57"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="ruYDS"
        label="YDS ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={58.3125}
        summaryAggregationMode="none"
      />
      <Column
        id="bb829"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="ruTD"
        label="TD  ⌈ru⌋"
        placeholder="Enter value"
        position="center"
        size={59.953125}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nRushing Touchdowns\n</div>'
        }
      />
      <Column
        id="3620d"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(21, 36, 66)"
        key="TGT"
        label="TGT"
        placeholder="Enter value"
        position="center"
        size={56}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTargets\n</div>'
        }
      />
      <Column
        id="38694"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#152442"
        key="REC"
        label="REC"
        placeholder="Enter value"
        position="center"
        size={59}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nReceptions\n</div>'
        }
      />
      <Column
        id="db7c4"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(21, 36, 66)"
        key="recYDS"
        label="YDS
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={51.140625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [Receiving]\n</div>'
        }
      />
      <Column
        id="e7cf5"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="rgb(21, 36, 66)"
        key="recTD"
        label="TD
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={50.9375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [Receiving]\n</div>'
        }
      />
      <Column
        id="23e31"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#152442"
        key="rec1D"
        label="1D
⌈rec⌋"
        placeholder="Enter value"
        position="center"
        size={67}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 13px;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nFirst Downs [Receiving]\n</div>'
        }
      />
      <Column
        id="c40d1"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#152442"
        key="YPRR"
        label="YPRR"
        placeholder="Enter value"
        position="center"
        size={68}
        summaryAggregationMode="none"
        textColor="{{
(() => {
 const v = parseFloat(String(item).replace(/[^0-9.-]/g, ''));
 if (!isFinite(v)) return null;
 const rules = [
  [2.7, '#00ffc4'],
  [2.4, '#85fff3'],
  [2.3, '#7dd1ff'],
  [2.1, '#957cff'],
  [1.9, '#a642ff'],
  [1.7, '#cf60ff'],
  [1.5, '#ff6fe1'],
 ];
 for (const [t, c] of rules) if (v >= t) return c;
 return '#ff2eb2';
})()
}}"
      />
      <Column
        id="fe787"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#152442"
        key="YPR"
        label="YPR"
        placeholder="Enter value"
        position="center"
        size={69}
        summaryAggregationMode="none"
      />
      <Column
        id="fd480"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.05)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#152442"
        key="YAC/R"
        label="YAC/REC"
        placeholder="Enter value"
        position="center"
        size={83}
        summaryAggregationMode="none"
      />
      <Event
        event="selectRow"
        method=""
        params={{}}
        pluginId=""
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Table>
  </View>
</Container>
