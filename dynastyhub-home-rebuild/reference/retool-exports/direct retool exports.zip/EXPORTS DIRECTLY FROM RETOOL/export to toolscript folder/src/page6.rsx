<Screen
  id="page6"
  _customShortcuts={[]}
  _hashParams={[]}
  _searchParams={[]}
  browserTitle=""
  title="Page 1"
  urlSlug="page6"
  uuid="bee15d23-5d61-463e-b03b-e7595d6fdeb8"
>
  <GoogleSheetsQuery
    id="query6"
    notificationDuration={4.5}
    resourceDisplayName="NFL Stats CSV"
    resourceName="c8688b0e-1e30-4681-97eb-40ab13d78a08"
    sheetName="NFLStatsCSV"
    showSuccessToaster={false}
    spreadsheetId="18W7X8_mAjXmCNceTt3m0lauiLLAUQSxRh2M99R3MS0s"
  />
  <connectResource id="query7" _componentId="table1" />
  <connectResource id="query8" _componentId="select1" />
  <Frame
    id="$main6"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    type="main"
  >
    <Text
      id="text2"
      horizontalAlign="center"
      style={{
        ordered: [
          { fontSize: "h1Font" },
          { fontWeight: "h1Font" },
          { fontFamily: "h1Font" },
          { color: "secondary" },
        ],
      }}
      value="DYNASTY HUB"
      verticalAlign="center"
    />
    <Navigation
      id="navigation8"
      appTargetByIndex=""
      captionByIndex=""
      data=""
      disabledByIndex=""
      hiddenByIndex=""
      highlightByIndex=""
      horizontalAlignment="center"
      iconByIndex=""
      iconPositionByIndex=""
      itemMode="static"
      itemTypeByIndex=""
      keyByIndex=""
      labels=""
      parentKeyByIndex=""
      retoolFileObject={{ ordered: [] }}
      screenTargetByIndex=""
      screenTargetIdByIndex=""
      style={{
        ordered: [
          { color: "#00ffaf" },
          { fontSize: "h6Font" },
          { fontWeight: "h6Font" },
          { fontFamily: "h6Font" },
          { highlightText: "#645efc" },
        ],
      }}
      tooltipByIndex=""
    >
      <Option
        id="a2fe3"
        disabled={false}
        hidden={false}
        icon="bold/interface-user-multiple"
        iconPosition="left"
        itemType="page"
        label="All"
        screenTargetId="Home"
      />
      <Option
        id="be95e"
        icon="bold/travel-map-location-target-1"
        iconPosition="left"
        itemType="page"
        key="12813ad1-3eb4-4879-9356-980a8f4cafcd"
        label="QB"
        screenTargetId="page2"
      />
      <Option
        id="7b749"
        icon="bold/travel-transportation-bus"
        iconPosition="left"
        itemType="page"
        label="RB"
        screenTargetId="page3"
      />
      <Option
        id="2fcba"
        icon="bold/interface-arrows-all-direction"
        iconPosition="left"
        itemType="page"
        key="52793"
        label="WR"
        screenTargetId="Rookies"
      />
      <Option
        id="373f4"
        disabled={false}
        hidden={false}
        icon="bold/interface-security-shield-1"
        iconPosition="left"
        itemType="page"
        label="TE"
        screenTargetId="page5"
      />
      <Option
        id="a5768"
        caption="flex"
        disabled={false}
        hidden={false}
        icon="bold/interface-page-controller-settings"
        iconPosition="left"
        itemType="page"
        label="TBL3"
        screenTargetId="page6"
      />
      <Event
        event="click"
        method="openPage"
        params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Navigation>
    <Include src="./tabbedContainer3.rsx" />
    <HTML
      id="html2"
      css={include("../lib/html2.css", "string")}
      html={include("../lib/html2.html", "string")}
    />
  </Frame>
</Screen>
