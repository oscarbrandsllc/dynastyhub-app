<Container
  id="tabbedContainer10"
  currentViewKey="{{ self.viewKeys[0] }}"
  footerPadding="0"
  headerPadding="0"
  heightType="fixed"
  loading=""
  margin="9px 9px 9px 35px"
  overflowType="hidden"
  padding="0px 0px 0px 0px"
  showBody={true}
  showFooter={true}
  showFooterBorder={false}
  showHeader={true}
  showHeaderBorder={false}
  style={{
    background: "tertiary",
    headerBackground: "#191f38",
    footerBackground: "canvas",
  }}
  styleContext={{ map: { primary: "primary" } }}
  transition="slide"
>
  <Header>
    <Icon
      id="icon2"
      disabled=""
      horizontalAlign="center"
      icon="bold/shopping-business-startup"
      margin="6px 0px 6px 0px"
      style={{ background: "tertiary", color: "highlight" }}
      styleVariant="background"
    >
      <Event
        event="click"
        method="openPage"
        params={{
          options: { passDataWith: "urlParams", newTab: true },
          pageName: "DataHub",
        }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Icon>
    <Text
      id="containerTitle132"
      heightType="fixed"
      horizontalAlign="center"
      margin="0"
      style={{
        background: "#191f38",
        fontSize: "10px",
        fontWeight: "300",
        fontFamily: "Michroma",
      }}
      value={
        '<span style=\n"font-size: 1.2em;\n  font-weight:400;\ncolor: #efefef;"> 2025｜Top Rookie Prospects</span> \n[Prospect Grades & Percentiles]'
      }
      verticalAlign="center"
    />
    <Button
      id="button18"
      margin="5px 2px 5px 10px"
      style={{
        fontWeight: "600",
        hoverBackground: "rgba(0, 255, 221, 1)",
        boxShadow: "highElevation",
        border: "highlight",
        background: "canvas",
        fontSize: "15px",
        fontFamily: "Quicksand",
        label: "highlight",
        borderRadius: "6px",
      }}
      text="KEY"
    >
      <Event
        event="click"
        method="show"
        params={{}}
        pluginId="modalFrame4"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Tabs
      id="tabs11"
      alignment="justify"
      heightType="fixed"
      itemMode="static"
      navigateContainer={true}
      style={{
        selectedBackground: "#5700ff",
        pillBorderRadius: "100px",
        fontSize: "11px",
        fontWeight: "300",
        fontFamily: "Quicksand",
        hoverText: "rgb(144, 117, 255)",
      }}
      targetContainerId="tabbedContainer10"
      value="{{ self.values[0] }}"
    >
      <Option id="501f8" value="Tab 1" />
      <Option id="c0dc6" value="Tab 2" />
      <Option id="08e21" value="Tab 3" />
    </Tabs>
  </Header>
  <View id="aaa75" iconPosition="left" label="Jeanty" viewKey="View 1">
    <Table
      id="table42"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1.2cqh; color: #6affd0;\\">21.3</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.89cqh; font-weight: 400;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1.2cqh; color: #65aeff;\\">5\'8\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1.2cqh; color: #6affd0;\\">211</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.89cqh;\\">lbs</span>",\n    "NFL": "<span style=\\"font-family: \'Orbitron\', sans-serif; font-size: 1.25cqh; font-weight: 600; color: #efefef;\\">LV</span>",\n    "FILM GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 1cqh; color: #efefef;\\">FILM |</span> <span style=\\"font-family:   \'bruno ace\', sans-serif; font-size: 1.2cqh; font-weight: 400; color: #6affd0;\\">98%</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 1.1cqh; font-weight: 800; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'orbitron\', sans-serif; font-size: 1.4cqh; font-weight: 600; color: #6affd0;\\">96</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0px 0px 1.5px 0px"
      overflowActionsOverlayMinWidth="600"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "300",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "canvas",
        fontSize: "12px",
        fontFamily: "ORBITRON",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        cellTooltip={
          ' "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.88em; \n      font-weight: 600; \n      color: #0E0E0E;\\"\n      >RB</span>"'
        }
        editable="false"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={47.46875}
        summaryAggregationMode="none"
      />
      <Column
        id="d56db"
        alignment="center"
        backgroundColor="rgba(0, 0, 0, 0.37)"
        cellTooltipMode="overflow"
        editableOptions={{ allowCustomValue: false }}
        format="markdown"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="NFL"
        label="NFL"
        optionList={{
          manualData: [
            {
              value:
                ' "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.88em; \n      font-weight: 600; \n      color: #efefef;\\"\n      >LV</span>"',
              label: "LV",
              color: "#0e0e0e",
              textColor: "#a5acaf",
              icon: "",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="center"
        size={38.8125}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={47.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={34.328125}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={41.734375}
        summaryAggregationMode="none"
      />
      <Column
        id="736b5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={75.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={67.265625}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart60"
      chartType="plotlyJson"
      margin="6px 12px 9px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [100,100,100,100,100,100,100,100],\n    "theta": [347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2c334f62",\n    "line": { "color": "#525a7739", "width": 1 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80,80,80,80,80,80,80,80],\n    "theta": [347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2D345153",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [60,60,60,60,60,60,60,60],\n    "theta": [347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2F365250",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [40,40,40,40,40,40,40,40],\n    "theta": [347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#30375455",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [20,20,20,20,20,20,20,20],\n    "theta": [347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#31385565",\n    "line": { "color": "#525a7735", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [94,93,98,87,98,87,98,94],\n    "theta": [347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode": "lines+markers",\n    "name": "ASHTON JEANTY",\n    "line": { "color": "#6700ff", "width": 2 },\n    "marker": {\n      "color": ["#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#00000000"],\n      "size": [5,5,5,5,5,5,5,5]\n    },\n    "fill": "toself",\n    "fillcolor": "#5300FF55",\n    "hoverinfo": "skip"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [84,83,88,77,88,77,88],\n    "theta": [347.14,38.57,90,141.43,192.86,244.29,295.71],\n    "mode": "text",\n    "text": [\n      "<span style=\\"color:#00ffaf;\\">94th%</span>",\n      "<span style=\\"color:#00ffaf;\\">93rd%</span>",\n      "<span style=\\"color:#00ffaf;\\">98th%</span>",\n      "<span style=\\"color:#bcd2ff;\\">87th%</span>",\n      "<span style=\\"color:#00ffaf;\\">98th%</span>",\n      "<span style=\\"color:#bcd2ff;\\">87th%</span>",\n      "<span style=\\"color:#00ffaf;\\">98th%</span>"\n    ],\n    "textposition": "middle center",\n    "textfont": { "size": 9, "family": "Bruno Ace" },\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0,100],\n      "showgrid": false,\n      "ticks": "",\n      "showticklabels": false,\n      "showline": false,\n      "linewidth": 0,\n      "linecolor": "rgba(0,0,0,0)"\n    },\n    "angularaxis": {\n      "showgrid": false,\n      "showline": false,\n      "tickmode": "array",\n      "tickvals": [347.14,38.57,90,141.43,192.86,244.29,295.71],\n      "ticktext": ["YPC","DMTR","ELU","YDS/OPP","IMP","recYDS","YACO/A"],\n      "tickfont": { "color": "white", "size": 10.5, "family": "Orbitron" },\n      "direction": "counterclockwise",\n      "rotation": -0.55,\n      "layer": "above traces"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "showlegend": false,\n  "annotations": [\n    {\n      "xref": "paper",\n      "yref": "paper",\n      "x": 0.5,\n      "y": 1.15,\n      "text": "ASHTON JEANTY",\n      "showarrow": false,\n      "font": { "color": "#6300ff", "size": 21, "family": "orbitron" },\n      "xanchor": "center",\n      "yanchor": "bottom"\n    }\n  ],\n  "margin": { "l": 45, "r": 45, "t": 70, "b": 30 },\n\n  /* block all interactivity */\n  "hovermode": false,\n  "dragmode": false\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container131"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="6px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle136"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic156"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".951"
        />
      </View>
    </Container>
    <Container
      id="container129"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle134"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic154"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.943"
        />
      </View>
    </Container>
    <Container
      id="container128"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle133"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic153"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.981"
        />
      </View>
    </Container>
    <Container
      id="container130"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle135"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic155"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "rgba(107, 176, 255, 1)",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.893"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart61"
      chartType="plotlyJson"
      margin="0px 11px 8.7px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "ATH"],\n    "y": [95, 94, 98, 89],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)",\n\n    /*— make trace non-interactive —*/\n    "hoverinfo": "skip"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "ATH"],\n    "ticktext": ["PRD", "EFF", "ELU", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    },\n    /*— lock axis so users can’t pan/zoom —*/\n    "fixedrange": true\n  },\n\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false,\n    /*— lock axis so users can’t pan/zoom —*/\n    "fixedrange": true\n  },\n\n  "margin": { "l": 2, "r": 2, "t": 1, "b": 15 },\n  "autosize": true,\n\n  /*— disable all global hover behaviour —*/\n  "hovermode": false\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="64854"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="T.Hunter"
    viewKey="View 5"
  >
    <Table
      id="table50"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS":\n      "WR",\n    "AGE": \n      "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: .95em; color: #6affd0;\\"\n      >21.9</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\"\n      >y.o.</span>",\n    "HT": \n      "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.95em; color: #6affd0;\\"\n      >6\'0\\\\\\"</b>",\n    "WT": \n      "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\"\n      >188</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\"\n      >lbs</span>",\n    "NFL": \n      "<span style=\\"font-family: \'Orbitron\', sans-serif; font-size: 1.1em; font-weight: 600; color: #C19F5B;\\"\n      >JAX</span>",\n    "FILM GRADE": \n      "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.78em; color: #efefef;\\"\n      >FILM |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.95em; font-weight: 700; color: #6affd0;\\"\n      >93%</span>",\n    "OVR GRADE": \n      "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.88em; font-weight: 600; color: #efefef;\\"\n      >OVR |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 1.2em; font-weight: 900; color: #6affd0;\\"\n      >94</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0px 0px 1.5px 0px"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "300",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "canvas",
        fontSize: "12px",
        fontFamily: "ORBITRON",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: '{{"/icon:bold/travel-transportation-bus"}}',
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
            { value: "WR", icon: "", label: "WR", caption: "" },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={50}
        summaryAggregationMode="none"
      />
      <Column
        id="68a0f"
        alignment="center"
        backgroundColor="rgba(0, 102, 120, 0.36)"
        cellTooltipMode="overflow"
        format="markdown"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="NFL"
        label="Nfl"
        optionList={{
          manualData: [
            {
              value:
                '"<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.88em; \n      font-weight: 600; \n      color: #efefef;\\"\n      >JAX</span>"',
              label: "JAX",
              color: "#006778",
              textColor: "rgba(193, 159, 91, 1)",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={48.0625}
        summaryAggregationMode="none"
        textColor="#c19f5b"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={62.6875}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={43.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={59.078125}
        summaryAggregationMode="none"
      />
      <Column
        id="39b7a"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={79.078125}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={87.375}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart66"
      chartType="plotlyJson"
      margin="6px 12px 9px 13px
"
      plotlyDataJson={
        '[\n  {\n    "type":"scatterpolar",\n    "r":[100,100,100,100,100,100,100,100],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines",\n    "fill":"toself",\n    "opacity":1,\n    "fillcolor":"#2c334f62",\n    "line":{"color":"#525a7739","width":1},\n    "hoverinfo":"skip",\n    "showlegend":false\n  },\n  {\n    "type":"scatterpolar",\n    "r":[80,80,80,80,80,80,80,80],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines",\n    "fill":"toself",\n    "opacity":1,\n    "fillcolor":"#2D345153",\n    "line":{"color":"#525a7729","width":0.9},\n    "hoverinfo":"skip",\n    "showlegend":false\n  },\n  {\n    "type":"scatterpolar",\n    "r":[60,60,60,60,60,60,60,60],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines",\n    "fill":"toself",\n    "opacity":1,\n    "fillcolor":"#2F365250",\n    "line":{"color":"#525a7729","width":0.9},\n    "hoverinfo":"skip",\n    "showlegend":false\n  },\n  {\n    "type":"scatterpolar",\n    "r":[40,40,40,40,40,40,40,40],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines",\n    "fill":"toself",\n    "opacity":1,\n    "fillcolor":"#30375415",\n    "line":{"color":"#525a7729","width":0.9},\n    "hoverinfo":"skip",\n    "showlegend":false\n  },\n  {\n    "type":"scatterpolar",\n    "r":[20,20,20,20,20,20,20,20],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines",\n    "fill":"toself",\n    "opacity":1,\n    "fillcolor":"#31385540",\n    "line":{"color":"#525a7730","width":0.9},\n    "hoverinfo":"skip",\n    "showlegend":false\n  },\n\n  {\n    "type":"scatterpolar",\n    "r":[69,84,77,78,72,84,99,69],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines+markers",\n    "name":"TRAVIS HUNTER",\n    "line":{"color":"#6700ff","width":2},\n    "marker":{\n      "color":["#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#00000000"],\n      "size":[5,5,5,5,5,5,5,5]\n    },\n    "fill":"toself",\n    "fillcolor":"#5300FF55",\n    "hoverinfo":"skip"\n  },\n\n  {\n    "type":"scatterpolar",\n    "r":[59,74,62,68,67,74,89],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n    "mode":"text",\n    "text":[\n      "<span style=\\"color:#ef91ff;\\">69th%</span>",\n      "<span style=\\"color:#bcd2ff;\\">84th%</span>",\n      "<span style=\\"color:#b991ff;\\">77th%</span>",\n      "<span style=\\"color:#b991ff;\\">78th%</span>",\n      "<span style=\\"color:#b991ff;\\">72nd%</span>",\n      "<span style=\\"color:#bcd2ff;\\">84th%</span>",\n      "<span style=\\"color:#00ffaf;\\">99th%</span>"\n    ],\n    "textposition":"middle center",\n    "textfont":{"size":9,"family":"Bruno Ace"},\n    "hoverinfo":"skip",\n    "showlegend":false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar":{\n    "bgcolor":"#141a32",\n    "radialaxis":{\n      "range":[0,100],\n      "showgrid":false,\n      "ticks":"",\n      "showticklabels":false,\n      "showline":false,\n      "linewidth":0,\n      "linecolor":"rgba(0,0,0,0)"\n    },\n    "angularaxis":{\n      "showgrid":false,\n      "showline":false,\n      "tickmode":"array",\n      "tickvals":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n      "ticktext":["TGT","YPRR","DMTR","1DRR","YDS","IMP/OPP","TgtQR"],\n      "tickfont":{"color":"white","size":10.5,"family":"Bruno Ace"},\n      "direction":"counterclockwise",\n      "rotation":-0.55,\n      "layer":"above traces"\n    }\n  },\n  "paper_bgcolor":"#141a32",\n  "showlegend":false,\n  "annotations":[\n    {\n      "xref":"paper","yref":"paper","x":0.5,"y":1.15,\n      "text":"TRAVIS HUNTER","showarrow":false,\n      "font":{"color":"#6300ff","size":21,"family":"orbitron"},\n      "xanchor":"center","yanchor":"bottom"\n    }\n  ],\n  "margin":{"l":48,"r":47,"t":70,"b":30},\n\n  /* block all interactivity */\n  "hovermode": false,\n  "dragmode": false\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container140"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="6px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle145"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic165"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#65aeff",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".887"
        />
      </View>
    </Container>
    <Container
      id="container141"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle146"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic166"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.963"
        />
      </View>
    </Container>
    <Container
      id="container142"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle147"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic167"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/computer-connection-usb-port"
          label=""
          labelCaption="ROUTE RUNNING GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.931"
        />
      </View>
    </Container>
    <Container
      id="container143"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle148"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic168"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.961"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart67"
      chartType="plotlyJson"
      margin="0px 11px 8.7px 0px
"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "RRG", "ATH"],\n    "y": [89, 96, 93, 96],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)",\n\n    /* disable hover */\n    "hoverinfo": "skip"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "RRG", "ATH"],\n    "ticktext": ["PRD", "EFF", "RRG", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    },\n    /* lock panning/zooming */\n    "fixedrange": true\n  },\n\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false,\n    /* lock panning/zooming */\n    "fixedrange": true\n  },\n\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true,\n\n  /* disable all hover & drag interactivity */\n  "hovermode": false,\n  "dragmode": false\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="97d42"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Loveland"
    viewKey="View 6"
  >
    <Table
      id="table55"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS":\n      "TE",\n    \n      "NFL": \n      "<b style=\\"font-family: \n      \'orbitron\', \n      sans-serif; \n      font-size: 1.1em; \n      color: #f04607;\\"\n      >CHI</b>",\n    \n    "AGE": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >21.0</b><span style=\\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.7em;\\"\n      >y.o.</span>",\n    \n    "HT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >6\'6\\\\\\"</b>",\n    \n    "WT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >248</b><span style=\n    \\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.6em;\\"\n      >lbs</span>",\n    \n    "FILM GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.78em; \n      color: #efefef;\\"\n      >FILM |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.95em; \n      font-weight: 700; \n      color: #6affd0;\\"\n      >90%</span>",\n    \n    "OVR GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.85em; \n      font-weight: 600; \n      color: #efefef;\\"\n      >OVR |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 1.15em; \n      font-weight: 700; \n      color: #6affd0;\\"\n      >90</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0px 0px 1.5px 0px"
      overflowActionsOverlayMinWidth="600"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "300",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "12px",
        fontFamily: "ORBITRON",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
            {
              value: "TE",
              label: "TE",
              color: "{{ theme.highlight }}",
              textColor: "rgba(255, 255, 255, 1)",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={44.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="99608"
        alignment="center"
        backgroundColor="rgba(13, 22, 52, 1)"
        cellTooltipMode="overflow"
        format="markdown"
        groupAggregationMode="none"
        key="NFL"
        label="Nfl"
        placeholder="Enter value"
        position="center"
        size={40.921875}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={64.765625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={44.46875}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={62.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="736b5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.734375}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.25}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart70"
      chartType="plotlyJson"
      margin="6px 12px 9px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [100, 100, 100, 100, 100, 100, 100, 100],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2c334f62",\n    "line": { "color": "#525a7739", "width": 1 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 80, 80, 80, 80, 80, 80, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2D345153",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [60, 60, 60, 60, 60, 60, 60, 60],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2F365250",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [40, 40, 40, 40, 40, 40, 40, 40],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#30375415",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [20, 20, 20, 20, 20, 20, 20, 20],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#31385540",\n    "line": { "color": "#525a7730", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [56, 63, 70, 48, 90, 98, 95, 56],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "fill": "toself",\n    "name": "TYLER WARREN",\n    "mode": "lines+markers",\n    "line": { "color": "#6700ff", "width": 2 },\n    "marker": {\n      "color": ["#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#00000000"],\n      "size": [5,5,5,5,5,5,5,5]\n    },\n    "fillcolor": "#5300FF55",\n    "hoverinfo": "none",\n    "hovertemplate": ""\n  },\n  {\n    "type": "scatterpolar",\n    "r": [46, 53, 60, 38, 80, 88, 85],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n    "mode": "text",\n    "text": [\n      "<span style=\\"color: #ef91ff;\\">56th%</span>",\n      "<span style=\\"color: #ef91ff;\\">63rd%</span>",\n      "<span style=\\"color: #b991ff;\\">7Oth%</span>",\n      "<span style=\\"color: #ef91ff;\\">48th%</span>",\n      "<span style=\\"color: #00ffaf;\\">9Oth%</span>",\n      "<span style=\\"color: #00ffaf;\\">98th%</span>",\n      "<span style=\\"color: #00ffaf;\\">95th%</span>"\n    ],\n    "textposition": "middle center",\n    "textfont": { "size": 9, "weight": 400, "family": "Bruno Ace" },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  }\n]'
      }
      plotlyLayoutJson={
        '{\n  "polar":{\n    "bgcolor":"#141a32",\n    "radialaxis":{"range":[0,100],"showgrid":false,"ticks":"",\n      \n      "showticklabels":false,\n      "showline":false},\n    "angularaxis":{\n      "showgrid":false,"showline":false,"tickmode":"array",\n      "tickvals":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n      "ticktext":["TGT","YPRR","DMTR","1DRR","YDS","IMP/OPP","TgtQR"],\n      "tickfont":{"color":"white","size":10.5,"family":"Bruno Ace"},\n      "direction":"counterclockwise","rotation":-0.55,"layer":"above traces"}\n  },\n  "paper_bgcolor":"#141a32",\n  "showlegend":false,\n  "annotations":[{\n      "xref":"paper","yref":"paper","x":0.5,"y":1.15,\n      "text":"COLSTON LOVELAND",\n      "showarrow":false,\n      "font":{"color":"#6300ff","size":21,"weight":400,"family":"orbitron"},\n      "xanchor":"center","yanchor":"bottom"}],\n  "margin":{"l":48,"r":47,"t":70,"b":30}\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container148"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="6px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle153"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic173"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6d50f9",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".711"
        />
      </View>
    </Container>
    <Container
      id="container149"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle154"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic174"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "rgba(109, 80, 249, 1)",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.712"
        />
      </View>
    </Container>
    <Container
      id="container150"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle155"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic175"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/computer-connection-usb-port"
          label=""
          labelCaption="ROUTE RUNNING GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.911"
        />
      </View>
    </Container>
    <Container
      id="container151"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle156"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic176"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "success",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.910"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart71"
      chartType="plotlyJson"
      margin="0px 11px 8.7px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "RRG", "ATH"],\n    "y": [74, 74, 91, 91],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "RRG", "ATH"],\n    "ticktext": ["PRD", "EFF", "RRG", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View id="eff2c" viewKey="Hampton">
    <Table
      id="table52"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS":\n      "RB",\n    \n      "NFL": \n      "<b style=\\"font-family: \n      \'orbitron\', \n      sans-serif; \n      font-size: 1.1em; \n      color: #FFC20E;\\"\n      >LAC</b>",\n    \n    "AGE": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >22.0</b><span style=\\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.7em;\\"\n      >y.o.</span>",\n    \n    "HT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >6\'0\\\\\\"</b>",\n    \n    "WT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >221</b><span style=\n      \\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.6em;\\"\n      >lbs</span>",\n    \n    "FILM GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.78em; \n      color: #efefef;\\"\n      >FILM |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.95em; \n      font-weight: 700; \n      color: #65aeff;\\"\n      >86%</span>",\n    \n    "OVR GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.85em; \n      font-weight: 600; \n      color: #efefef;\\"\n      >OVR |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 1.15em; \n      font-weight: 700; \n      color: #6affd0;\\"\n      >90</span>%"\n  }\n]\n'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0px 0px 1.5px 0px"
      overflowActionsOverlayMinWidth="600"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "300",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "12px",
        fontFamily: "ORBITRON",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable={false}
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={46.078125}
        summaryAggregationMode="none"
      />
      <Column
        id="4a2ca"
        alignment="center"
        backgroundColor="rgba(0, 129, 199, 0.37)"
        cellTooltipMode="overflow"
        format="markdown"
        groupAggregationMode="none"
        key="NFL"
        label="Nfl"
        placeholder="Enter value"
        position="center"
        size={48.171875}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={68.671875}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={45.09375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={57.921875}
        summaryAggregationMode="none"
      />
      <Column
        id="736b5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.25}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart64"
      chartType="plotlyJson"
      margin="6px 12px 9px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [100, 100, 100, 100, 100, 100, 100, 100],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2c334f62",\n    "line": { "color": "#525a7739", "width": 1 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 80, 80, 80, 80, 80, 80, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2D345153",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [60, 60, 60, 60, 60, 60, 60, 60],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2F365250",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [40, 40, 40, 40, 40, 40, 40, 40],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#30375415",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [20, 20, 20, 20, 20, 20, 20, 20],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#31385520",\n    "line": { "color": "#525a7730", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [57, 69, 72, 87, 74, 57, 65, 57],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "fill": "toself",\n    "name": "OMARION HAMPTON",\n    "mode": "lines+markers",\n    "line": { "color": "#6700ff", "width": 2 },\n    "marker": {\n      "color": ["#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#00000000"],\n      "size": [5,5,5,5,5,5,5,5]\n    },\n    "fillcolor": "#5300FF50",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [47, 59, 72, 87, 74, 57, 65],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n    "mode": "text",\n    "text": [\n      "<span style=\\"color:#ef91ff;\\">57th%</span>",\n      "<span style=\\"color:#ef91ff;\\">69th%</span>",\n      "<span style=\\"color:#b991ff;\\">72nd%</span>",\n      "<span style=\\"color:#bcd2ff;\\">87th%</span>",\n      "<span style=\\"color:#b991ff;\\">74th%</span>",\n      "<span style=\\"color:#ef91ff;\\">57th%</span>",\n      "<span style=\\"color:#ef91ff;\\">65th%</span>"\n    ],\n    "textposition": "middle center",\n    "textfont": { "size": 9.3, "weight": 400, "family": "Bruno Ace" },\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "showgrid": false,\n      "ticks": "",\n      "showticklabels": false,\n      "showline": false,\n      "linewidth": 0,\n      "linecolor": "rgba(0,0,0,0)"\n    },\n    "angularaxis": {\n      "showgrid": false,\n      "showline": false,\n      "tickmode": "array",\n      "tickvals": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n      "ticktext": ["YPC","DMTR","ELU","YACO/A","IMP","recYDS","YDS/OPP"],\n      "tickfont": { "color": "white", "size": 10.5, "family": "Bruno Ace" },\n      "direction": "counterclockwise",\n      "rotation": -0.75,\n      "layer": "above traces"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "showlegend": false,\n  "annotations": [\n    {\n      "xref": "paper",\n      "yref": "paper",\n      "x": 0.5,\n      "y": 1.15,\n      "text": "OMARION HAMPTON",\n      "showarrow": false,\n      "font": { "color": "#6300ff", "size": 21, "weight": 400, "family": "orbitron" },\n      "xanchor": "center",\n      "yanchor": "bottom"\n    }\n  ],\n  "margin": { "l": 48, "r": 47, "t": 70, "b": 30 }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container136"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="6px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle141"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic161"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6bb0ff",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".862"
        />
      </View>
    </Container>
    <Container
      id="container137"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle142"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic162"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6bb0ff",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.828"
        />
      </View>
    </Container>
    <Container
      id="container138"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle143"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic163"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6bb0ff",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.864"
        />
      </View>
    </Container>
    <Container
      id="container139"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle144"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic164"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6bb0ff",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.89"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart65"
      chartType="plotlyJson"
      margin="0px 11px 8.7px 0px
"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "ATH"],\n    "y": [86, 83, 86, 89],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "ATH"],\n    "ticktext": ["PRD", "EFF", "ELU", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View id="64058" label="McMillan" viewKey="View 2">
    <Table
      id="table43"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS":\n      "WR",\n    \n      "NFL": \n      "<b style=\\"font-family: \n      \'orbitron\', \n      sans-serif; \n      font-size: 1.1em; \n      color: #0085CA;\\"\n      >CAR</b>",\n    \n    "AGE": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >22.0</b><span style=\\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.7em;\\"\n      >y.o.</span>",\n    \n    "HT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >6\'4\\\\\\"</b>",\n    \n    "WT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >219</b><span style=\n      \\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.6em;\\"\n      >lbs</span>",\n    \n    "FILM GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.78em; \n      color: #efefef;\\"\n      >FILM |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.95em; \n      font-weight: 700; \n      color: #65aeff;\\"\n      >88%</span>",\n    \n    "OVR GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.85em; \n      font-weight: 600; \n      color: #efefef;\\"\n      >OVR |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 1.15em; \n      font-weight: 700; \n      color: #6affd0;\\"\n      >91</span>%"\n  }\n]\n'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0px 0px 1.5px 0px"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "300",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "12px",
        fontFamily: "ORBITRON",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: '{{"/icon:bold/travel-transportation-bus"}}',
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
            { value: "WR", icon: "", label: "WR" },
          ],
        }}
        placeholder="Select option"
        position="left"
        size={50}
        summaryAggregationMode="none"
      />
      <Column
        id="e57a7"
        alignment="center"
        backgroundColor="rgba(0, 0, 0, 0.35)"
        cellTooltipMode="overflow"
        format="markdown"
        groupAggregationMode="none"
        key="NFL"
        label="Nfl"
        placeholder="Enter value"
        position="center"
        size={48.78125}
        summaryAggregationMode="none"
        textColor="#0085ca"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={68.671875}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={43.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={58.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="9cf1e"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.4375}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={78.125}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart62"
      chartType="plotlyJson"
      margin="6px 12px 9px 13px"
      plotlyDataJson={
        '[\n  { "type":"scatterpolar","r":[100,100,100,100,100,100,100,100],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2c334f62",\n    "line":{"color":"#525a7739","width":1},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false },\n  { "type":"scatterpolar","r":[80,80,80,80,80,80,80,80],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2D345153",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false },\n  { "type":"scatterpolar","r":[60,60,60,60,60,60,60,60],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2F365250",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false },\n  { "type":"scatterpolar","r":[40,40,40,40,40,40,40,40],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#30375415",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false },\n  { "type":"scatterpolar","r":[20,20,20,20,20,20,20,20],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#31385540",\n    "line":{"color":"#525a7730","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false },\n\n  { "type":"scatterpolar",\n    "r":[95,81,91,77,98,71,65,95],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "fill":"toself","name":"TETAIR​OA MCMILLAN",\n    "mode":"lines+markers","line":{"color":"#6700ff","width":2},\n    "marker":{"color":["#6300ff","#6300ff","#6300ff","#6300ff",\n                       "#6300ff","#6300ff","#6300ff","#00000000"],\n              "size":[5,5,5,5,5,5,5,5]},\n    "fillcolor":"#5300FF55","hoverinfo":"none","hovertemplate":"" },\n\n  { "type":"scatterpolar",\n    "r":[88,79,85,70,90,69,64],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n    "mode":"text",\n    "text":[\n      "<span style=\\"color:#00ffaf;\\">98th%</span>",\n      "<span style=\\"color:#bcd2ff;\\">81st%</span>",\n      "<span style=\\"color:#00ffaf;\\">93rd%</span>",\n      "<span style=\\"color:#b991ff;\\">77th%</span>",\n      "<span style=\\"color:#00ffaf;\\">99th%</span>",\n      "<span style=\\"color:#b991ff;\\">71st%</span>",\n      "<span style=\\"color:#ef91ff;\\">65th%</span>"\n    ],\n    "textposition":"middle center",\n    "textfont":{"size":9,"weight":400,"family":"Bruno Ace"},\n    "hoverinfo":"none","hovertemplate":"","showlegend":false }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar":{\n    "bgcolor":"#141a32",\n    "radialaxis":{"range":[0,100],"showgrid":false,"ticks":"",\n      "showticklabels":false,"showline":false,"linewidth":0,\n      "linecolor":"rgba(0,0,0,0)"},\n    "angularaxis":{\n      "showgrid":false,"showline":false,"tickmode":"array",\n      "tickvals":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n      "ticktext":["TGT","YPRR","DMTR","1DRR","YDS","IMP/OPP","TgtQR"],\n      "tickfont":{"color":"white", "size": 10.5, "family": "Bruno Ace" },\n      "direction":"counterclockwise","rotation":-0.55,"layer":"above traces"}\n  },\n  "paper_bgcolor":"#141a32",\n  "showlegend":false,\n  "annotations":[{\n      "xref":"paper","yref":"paper","x":0.5,"y":1.15,\n      "text":"TETAIROA  MCMILLAN","showarrow":false,\n      "font":{"color":"#6300ff","size":21,"weight":400,"family":"orbitron"},\n      "xanchor":"center","yanchor":"bottom"}],\n  "margin":{"l":48,"r":47,"t":70,"b":30}\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container132"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="6px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle137"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic157"
          align="center"
          decimalPlaces=""
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".977"
        />
      </View>
    </Container>
    <Container
      id="container133"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle138"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic158"
          align="center"
          decimalPlaces=""
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#5789ff",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.898"
        />
      </View>
    </Container>
    <Container
      id="container134"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle139"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic159"
          align="center"
          decimalPlaces=""
          formattingStyle="percent"
          icon="bold/computer-connection-usb-port"
          label=""
          labelCaption="ROUTE RUNNING GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "rgba(87, 137, 255, 1)",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.89"
        />
      </View>
    </Container>
    <Container
      id="container135"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle140"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic160"
          align="center"
          decimalPlaces=""
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.87"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart63"
      chartType="plotlyJson"
      margin="0px 11px 8.7px 0px
"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "RRG", "ATH"],\n    "y": [97, 90, 89, 87],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "RRG", "ATH"],\n    "ticktext": ["PRD", "EFF", "RRG", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="fb87f"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Warren"
    viewKey="View 9"
  >
    <Table
      id="table65"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS":\n      "TE",\n    "AGE": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >22.9</b><span style=\\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.7em;\\"\n      >y.o.</span>",\n    "HT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >6\'6\\\\\\"</b>",\n    "WT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >256</b><span style=\\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.6em;\\"\n      >lbs</span>",\n    "NFL": "<b style=\\"font-family: \n      \'orbitron\', \n      sans-serif; \n      font-size: 1.1em; \n      color: #FFFFFF;\\"\n      >IND</span>",\n    "FILM GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.78em; \n      color: #efefef;\\"\n      >FILM |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.95em; \n      font-weight: 700; \n      color: #6affd0;\\"\n      >90%</span>",\n    "OVR GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.85em; \n      font-weight: 600; \n      color: #efefef;\\"\n      >OVR |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 1.15em; \n      font-weight: 700; \n      color: #65aeff;\\"\n      >89</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0px 0px 1.5px 0px"
      overflowActionsOverlayMinWidth="600"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "300",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "12px",
        fontFamily: "ORBITRON",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
            {
              value: "TE",
              label: "TE",
              color: "{{ theme.highlight }}",
              textColor: "{{ theme.surfacePrimary }}",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={44.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="096d5"
        alignment="center"
        backgroundColor="rgba(0, 72, 255, 0.32)"
        cellTooltipMode="overflow"
        format="markdown"
        groupAggregationMode="none"
        key="NFL"
        label="Nfl"
        placeholder="Enter value"
        position="center"
        size={40.828125}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={68.046875}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={44.46875}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={62.53125}
        summaryAggregationMode="none"
      />
      <Column
        id="736b5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.734375}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={85.375}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart94"
      chartType="plotlyJson"
      margin="6px 12px 9px 13px
"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [100, 100, 100, 100, 100, 100, 100, 100],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2c334f62",\n    "line": { "color": "#525a7739", "width": 1 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 80, 80, 80, 80, 80, 80, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2D345153",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [60, 60, 60, 60, 60, 60, 60, 60],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2F365250",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [40, 40, 40, 40, 40, 40, 40, 40],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#30375415",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [20, 20, 20, 20, 20, 20, 20, 20],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#31385540",\n    "line": { "color": "#525a7730", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [56, 63, 70, 48, 90, 98, 95, 56],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "fill": "toself",\n    "name": "TYLER WARREN",\n    "mode": "lines+markers",\n    "line": { "color": "#6700ff", "width": 2 },\n    "marker": {\n      "color": ["#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#00000000"],\n      "size": [5,5,5,5,5,5,5,5]\n    },\n    "fillcolor": "#5300FF55",\n    "hoverinfo": "none",\n    "hovertemplate": ""\n  },\n  {\n    "type": "scatterpolar",\n    "r": [46, 53, 60, 38, 80, 88, 85],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n    "mode": "text",\n    "text": [\n      "<span style=\\"color: #ef91ff;\\">56th%</span>",\n      "<span style=\\"color: #ef91ff;\\">63rd%</span>",\n      "<span style=\\"color: #b991ff;\\">7Oth%</span>",\n      "<span style=\\"color: #ef91ff;\\">48th%</span>",\n      "<span style=\\"color: #00ffaf;\\">9Oth%</span>",\n      "<span style=\\"color: #00ffaf;\\">98th%</span>",\n      "<span style=\\"color: #00ffaf;\\">95th%</span>"\n    ],\n    "textposition": "middle center",\n    "textfont": { "size": 9, "weight": 400, "family": "Bruno Ace" },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  }\n]'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0,100],\n      "showgrid": false,\n      "ticks": "",\n      "showticklabels": false,\n      "showline": false,\n      "linewidth": 0,\n      "linecolor": "rgba(0,0,0,0)"\n    },\n    "angularaxis": {\n      "showgrid": false,\n      "showline": false,\n      "tickmode": "array",\n      "tickvals": [347.14,38.57,90,141.43,192.86,244.29,295.71],\n      "ticktext": ["TGT","YPRR","DMTR","1DRR","YDS","IMP/OPP","TgtQR"],\n      "tickfont": { "color": "white", "size": 10.5, "family": "Bruno Ace" },\n      "direction": "counterclockwise",\n      "rotation": -0.55,\n      "layer": "above traces"\n    }\n  },\n\n  "paper_bgcolor": "#141a32",\n  "showlegend": false,\n\n  "annotations": [\n    {\n      "xref": "paper", "yref": "paper",\n      "x": 0.5, "y": 1.15,\n      "text": "TYLER WARREN",\n      "showarrow": false,\n      "font": { "color": "#6300ff", "size": 21, "family": "orbitron" },\n      "xanchor": "center", "yanchor": "bottom"\n    }\n  ],\n\n  "margin": { "l": 48, "r": 47, "t": 70, "b": 30 },\n\n  /* — global interactivity blockers — */\n  "hovermode": false,\n  "dragmode": false\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container198"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="6px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle424"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic427"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "info",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".878"
        />
      </View>
    </Container>
    <Container
      id="container199"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle425"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic428"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "info",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.888"
        />
      </View>
    </Container>
    <Container
      id="container200"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle426"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic429"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/computer-connection-usb-port"
          label=""
          labelCaption="ROUTE RUNNING GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.867"
        />
      </View>
    </Container>
    <Container
      id="container201"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle427"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic430"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.933"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart95"
      chartType="plotlyJson"
      margin="0px 11px 8.7px 0px
"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "RRG", "ATH"],\n    "y": [88, 89, 86, 93],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)",\n\n    /*— key to hiding hover —*/\n    "hoverinfo": "skip"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "RRG", "ATH"],\n    "ticktext": ["PRD", "EFF", "RRG", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    },\n    /*— lock zoom/pan —*/\n    "fixedrange": true\n  },\n\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false,\n    /*— lock zoom/pan —*/\n    "fixedrange": true\n  },\n\n  "margin": { "l": 2, "r": 2, "t": 1, "b": 15 },\n  "autosize": true,\n\n  /*— turn off global hover behaviour —*/\n  "hovermode": false\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="a8b36"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Henderson"
    viewKey="View 7"
  >
    <Table
      id="table54"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS":\n      "RB",\n    \n      "NFL": \n      "<b style=\\"font-family: \n      \'orbitron\', \n      sans-serif; \n      font-size: 1.1em; \n      color: #C60C30;\\"\n      >NE</b>",\n    \n    "AGE": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >22.4</b><span style=\\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.7em;\\"\n      >y.o.</span>",\n    \n    "HT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #65aeff;\\"\n      >5\'10\\\\\\"</b>",\n    \n    "WT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #65aeff;\\"\n      >202</b><span style=\n      \\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.6em;\\"\n      >lbs</span>",\n    \n    "FILM GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.78em; \n      color: #efefef;\\"\n      >FILM |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.95em; \n      font-weight: 700; \n      color: #65aeff;\\"\n      >84%</span>",\n    \n    "OVR GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.85em; \n      font-weight: 600; \n      color: #efefef;\\"\n      >OVR |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 1.15em; \n      font-weight: 700; \n      color: #65aeff;\\"\n      >88</span>%"\n  }\n]\n'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0px 0px 1.5px 0px"
      overflowActionsOverlayMinWidth="600"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "300",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "12px",
        fontFamily: "ORBITRON",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable={false}
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={46.078125}
        summaryAggregationMode="none"
      />
      <Column
        id="ff17d"
        alignment="center"
        backgroundColor="rgba(0, 34, 69, 0.5)"
        format="markdown"
        groupAggregationMode="none"
        key="NFL"
        label="Nfl"
        placeholder="Enter value"
        position="center"
        size={37.09375}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={67.5625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={50.375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={63.046875}
        summaryAggregationMode="none"
      />
      <Column
        id="736b5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.28125}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={85.890625}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart72"
      chartType="plotlyJson"
      margin="6px 12px 9px 13px
"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [100, 100, 100, 100, 100, 100, 100, 100],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2c334f62",\n    "line": { "color": "#525a7739", "width": 1 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 80, 80, 80, 80, 80, 80, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2D345153",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [60, 60, 60, 60, 60, 60, 60, 60],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2F365250",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [40, 40, 40, 40, 40, 40, 40, 40],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#30375455",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [20, 20, 20, 20, 20, 20, 20, 20],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#31385565",\n    "line": { "color": "#525a7735", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [91, 52, 54, 80, 74, 83, 91, 91],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "fill": "toself",\n    "name": "TREVEYON HENDERSON",\n    "mode": "lines+markers",\n    "line": { "color": "#6700ff", "width": 2 },\n    "marker": {\n      "color": ["#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#00000000"],\n      "size": [5,5,5,5,5,5,5,5]\n    },\n    "fillcolor": "#5300FF55",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [91, 52, 54, 80, 74, 83, 91],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n    "mode": "text",\n    "text": [\n      "<span style=\\"color:#00ffaf;\\">91st%</span>",\n      "<span style=\\"color:#ef91ff;\\">52nd%</span>",\n      "<span style=\\"color:#ef91ff;\\">76th%</span>",\n      "<span style=\\"color:#b991ff;\\">80th%</span>",\n      "<span style=\\"color:#b991ff;\\">74th%</span>",\n      "<span style=\\"color:#00ffaf;\\">83rd%</span>",\n      "<span style=\\"color:#00ffaf;\\">91st%</span>"\n    ],\n    "textposition": "middle center",\n    "textfont": { "size": 9, "weight": 400, "family": "Bruno Ace" },\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "showgrid": false,\n      "ticks": "",\n      "showticklabels": false,\n      "showline": false,\n      "linewidth": 0,\n      "linecolor": "rgba(0,0,0,0)"\n    },\n    "angularaxis": {\n      "showgrid": false,\n      "showline": false,\n      "tickmode": "array",\n      "tickvals": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n      "ticktext": ["YPC","DMTR","ELU","YACO/A","IMP","recYDS","YDS/OPP"],\n      "tickfont": { "color": "white", "size": 10.5, "family": "Bruno Ace" },\n      "direction": "counterclockwise",\n      "rotation": -0.65,\n      "layer": "above traces"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "showlegend": false,\n  "annotations": [\n    {\n      "xref": "paper",\n      "yref": "paper",\n      "x": 0.5,\n      "y": 1.15,\n      "text": "TREVEYON HENDERSON",\n      "showarrow": false,\n      "font": { "color": "#6300ff", "size": 20, "weight": 400, "family": "orbitron" },\n      "xanchor": "center",\n      "yanchor": "bottom"\n    }\n  ],\n  "margin": { "l": 48, "r": 47, "t": 70, "b": 30 }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container152"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="6px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle157"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic177"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#65aeff",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".896"
        />
      </View>
    </Container>
    <Container
      id="container153"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle158"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic178"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#65aeff",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.883"
        />
      </View>
    </Container>
    <Container
      id="container154"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle159"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic179"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#b991ff",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.762"
        />
      </View>
    </Container>
    <Container
      id="container155"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle160"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic180"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.940"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart73"
      chartType="plotlyJson"
      margin="0px 11px 8.7px 0px
"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "ATH"],\n    "y": [90, 88, 76, 94],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "ATH"],\n    "ticktext": ["PRD", "EFF", "ELU", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="1e07e"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Egbuka"
    viewKey="View 8"
  >
    <Table
      id="table51"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS":\n      "WR",\n    \n      "NFL": \n      "<b style=\\"font-family: \n      \'orbitron\', \n      sans-serif; \n      font-size: 1.1em; \n      color: #34302B;\\"\n      >TB</b>",\n    \n    "AGE": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >22.5</b><span style=\\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.7em;\\"\n      >y.o.</span>",\n    \n    "HT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >6\'1\\\\\\"</b>",\n    \n    "WT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >202</b><span style=\n      \\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.6em;\\"\n      >lbs</span>",\n    \n    "FILM GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.78em; \n      color: #efefef;\\"\n      >FILM |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.95em; \n      font-weight: 700; \n      color: #65aeff;\\"\n      >86%</span>",\n    \n    "OVR GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.85em; \n      font-weight: 600; \n      color: #efefef;\\"\n      >OVR |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 1.15em; \n      font-weight: 700; \n      color: #65aeff;\\"\n      >89</span>%"\n  }\n]\n'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0px 0px 1.5px 0px"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "300",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "12px",
        fontFamily: "ORBITRON",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
            { value: "WR", icon: "", label: "WR" },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={50}
        summaryAggregationMode="none"
      />
      <Column
        id="225b5"
        alignment="center"
        backgroundColor="rgba(201, 61, 85, 0.53)"
        format="markdown"
        groupAggregationMode="none"
        key="NFL"
        label="Nfl"
        placeholder="Enter value"
        position="center"
        size={37.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={67.578125}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={39.96875}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={63.046875}
        summaryAggregationMode="none"
      />
      <Column
        id="227b1"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={85.375}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart74"
      chartType="plotlyJson"
      margin="6px 12px 9px 13px
"
      plotlyDataJson={
        '[\n  { "type":"scatterpolar","r":[100,100,100,100,100,100,100,100],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2c334f62",\n    "line":{"color":"#525a7739","width":1},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n  { "type":"scatterpolar","r":[80,80,80,80,80,80,80,80],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2D345153",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n  { "type":"scatterpolar","r":[60,60,60,60,60,60,60,60],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2F365250",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n  { "type":"scatterpolar","r":[40,40,40,40,40,40,40,40],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#30375415",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n  { "type":"scatterpolar","r":[20,20,20,20,20,20,20,20],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#31385540",\n    "line":{"color":"#525a7730","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n\n  { "type":"scatterpolar",\n    "r":[89,89,92,93,53,80,92,89],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "fill":"toself","name":"EMEKA EGBUKA","mode":"lines+markers",\n    "line":{"color":"#6700ff","width":2},\n    "marker":{"color":["#6300ff","#6300ff","#6300ff","#6300ff",\n                       "#6300ff","#6300ff","#6300ff","#00000000"],\n              "size":[5,5,5,5,5,5,5,5]},\n    "fillcolor":"#5300FF55","hoverinfo":"none","hovertemplate":""},\n\n  { "type":"scatterpolar",\n    "r":[79,79,82,83,43,70,82],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n    "mode":"text",\n    "text":[\n      "<span style=\\"color:#bcd2ff;\\">89th%</span>",\n      "<span style=\\"color:#bcd2ff;\\">89th%</span>",\n      "<span style=\\"color:#00ffaf;\\">92nd%</span>",\n      "<span style=\\"color:#00ffaf;\\">93rd%</span>",\n      "<span style=\\"color:#ef91ff;\\">53rd%</span>",\n      "<span style=\\"color:#bcd2ff;\\">80th%</span>",\n      "<span style=\\"color:#00ffaf;\\">92nd%</span>"\n    ],\n    "textposition":"middle center",\n    "textfont":{"size":9,"weight":400,"family":"Bruno Ace"},\n    "hoverinfo":"none","hovertemplate":"","showlegend":false}\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar":{\n    "bgcolor":"#141a32",\n    "radialaxis":{"range":[0,100],"showgrid":false,"ticks":"",\n      "showticklabels":false,"showline":false,"linewidth":0,\n      "linecolor":"rgba(0,0,0,0)"},\n    "angularaxis":{\n      "showgrid":false,"showline":false,"tickmode":"array",\n      "tickvals":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n      "ticktext":["TGT","YPRR","DMTR","1DRR","YDS","IMP/OPP","TgtQR"],\n      "tickfont":{"color":"white","size":10.5,"family":"Bruno Ace"},\n      "direction":"counterclockwise","rotation":-0.55,"layer":"above traces"}\n  },\n  "paper_bgcolor":"#141a32",\n  "showlegend":false,\n  "annotations":[{\n      "xref":"paper","yref":"paper","x":0.5,"y":1.15,\n      "text":"EMEKA EGBUKA",\n      "showarrow":false,\n      "font":{"color":"#6300ff","size":21,"weight":400,"family":"orbitron"},\n      "xanchor":"center","yanchor":"bottom"}],\n  "margin":{"l":48,"r":47,"t":70,"b":30}\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container156"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="6px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle161"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic181"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".957"
        />
      </View>
    </Container>
    <Container
      id="container157"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle162"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic182"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.935"
        />
      </View>
    </Container>
    <Container
      id="container158"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle163"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic183"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/computer-connection-usb-port"
          label=""
          labelCaption="ROUTE RUNNING GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.911"
        />
      </View>
    </Container>
    <Container
      id="container159"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle164"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic184"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#65aeff",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.87"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart75"
      chartType="plotlyJson"
      margin="0px 11px 8.7px 0px
"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "RRG", "ATH"],\n    "y": [96, 94, 91, 87],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "RRG", "ATH"],\n    "ticktext": ["PRD", "EFF", "RRG", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="0ac25"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Skattebo"
    viewKey="View 4"
  >
    <Table
      id="table53"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS":\n      "RB",\n    \n      "NFL": \n      "<b style=\\"font-family: \n      \'orbitron\', \n      sans-serif; \n      font-size: 1.05em; \n      color: #FFFFFF;\\"\n      >NYG</b>",\n    \n    "AGE": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >22.0</b><span style=\\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.7em;\\"\n      >y.o.</span>",\n    \n    "HT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #65aeff;\\"\n      >5\'10\\\\\\"</b>",\n    \n    "WT": \n      "<b style=\\"font-family: \n      \'Syncopate\', \n      sans-serif; \n      font-size: 1em; \n      color: #6affd0;\\"\n      >219</b><span style=\n      \\"\n      font-family: \'Syncopate\', \n      sans-serif; \n      font-size: 0.6em;\\"\n      >lbs</span>",\n    \n    "FILM GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.78em; \n      color: #efefef;\\"\n      >FILM |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.95em; \n      font-weight: 700; \n      color: #65aeff;\\"\n      >85%</span>",\n    \n    "OVR GRADE": \n      "<span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 0.85em; \n      font-weight: 600; \n      color: #efefef;\\"\n      >OVR |</span> <span style=\\"font-family: \n      \'bruno ace\', \n      sans-serif; \n      font-size: 1.15em; \n      font-weight: 700; \n      color: #65aeff;\\"\n      >88</span>%"\n  }\n]\n'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0px 0px 1.5px 0px"
      overflowActionsOverlayMinWidth="600"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "300",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "12px",
        fontFamily: "ORBITRON",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable={false}
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={46.078125}
        summaryAggregationMode="none"
      />
      <Column
        id="a2bdf"
        alignment="center"
        backgroundColor="rgba(6, 52, 205, 0.43)"
        format="markdown"
        groupAggregationMode="none"
        key="NFL"
        label="Nfl"
        placeholder="Enter value"
        position="center"
        size={47.109375}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={68.671875}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={50.375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={58.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="736b5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={79.46875}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={85.890625}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart68"
      chartType="plotlyJson"
      margin="6px 12px 9px 13px
"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [100, 100, 100, 100, 100, 100, 100, 100],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2c334f62",\n    "line": { "color": "#525a7739", "width": 1 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 80, 80, 80, 80, 80, 80, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2D345153",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [60, 60, 60, 60, 60, 60, 60, 60],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2F365250",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [40, 40, 40, 40, 40, 40, 40, 40],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#30375455",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [20, 20, 20, 20, 20, 20, 20, 20],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#31385565",\n    "line": { "color": "#525a7735", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 99, 91, 69, 69, 94, 98, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "fill": "toself",\n    "name": "CAM SKATTEBO",\n    "mode": "lines+markers",\n    "line": { "color": "#6700ff", "width": 2 },\n    "marker": {\n      "color": ["#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#00000000"],\n      "size": [5,5,5,5,5,5,5,5]\n    },\n    "fillcolor": "#5300FF55",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [70, 89, 81, 59, 59, 84, 88],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n    "mode": "text",\n    "text": [\n      "<span style=\\"color:#bcd2ff;\\">80th%</span>",\n      "<span style=\\"color:#00ffaf;\\">99th%</span>",\n      "<span style=\\"color:#00ffaf;\\">91st%</span>",\n      "<span style=\\"color:#ef91ff;\\">69th%</span>",\n      "<span style=\\"color:#ef91ff;\\">69th%</span>",\n      "<span style=\\"color:#00ffaf;\\">94th%</span>",\n      "<span style=\\"color:#00ffaf;\\">98th%</span>"\n    ],\n    "textposition": "middle center",\n    "textfont": { "size": 9.3, "weight": 400, "family": "Bruno Ace" },\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "showgrid": false,\n      "ticks": "",\n      "showticklabels": false,\n      "showline": false,\n      "linewidth": 0,\n      "linecolor": "rgba(0,0,0,0)"\n    },\n    "angularaxis": {\n      "showgrid": false,\n      "showline": false,\n      "tickmode": "array",\n      "tickvals": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n      "ticktext": ["YPC","DMTR","ELU","YACO/A","IMP","recYDS","YDS/OPP"],\n      "tickfont": { "color": "white", "size": 10.5, "family": "Bruno Ace" },\n      "direction": "counterclockwise",\n      "rotation": -0.55,\n      "layer": "above traces"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "showlegend": false,\n  "annotations": [\n    {\n      "xref": "paper",\n      "yref": "paper",\n      "x": 0.5,\n      "y": 1.15,\n      "text": "CAM SKATTEBO",\n      "showarrow": false,\n      "font": { "color": "#6300ff", "size": 21, "weight": 400, "family": "orbitron" },\n      "xanchor": "center",\n      "yanchor": "bottom"\n    }\n  ],\n  "margin": { "l": 45, "r": 45, "t": 70, "b": 30 }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container144"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="6px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle149"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic169"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".949"
        />
      </View>
    </Container>
    <Container
      id="container145"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle150"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic170"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#65aeff",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.869"
        />
      </View>
    </Container>
    <Container
      id="container146"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle151"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic171"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.927"
        />
      </View>
    </Container>
    <Container
      id="container147"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle152"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic172"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#b991ff",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.770"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart69"
      chartType="plotlyJson"
      margin="0px 11px 8.7px 0px
"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "ATH"],\n    "y": [95, 87, 93, 77],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "ATH"],\n    "ticktext": ["PRD", "EFF", "ELU", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <Footer>
    <Button
      id="prevButton4"
      disabled=""
      iconBefore="bold/interface-arrows-left-alternate"
      margin="5px 15px 5px 15px"
      style={{
        border: "highlight",
        label: "#7300ff",
        fontSize: "13px",
        fontWeight: "600",
        fontFamily: "Quicksand",
        borderRadius: "5px",
      }}
      styleVariant="outline"
      text="Previous"
    >
      <Event
        event="click"
        method="showPreviousVisibleView"
        params={{ map: { wrap: false } }}
        pluginId="tabbedContainer10"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="nextButton4"
      disabled=""
      iconAfter="bold/interface-arrows-right-alternate"
      margin="5px 15px 5px 25px"
      style={{ background: "highlight", borderRadius: "5px" }}
      text="Next"
    >
      <Event
        event="click"
        method="showNextVisibleView"
        params={{ map: { wrap: false } }}
        pluginId="tabbedContainer10"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</Container>
