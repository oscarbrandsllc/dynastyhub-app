<Container
  id="container7"
  footerPadding="4px 12px"
  headerPadding="0"
  heightType="fixed"
  margin="9px 36px 9px 9px"
  overflowType="hidden"
  padding="10px 16px 10px 16px"
  showBody={true}
  showHeader={true}
  showHeaderBorder={false}
  style={{ background: "tertiary", headerBackground: "#191f38" }}
>
  <Header>
    <Text
      id="containerTitle428"
      heightType="fixed"
      horizontalAlign="center"
      margin="8px 22px"
      style={{
        fontSize: "10px",
        fontWeight: "300",
        fontFamily: "ORBITRON",
        background: "rgba(32, 39, 66, 0.77)",
      }}
      value={
        '<span style="background: linear-gradient(to right, #5700ff, #c332ff);\n    -webkit-background-clip: text;\n    background-clip: text;\n    font-size: 1.55cqh;\n    font-weight: 400;\n    color: transparent;\n  "> dh research </span> '
      }
      verticalAlign="center"
    />
    <Text
      id="containerTitle7"
      heightType="fixed"
      horizontalAlign="center"
      margin="0"
      style={{
        background: "#191f38",
        fontSize: "12px",
        fontWeight: "300",
        fontFamily: "Quicksand",
      }}
      value={
        '<span style=\n"font-size: 1.2em;\ncolor: #efefef;"> Career Length Analytics</span> \n<b>[SYOP]</b> Significant Years of Production vs. <b>[B/O]</b> Breakout'
      }
      verticalAlign="center"
    />
    <Button
      id="button14"
      margin="5px 14px 5px 35px"
      style={{
        fontWeight: "600",
        hoverBackground: "rgba(0, 255, 221, 1)",
        boxShadow: "highElevation",
        border: "highlight",
        background: "canvas",
        fontSize: "10px",
        fontFamily: "Quicksand",
        label: "highlight",
        borderRadius: "6px",
      }}
      text="KEY"
    >
      <Event
        event="click"
        method="show"
        params={{}}
        pluginId="modalFrame5"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <View id="9269c" viewKey="View 1">
    <Chart
      id="sunburstChart2"
      chartType="sunburst"
      colorArray={'["#6911ee","#7b0Fff","#8421ff","#8d2fff"]\t\t\t\t\t\t\t'}
      colorArrayDropDown={[
        "#FDDEA0",
        "#8C2A81",
        "#A5DB36",
        "#36B779",
        "#1E988B",
        "#31688E",
        "#462F7D",
      ]}
      gradientColorArray={[
        ["0.0", "{{ theme.canvas }}"],
        ["1.0", "{{ theme.primary }}"],
      ]}
      hoverTemplate="%{label}<extra></extra> "
      hoverTemplateMode="source"
      labelData={
        '["Mean | 𝛬 <br>&<br> Mode | ϻ",\n  "QB ",\n  "RB ",\n  "WR ",\n  "TE ",\n  "SP𝛬  <br>(7.2)",\n  "BO𝛬  <br>(2.3)",\n  "SPϻ <br>(6)",\n  "BOϻ <br>(1)",\n  "SP𝛬  <br>(3.41)",\n  "BO𝛬  <br>(2.2)",\n  "SPϻ <br>(0.7)",\n  "BOϻ <br>(1.7)",\n  "SP𝛬  <br>(4.9)",\n  "BO𝛬  <br>(2.9)",\n  "SPϻ <br>(3)",\n  "BOϻ <br>(2)",\n  "SP𝛬  <br>(4.0)",\n  "BO𝛬  <br>(3.5)",\n  "SPϻ <br>(2)",\n  "BOϻ <br>(3)"]'
      }
      legendPosition="none"
      lineWidth="5"
      margin="0px 0px 2px 0px"
      parentData={
        '[\n  "",\n  "Mean | 𝛬 <br>&<br> Mode | ϻ",\n  "Mean | 𝛬 <br>&<br> Mode | ϻ",\n  "Mean | 𝛬 <br>&<br> Mode | ϻ",\n  "Mean | 𝛬 <br>&<br> Mode | ϻ",\n  "QB ",\n  "QB ",\n  "QB ",\n  "QB ",\n  "RB ",\n  "RB ",\n  "RB ",\n  "RB ",\n  "WR ",\n  "WR ",\n  "WR ",\n  "WR ",\n  "TE ",\n  "TE ",\n  "TE ",\n  "TE "\n]'
      }
      selectedPoints="[]"
      style={{
        fontWeight: "500",
        axisFontWeight: "700",
        titleFontSize: "10px",
        legendTextColor: "#ffffffff",
        titleFontFamily: "Quicksand",
        fontSize: "14px",
        axisFontSize: "24px",
        fontFamily: "Quicksand",
        axisFontFamily: "Quicksand",
        componentBackgroundColor: "canvas",
        chartTextColor: "surfacePrimary",
        titleFontWeight: "500",
      }}
      sunburstDataLeafOpacity=".3"
      textTemplate="%{label}"
      textTemplateMode="source"
      textTemplatePosition="horizontal"
      title={
        '  AVG [<b>Mean</b> | "<b>𝛬</b>"]・<b>＆</b>・Majority [<b>Mode</b> | "ϻ"]'
      }
      valueData="[51.6, 16.46, 9.8, 12.82, 12.5, 6.5, 2.49, 5.35, 2.1, 3.31, 2.5, 1.89, 2.1, 4.92, 2.84, 3, 2, 4.01, 3.49, 2, 3]"
    />
    <IFrame
      id="iFrame23"
      allowFullscreen={true}
      allowPopups={true}
      margin="0px 0px 2px 10px"
      src="https://flo.uri.sh/visualisation/21911378/embed"
      style={{
        ordered: [
          { borderColor: "rgba(20, 26, 50, 0)" },
          { background: "#141a32" },
        ],
      }}
      title="{{ self.src }}"
      tooltipText={
        '<div style="\n  background-color: #212843;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 1px;\n  margin: -7px;\n  font-weight: 300;\n  font-size: 0.9em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #6300ff ;\n"> ⌁ Interactive | Filter out POS\'s to refine and hover for % of POS by SYOP ⌁ </div> '
      }
    />
    <IFrame
      id="iFrame24"
      allowFullscreen={true}
      allowPopups={true}
      margin="10px 0px 8px 0px"
      src="https://flo.uri.sh/visualisation/21979945/embed"
      style={{
        ordered: [
          { borderColor: "rgba(20, 26, 50, 0)" },
          { background: "#141a32" },
        ],
      }}
      title="{{ self.src }}"
    />
  </View>
</Container>
