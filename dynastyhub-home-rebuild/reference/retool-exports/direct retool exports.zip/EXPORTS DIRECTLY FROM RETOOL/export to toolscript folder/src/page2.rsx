<Screen
  id="page2"
  _customShortcuts={[]}
  _hashParams={[]}
  _searchParams={[]}
  browserTitle=""
  title={null}
  urlSlug=""
  uuid="79826da9-88ac-49da-ad34-5519d3123280"
>
  <GoogleSheetsQuery
    id="query5"
    resourceDisplayName="NFL Stats CSV"
    resourceName="c8688b0e-1e30-4681-97eb-40ab13d78a08"
    sheetName="NFLStatsCSV"
    spreadsheetId="18W7X8_mAjXmCNceTt3m0lauiLLAUQSxRh2M99R3MS0s"
  />
  <Include src="./drawerFrame1.rsx" />
  <Include src="./modalFrame1.rsx" />
  <Frame
    id="$main2"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    style={{}}
    type="main"
  >
    <Container
      id="container205"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      heightType="fixed"
      margin="0"
      overflowType="hidden"
      padding="0"
      showBody={true}
      style={{ background: "primary", borderRadius: "0px" }}
    >
      <View id="10a74" viewKey="View 1">
        <Container
          id="group3"
          _align="center"
          _gap="0px"
          _justify="center"
          _type="stack"
          footerPadding="4px 12px"
          headerPadding="4px 12px"
          heightType="fixed"
          margin="7px 30px 6px 33px"
          padding="0"
          showBody={true}
          showBorder={false}
          style={{ map: { background: "tertiary" } }}
        >
          <View id="00030" viewKey="View 1">
            <Image
              id="image8"
              fit="contain"
              heightType="fixed"
              horizontalAlign="right"
              margin="2px 8px"
              retoolStorageFileId="44bf0765-e78a-43ea-bc38-ebcff7d64298"
              src="https://picsum.photos/id/1025/800/600"
              srcType="retoolStorageFileId"
            />
            <Text
              id="text21"
              heightType="fixed"
              imageWidth="fill"
              margin="0"
              style={{
                fontSize: "41px",
                fontWeight: "400",
                fontFamily: "ORBITRON",
              }}
              value={
                '  <span style="font-size: 1.5cqw; background: linear-gradient(to right, #5700ff, #6e00f6, #8d28ff, #c332ff);\n    -webkit-background-clip: text;\n    background-clip: text;\n    color: transparent;\n  ">rankings hub</span> '
              }
              verticalAlign="center"
            />
          </View>
        </Container>
        <Navigation
          id="navigation23"
          data="{{ retoolContext.pages }}"
          highlightByIndex="{{ retoolContext.currentPage === item.id }}"
          horizontalAlignment="justify"
          itemMode="static"
          labels="{{ item.title || item.id }}"
          margin="4px 15px 4px 5px"
          retoolFileObject={{ ordered: [] }}
          showInEditor={true}
          style={{
            highlightText: "#7476ff",
            fontSize: "16px",
            fontWeight: "700",
            fontFamily: "Quicksand",
            background: "#212843",
            highlightBackground: "#2c334f",
            hoverText: "secondary",
          }}
        >
          <Option
            id="1de3f"
            caption="Home"
            icon="bold/interface-home-3"
            iconPosition="left"
            itemType="page"
            screenTargetId="Home"
          />
          <Option
            id="60b8d"
            caption="Data Hub"
            icon="bold/interface-arrows-diagonal"
            iconPosition="left"
            itemType="page"
          />
          <Option
            id="d4f21"
            caption="Charts"
            icon="bold/money-graph-arrow-increase"
            iconPosition="left"
            itemType="page"
            screenTargetId="Charts"
          />
          <Option
            id="b6a91"
            caption="Rankings"
            disabled={false}
            hidden={false}
            highlight={false}
            icon="bold/interface-award-crown"
            iconPosition="replace"
            itemType="page"
            screenTargetId="page2"
          />
          <Event
            event="click"
            method="show"
            params={{}}
            pluginId="modalFrame2"
            targetId="718b5"
            type="widget"
            waitMs="0"
            waitType="debounce"
          />
          <Event
            event="click"
            method="show"
            params={{ ordered: [] }}
            pluginId="modalFrame2"
            targetId="1d317"
            type="widget"
            waitMs="0"
            waitType="debounce"
          />
          <Event
            event="click"
            method="openPage"
            params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
            pluginId=""
            type="util"
            waitMs="0"
            waitType="debounce"
          />
        </Navigation>
        <Navigation
          id="navigation22"
          data="{{ retoolContext.pages }}"
          highlightByIndex="{{ retoolContext.currentPage === item.id }}"
          horizontalAlignment="justify"
          itemMode="static"
          labels="{{ item.title || item.id }}"
          margin="4px 5px 4px 15px"
          retoolFileObject={{ ordered: [] }}
          showInEditor={true}
          style={{
            highlightText: "#7476ff",
            fontSize: "16px",
            fontWeight: "700",
            fontFamily: "Quicksand",
            background: "tertiary",
            highlightBackground: "#2c334f",
            hoverText: "secondary",
          }}
        >
          <Option
            id="c2822"
            caption="Research"
            disabled={false}
            hidden={false}
            icon="bold/ecology-science-erlenmeyer-flask"
            iconPosition="left"
            itemType="page"
            screenTargetId="page3"
          />
          <Option
            id="c05bb"
            caption="Rookies"
            disabled={false}
            hidden={false}
            highlight={false}
            icon="bold/shopping-business-startup"
            iconPosition="right"
            itemType="page"
            screenTargetId="Rookies"
          />
          <Option
            id="a8f67"
            caption="Subscribe"
            disabled={false}
            hidden={false}
            highlight={false}
            icon="bold/shopping-jewelry-diamond-2"
            iconPosition="left"
            itemType="page"
            screenTargetId="page5"
          />
          <Option
            id="1d317"
            caption="— KEY"
            disabled={false}
            hidden={false}
            highlight={false}
            icon="bold/interface-login-key"
            iconPosition="left"
            itemType="custom"
          >
            <Event
              event="click"
              method="show"
              params={{ ordered: [] }}
              pluginId="modalFrame2"
              type="widget"
              waitMs="0"
              waitType="debounce"
            />
          </Option>
          <Event
            event="click"
            method="show"
            params={{}}
            pluginId="modalFrame2"
            targetId="718b5"
            type="widget"
            waitMs="0"
            waitType="debounce"
          />
          <Event
            event="click"
            method="openPage"
            params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
            pluginId=""
            type="util"
            waitMs="0"
            waitType="debounce"
          />
        </Navigation>
      </View>
    </Container>
    <Include src="./tabbedContainer14.rsx" />
  </Frame>
</Screen>
