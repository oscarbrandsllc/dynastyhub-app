<ModalFrame
  id="modalFrame4"
  footerPadding="8px 12px"
  headerPadding="10px 5px 1px 0px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  margin="0"
  overlayInteraction={true}
  padding="8px 12px"
  showHeader={true}
  showHeaderBorder={false}
  showOverlay={true}
  size="medium"
  style={{ map: { background: "tertiary" } }}
>
  <Header>
    <Icon
      id="icon1"
      horizontalAlign="center"
      icon="bold/interface-alert-information-circle-alternate"
      margin="11px 8px"
      style={{}}
      tooltipText="kghfhjgg"
    />
    <Text
      id="modalTitle4"
      heightType="fixed"
      horizontalAlign="center"
      style={{
        background: "#141a32",
        fontSize: "10px",
        fontWeight: "400",
        fontFamily: "Bruno Ace",
      }}
      value={
        '<span style=\n"font-size: 1.35em;\n">PROSPECT GRADES AND PERCENTILES ｜ KEY </span> '
      }
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton4"
      ariaLabel="Close"
      horizontalAlign="center"
      iconBefore="bold/interface-delete-square-alternate"
      style={{
        fontSize: "28px",
        fontWeight: "600",
        fontFamily: "Quicksand",
        icon: "secondary",
        border: "rgba(255, 255, 255, 0)",
        hoverBackground: "danger",
      }}
      styleVariant="outline"
    >
      <Event
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="modalFrame4"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <Table
      id="table68"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:400;color:#6746ff;\\">GRADES</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.9em;font-weight:300;color:#ffffff;\\"><b>Grades</b> ⟡ Calculated using a combination of performance metrics, film review, and data analysis. These evaluations are relative to the evaluated category and are balanced by the quality of competition faced.</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:400;color:#6746ff;\\">PRD  GRADE</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.9em;font-weight:300;color:#ffffff;\\"><b>Production Grade</b> ✧ Carefully calculated, utilizing cumulative percentiles for metrics such as YDS, TDs, 1D, etc., quantifying prospect’s overall collegiate production.</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:400;color:#6746ff;\\">EFF GRADE</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.9em;font-weight:300;color:#ffffff;\\"><b>Efficiency Grade</b> ✧ A percentile-based composite grade blending efficiency stats such as, Yards per Attempt, Touchdowns per Attempt, YPRR, etc., spotlighting prospect effectiveness with each opportunity.</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:400;color:#6746ff;\\">ELU  GRADE</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.9em;font-weight:300;color:#ffffff;\\"><b>Elusiveness Grade</b> ✧ Percentile composite that blends Missed Tackles Forced/ Attempt, Yards After Contact/ Attempt, and other elusiveness factors to quantify a player’s ability to evade tacklers and gain extra yardage.</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:400;color:#6746ff;\\">FILM  GRADE</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.9em;font-weight:300;color:#ffffff;\\"><b>Film Grade</b> ✧ Aggregates detailed scouting grades from full-career tape study, scoring every facet of the player’s positional responsibilities.</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:400;color:#6746ff;\\">ATH  GRADE</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.9em;font-weight:300;color:#ffffff;\\"><b>Athleticism Grade</b> ✧ Composite athletic score using height, weight, RAS (if available), combine / pro-day metrics, and top MPH reached in player’s NCAA career.</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:400;color:#6746ff;\\">RR  GRADE</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.9em;font-weight:300;color:#ffffff;\\"><b>Route-Running / Separation Grade</b> ✧ Combines separation metrics and film analysis (e.g., win rates vs man &amp; zone, separation YDS at pass release) to rate a prospect’s ability to get open at every depth, against all coverages, and balanced against opponent quality.</span>"\n  }\n]\n'
      }
      defaultSelectedRow={{
        mode: "none",
        indexType: "display",
        index: 0,
        key: "",
      }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="2px 8px 1px 15px"
      primaryKeyColumnId="0b85e"
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      showInEditor={true}
      style={{
        headerFontFamily: "Michroma",
        fontWeight: "400",
        rowSeparator: "rgba(48, 55, 84, 1)",
        border: "rgba(47, 55, 86, 1)",
        hoverRowBackground: "rgba(102, 0, 255, 0.08)",
        alternateRowBackground: "rgba(22, 27, 48, 1)",
        background: "rgba(17, 23, 44, 1)",
        fontSize: "8px",
        fontFamily: "ORBITRON",
        headerFontWeight: "400",
        headerText: "rgba(135, 79, 255, 1)",
        headerBackground: "rgba(35, 41, 60, 1)",
        headerFontSize: "11px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="0b85e"
        alignment="center"
        editable="false"
        format="markdown"
        groupAggregationMode="none"
        key="Abbreviation"
        label="ABBRV"
        placeholder="Enter value"
        position="center"
        referenceId="abbrv"
        size={95.28125}
        summaryAggregationMode="none"
        valueOverride="{}"
      />
      <Column
        id="2f3d1"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="Definition"
        label="DEFINITION"
        placeholder="Enter value"
        position="center"
        size={1321.6875}
        summaryAggregationMode="none"
      />
    </Table>
    <Table
      id="table67"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">ELU</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"><b>Elusiveness</b>  ⟡  DH Original Metric. Calculated using multiple advanced analytics, driven by <strong>MTF/A</strong> and <strong>YACO/A</strong></span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">MTF/A</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"> <b>Missed Tackles Forced per Attempt</b> ⟡ AVG amount of missed tackles forced, per carry</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">YACO/A</span>",\n    "Definition":"<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"> <b>Yards After Contact per Attempt</b>  ⟡  AVG yards gained after contact, per carry</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">YDS</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"><b>Yards</b>  ⟡  Sum of rushing and receiving yards </span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">YPC</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"><b>Yards per Carry</b>  ⟡  Average rush yards gained per carry</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">recYDS</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"><b>Receiving Yards</b>  ⟡  YDS gained on reception</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">YPRR</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"> <b>Yards per Route Run</b>  ⟡  AVG Receiving Yards gained per each Route Run</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">1DRR</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"><b>First Downs per Route Run</b>  ⟡ AVG amount of First-Downs per Route Run</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">TGT</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"> <b>Targets</b>  ⟡  Pass attempts intended for specified player </span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">TgtQR</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"><b>Targeted QB Rating</b>  ⟡  QB passer rating on throws to indicated player</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">DMTR</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"><b>Dominator Rating</b>  ⟡  Player’s Share of Team Yards & TDs</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">IMP</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"><b>Impact Plays</b>  ⟡  Total TDs & 1D(First Downs)</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.15em;font-weight:500;color:#722eff;\\">OPP</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"><b>Opportunities</b>  ⟡  Total player Carries & TGTs</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.11em;font-weight:500;color:#722eff;\\">IMP/OPP</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"><b>IMP/Opporunity</b>  ⟡  Average # IMP per OPP</span>"\n  },\n  {\n    "Abbreviation": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:1.08em;font-weight:500;color:#722eff;\\">YDS/OPP</span>",\n    "Definition": "<span style=\\"font-family:\'Quicksand\',sans-serif;font-size:0.8em;font-weight:300;color:#ffffff;display:block;text-align:left;\\"><b>Yards/Opporunity</b>  ⟡  Yards per Opportunity</span>" }\n]'
      }
      defaultSelectedRow={{
        mode: "none",
        indexType: "display",
        index: 0,
        key: "",
      }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      heightType="auto"
      margin="2px 0px 2px 8px"
      primaryKeyColumnId="0b85e"
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      showInEditor={true}
      style={{
        headerFontFamily: "Michroma",
        fontWeight: "400",
        rowSeparator: "rgba(48, 55, 84, 1)",
        border: "rgba(47, 55, 86, 1)",
        hoverRowBackground: "rgba(102, 0, 255, 0.08)",
        alternateRowBackground: "rgba(26, 31, 54, 1)",
        background: "rgba(22, 28, 54, 1)",
        fontSize: "8px",
        fontFamily: "ORBITRON",
        headerFontWeight: "400",
        headerText: "#994fff",
        headerBackground: "rgba(38, 44, 64, 1)",
        headerFontSize: "11px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="0b85e"
        alignment="center"
        editable="false"
        format="markdown"
        groupAggregationMode="none"
        key="Abbreviation"
        label="ABBRV"
        placeholder="Enter value"
        position="center"
        size={67.84375}
        summaryAggregationMode="none"
        valueOverride="{}"
      />
      <Column
        id="2f3d1"
        alignment="center"
        editable="false"
        format="markdown"
        groupAggregationMode="none"
        key="Definition"
        label="DEFINITION"
        placeholder="Enter value"
        position="center"
        size={506.390625}
        summaryAggregationMode="none"
      />
    </Table>
  </Body>
</ModalFrame>
