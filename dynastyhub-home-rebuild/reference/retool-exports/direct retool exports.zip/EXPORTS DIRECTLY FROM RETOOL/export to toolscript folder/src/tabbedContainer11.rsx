<Container
  id="tabbedContainer11"
  currentViewKey="{{ self.viewKeys[0] }}"
  footerPadding="0"
  headerPadding="0"
  heightType="fixed"
  margin="9px 9px 9px 35px"
  padding="0px 0px 0px 0px"
  showBody={true}
  showFooter={true}
  showFooterBorder={false}
  showHeader={true}
  showHeaderBorder={false}
  style={{
    background: "tertiary",
    headerBackground: "#191f38",
    footerBackground: "primary",
  }}
  styleContext={{ map: { primary: "primary" } }}
>
  <Header>
    <Text
      id="containerTitle387"
      horizontalAlign="center"
      margin="0"
      style={{
        background: "#191f38",
        fontSize: "12px",
        fontWeight: "400",
        fontFamily: "Quicksand",
      }}
      value={
        '<span style=\n"font-size: 1.15em;\ncolor: #efefef;">  2025｜TOP ROOKIE PROSPECTS</span> <br>[Prospect Grades & Percentile]'
      }
      verticalAlign="center"
    />
    <Button
      id="button19"
      margin="5px 2px 5px 10px"
      style={{
        fontWeight: "600",
        hoverBackground: "rgba(0, 255, 221, 1)",
        boxShadow: "highElevation",
        border: "secondary",
        background: "primary",
        fontSize: "15px",
        fontFamily: "Quicksand",
        label: "secondary",
        borderRadius: "6px",
      }}
      text="KEY"
    >
      <Event
        event="click"
        method="show"
        params={{}}
        pluginId="modalFrame4"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Tabs
      id="tabs12"
      alignment="justify"
      heightType="fixed"
      itemMode="static"
      navigateContainer={true}
      style={{
        selectedBackground: "#5700ff",
        pillBorderRadius: "100px",
        fontSize: "11px",
        fontWeight: "300",
        fontFamily: "Quicksand",
        hoverBackground: "tertiary",
      }}
      targetContainerId="tabbedContainer11"
      value="{{ self.values[0] }}"
    >
      <Option id="501f8" value="Tab 1" />
      <Option id="c0dc6" value="Tab 2" />
      <Option id="08e21" value="Tab 3" />
    </Tabs>
  </Header>
  <View id="aaa75" iconPosition="left" label="Jeanty" viewKey="View 1">
    <Table
      id="table56"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">21.3</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'8\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">211</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; color: #adb5ee;\\">BSU</i>",\n    "FILM GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.78em; color: #efefef;\\">FILM |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.95em; font-weight: 700; color: #6affd0;\\">98%</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.88em; font-weight: 600; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 1.2em; font-weight: 700; color: #6affd0;\\">96</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      overflowActionsOverlayMinWidth="600"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="b555e"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        hidden="false"
        key="CFB"
        label="CFB"
        placeholder="Enter value"
        position="center"
        size={43.75}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={63.40625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={43.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={54.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="736b5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.65625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={87.234375}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart76"
      chartType="plotlyJson"
      margin="10px 12px 7px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [100, 100, 100, 100, 100, 100, 100, 100],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2c334f62",\n    "line": { "color": "#525a7739", "width": 1 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 80, 80, 80, 80, 80, 80, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2D345153",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [60, 60, 60, 60, 60, 60, 60, 60],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2F365250",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [40, 40, 40, 40, 40, 40, 40, 40],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#30375455",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [20, 20, 20, 20, 20, 20, 20, 20],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#31385565",\n    "line": { "color": "#525a7735", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [94, 93, 98, 87, 98, 87, 98, 94],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "fill": "toself",\n    "name": "ASHTON JEANTY",\n    "mode": "lines+markers",\n    "line": {"color": "#6700ff", "width": 2},\n    "marker": {\n      "color": ["#6300ff", "#6300ff", "#6300ff", "#6300ff", "#6300ff", "#6300ff", "#6300ff", "#00000000"],\n      "size": [5, 5, 5, 5, 5, 5, 5, 5],\n      "color": "#6300FF"\n    },\n    "fillcolor": "#5300FF55",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [84, 83, 88, 77, 88, 77, 88],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n    "mode": "text",\n    "text": [\n      "<span style=\\"color: #00ffaf;\\">94th%</span>",\n      "<span style=\\"color: #00ffaf;\\">93rd%</span>",\n      "<span style=\\"color: #00ffaf;\\">98th%</span>",\n      "<span style=\\"color: #bcd2ff;\\">87th%</span>",\n      "<span style=\\"color: #00ffaf;\\">98th%</span>",\n      "<span style=\\"color: #bcd2ff;\\">87th%</span>",\n      "<span style=\\"color: #00ffaf;\\">98th%</span>"\n    ],\n    "textposition": "middle center",\n    "textfont": { "size": 9, "weight": 400, "family": "Bruno Ace" },\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '\n\n{\n  "polar": {\n    \n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "showgrid": false,\n      "ticks": "",\n      "showticklabels": false,\n      "showline": false,\n      "linewidth": 0,\n      "linecolor": "rgba(0,0,0,0)"\n      \n    },\n    "angularaxis": {\n      "showgrid": false,\n      "showline": false,\n      "tickmode": "array",\n      "tickvals": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n      "ticktext": ["YPC", "DMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A"],\n      "tickfont": {\n        "color": "white",\n       "size": 10.5, "family": "Orbitron" },\n      "direction": "counterclockwise",\n      "rotation": -0.55,\n      "layer": "above traces"\n      \n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "showlegend": false,\n  "annotations": [\n    {\n      "xref": "paper",\n      "yref": "paper",\n      "x": 0.5,\n      "y": 1.15,\n      "text": "ASHTON JEANTY",\n      "showarrow": false,\n      "font": {\n        "color": "#6300ff",\n        "size": 21,\n        "weight": 400,\n        "family": "orbitron"\n      },\n      "xanchor": "center",\n      "yanchor": "bottom"\n    }\n  ],\n  "margin": {\n    "l": 45,\n    "r": 45,\n    "t": 70,\n    "b": 30\n  }\n}'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container165"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle391"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic394"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".951"
        />
      </View>
    </Container>
    <Container
      id="container163"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle389"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic392"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.943"
        />
      </View>
    </Container>
    <Container
      id="container162"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle388"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic391"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.981"
        />
      </View>
    </Container>
    <Container
      id="container164"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle390"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic393"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "rgba(107, 176, 255, 1)",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.893"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart77"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "ATH"],\n    "y": [95, 94, 98, 89],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "ATH"],\n    "ticktext": ["PRD", "EFF", "ELU", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="64854"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="T.Hunter"
    viewKey="View 5"
  >
    <Table
      id="table63"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "WR",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">21.9</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">6\'0\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">188</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; color: #adb5ee;\\">COL</i>",\n    "FILM GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.78em; color: #efefef;\\">FILM |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.95em; font-weight: 700; color: #6affd0;\\">93%</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; font-weight: 600; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 1.15em; font-weight: 900; color: #6affd0;\\">94</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: '{{"/icon:bold/travel-transportation-bus"}}',
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
            { value: "WR", icon: "", label: "WR" },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={51.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="b555e"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        hidden="false"
        key="CFB"
        label="CFB"
        placeholder="Enter value"
        position="center"
        size={42.15625}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={64.140625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={45.09375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={59.078125}
        summaryAggregationMode="none"
      />
      <Column
        id="39b7a"
        alignment="left"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={79.71875}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={85.375}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart82"
      chartType="plotlyJson"
      margin="10px 12px 8px 13px"
      plotlyDataJson={
        '[\n  { "type":"scatterpolar","r":[100,100,100,100,100,100,100,100],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2c334f62",\n    "line":{"color":"#525a7739","width":1},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n  { "type":"scatterpolar","r":[80,80,80,80,80,80,80,80],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2D345153",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n  { "type":"scatterpolar","r":[60,60,60,60,60,60,60,60],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2F365250",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n  { "type":"scatterpolar","r":[40,40,40,40,40,40,40,40],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#30375415",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n  { "type":"scatterpolar","r":[20,20,20,20,20,20,20,20],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#31385540",\n    "line":{"color":"#525a7730","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n\n  { "type":"scatterpolar",\n    "r":[69,84,77,78,72,84,99,69],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "fill":"toself","name":"TRAVIS HUNTER","mode":"lines+markers",\n    "line":{"color":"#6700ff","width":2},\n    "marker":{"color":["#6300ff","#6300ff","#6300ff","#6300ff",\n                       "#6300ff","#6300ff","#6300ff","#00000000"],\n              "size":[5,5,5,5,5,5,5,5]},\n    "fillcolor":"#5300FF55","hoverinfo":"none","hovertemplate":""},\n\n  { "type":"scatterpolar",\n    "r":[59,74,62,68,67,74,89],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n    "mode":"text",\n    "text":[\n      "<span style=\\"color:#ef91ff;\\">69th%</span>",\n      "<span style=\\"color:#bcd2ff;\\">84th%</span>",\n      "<span style=\\"color:#b991ff;\\">77th%</span>",\n      "<span style=\\"color:#b991ff;\\">78th%</span>",\n      "<span style=\\"color:#b991ff;\\">72nd %</span>",\n      "<span style=\\"color:#bcd2ff;\\">84th%</span>",\n      "<span style=\\"color:#00ffaf;\\">99th%</span>"\n    ],\n    "textposition":"middle center",\n    "textfont":{"size":9,"weight":400,"family":"Bruno Ace"},\n    "hoverinfo":"none","hovertemplate":"","showlegend":false}\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar":{\n    "bgcolor":"#141a32",\n    "radialaxis":{"range":[0,100],"showgrid":false,"ticks":"",\n      "showticklabels":false,"showline":false,"linewidth":0,\n      "linecolor":"rgba(0,0,0,0)"},\n    "angularaxis":{\n      "showgrid":false,"showline":false,"tickmode":"array",\n      "tickvals":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n      "ticktext":["TGT","YPRR","DMTR","1DRR","YDS","IMP/OPP","TgtQR"],\n      "tickfont":{"color":"white","size":10.5,"family":"Bruno Ace"},\n      "direction":"counterclockwise","rotation":-0.55,"layer":"above traces"}\n  },\n  "paper_bgcolor":"#141a32",\n  "showlegend":false,\n  "annotations":[{\n      "xref":"paper","yref":"paper","x":0.5,"y":1.15,\n      "text":"TRAVIS HUNTER",\n      "showarrow":false,\n      "font":{"color":"#6300ff","size":21,"weight":400,"family":"orbitron"},\n      "xanchor":"center","yanchor":"bottom"}],\n  "margin":{"l":48,"r":47,"t":70,"b":30}\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container174"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle400"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic403"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#65aeff",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".887"
        />
      </View>
    </Container>
    <Container
      id="container175"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle401"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic404"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.963"
        />
      </View>
    </Container>
    <Container
      id="container176"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle402"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic405"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/computer-connection-usb-port"
          label=""
          labelCaption="ROUTE RUNNING GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.931"
        />
      </View>
    </Container>
    <Container
      id="container177"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle403"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic406"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.961"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart83"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "RRG", "ATH"],\n    "y": [89, 96, 93, 96],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "RRG", "ATH"],\n    "ticktext": ["PRD", "EFF", "RRG", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View id="eff2c" viewKey="Hampton">
    <Table
      id="table59"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">22.0</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">6\'0\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">221</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; color: #adb5ee;\\">UNC</i>",\n    "FILM GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.78em; color: #efefef;\\">FILM |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.95em; font-weight: 700; color: #65aeff;\\">86%</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; font-weight: 600; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 1.15em; font-weight: 700; color: #6affd0;\\">90</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      overflowActionsOverlayMinWidth="600"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="df0e5"
        alignment="left"
        format="markdown"
        groupAggregationMode="none"
        key="CFB"
        label="Cfb"
        placeholder="Enter value"
        position="center"
        size={43.453125}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={68.671875}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={45.09375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={57.921875}
        summaryAggregationMode="none"
      />
      <Column
        id="736b5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.65625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.4375}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart80"
      chartType="plotlyJson"
      margin="10px 12px 7px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [100, 100, 100, 100, 100, 100, 100, 100],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2c334f62",\n    "line": { "color": "#525a7739", "width": 1 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 80, 80, 80, 80, 80, 80, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2D345153",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [60, 60, 60, 60, 60, 60, 60, 60],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2F365250",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [40, 40, 40, 40, 40, 40, 40, 40],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#30375415",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [20, 20, 20, 20, 20, 20, 20, 20],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#31385520",\n    "line": { "color": "#525a7730", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [57, 69, 72, 87, 74, 57, 65, 57],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "fill": "toself",\n    "name": "OMARION HAMPTON",\n    "mode": "lines+markers",\n    "line": { "color": "#6700ff", "width": 2 },\n    "marker": {\n      "color": ["#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#00000000"],\n      "size": [5,5,5,5,5,5,5,5]\n    },\n    "fillcolor": "#5300FF50",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [47, 59, 72, 87, 74, 57, 65],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n    "mode": "text",\n    "text": [\n      "<span style=\\"color:#ef91ff;\\">57th%</span>",\n      "<span style=\\"color:#ef91ff;\\">69th%</span>",\n      "<span style=\\"color:#b991ff;\\">72nd%</span>",\n      "<span style=\\"color:#bcd2ff;\\">87th%</span>",\n      "<span style=\\"color:#b991ff;\\">74th%</span>",\n      "<span style=\\"color:#ef91ff;\\">57th%</span>",\n      "<span style=\\"color:#ef91ff;\\">65th%</span>"\n    ],\n    "textposition": "middle center",\n    "textfont": { "size": 9.3, "weight": 400, "family": "Bruno Ace" },\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "showgrid": false,\n      "ticks": "",\n      "showticklabels": false,\n      "showline": false,\n      "linewidth": 0,\n      "linecolor": "rgba(0,0,0,0)"\n    },\n    "angularaxis": {\n      "showgrid": false,\n      "showline": false,\n      "tickmode": "array",\n      "tickvals": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n      "ticktext": ["YPC","DMTR","ELU","YACO/A","IMP","recYDS","YDS/OPP"],\n      "tickfont": { "color": "white", "size": 10.5, "family": "Bruno Ace" },\n      "direction": "counterclockwise",\n      "rotation": -0.75,\n      "layer": "above traces"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "showlegend": false,\n  "annotations": [\n    {\n      "xref": "paper",\n      "yref": "paper",\n      "x": 0.5,\n      "y": 1.15,\n      "text": "OMARION HAMPTON",\n      "showarrow": false,\n      "font": { "color": "#6300ff", "size": 21, "weight": 400, "family": "orbitron" },\n      "xanchor": "center",\n      "yanchor": "bottom"\n    }\n  ],\n  "margin": { "l": 48, "r": 47, "t": 70, "b": 30 }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container170"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle396"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic399"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6bb0ff",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".862"
        />
      </View>
    </Container>
    <Container
      id="container171"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle397"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic400"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6bb0ff",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.828"
        />
      </View>
    </Container>
    <Container
      id="container172"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle398"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic401"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6bb0ff",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.864"
        />
      </View>
    </Container>
    <Container
      id="container173"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle399"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic402"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6bb0ff",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.89"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart81"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "ATH"],\n    "y": [86, 83, 86, 89],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "ATH"],\n    "ticktext": ["PRD", "EFF", "ELU", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View id="64058" label="McMillan" viewKey="View 2">
    <Table
      id="table57"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS":"WR",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">22.0</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">6\'4\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">219</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #adb5ee;\\">UA</span>",\n    "FILM GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.78em; color: #efefef;\\">FILM |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.95em; font-weight: 700; color: #65aeff;\\">88%</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; font-weight: 600; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 1.15em; font-weight: 700; color: #6affd0;\\">91</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: '{{"/icon:bold/travel-transportation-bus"}}',
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
            { value: "WR", icon: "", label: "WR" },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={51.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="b555e"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        hidden="false"
        key="CFB"
        label="CFB"
        placeholder="Enter value"
        position="center"
        size={38.453125}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={68.671875}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={43.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={58.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="9cf1e"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={81.078125}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={78.3125}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart78"
      chartType="plotlyJson"
      margin="10px 12px 7px 13px"
      plotlyDataJson={
        '[\n  { "type":"scatterpolar","r":[100,100,100,100,100,100,100,100],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2c334f62",\n    "line":{"color":"#525a7739","width":1},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false },\n  { "type":"scatterpolar","r":[80,80,80,80,80,80,80,80],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2D345153",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false },\n  { "type":"scatterpolar","r":[60,60,60,60,60,60,60,60],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2F365250",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false },\n  { "type":"scatterpolar","r":[40,40,40,40,40,40,40,40],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#30375415",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false },\n  { "type":"scatterpolar","r":[20,20,20,20,20,20,20,20],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#31385540",\n    "line":{"color":"#525a7730","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false },\n\n  { "type":"scatterpolar",\n    "r":[95,81,91,77,98,71,65,95],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "fill":"toself","name":"TETAIR​OA MCMILLAN",\n    "mode":"lines+markers","line":{"color":"#6700ff","width":2},\n    "marker":{"color":["#6300ff","#6300ff","#6300ff","#6300ff",\n                       "#6300ff","#6300ff","#6300ff","#00000000"],\n              "size":[5,5,5,5,5,5,5,5]},\n    "fillcolor":"#5300FF55","hoverinfo":"none","hovertemplate":"" },\n\n  { "type":"scatterpolar",\n    "r":[88,79,85,70,90,69,64],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n    "mode":"text",\n    "text":[\n      "<span style=\\"color:#00ffaf;\\">98th%</span>",\n      "<span style=\\"color:#bcd2ff;\\">81st%</span>",\n      "<span style=\\"color:#00ffaf;\\">93rd%</span>",\n      "<span style=\\"color:#b991ff;\\">77th%</span>",\n      "<span style=\\"color:#00ffaf;\\">99th%</span>",\n      "<span style=\\"color:#b991ff;\\">71st%</span>",\n      "<span style=\\"color:#ef91ff;\\">65th%</span>"\n    ],\n    "textposition":"middle center",\n    "textfont":{"size":9,"weight":400,"family":"Bruno Ace"},\n    "hoverinfo":"none","hovertemplate":"","showlegend":false }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar":{\n    "bgcolor":"#141a32",\n    "radialaxis":{"range":[0,100],"showgrid":false,"ticks":"",\n      "showticklabels":false,"showline":false,"linewidth":0,\n      "linecolor":"rgba(0,0,0,0)"},\n    "angularaxis":{\n      "showgrid":false,"showline":false,"tickmode":"array",\n      "tickvals":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n      "ticktext":["TGT","YPRR","DMTR","1DRR","YDS","IMP/OPP","TgtQR"],\n      "tickfont":{"color":"white", "size": 10.5, "family": "Bruno Ace" },\n      "direction":"counterclockwise","rotation":-0.55,"layer":"above traces"}\n  },\n  "paper_bgcolor":"#141a32",\n  "showlegend":false,\n  "annotations":[{\n      "xref":"paper","yref":"paper","x":0.5,"y":1.15,\n      "text":"TETAIROA  MCMILLAN","showarrow":false,\n      "font":{"color":"#6300ff","size":21,"weight":400,"family":"orbitron"},\n      "xanchor":"center","yanchor":"bottom"}],\n  "margin":{"l":48,"r":47,"t":70,"b":30}\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container166"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle392"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic395"
          align="center"
          decimalPlaces=""
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".977"
        />
      </View>
    </Container>
    <Container
      id="container167"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle393"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic396"
          align="center"
          decimalPlaces=""
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#5789ff",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.898"
        />
      </View>
    </Container>
    <Container
      id="container168"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle394"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic397"
          align="center"
          decimalPlaces=""
          formattingStyle="percent"
          icon="bold/computer-connection-usb-port"
          label=""
          labelCaption="ROUTE RUNNING GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "rgba(87, 137, 255, 1)",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.89"
        />
      </View>
    </Container>
    <Container
      id="container169"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle395"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic398"
          align="center"
          decimalPlaces=""
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.87"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart79"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "RRG", "ATH"],\n    "y": [97, 90, 89, 87],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "RRG", "ATH"],\n    "ticktext": ["PRD", "EFF", "RRG", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="0ac25"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Skattebo"
    viewKey="View 4"
  >
    <Table
      id="table60"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">22.0</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'10\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">219</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; color: #adb5ee;\\">ASu</i>",\n    "FILM GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.78em; color: #efefef;\\">FILM |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.95em; font-weight: 700; color: #65aeff;\\">85%</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; font-weight: 600; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 1.15em; font-weight: 700; color: #65aeff;\\">88</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      overflowActionsOverlayMinWidth="600"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="df0e5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="CFB"
        label="Cfb"
        placeholder="Enter value"
        position="center"
        size={42.90625}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={68.671875}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={50.375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={58.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="736b5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.109375}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.078125}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart84"
      chartType="plotlyJson"
      margin="10px 12px 7px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [100, 100, 100, 100, 100, 100, 100, 100],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2c334f62",\n    "line": { "color": "#525a7739", "width": 1 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 80, 80, 80, 80, 80, 80, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2D345153",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [60, 60, 60, 60, 60, 60, 60, 60],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2F365250",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [40, 40, 40, 40, 40, 40, 40, 40],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#30375455",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [20, 20, 20, 20, 20, 20, 20, 20],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#31385565",\n    "line": { "color": "#525a7735", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 99, 91, 69, 69, 94, 98, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "fill": "toself",\n    "name": "CAM SKATTEBO",\n    "mode": "lines+markers",\n    "line": { "color": "#6700ff", "width": 2 },\n    "marker": {\n      "color": ["#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#00000000"],\n      "size": [5,5,5,5,5,5,5,5]\n    },\n    "fillcolor": "#5300FF55",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [70, 89, 81, 59, 59, 84, 88],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n    "mode": "text",\n    "text": [\n      "<span style=\\"color:#bcd2ff;\\">80th%</span>",\n      "<span style=\\"color:#00ffaf;\\">99th%</span>",\n      "<span style=\\"color:#00ffaf;\\">91st%</span>",\n      "<span style=\\"color:#ef91ff;\\">69th%</span>",\n      "<span style=\\"color:#ef91ff;\\">69th%</span>",\n      "<span style=\\"color:#00ffaf;\\">94th%</span>",\n      "<span style=\\"color:#00ffaf;\\">98th%</span>"\n    ],\n    "textposition": "middle center",\n    "textfont": { "size": 9.3, "weight": 400, "family": "Bruno Ace" },\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "showgrid": false,\n      "ticks": "",\n      "showticklabels": false,\n      "showline": false,\n      "linewidth": 0,\n      "linecolor": "rgba(0,0,0,0)"\n    },\n    "angularaxis": {\n      "showgrid": false,\n      "showline": false,\n      "tickmode": "array",\n      "tickvals": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n      "ticktext": ["YPC","DMTR","ELU","YACO/A","IMP","recYDS","YDS/OPP"],\n      "tickfont": { "color": "white", "size": 10.5, "family": "Bruno Ace" },\n      "direction": "counterclockwise",\n      "rotation": -0.55,\n      "layer": "above traces"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "showlegend": false,\n  "annotations": [\n    {\n      "xref": "paper",\n      "yref": "paper",\n      "x": 0.5,\n      "y": 1.15,\n      "text": "CAM SKATTEBO",\n      "showarrow": false,\n      "font": { "color": "#6300ff", "size": 21, "weight": 400, "family": "orbitron" },\n      "xanchor": "center",\n      "yanchor": "bottom"\n    }\n  ],\n  "margin": { "l": 45, "r": 45, "t": 70, "b": 30 }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container178"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle404"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic407"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".949"
        />
      </View>
    </Container>
    <Container
      id="container179"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle405"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic408"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#65aeff",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.869"
        />
      </View>
    </Container>
    <Container
      id="container180"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle406"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic409"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.927"
        />
      </View>
    </Container>
    <Container
      id="container181"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle407"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic410"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#b991ff",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.770"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart85"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "ATH"],\n    "y": [95, 87, 93, 77],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "ATH"],\n    "ticktext": ["PRD", "EFF", "ELU", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="97d42"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Warren"
    viewKey="View 6"
  >
    <Table
      id="table62"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">22.0</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'10\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">219</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #adb5ee;\\">PSU</span>",\n    "FILM GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.78em; color: #efefef;\\">FILM |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.95em; font-weight: 700; color: #65aeff;\\">85%</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; font-weight: 600; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 1.15em; font-weight: 700; color: #65aeff;\\">88</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      overflowActionsOverlayMinWidth="600"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="df0e5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="CFB"
        label="Cfb"
        placeholder="Enter value"
        position="center"
        size={42.96875}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={68.671875}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={50.375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={58.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="736b5"
        alignment="left"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.109375}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.078125}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart86"
      chartType="plotlyJson"
      margin="10px 12px 8px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [100, 100, 100, 100, 100, 100, 100, 100],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2c334f62",\n    "line": { "color": "#525a7739", "width": 1 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 80, 80, 80, 80, 80, 80, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2D345153",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [60, 60, 60, 60, 60, 60, 60, 60],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2F365250",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [40, 40, 40, 40, 40, 40, 40, 40],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#30375415",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [20, 20, 20, 20, 20, 20, 20, 20],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#31385540",\n    "line": { "color": "#525a7730", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [56, 63, 70, 48, 90, 98, 95, 56],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "fill": "toself",\n    "name": "TYLER WARREN",\n    "mode": "lines+markers",\n    "line": { "color": "#6700ff", "width": 2 },\n    "marker": {\n      "color": ["#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#00000000"],\n      "size": [5,5,5,5,5,5,5,5]\n    },\n    "fillcolor": "#5300FF55",\n    "hoverinfo": "none",\n    "hovertemplate": ""\n  },\n  {\n    "type": "scatterpolar",\n    "r": [46, 53, 60, 38, 80, 88, 85],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n    "mode": "text",\n    "text": [\n      "<span style=\\"color: #ef91ff;\\">56th%</span>",\n      "<span style=\\"color: #ef91ff;\\">63rd%</span>",\n      "<span style=\\"color: #b991ff;\\">7Oth%</span>",\n      "<span style=\\"color: #ef91ff;\\">48th%</span>",\n      "<span style=\\"color: #00ffaf;\\">9Oth%</span>",\n      "<span style=\\"color: #00ffaf;\\">98th%</span>",\n      "<span style=\\"color: #00ffaf;\\">95th%</span>"\n    ],\n    "textposition": "middle center",\n    "textfont": { "size": 9, "weight": 400, "family": "Bruno Ace" },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  }\n]'
      }
      plotlyLayoutJson={
        '{\n  "polar":{\n    "bgcolor":"#141a32",\n    "radialaxis":{"range":[0,100],"showgrid":false,"ticks":"",\n      "showticklabels":false,"showline":false,"linewidth":0,\n      "linecolor":"rgba(0,0,0,0)"},\n    "angularaxis":{\n      "showgrid":false,"showline":false,"tickmode":"array",\n      "tickvals":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n      "ticktext":["TGT","YPRR","DMTR","1DRR","YDS","IMP/OPP","TgtQR"],\n      "tickfont":{"color":"white","size":10.5,"family":"Bruno Ace"},\n      "direction":"counterclockwise","rotation":-0.55,"layer":"above traces"}\n  },\n  "paper_bgcolor":"#141a32",\n  "showlegend":false,\n  "annotations":[{\n      "xref":"paper","yref":"paper","x":0.5,"y":1.15,\n      "text":"TYLER WARREN",\n      "showarrow":false,\n      "font":{"color":"#6300ff","size":21,"weight":400,"family":"orbitron"},\n      "xanchor":"center","yanchor":"bottom"}],\n  "margin":{"l":48,"r":47,"t":70,"b":30}\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container182"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle408"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic411"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".951"
        />
      </View>
    </Container>
    <Container
      id="container183"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle409"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic412"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.916"
        />
      </View>
    </Container>
    <Container
      id="container184"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle410"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic413"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/computer-connection-usb-port"
          label=""
          labelCaption="ROUTE RUNNING GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.982"
        />
      </View>
    </Container>
    <Container
      id="container185"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle411"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic414"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.933"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart87"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "RRG", "ATH"],\n    "y": [92, 98, 86, 94],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "RRG", "ATH"],\n    "ticktext": ["PRD", "EFF", "RRG", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="a8b36"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Henderson"
    viewKey="View 7"
  >
    <Table
      id="table61"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">22.4</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'10\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">202</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; color: #adb5ee;\\">OSu</i>",\n    "FILM GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.78em; color: #efefef;\\">FILM |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.95em; font-weight: 700; color: #65aeff;\\">84%</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; font-weight: 600; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 1.15em; font-weight: 700; color: #65aeff;\\">88</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      overflowActionsOverlayMinWidth="600"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="df0e5"
        alignment="left"
        format="markdown"
        groupAggregationMode="none"
        key="CFB"
        label="Cfb"
        placeholder="Enter value"
        position="center"
        size={42.90625}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={67.5625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={50.375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={63.046875}
        summaryAggregationMode="none"
      />
      <Column
        id="736b5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.921875}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.078125}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart88"
      chartType="plotlyJson"
      margin="10px 12px 7px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [100, 100, 100, 100, 100, 100, 100, 100],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2c334f62",\n    "line": { "color": "#525a7739", "width": 1 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 80, 80, 80, 80, 80, 80, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2D345153",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [60, 60, 60, 60, 60, 60, 60, 60],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2F365250",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [40, 40, 40, 40, 40, 40, 40, 40],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#30375455",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [20, 20, 20, 20, 20, 20, 20, 20],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#31385565",\n    "line": { "color": "#525a7735", "width": 0.9 },\n    "hoverinfo": "skip",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [91, 52, 54, 80, 74, 83, 91, 91],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "fill": "toself",\n    "name": "TREVEYON HENDERSON",\n    "mode": "lines+markers",\n    "line": { "color": "#6700ff", "width": 2 },\n    "marker": {\n      "color": ["#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#00000000"],\n      "size": [5,5,5,5,5,5,5,5]\n    },\n    "fillcolor": "#5300FF55",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [91, 52, 54, 80, 74, 83, 91],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n    "mode": "text",\n    "text": [\n      "<span style=\\"color:#00ffaf;\\">91st%</span>",\n      "<span style=\\"color:#ef91ff;\\">52nd%</span>",\n      "<span style=\\"color:#ef91ff;\\">76th%</span>",\n      "<span style=\\"color:#b991ff;\\">80th%</span>",\n      "<span style=\\"color:#b991ff;\\">74th%</span>",\n      "<span style=\\"color:#00ffaf;\\">83rd%</span>",\n      "<span style=\\"color:#00ffaf;\\">91st%</span>"\n    ],\n    "textposition": "middle center",\n    "textfont": { "size": 9, "weight": 400, "family": "Bruno Ace" },\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "showgrid": false,\n      "ticks": "",\n      "showticklabels": false,\n      "showline": false,\n      "linewidth": 0,\n      "linecolor": "rgba(0,0,0,0)"\n    },\n    "angularaxis": {\n      "showgrid": false,\n      "showline": false,\n      "tickmode": "array",\n      "tickvals": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n      "ticktext": ["YPC","DMTR","ELU","YACO/A","IMP","recYDS","YDS/OPP"],\n      "tickfont": { "color": "white", "size": 10.5, "family": "Bruno Ace" },\n      "direction": "counterclockwise",\n      "rotation": -0.65,\n      "layer": "above traces"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "showlegend": false,\n  "annotations": [\n    {\n      "xref": "paper",\n      "yref": "paper",\n      "x": 0.5,\n      "y": 1.15,\n      "text": "TREVEYON HENDERSON",\n      "showarrow": false,\n      "font": { "color": "#6300ff", "size": 20, "weight": 400, "family": "orbitron" },\n      "xanchor": "center",\n      "yanchor": "bottom"\n    }\n  ],\n  "margin": { "l": 48, "r": 47, "t": 70, "b": 30 }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container186"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle412"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic415"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#65aeff",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".896"
        />
      </View>
    </Container>
    <Container
      id="container187"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle413"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic416"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#65aeff",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.883"
        />
      </View>
    </Container>
    <Container
      id="container188"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle414"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic417"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#b991ff",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.762"
        />
      </View>
    </Container>
    <Container
      id="container189"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle415"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic418"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.940"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart89"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "ATH"],\n    "y": [90, 88, 76, 94],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "ATH"],\n    "ticktext": ["PRD", "EFF", "ELU", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="1e07e"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Egbuka"
    viewKey="View 8"
  >
    <Table
      id="table58"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "WR",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">22.5</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">6\'1\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">202</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; color: #adb5ee;\\">OSU</i>",\n    "FILM GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.78em; color: #efefef;\\">FILM |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.95em; font-weight: 700; color: #65aeff;\\">86%</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; font-weight: 600; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 1.15em; font-weight: 700; color: #65aeff;\\">89</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
            { value: "WR", icon: "", label: "WR" },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={51.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="b555e"
        alignment="right"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        hidden="false"
        key="CFB"
        label="CFB"
        placeholder="Enter value"
        position="center"
        size={44.03125}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="right"
        backgroundColor="{{ theme.primary }}"
        editable="false"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={67.578125}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="right"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={39.96875}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={63.046875}
        summaryAggregationMode="none"
      />
      <Column
        id="227b1"
        alignment="left"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.65625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={85.5625}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart90"
      chartType="plotlyJson"
      margin="10px 12px 7px 13px"
      plotlyDataJson={
        '[\n  { "type":"scatterpolar","r":[100,100,100,100,100,100,100,100],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2c334f62",\n    "line":{"color":"#525a7739","width":1},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n  { "type":"scatterpolar","r":[80,80,80,80,80,80,80,80],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2D345153",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n  { "type":"scatterpolar","r":[60,60,60,60,60,60,60,60],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#2F365250",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n  { "type":"scatterpolar","r":[40,40,40,40,40,40,40,40],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#30375415",\n    "line":{"color":"#525a7729","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n  { "type":"scatterpolar","r":[20,20,20,20,20,20,20,20],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "mode":"lines","fill":"toself","opacity":1,"fillcolor":"#31385540",\n    "line":{"color":"#525a7730","width":0.9},"hoverinfo":"none",\n    "hovertemplate":"","showlegend":false},\n\n  { "type":"scatterpolar",\n    "r":[89,89,92,93,53,80,92,89],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71,347.14],\n    "fill":"toself","name":"EMEKA EGBUKA","mode":"lines+markers",\n    "line":{"color":"#6700ff","width":2},\n    "marker":{"color":["#6300ff","#6300ff","#6300ff","#6300ff",\n                       "#6300ff","#6300ff","#6300ff","#00000000"],\n              "size":[5,5,5,5,5,5,5,5]},\n    "fillcolor":"#5300FF55","hoverinfo":"none","hovertemplate":""},\n\n  { "type":"scatterpolar",\n    "r":[79,79,82,83,43,70,82],\n    "theta":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n    "mode":"text",\n    "text":[\n      "<span style=\\"color:#bcd2ff;\\">89th%</span>",\n      "<span style=\\"color:#bcd2ff;\\">89th%</span>",\n      "<span style=\\"color:#00ffaf;\\">92nd%</span>",\n      "<span style=\\"color:#00ffaf;\\">93rd%</span>",\n      "<span style=\\"color:#ef91ff;\\">53rd%</span>",\n      "<span style=\\"color:#bcd2ff;\\">80th%</span>",\n      "<span style=\\"color:#00ffaf;\\">92nd%</span>"\n    ],\n    "textposition":"middle center",\n    "textfont":{"size":9,"weight":400,"family":"Bruno Ace"},\n    "hoverinfo":"none","hovertemplate":"","showlegend":false}\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar":{\n    "bgcolor":"#141a32",\n    "radialaxis":{"range":[0,100],"showgrid":false,"ticks":"",\n      "showticklabels":false,"showline":false,"linewidth":0,\n      "linecolor":"rgba(0,0,0,0)"},\n    "angularaxis":{\n      "showgrid":false,"showline":false,"tickmode":"array",\n      "tickvals":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n      "ticktext":["TGT","YPRR","DMTR","1DRR","YDS","IMP/OPP","TgtQR"],\n      "tickfont":{"color":"white","size":10.5,"family":"Bruno Ace"},\n      "direction":"counterclockwise","rotation":-0.55,"layer":"above traces"}\n  },\n  "paper_bgcolor":"#141a32",\n  "showlegend":false,\n  "annotations":[{\n      "xref":"paper","yref":"paper","x":0.5,"y":1.15,\n      "text":"EMEKA EGBUKA",\n      "showarrow":false,\n      "font":{"color":"#6300ff","size":21,"weight":400,"family":"orbitron"},\n      "xanchor":"center","yanchor":"bottom"}],\n  "margin":{"l":48,"r":47,"t":70,"b":30}\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container190"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle416"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic419"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".957"
        />
      </View>
    </Container>
    <Container
      id="container191"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle417"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic420"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.935"
        />
      </View>
    </Container>
    <Container
      id="container192"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle418"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic421"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/computer-connection-usb-port"
          label=""
          labelCaption="ROUTE RUNNING GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.911"
        />
      </View>
    </Container>
    <Container
      id="container193"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle419"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic422"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#65aeff",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.87"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart91"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "RRG", "ATH"],\n    "y": [96, 94, 91, 87],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "RRG", "ATH"],\n    "ticktext": ["PRD", "EFF", "RRG", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="f0131"
    disabled={false}
    hidden={false}
    iconPosition="left"
    viewKey="View 9"
  >
    <Table
      id="table64"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">22.0</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'10\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">219</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #adb5ee;\\">PSU</span>",\n    "FILM GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.78em; color: #efefef;\\">FILM |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.95em; font-weight: 700; color: #65aeff;\\">85%</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 0.85em; font-weight: 600; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'bruno ace\', sans-serif; font-size: 1.15em; font-weight: 700; color: #65aeff;\\">88</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      overflowActionsOverlayMinWidth="600"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: "",
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="df0e5"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="CFB"
        label="Cfb"
        placeholder="Enter value"
        position="center"
        size={42.96875}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={68.671875}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={50.375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={58.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="736b5"
        alignment="left"
        format="markdown"
        groupAggregationMode="none"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={80.109375}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.078125}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart92"
      chartType="plotlyJson"
      margin="10px 12px 8px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [100, 100, 100, 100, 100, 100, 100, 100],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2c334f62",\n    "line": { "color": "#525a7739", "width": 1 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [80, 80, 80, 80, 80, 80, 80, 80],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2D345153",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [60, 60, 60, 60, 60, 60, 60, 60],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#2F365250",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [40, 40, 40, 40, 40, 40, 40, 40],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#30375415",\n    "line": { "color": "#525a7729", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [20, 20, 20, 20, 20, 20, 20, 20],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "mode": "lines",\n    "fill": "toself",\n    "opacity": 1,\n    "fillcolor": "#31385540",\n    "line": { "color": "#525a7730", "width": 0.9 },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  },\n  {\n    "type": "scatterpolar",\n    "r": [56, 63, 70, 48, 90, 98, 95, 56],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71, 347.14],\n    "fill": "toself",\n    "name": "TYLER WARREN",\n    "mode": "lines+markers",\n    "line": { "color": "#6700ff", "width": 2 },\n    "marker": {\n      "color": ["#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#6300ff","#00000000"],\n      "size": [5,5,5,5,5,5,5,5]\n    },\n    "fillcolor": "#5300FF55",\n    "hoverinfo": "none",\n    "hovertemplate": ""\n  },\n  {\n    "type": "scatterpolar",\n    "r": [46, 53, 60, 38, 80, 88, 85],\n    "theta": [347.14, 38.57, 90, 141.43, 192.86, 244.29, 295.71],\n    "mode": "text",\n    "text": [\n      "<span style=\\"color: #ef91ff;\\">56th%</span>",\n      "<span style=\\"color: #ef91ff;\\">63rd%</span>",\n      "<span style=\\"color: #b991ff;\\">7Oth%</span>",\n      "<span style=\\"color: #ef91ff;\\">48th%</span>",\n      "<span style=\\"color: #00ffaf;\\">9Oth%</span>",\n      "<span style=\\"color: #00ffaf;\\">98th%</span>",\n      "<span style=\\"color: #00ffaf;\\">95th%</span>"\n    ],\n    "textposition": "middle center",\n    "textfont": { "size": 9, "weight": 400, "family": "Bruno Ace" },\n    "hoverinfo": "none",\n    "hovertemplate": "",\n    "showlegend": false\n  }\n]'
      }
      plotlyLayoutJson={
        '{\n  "polar":{\n    "bgcolor":"#141a32",\n    "radialaxis":{"range":[0,100],"showgrid":false,"ticks":"",\n      "showticklabels":false,"showline":false,"linewidth":0,\n      "linecolor":"rgba(0,0,0,0)"},\n    "angularaxis":{\n      "showgrid":false,"showline":false,"tickmode":"array",\n      "tickvals":[347.14,38.57,90,141.43,192.86,244.29,295.71],\n      "ticktext":["TGT","YPRR","DMTR","1DRR","YDS","IMP/OPP","TgtQR"],\n      "tickfont":{"color":"white","size":10.5,"family":"Bruno Ace"},\n      "direction":"counterclockwise","rotation":-0.55,"layer":"above traces"}\n  },\n  "paper_bgcolor":"#141a32",\n  "showlegend":false,\n  "annotations":[{\n      "xref":"paper","yref":"paper","x":0.5,"y":1.15,\n      "text":"TYLER WARREN",\n      "showarrow":false,\n      "font":{"color":"#6300ff","size":21,"weight":400,"family":"orbitron"},\n      "xanchor":"center","yanchor":"bottom"}],\n  "margin":{"l":48,"r":47,"t":70,"b":30}\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container194"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle420"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic423"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value=".951"
        />
      </View>
    </Container>
    <Container
      id="container195"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle421"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic424"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.916"
        />
      </View>
    </Container>
    <Container
      id="container196"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle422"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic425"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/computer-connection-usb-port"
          label=""
          labelCaption="ROUTE RUNNING GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.982"
        />
      </View>
    </Container>
    <Container
      id="container197"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle423"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic426"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="ATHLETICISM GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "9px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
            fontFamily: "Bruno Ace",
          }}
          suffix="%"
          value="0.933"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart93"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "RRG", "ATH"],\n    "y": [92, 98, 86, 94],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "RRG", "ATH"],\n    "ticktext": ["PRD", "EFF", "RRG", "ATH"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <Footer>
    <Button
      id="prevButton5"
      disabled=""
      iconBefore="bold/interface-arrows-left-alternate"
      margin="5px 15px 5px 15px"
      style={{
        border: "highlight",
        label: "#7300ff",
        fontSize: "13px",
        fontWeight: "600",
        fontFamily: "Quicksand",
        borderRadius: "5px",
      }}
      styleVariant="outline"
      text="Previous"
    >
      <Event
        event="click"
        method="showPreviousVisibleView"
        params={{ map: { wrap: false } }}
        pluginId="tabbedContainer11"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="nextButton5"
      disabled=""
      iconAfter="bold/interface-arrows-right-alternate"
      margin="5px 15px 5px 25px"
      style={{ background: "highlight", borderRadius: "5px" }}
      text="Next"
    >
      <Event
        event="click"
        method="showNextVisibleView"
        params={{ map: { wrap: false } }}
        pluginId="tabbedContainer11"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</Container>
