<Screen
  id="Home"
  _customShortcuts={[]}
  _hashParams={[]}
  _searchParams={[]}
  browserTitle=""
  title="Page 1"
  urlSlug=""
  uuid="1efa5a4f-6746-42dc-b87b-3d9014be9545"
>
  <Include src="./modalFrame4.rsx" />
  <Include src="./modalFrame5.rsx" />
  <Include src="./modalFrame6.rsx" />
  <Frame
    id="$main"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="0"
    style={{ ordered: [] }}
    type="main"
  >
    <Container
      id="container127"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      heightType="fixed"
      margin="0"
      overflowType="hidden"
      padding="0"
      showBody={true}
      style={{ background: "canvas", borderRadius: "0px" }}
    >
      <View id="10a74" viewKey="View 1">
        <Text
          id="text14"
          heightType="fixed"
          horizontalAlign="center"
          margin="0"
          style={{
            fontSize: "37px",
            fontWeight: "400",
            fontFamily: "ORBITRON",
            background: "canvas",
          }}
          value={
            '  <span style="background: linear-gradient(to right, #5700ff, #6e00f6, #8d28ff, #c332ff);\n    -webkit-background-clip: text;\n    background-clip: text;\n    color: transparent;\n  ">dynasty hub</span> '
          }
        />
        <Navigation
          id="navigation14"
          data="{{ retoolContext.pages }}"
          highlightByIndex="{{ retoolContext.currentPage === item.id }}"
          horizontalAlignment="justify"
          itemMode="static"
          labels="{{ item.title || item.id }}"
          margin="4px 5px 4px 15px"
          retoolFileObject={{ ordered: [] }}
          showInEditor={true}
          style={{
            highlightText: "#7476ff",
            fontSize: "16px",
            fontWeight: "700",
            fontFamily: "Quicksand",
            background: "tertiary",
            highlightBackground: "#2c334f",
            hoverText: "secondary",
          }}
        >
          <Option
            id="c2822"
            caption="Research"
            disabled={false}
            hidden={false}
            icon="bold/ecology-science-erlenmeyer-flask"
            iconPosition="left"
            itemType="page"
            screenTargetId="page3"
          />
          <Option
            id="c05bb"
            caption="Rookies"
            disabled={false}
            hidden={false}
            highlight={false}
            icon="bold/shopping-business-startup"
            iconPosition="right"
            itemType="page"
            screenTargetId="Rookies"
          />
          <Option
            id="a8f67"
            caption="Subscribe"
            disabled={false}
            hidden={false}
            highlight={false}
            icon="bold/shopping-jewelry-diamond-2"
            iconPosition="left"
            itemType="page"
            screenTargetId="page5"
          />
          <Option
            id="1d317"
            caption="— KEY"
            disabled={false}
            hidden={false}
            highlight={false}
            icon="bold/interface-login-key"
            iconPosition="left"
            itemType="custom"
          >
            <Event
              event="click"
              method="show"
              params={{ ordered: [] }}
              pluginId="modalFrame2"
              type="widget"
              waitMs="0"
              waitType="debounce"
            />
          </Option>
          <Event
            event="click"
            method="show"
            params={{}}
            pluginId="modalFrame2"
            targetId="718b5"
            type="widget"
            waitMs="0"
            waitType="debounce"
          />
          <Event
            event="click"
            method="openPage"
            params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
            pluginId=""
            type="util"
            waitMs="0"
            waitType="debounce"
          />
        </Navigation>
        <Navigation
          id="navigation15"
          data="{{ retoolContext.pages }}"
          highlightByIndex="{{ retoolContext.currentPage === item.id }}"
          horizontalAlignment="justify"
          itemMode="static"
          labels="{{ item.title || item.id }}"
          margin="4px 2px 4px 22px"
          retoolFileObject={{ ordered: [] }}
          showInEditor={true}
          style={{
            highlightText: "#7476ff",
            fontSize: "16px",
            fontWeight: "700",
            fontFamily: "Quicksand",
            background: "#212843",
            highlightBackground: "#2c334f",
            hoverText: "secondary",
          }}
        >
          <Option
            id="1de3f"
            caption="Home"
            icon="bold/interface-home-3"
            iconPosition="left"
            itemType="page"
            screenTargetId="Home"
          />
          <Option
            id="60b8d"
            caption="Data Hub"
            icon="bold/interface-arrows-diagonal"
            iconPosition="left"
            itemType="page"
          />
          <Option
            id="d4f21"
            caption="Charts"
            icon="bold/money-graph-arrow-increase"
            iconPosition="left"
            itemType="page"
            screenTargetId="Charts"
          />
          <Option
            id="b6a91"
            caption="Rankings"
            disabled={false}
            hidden={false}
            highlight={false}
            icon="bold/interface-award-crown"
            iconPosition="replace"
            itemType="page"
            screenTargetId="page2"
          />
          <Event
            event="click"
            method="show"
            params={{}}
            pluginId="modalFrame2"
            targetId="718b5"
            type="widget"
            waitMs="0"
            waitType="debounce"
          />
          <Event
            event="click"
            method="show"
            params={{ ordered: [] }}
            pluginId="modalFrame2"
            targetId="1d317"
            type="widget"
            waitMs="0"
            waitType="debounce"
          />
          <Event
            event="click"
            method="openPage"
            params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
            pluginId=""
            type="util"
            waitMs="0"
            waitType="debounce"
          />
        </Navigation>
      </View>
    </Container>
    <Include src="./tabbedContainer10.rsx" />
    <Include src="./container7.rsx" />
    <Container
      id="stack7"
      _align="center"
      _gap="{{ stack7. padding }}"
      _justify="center"
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="9px 9px 9px 35px"
      padding="10px 16px 10px 16px"
      showBody={true}
      showHeader={true}
      showHeaderBorder={false}
      style={{ background: "#212843", headerBackground: "primary" }}
    >
      <Header>
        <Text
          id="containerTitle167"
          heightType="fixed"
          horizontalAlign="center"
          margin="0"
          style={{
            background: "primary",
            fontSize: "12px",
            fontWeight: "300",
            fontFamily: "Quicksand",
          }}
          value={
            '<span style=\n"font-size: 1.2em;\n  font-weight:400;\ncolor: #efefef;"> 2025｜Distributions</span> \n[Championship Ownership Data & Top 60 Positional Distribution]'
          }
          verticalAlign="center"
        />
      </Header>
      <View id="89cab" viewKey="View 1">
        <IFrame
          id="iFrame6"
          margin="0px 0px 0px 6px"
          src="https://flo.uri.sh/visualisation/21672127/embed"
          style={{
            ordered: [
              { borderColor: "rgba(224, 224, 224, 0)" },
              { background: "#141a32" },
            ],
          }}
          title="{{ self.src }}"
        />
        <IFrame
          id="iFrame9"
          allowPopups={true}
          margin="0px 6px 0px 0px"
          src="https://flo.uri.sh/visualisation/22012229/embed"
          style={{
            ordered: [
              { borderColor: "rgba(224, 224, 224, 0)" },
              { borderRadius: "10px" },
              { background: "primary" },
            ],
          }}
          title="{{ self.src }}"
          tooltipText={
            '<div style=\n"background-color: #3b4777;\ncolor: #f85f87;\ntext-align: center;\npadding: 4px;\nmargin: -10px;\nfont-weight: 500;\nfont-style: italic;\nfont-size: 14.5px;"\n>Hover over data points, and click filters to break down info.\n</div>'
          }
        />
      </View>
    </Container>
    <Container
      id="container10"
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="9px 36px 9px 9px"
      overflowType="hidden"
      padding="10px 16px 10px 16px"
      showBody={true}
      showHeader={true}
      showHeaderBorder={false}
      style={{ background: "tertiary", headerBackground: "primary" }}
    >
      <Header>
        <Text
          id="containerTitle11"
          heightType="fixed"
          horizontalAlign="center"
          margin="4px 8px 0px 8px"
          overflowType="hidden"
          style={{ map: { background: "primary" } }}
          value={
            '<div style="display:flex;justify-content:center;align-items:flex-start;background:#141a32;padding:0;">\n  <!-- LEFT BLOCK -->\n  <div style="text-align:center;margin-right:20px;">\n    <!-- top line (now tighter) -->\n    <div style="line-height:1em;margin-bottom:0;">\n      <span style="font-weight:400;font-size:1.1em;color:#fff;line-height:1em;">𐘳⟲nsistency%</span>\n      <span style="font-weight:bold;color:#6e5bfb;font-size:1em;line-height:1em;">𐩑 𐘳﹪</span>\n    </div>\n    <!-- bottom line (pulled up 2 px) -->\n    <div style="margin-top:0px;">\n      <span style="font-weight:300;font-size:.85em;line-height:1em;">\n        [<b>RATE</b>&nbsp;|&nbsp;Games&nbsp;with&nbsp;at&nbsp;least&nbsp;12 fpts]\n      </span>\n    </div>\n  </div>\n\n  <!-- AMPERSAND -->\n  <div style="align-self:flex-start;">\n    <span style="font-weight:600;color:#cec2ec;font-size:1.2em;line-height:1em;">&amp;</span>\n  </div>\n\n  <!-- RIGHT BLOCK -->\n  <div style="text-align:center;margin-left:20px;">\n    <div style="line-height:1em;margin-bottom:0;">\n      <span style="font-weight:400;color:#fff;font-size:1.1em;line-height:1em;">ℂeiling</span>\n      <span style="font-weight:bold;color:#ff2860;font-size:1em;line-height:1em;">𐩑 ℂꜛ</span>\n    </div>\n    <div style="margin-top:-0px;">\n      <span style="font-size:.85em;line-height:1em;">\n        [<b>AVG FPTS</b>&nbsp;|&nbsp;PLYR&nbsp;Top&nbsp;3&nbsp;Wks]\n      </span>\n    </div>\n  </div>\n</div>'
          }
          verticalAlign="center"
        />
        <Button
          id="button16"
          margin="6px 0px 6px 0px"
          style={{
            fontWeight: "600",
            hoverBackground: "rgba(0, 255, 221, 1)",
            boxShadow: "highElevation",
            border: "secondary",
            background: "primary",
            fontSize: "15px",
            fontFamily: "Quicksand",
            label: "secondary",
            borderRadius: "6px",
          }}
          text="KEY"
        >
          <Event
            event="click"
            method="show"
            params={{}}
            pluginId="modalFrame6"
            type="widget"
            waitMs="0"
            waitType="debounce"
          />
        </Button>
      </Header>
      <View id="9269c" viewKey="View 1">
        <IFrame
          id="iFrame18"
          allowPopups={true}
          margin="0px 6px 0px 0px"
          src="https://flo.uri.sh/visualisation/21746730/embed"
          style={{
            ordered: [
              { borderColor: "rgba(224, 224, 224, 0)" },
              { borderRadius: "10px" },
              { background: "primary" },
            ],
          }}
          title="{{ self.src }}"
          tooltipText={
            '<div style="\n  background-color: #212843;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n"> ✦ Bubble Size Scaled by PPR Fpts ✦ <br>\n⌁ Interactive | Hover over data points, and click filters for break down ⌁ </div>'
          }
        />
        <IFrame
          id="iFrame17"
          allowPopups={true}
          margin="0px 0px 0px 6px"
          src="https://flo.uri.sh/visualisation/21814104/embed"
          style={{
            ordered: [
              { background: "#141a32" },
              { borderRadius: "10px" },
              { borderColor: "rgba(48, 53, 75, 0)" },
            ],
          }}
          title="ff"
          tooltipText={
            '<div style="\n  background-color: #212843;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 8px #c0c0c0 ;\n"> ✦ Bubble Size Scaled by PPR Fpts ✦ <br>\n⌁ Interactive | Hover over data points, and click filters for break down ⌁ </div>'
          }
        />
      </View>
    </Container>
    <Container
      id="container207"
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="9px 36px 9px 36px"
      overflowType="hidden"
      padding="5px 16px 5px 16px"
      showBody={true}
      showHeaderBorder={false}
      style={{ background: "tertiary", headerBackground: "primary" }}
    >
      <Header>
        <Button
          id="button23"
          margin="5px 0px 5px 0px"
          style={{
            fontWeight: "300",
            hoverBackground: "tertiary",
            boxShadow: "0 0px 6px 0 #FA0088",
            border: "danger",
            background: "primary",
            fontSize: "11px",
            fontFamily: "Product Sans",
            label: "rgba(252, 193, 224, 1)",
            borderRadius: "6px",
          }}
          text="Link to Interactive 
• Gemini Chart • "
        >
          <Event
            event="click"
            method="openUrl"
            params={{ map: { url: "https://g.co/gemini/share/53b59752ae0f" } }}
            pluginId=""
            type="util"
            waitMs="0"
            waitType="debounce"
          />
        </Button>
        <Text
          id="containerTitle430"
          heightType="fixed"
          horizontalAlign="center"
          margin="4px 8px 0px 8px"
          overflowType="hidden"
          style={{ map: { background: "primary" } }}
          value={
            '<span style=\n"font-size: 1.2em;\n  font-weight:400;\ncolor: #efefef;"> 2008-2020｜NFL Draft Hit Rates</span> \n[Positional and Draft Range Hit Rates]'
          }
          verticalAlign="center"
        />
        <Button
          id="button21"
          margin="6px 0px 6px 0px"
          style={{
            fontWeight: "600",
            hoverBackground: "rgba(0, 255, 221, 1)",
            boxShadow: "highElevation",
            border: "secondary",
            background: "primary",
            fontSize: "15px",
            fontFamily: "Quicksand",
            label: "secondary",
            borderRadius: "6px",
          }}
          text="KEY"
        >
          <Event
            event="click"
            method="show"
            params={{}}
            pluginId="modalFrame6"
            type="widget"
            waitMs="0"
            waitType="debounce"
          />
        </Button>
      </Header>
      <View id="9269c" viewKey="View 1">
        <IFrame
          id="iFrame35"
          allowFullscreen={true}
          hidden=""
          margin="0px 100px 0px 100px"
          src="https://cheery-piroshki-93e724.netlify.app/"
          title="{{ self.src }}"
        />
      </View>
    </Container>
  </Frame>
</Screen>
