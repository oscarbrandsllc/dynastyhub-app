<Container
  id="tabbedContainer13"
  _gap="0px"
  currentViewKey="{{ self.viewKeys[0] }}"
  enableFullBleed={true}
  footerPadding="4px 12px"
  headerPadding="4px 12px"
  heightType="fixed"
  margin="8px 50px"
  padding="0"
  showBody={true}
  showHeader={true}
  style={{
    background: "rgba(15, 15, 15, 0.1)",
    headerBackground: "rgba(6, 10, 18, 0.66)",
    borderRadius: "14px",
    border: "rgba(19, 19, 19, 0.82)",
    boxShadow: "highElevation",
  }}
  styleContext={{}}
  transition="slide"
>
  <Header>
    <Text
      id="text32"
      heightType="fixed"
      horizontalAlign="center"
      margin="1px 10px"
      style={{}}
      value={
        '<div style="\n  background-color: #212843;\n  padding: 6px 55px;\n  border-radius: 0px;\n  display: inline-flex;\n  box-shadow: 0 0 4px #aa00ff;\n">\n  <span style="\n    font-size: 1.2cqw;\n    font-family: Orbitron;\n    background: linear-gradient(to right, #c332ff, #8d28ff, #6e00f6, #5700ff);\n    -webkit-background-clip: text;\n    background-clip: text;\n    color: transparent;\n  ">2024  ⌁  NFL STATS</span>\n</div>\n'
      }
      verticalAlign="center"
    />
    <Container
      id="group10"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      margin="0"
      padding="0"
      showBody={true}
      style={{
        background: "rgba(115, 0, 255, 0.03)",
        border: "rgba(115, 0, 255, 0.6)",
        borderRadius: "10px",
        boxShadow: "0 0 5px 1px rgba(0, 0, 0, 0.06)",
      }}
    >
      <View id="00030" viewKey="View 1">
        <Container
          id="group12"
          footerPadding="4px 12px"
          headerPadding="4px 12px"
          margin="0"
          padding="0"
          showBody={true}
          showBorder={false}
          style={{ map: { background: "rgba(255, 255, 255, 0)" } }}
        >
          <View id="00030" viewKey="View 1">
            <Icon
              id="icon11"
              horizontalAlign="right"
              icon="bold/interface-geometric-square"
              margin="6px 4px"
              style={{ map: { color: "#b5a1fe" } }}
            />
            <Text
              id="text35"
              heightType="fixed"
              margin="0"
              style={{
                fontSize: "10px",
                fontWeight: "300",
                fontFamily: "Product Sans",
                color: "#b5a1fe",
              }}
              value="TOTAL"
              verticalAlign="center"
            />
          </View>
        </Container>
        <Container
          id="group13"
          footerPadding="4px 12px"
          headerPadding="4px 12px"
          margin="0"
          padding="0"
          showBody={true}
          style={{
            background: "rgba(255, 255, 255, 0)",
            border: "rgba(115, 0, 255, 0.12)",
          }}
        >
          <View id="00030" viewKey="View 1">
            <Icon
              id="icon12"
              horizontalAlign="right"
              icon="bold/interface-geometric-square"
              margin="6px 4px"
              style={{ map: { color: "#c6ffe8" } }}
            />
            <Text
              id="text36"
              heightType="fixed"
              margin="0"
              style={{
                fontSize: "10px",
                fontWeight: "300",
                fontFamily: "Product Sans",
                color: "#c6ffe8",
              }}
              value="RUSHING"
              verticalAlign="center"
            />
          </View>
        </Container>
        <Container
          id="group11"
          footerPadding="4px 12px"
          headerPadding="4px 12px"
          margin="0"
          padding="0"
          showBody={true}
          showBorder={false}
          style={{ map: { background: "rgba(255, 255, 255, 0)" } }}
        >
          <View id="00030" viewKey="View 1">
            <Icon
              id="icon10"
              horizontalAlign="right"
              icon="bold/interface-geometric-square"
              margin="6px 4px"
              style={{ map: { color: "#99cdff" } }}
            />
            <Text
              id="text34"
              heightType="fixed"
              margin="0"
              style={{
                fontSize: "10px",
                fontWeight: "300",
                fontFamily: "Product Sans",
                color: "#99cdff",
              }}
              value="RECEIVING"
              verticalAlign="center"
            />
          </View>
        </Container>
      </View>
    </Container>
    <Text
      id="text33"
      horizontalAlign="right"
      style={{
        fontSize: "12px",
        fontWeight: "300",
        fontFamily: "Product Sans",
      }}
      value="Stat Category Legend:"
      verticalAlign="center"
    />
    <Button
      id="button27"
      horizontalAlign="center"
      iconBefore="bold/interface-login-key"
      margin="0px 0px"
      style={{
        boxShadow: "mediumElevation",
        activeBackground: "rgba(116, 110, 110, 1)",
        background: "canvas",
        border: "#7300ff",
        fontSize: "18px",
        fontWeight: "400",
        fontFamily: "Gruppo",
        label: "#9350ff",
      }}
      submitTargetId=""
      text="KEY"
    >
      <Event
        event="click"
        method="show"
        params={{ ordered: [] }}
        pluginId="modalFrame3"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Tabs
      id="tabs14"
      alignment="justify"
      heightType="fixed"
      itemMode="static"
      margin="4px 20px"
      navigateContainer={true}
      style={{
        fontSize: "13px",
        fontWeight: "400",
        fontFamily: "Gruppo",
        hoverBackground: "danger",
        selectedText: "surfacePrimary",
        selectedBackground: "rgb(103, 0, 255)",
        pillBorderRadius: "4px",
      }}
      targetContainerId="tabbedContainer13"
      value="{{ self.values[0] }}"
    >
      <Option id="d0134" label="ALL" value="Tab 1" />
      <Option
        id="c1fb3"
        icon="bold/travel-map-location-target-1"
        iconPosition="left"
        value="QB"
      />
      <Option id="9c928" value="Tab 3" />
    </Tabs>
    <Icon
      id="icon9"
      icon={'{{  "/icon:bold/interface-alert-information-circle-alternate"  }}'}
      margin="6px 3px"
      style={{ map: { color: "secondary" } }}
      tooltipText={
        '<div style="\n  background-color: #212843;\n  color: #ffffff;\n  font-size: 11px;\n  text-align: center;\n  padding: 1px 4px;\n  margin: -5px;\n  font-weight: 300;\n  border-radius: 4px;\n  box-shadow: 0 0 14px #000000;\n">\n📈 · Hover over any column headers to view full stat labels<br> \n🗝️ · Select "KEY" for full definitions of all metrics, additional <br> info,and detailed breakdowns of advanced metrics.\n</div>'
      }
    >
      <Event
        enabled="onhover"
        event="click"
        method="showNotification"
        params={{
          map: {
            options: {
              notificationType: "info",
              title: "Career Stats",
              description:
                '✦ Hover on column headers to expand abbreviated metric terms.\n\n✦ Select "KEY"🔑 for full stat definitions, additional info, and detailed breakdowns of the advanced metrics.',
            },
          },
        }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Icon>
  </Header>
  <View
    id="325df"
    disabled={false}
    hidden={false}
    icon="bold/interface-page-controller-settings"
    iconPosition="left"
    viewKey="FLX"
  >
    <Table
      id="table93"
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "RK": "1",\n    "posRK": "1",\n    "Player": "Ja\'Marr Chase",\n    "POS": "WR",\n    "TM": "CIN",\n    "PPR": "403.0",\n    "PPR/G": "23.7",\n    "PPR/OPP": "2.32",\n    "CSTY": "88.2",\n    "CLNG": "47.3",\n    "G": "17",\n    "OPP": "174",\n    "YDS(t)": "1740",\n    "TD(t)": "17",\n    "1D(t)": "77",\n    "LNG": "70",\n    "BP": "19",\n    "IMP(t)": "94",\n    "IMP%": "0.540",\n    "RecYDS": "1708",\n    "RecTD": "17",\n    "REC": "127",\n    "TGT": "171",\n    "YPT": "9.99",\n    "YPR": "13.45",\n    "YAC/REC": "6.28",\n    "Rec1D": "75",\n    "YPRR": "2.41",\n    "1DRR": "0.106",\n    "CAR": "3",\n    "RuYDS": "32",\n    "YPC": "10.67",\n    "RuTD": "0",\n    "Ru1D": "2",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "2",\n    "posRK": "1",\n    "Player": "Jahmyr Gibbs",\n    "POS": "RB",\n    "TM": "DET",\n    "PPR": "364.9",\n    "PPR/G": "21.5",\n    "PPR/OPP": "1.17",\n    "CSTY": "100",\n    "CLNG": "35.5",\n    "G": "17",\n    "OPP": "313",\n    "YDS(t)": "1929",\n    "TD(t)": "20",\n    "1D(t)": "96",\n    "LNG": "70",\n    "BP": "19",\n    "IMP(t)": "116",\n    "IMP%": "0.371",\n    "RecYDS": "517",\n    "RecTD": "4",\n    "REC": "52",\n    "TGT": "63",\n    "YPT": "8.21",\n    "YPR": "9.94",\n    "YAC/REC": "11.52",\n    "Rec1D": "26",\n    "YPRR": "1.67",\n    "1DRR": "0.084",\n    "CAR": "250",\n    "RuYDS": "1412",\n    "YPC": "5.65",\n    "RuTD": "16",\n    "Ru1D": "70",\n    "ELU": "0.503",\n    "MTF/A": "0.252",\n    "YCO/A": "3.34"\n  },\n  {\n    "RK": "3",\n    "posRK": "2",\n    "Player": "Saquon Barkley",\n    "POS": "RB",\n    "TM": "PHI",\n    "PPR": "351.3",\n    "PPR/G": "22.0",\n    "PPR/OPP": "0.91",\n    "CSTY": "81.3",\n    "CLNG": "38.3",\n    "G": "16",\n    "OPP": "384",\n    "YDS(t)": "2283",\n    "TD(t)": "15",\n    "1D(t)": "94",\n    "LNG": "72",\n    "BP": "21",\n    "IMP(t)": "109",\n    "IMP%": "0.284",\n    "RecYDS": "278",\n    "RecTD": "2",\n    "REC": "33",\n    "TGT": "39",\n    "YPT": "7.13",\n    "YPR": "8.42",\n    "YAC/REC": "7.45",\n    "Rec1D": "12",\n    "YPRR": "0.93",\n    "1DRR": "0.040",\n    "CAR": "345",\n    "RuYDS": "2005",\n    "YPC": "5.81",\n    "RuTD": "13",\n    "Ru1D": "82",\n    "ELU": "0.417",\n    "MTF/A": "0.180",\n    "YCO/A": "3.17"\n  },\n  {\n    "RK": "4",\n    "posRK": "3",\n    "Player": "Bijan Robinson",\n    "POS": "RB",\n    "TM": "ATL",\n    "PPR": "339.7",\n    "PPR/G": "20.0",\n    "PPR/OPP": "0.91",\n    "CSTY": "82.4",\n    "CLNG": "28.7",\n    "G": "17",\n    "OPP": "374",\n    "YDS(t)": "1887",\n    "TD(t)": "15",\n    "1D(t)": "102",\n    "LNG": "37",\n    "BP": "8",\n    "IMP(t)": "117",\n    "IMP%": "0.313",\n    "RecYDS": "431",\n    "RecTD": "1",\n    "REC": "61",\n    "TGT": "70",\n    "YPT": "6.16",\n    "YPR": "7.07",\n    "YAC/REC": "8.74",\n    "Rec1D": "20",\n    "YPRR": "1.11",\n    "1DRR": "0.051",\n    "CAR": "304",\n    "RuYDS": "1456",\n    "YPC": "4.79",\n    "RuTD": "14",\n    "Ru1D": "82",\n    "ELU": "0.458",\n    "MTF/A": "0.230",\n    "YCO/A": "3.03"\n  },\n  {\n    "RK": "5",\n    "posRK": "4",\n    "Player": "Derrick Henry",\n    "POS": "RB",\n    "TM": "BAL",\n    "PPR": "338.4",\n    "PPR/G": "19.9",\n    "PPR/OPP": "0.98",\n    "CSTY": "88.2",\n    "CLNG": "32.1",\n    "G": "17",\n    "OPP": "346",\n    "YDS(t)": "2114",\n    "TD(t)": "18",\n    "1D(t)": "104",\n    "LNG": "87",\n    "BP": "21",\n    "IMP(t)": "122",\n    "IMP%": "0.353",\n    "RecYDS": "193",\n    "RecTD": "2",\n    "REC": "19",\n    "TGT": "21",\n    "YPT": "9.19",\n    "YPR": "10.16",\n    "YAC/REC": "11.47",\n    "Rec1D": "11",\n    "YPRR": "1.08",\n    "1DRR": "0.061",\n    "CAR": "325",\n    "RuYDS": "1921",\n    "YPC": "5.91",\n    "RuTD": "16",\n    "Ru1D": "93",\n    "ELU": "0.509",\n    "MTF/A": "0.246",\n    "YCO/A": "3.50"\n  },\n  {\n    "RK": "6",\n    "posRK": "2",\n    "Player": "Justin Jefferson",\n    "POS": "WR",\n    "TM": "MIN",\n    "PPR": "316.6",\n    "PPR/G": "18.6",\n    "PPR/OPP": "2.10",\n    "CSTY": "82.4",\n    "CLNG": "30.6",\n    "G": "17",\n    "OPP": "151",\n    "YDS(t)": "1536",\n    "TD(t)": "10",\n    "1D(t)": "62",\n    "LNG": "97",\n    "BP": "28",\n    "IMP(t)": "72",\n    "IMP%": "0.477",\n    "RecYDS": "1533",\n    "RecTD": "10",\n    "REC": "103",\n    "TGT": "150",\n    "YPT": "10.22",\n    "YPR": "14.88",\n    "YAC/REC": "4.68",\n    "Rec1D": "62",\n    "YPRR": "2.5",\n    "1DRR": "0.101",\n    "CAR": "1",\n    "RuYDS": "3",\n    "YPC": "3.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "7",\n    "posRK": "3",\n    "Player": "Amon-Ra St. Brown",\n    "POS": "WR",\n    "TM": "DET",\n    "PPR": "313.9",\n    "PPR/G": "18.5",\n    "PPR/OPP": "2.24",\n    "CSTY": "82.4",\n    "CLNG": "34.4",\n    "G": "17",\n    "OPP": "140",\n    "YDS(t)": "1269",\n    "TD(t)": "12",\n    "1D(t)": "72",\n    "LNG": "66",\n    "BP": "14",\n    "IMP(t)": "84",\n    "IMP%": "0.600",\n    "RecYDS": "1263",\n    "RecTD": "12",\n    "REC": "115",\n    "TGT": "138",\n    "YPT": "9.15",\n    "YPR": "10.98",\n    "YAC/REC": "3.53",\n    "Rec1D": "71",\n    "YPRR": "2.29",\n    "1DRR": "0.129",\n    "CAR": "2",\n    "RuYDS": "6",\n    "YPC": "3.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "8",\n    "posRK": "5",\n    "Player": "De\'Von Achane",\n    "POS": "RB",\n    "TM": "MIA",\n    "PPR": "299.9",\n    "PPR/G": "17.6",\n    "PPR/OPP": "1.04",\n    "CSTY": "64.7",\n    "CLNG": "30.9",\n    "G": "17",\n    "OPP": "288",\n    "YDS(t)": "1499",\n    "TD(t)": "12",\n    "1D(t)": "68",\n    "LNG": "61",\n    "BP": "8",\n    "IMP(t)": "80",\n    "IMP%": "0.278",\n    "RecYDS": "592",\n    "RecTD": "6",\n    "REC": "78",\n    "TGT": "85",\n    "YPT": "6.96",\n    "YPR": "7.59",\n    "YAC/REC": "8.47",\n    "Rec1D": "30",\n    "YPRR": "1.45",\n    "1DRR": "0.074",\n    "CAR": "203",\n    "RuYDS": "907",\n    "YPC": "4.47",\n    "RuTD": "6",\n    "Ru1D": "38",\n    "ELU": "0.376",\n    "MTF/A": "0.158",\n    "YCO/A": "2.91"\n  },\n  {\n    "RK": "9",\n    "posRK": "6",\n    "Player": "Josh Jacobs",\n    "POS": "RB",\n    "TM": "GB",\n    "PPR": "299.1",\n    "PPR/G": "17.6",\n    "PPR/OPP": "0.87",\n    "CSTY": "82.4",\n    "CLNG": "26.2",\n    "G": "17",\n    "OPP": "342",\n    "YDS(t)": "1671",\n    "TD(t)": "16",\n    "1D(t)": "89",\n    "LNG": "49",\n    "BP": "12",\n    "IMP(t)": "105",\n    "IMP%": "0.307",\n    "RecYDS": "342",\n    "RecTD": "1",\n    "REC": "36",\n    "TGT": "41",\n    "YPT": "8.34",\n    "YPR": "9.5",\n    "YAC/REC": "11.33",\n    "Rec1D": "15",\n    "YPRR": "1.36",\n    "1DRR": "0.060",\n    "CAR": "301",\n    "RuYDS": "1329",\n    "YPC": "4.42",\n    "RuTD": "15",\n    "Ru1D": "74",\n    "ELU": "0.481",\n    "MTF/A": "0.223",\n    "YCO/A": "3.45"\n  },\n  {\n    "RK": "10",\n    "posRK": "4",\n    "Player": "Drake London",\n    "POS": "WR",\n    "TM": "ATL",\n    "PPR": "280.8",\n    "PPR/G": "16.5",\n    "PPR/OPP": "1.87",\n    "CSTY": "70.6",\n    "CLNG": "31.2",\n    "G": "17",\n    "OPP": "150",\n    "YDS(t)": "1268",\n    "TD(t)": "9",\n    "1D(t)": "67",\n    "LNG": "39",\n    "BP": "12",\n    "IMP(t)": "76",\n    "IMP%": "0.507",\n    "RecYDS": "1271",\n    "RecTD": "9",\n    "REC": "100",\n    "TGT": "149",\n    "YPT": "8.53",\n    "YPR": "12.71",\n    "YAC/REC": "3.28",\n    "Rec1D": "67",\n    "YPRR": "2.32",\n    "1DRR": "0.122",\n    "CAR": "1",\n    "RuYDS": "-3",\n    "YPC": "-3.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "11",\n    "posRK": "5",\n    "Player": "Brian Thomas Jr.",\n    "POS": "WR",\n    "TM": "JAX",\n    "PPR": "280.0",\n    "PPR/G": "16.5",\n    "PPR/OPP": "2.07",\n    "CSTY": "70.6",\n    "CLNG": "28.2",\n    "G": "17",\n    "OPP": "135",\n    "YDS(t)": "1330",\n    "TD(t)": "10",\n    "1D(t)": "56",\n    "LNG": "85",\n    "BP": "18",\n    "IMP(t)": "66",\n    "IMP%": "0.489",\n    "RecYDS": "1282",\n    "RecTD": "10",\n    "REC": "87",\n    "TGT": "129",\n    "YPT": "9.94",\n    "YPR": "14.74",\n    "YAC/REC": "6.57",\n    "Rec1D": "53",\n    "YPRR": "2.45",\n    "1DRR": "0.101",\n    "CAR": "6",\n    "RuYDS": "48",\n    "YPC": "8.00",\n    "RuTD": "0",\n    "Ru1D": "3",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "12",\n    "posRK": "7",\n    "Player": "Kyren Williams",\n    "POS": "RB",\n    "TM": "LAR",\n    "PPR": "278.1",\n    "PPR/G": "17.4",\n    "PPR/OPP": "0.79",\n    "CSTY": "87.5",\n    "CLNG": "26.0",\n    "G": "16",\n    "OPP": "354",\n    "YDS(t)": "1481",\n    "TD(t)": "16",\n    "1D(t)": "91",\n    "LNG": "30",\n    "BP": "3",\n    "IMP(t)": "107",\n    "IMP%": "0.302",\n    "RecYDS": "182",\n    "RecTD": "2",\n    "REC": "34",\n    "TGT": "38",\n    "YPT": "4.79",\n    "YPR": "5.35",\n    "YAC/REC": "5.94",\n    "Rec1D": "7",\n    "YPRR": "0.52",\n    "1DRR": "0.020",\n    "CAR": "316",\n    "RuYDS": "1299",\n    "YPC": "4.11",\n    "RuTD": "14",\n    "Ru1D": "84",\n    "ELU": "0.362",\n    "MTF/A": "0.158",\n    "YCO/A": "2.72"\n  },\n  {\n    "RK": "13",\n    "posRK": "6",\n    "Player": "Malik Nabers",\n    "POS": "WR",\n    "TM": "NYG",\n    "PPR": "271.6",\n    "PPR/G": "18.1",\n    "PPR/OPP": "1.60",\n    "CSTY": "80.0",\n    "CLNG": "31.0",\n    "G": "15",\n    "OPP": "170",\n    "YDS(t)": "1206",\n    "TD(t)": "7",\n    "1D(t)": "56",\n    "LNG": "59",\n    "BP": "16",\n    "IMP(t)": "63",\n    "IMP%": "0.371",\n    "RecYDS": "1204",\n    "RecTD": "7",\n    "REC": "109",\n    "TGT": "165",\n    "YPT": "7.3",\n    "YPR": "11.05",\n    "YAC/REC": "4.36",\n    "Rec1D": "55",\n    "YPRR": "2.17",\n    "1DRR": "0.099",\n    "CAR": "5",\n    "RuYDS": "2",\n    "YPC": "0.40",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "14",\n    "posRK": "7",\n    "Player": "Terry McLaurin",\n    "POS": "WR",\n    "TM": "WAS",\n    "PPR": "269.8",\n    "PPR/G": "15.9",\n    "PPR/OPP": "2.31",\n    "CSTY": "76.5",\n    "CLNG": "25.6",\n    "G": "17",\n    "OPP": "117",\n    "YDS(t)": "1098",\n    "TD(t)": "13",\n    "1D(t)": "56",\n    "LNG": "86",\n    "BP": "12",\n    "IMP(t)": "69",\n    "IMP%": "0.590",\n    "RecYDS": "1096",\n    "RecTD": "13",\n    "REC": "82",\n    "TGT": "115",\n    "YPT": "9.53",\n    "YPR": "13.37",\n    "YAC/REC": "3.6",\n    "Rec1D": "56",\n    "YPRR": "1.98",\n    "1DRR": "0.101",\n    "CAR": "2",\n    "RuYDS": "2",\n    "YPC": "1.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "15",\n    "posRK": "8",\n    "Player": "James Cook",\n    "POS": "RB",\n    "TM": "BUF",\n    "PPR": "266.7",\n    "PPR/G": "16.7",\n    "PPR/OPP": "1.09",\n    "CSTY": "62.5",\n    "CLNG": "28.1",\n    "G": "16",\n    "OPP": "245",\n    "YDS(t)": "1267",\n    "TD(t)": "18",\n    "1D(t)": "63",\n    "LNG": "65",\n    "BP": "9",\n    "IMP(t)": "81",\n    "IMP%": "0.331",\n    "RecYDS": "258",\n    "RecTD": "2",\n    "REC": "32",\n    "TGT": "38",\n    "YPT": "6.79",\n    "YPR": "8.06",\n    "YAC/REC": "8.44",\n    "Rec1D": "14",\n    "YPRR": "1.15",\n    "1DRR": "0.062",\n    "CAR": "207",\n    "RuYDS": "1009",\n    "YPC": "4.87",\n    "RuTD": "16",\n    "Ru1D": "49",\n    "ELU": "0.423",\n    "MTF/A": "0.179",\n    "YCO/A": "3.26"\n  },\n  {\n    "RK": "16",\n    "posRK": "9",\n    "Player": "Alvin Kamara",\n    "POS": "RB",\n    "TM": "NO",\n    "PPR": "265.3",\n    "PPR/G": "19.0",\n    "PPR/OPP": "0.84",\n    "CSTY": "92.9",\n    "CLNG": "32.1",\n    "G": "14",\n    "OPP": "315",\n    "YDS(t)": "1493",\n    "TD(t)": "8",\n    "1D(t)": "70",\n    "LNG": "57",\n    "BP": "10",\n    "IMP(t)": "78",\n    "IMP%": "0.248",\n    "RecYDS": "543",\n    "RecTD": "2",\n    "REC": "68",\n    "TGT": "87",\n    "YPT": "6.24",\n    "YPR": "7.99",\n    "YAC/REC": "8.04",\n    "Rec1D": "18",\n    "YPRR": "1.75",\n    "1DRR": "0.058",\n    "CAR": "228",\n    "RuYDS": "950",\n    "YPC": "4.17",\n    "RuTD": "6",\n    "Ru1D": "52",\n    "ELU": "0.387",\n    "MTF/A": "0.180",\n    "YCO/A": "2.76"\n  },\n  {\n    "RK": "17",\n    "posRK": "8",\n    "Player": "CeeDee Lamb",\n    "POS": "WR",\n    "TM": "DAL",\n    "PPR": "263.4",\n    "PPR/G": "17.6",\n    "PPR/OPP": "1.65",\n    "CSTY": "73.3",\n    "CLNG": "29.9",\n    "G": "15",\n    "OPP": "160",\n    "YDS(t)": "1264",\n    "TD(t)": "6",\n    "1D(t)": "58",\n    "LNG": "65",\n    "BP": "16",\n    "IMP(t)": "64",\n    "IMP%": "0.400",\n    "RecYDS": "1194",\n    "RecTD": "6",\n    "REC": "101",\n    "TGT": "146",\n    "YPT": "8.18",\n    "YPR": "11.82",\n    "YAC/REC": "5.39",\n    "Rec1D": "54",\n    "YPRR": "2.27",\n    "1DRR": "0.103",\n    "CAR": "14",\n    "RuYDS": "70",\n    "YPC": "5.00",\n    "RuTD": "0",\n    "Ru1D": "4",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "18",\n    "posRK": "1",\n    "Player": "Brock Bowers",\n    "POS": "TE",\n    "TM": "LV",\n    "PPR": "262.7",\n    "PPR/G": "15.5",\n    "PPR/OPP": "1.72",\n    "CSTY": "58.8",\n    "CLNG": "28.4",\n    "G": "17",\n    "OPP": "153",\n    "YDS(t)": "1207",\n    "TD(t)": "5",\n    "1D(t)": "63",\n    "LNG": "57",\n    "BP": "15",\n    "IMP(t)": "68",\n    "IMP%": "0.444",\n    "RecYDS": "1194",\n    "RecTD": "5",\n    "REC": "112",\n    "TGT": "148",\n    "YPT": "8.07",\n    "YPR": "10.66",\n    "YAC/REC": "5.32",\n    "Rec1D": "61",\n    "YPRR": "2.02",\n    "1DRR": "0.103",\n    "CAR": "5",\n    "RuYDS": "13",\n    "YPC": "2.60",\n    "RuTD": "0",\n    "Ru1D": "2",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "19",\n    "posRK": "10",\n    "Player": "Chase Brown",\n    "POS": "RB",\n    "TM": "CIN",\n    "PPR": "255.0",\n    "PPR/G": "15.9",\n    "PPR/OPP": "0.87",\n    "CSTY": "68.8",\n    "CLNG": "25.8",\n    "G": "16",\n    "OPP": "292",\n    "YDS(t)": "1350",\n    "TD(t)": "11",\n    "1D(t)": "72",\n    "LNG": "40",\n    "BP": "10",\n    "IMP(t)": "83",\n    "IMP%": "0.284",\n    "RecYDS": "360",\n    "RecTD": "4",\n    "REC": "54",\n    "TGT": "63",\n    "YPT": "5.71",\n    "YPR": "6.67",\n    "YAC/REC": "6",\n    "Rec1D": "23",\n    "YPRR": "1.06",\n    "1DRR": "0.068",\n    "CAR": "229",\n    "RuYDS": "990",\n    "YPC": "4.32",\n    "RuTD": "7",\n    "Ru1D": "49",\n    "ELU": "0.432",\n    "MTF/A": "0.201",\n    "YCO/A": "3.08"\n  },\n  {\n    "RK": "20",\n    "posRK": "9",\n    "Player": "Garrett Wilson",\n    "POS": "WR",\n    "TM": "NYJ",\n    "PPR": "253.9",\n    "PPR/G": "14.9",\n    "PPR/OPP": "1.65",\n    "CSTY": "52.9",\n    "CLNG": "27.9",\n    "G": "17",\n    "OPP": "154",\n    "YDS(t)": "1109",\n    "TD(t)": "7",\n    "1D(t)": "61",\n    "LNG": "42",\n    "BP": "16",\n    "IMP(t)": "68",\n    "IMP%": "0.442",\n    "RecYDS": "1104",\n    "RecTD": "7",\n    "REC": "101",\n    "TGT": "152",\n    "YPT": "7.26",\n    "YPR": "10.93",\n    "YAC/REC": "4.42",\n    "Rec1D": "60",\n    "YPRR": "1.69",\n    "1DRR": "0.092",\n    "CAR": "2",\n    "RuYDS": "5",\n    "YPC": "2.50",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "21",\n    "posRK": "11",\n    "Player": "James Conner",\n    "POS": "RB",\n    "TM": "ARI",\n    "PPR": "251.8",\n    "PPR/G": "15.7",\n    "PPR/OPP": "0.87",\n    "CSTY": "68.8",\n    "CLNG": "26.6",\n    "G": "16",\n    "OPP": "289",\n    "YDS(t)": "1508",\n    "TD(t)": "9",\n    "1D(t)": "83",\n    "LNG": "53",\n    "BP": "10",\n    "IMP(t)": "92",\n    "IMP%": "0.318",\n    "RecYDS": "414",\n    "RecTD": "1",\n    "REC": "47",\n    "TGT": "53",\n    "YPT": "7.81",\n    "YPR": "8.81",\n    "YAC/REC": "10.28",\n    "Rec1D": "18",\n    "YPRR": "1.54",\n    "1DRR": "0.067",\n    "CAR": "236",\n    "RuYDS": "1094",\n    "YPC": "4.64",\n    "RuTD": "8",\n    "Ru1D": "65",\n    "ELU": "0.536",\n    "MTF/A": "0.288",\n    "YCO/A": "3.30"\n  },\n  {\n    "RK": "22",\n    "posRK": "10",\n    "Player": "Jaxon Smith-Njigba",\n    "POS": "WR",\n    "TM": "SEA",\n    "PPR": "251.6",\n    "PPR/G": "14.8",\n    "PPR/OPP": "1.82",\n    "CSTY": "58.8",\n    "CLNG": "28.2",\n    "G": "17",\n    "OPP": "138",\n    "YDS(t)": "1156",\n    "TD(t)": "6",\n    "1D(t)": "57",\n    "LNG": "46",\n    "BP": "14",\n    "IMP(t)": "63",\n    "IMP%": "0.457",\n    "RecYDS": "1130",\n    "RecTD": "6",\n    "REC": "100",\n    "TGT": "133",\n    "YPT": "8.5",\n    "YPR": "11.3",\n    "YAC/REC": "4.82",\n    "Rec1D": "56",\n    "YPRR": "1.81",\n    "1DRR": "0.090",\n    "CAR": "5",\n    "RuYDS": "26",\n    "YPC": "5.20",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "23",\n    "posRK": "12",\n    "Player": "Aaron Jones",\n    "POS": "RB",\n    "TM": "MIN",\n    "PPR": "247.6",\n    "PPR/G": "14.6",\n    "PPR/OPP": "0.79",\n    "CSTY": "64.7",\n    "CLNG": "22.8",\n    "G": "17",\n    "OPP": "313",\n    "YDS(t)": "1546",\n    "TD(t)": "7",\n    "1D(t)": "69",\n    "LNG": "41",\n    "BP": "7",\n    "IMP(t)": "76",\n    "IMP%": "0.243",\n    "RecYDS": "408",\n    "RecTD": "2",\n    "REC": "51",\n    "TGT": "58",\n    "YPT": "7.03",\n    "YPR": "8",\n    "YAC/REC": "8.51",\n    "Rec1D": "20",\n    "YPRR": "1.29",\n    "1DRR": "0.063",\n    "CAR": "255",\n    "RuYDS": "1138",\n    "YPC": "4.46",\n    "RuTD": "5",\n    "Ru1D": "49",\n    "ELU": "0.405",\n    "MTF/A": "0.180",\n    "YCO/A": "3.00"\n  },\n  {\n    "RK": "24",\n    "posRK": "13",\n    "Player": "Jonathan Taylor",\n    "POS": "RB",\n    "TM": "IND",\n    "PPR": "246.7",\n    "PPR/G": "17.6",\n    "PPR/OPP": "0.74",\n    "CSTY": "71.4",\n    "CLNG": "31.3",\n    "G": "14",\n    "OPP": "333",\n    "YDS(t)": "1567",\n    "TD(t)": "12",\n    "1D(t)": "78",\n    "LNG": "70",\n    "BP": "12",\n    "IMP(t)": "90",\n    "IMP%": "0.270",\n    "RecYDS": "136",\n    "RecTD": "1",\n    "REC": "18",\n    "TGT": "30",\n    "YPT": "4.53",\n    "YPR": "7.56",\n    "YAC/REC": "8.5",\n    "Rec1D": "7",\n    "YPRR": "0.5",\n    "1DRR": "0.026",\n    "CAR": "303",\n    "RuYDS": "1431",\n    "YPC": "4.72",\n    "RuTD": "11",\n    "Ru1D": "71",\n    "ELU": "0.320",\n    "MTF/A": "0.119",\n    "YCO/A": "2.68"\n  },\n  {\n    "RK": "25",\n    "posRK": "14",\n    "Player": "Bucky Irving",\n    "POS": "RB",\n    "TM": "TB",\n    "PPR": "246.4",\n    "PPR/G": "14.5",\n    "PPR/OPP": "0.96",\n    "CSTY": "64.7",\n    "CLNG": "25.9",\n    "G": "17",\n    "OPP": "257",\n    "YDS(t)": "1514",\n    "TD(t)": "8",\n    "1D(t)": "68",\n    "LNG": "56",\n    "BP": "11",\n    "IMP(t)": "76",\n    "IMP%": "0.296",\n    "RecYDS": "392",\n    "RecTD": "0",\n    "REC": "47",\n    "TGT": "50",\n    "YPT": "7.84",\n    "YPR": "8.34",\n    "YAC/REC": "11.28",\n    "Rec1D": "16",\n    "YPRR": "1.63",\n    "1DRR": "0.067",\n    "CAR": "207",\n    "RuYDS": "1122",\n    "YPC": "5.42",\n    "RuTD": "8",\n    "Ru1D": "52",\n    "ELU": "0.578",\n    "MTF/A": "0.275",\n    "YCO/A": "4.03"\n  },\n  {\n    "RK": "26",\n    "posRK": "15",\n    "Player": "Chuba Hubbard",\n    "POS": "RB",\n    "TM": "CAR",\n    "PPR": "245.6",\n    "PPR/G": "16.4",\n    "PPR/OPP": "0.81",\n    "CSTY": "60.0",\n    "CLNG": "29.1",\n    "G": "15",\n    "OPP": "302",\n    "YDS(t)": "1366",\n    "TD(t)": "11",\n    "1D(t)": "72",\n    "LNG": "38",\n    "BP": "9",\n    "IMP(t)": "83",\n    "IMP%": "0.275",\n    "RecYDS": "171",\n    "RecTD": "1",\n    "REC": "43",\n    "TGT": "52",\n    "YPT": "3.29",\n    "YPR": "3.98",\n    "YAC/REC": "5.77",\n    "Rec1D": "10",\n    "YPRR": "0.51",\n    "1DRR": "0.030",\n    "CAR": "250",\n    "RuYDS": "1195",\n    "YPC": "4.78",\n    "RuTD": "10",\n    "Ru1D": "62",\n    "ELU": "0.460",\n    "MTF/A": "0.200",\n    "YCO/A": "3.46"\n  },\n  {\n    "RK": "27",\n    "posRK": "2",\n    "Player": "Trey McBride",\n    "POS": "TE",\n    "TM": "ARI",\n    "PPR": "243.8",\n    "PPR/G": "15.2",\n    "PPR/OPP": "1.74",\n    "CSTY": "62.5",\n    "CLNG": "25.7",\n    "G": "16",\n    "OPP": "140",\n    "YDS(t)": "1148",\n    "TD(t)": "3",\n    "1D(t)": "64",\n    "LNG": "37",\n    "BP": "10",\n    "IMP(t)": "67",\n    "IMP%": "0.479",\n    "RecYDS": "1146",\n    "RecTD": "2",\n    "REC": "111",\n    "TGT": "139",\n    "YPT": "8.24",\n    "YPR": "10.32",\n    "YAC/REC": "4.74",\n    "Rec1D": "63",\n    "YPRR": "2.14",\n    "1DRR": "0.118",\n    "CAR": "1",\n    "RuYDS": "2",\n    "YPC": "2.00",\n    "RuTD": "1",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "28",\n    "posRK": "16",\n    "Player": "Breece Hall",\n    "POS": "RB",\n    "TM": "NYJ",\n    "PPR": "240.9",\n    "PPR/G": "15.1",\n    "PPR/OPP": "0.85",\n    "CSTY": "62.5",\n    "CLNG": "27.2",\n    "G": "16",\n    "OPP": "284",\n    "YDS(t)": "1359",\n    "TD(t)": "8",\n    "1D(t)": "53",\n    "LNG": "57",\n    "BP": "12",\n    "IMP(t)": "61",\n    "IMP%": "0.215",\n    "RecYDS": "483",\n    "RecTD": "3",\n    "REC": "57",\n    "TGT": "75",\n    "YPT": "6.44",\n    "YPR": "8.47",\n    "YAC/REC": "8.77",\n    "Rec1D": "15",\n    "YPRR": "1.26",\n    "1DRR": "0.039",\n    "CAR": "209",\n    "RuYDS": "876",\n    "YPC": "4.19",\n    "RuTD": "5",\n    "Ru1D": "38",\n    "ELU": "0.400",\n    "MTF/A": "0.172",\n    "YCO/A": "3.04"\n  },\n  {\n    "RK": "29",\n    "posRK": "17",\n    "Player": "Joe Mixon",\n    "POS": "RB",\n    "TM": "HOU",\n    "PPR": "240.5",\n    "PPR/G": "17.2",\n    "PPR/OPP": "0.82",\n    "CSTY": "57.1",\n    "CLNG": "29.8",\n    "G": "14",\n    "OPP": "293",\n    "YDS(t)": "1325",\n    "TD(t)": "12",\n    "1D(t)": "64",\n    "LNG": "59",\n    "BP": "12",\n    "IMP(t)": "76",\n    "IMP%": "0.259",\n    "RecYDS": "309",\n    "RecTD": "1",\n    "REC": "36",\n    "TGT": "48",\n    "YPT": "6.44",\n    "YPR": "8.58",\n    "YAC/REC": "10.14",\n    "Rec1D": "12",\n    "YPRR": "1.3",\n    "1DRR": "0.051",\n    "CAR": "245",\n    "RuYDS": "1016",\n    "YPC": "4.15",\n    "RuTD": "11",\n    "Ru1D": "52",\n    "ELU": "0.370",\n    "MTF/A": "0.151",\n    "YCO/A": "2.92"\n  },\n  {\n    "RK": "30",\n    "posRK": "11",\n    "Player": "Mike Evans",\n    "POS": "WR",\n    "TM": "TB",\n    "PPR": "240.4",\n    "PPR/G": "17.2",\n    "PPR/OPP": "2.25",\n    "CSTY": "50.0",\n    "CLNG": "30.8",\n    "G": "14",\n    "OPP": "107",\n    "YDS(t)": "1004",\n    "TD(t)": "11",\n    "1D(t)": "53",\n    "LNG": "57",\n    "BP": "15",\n    "IMP(t)": "64",\n    "IMP%": "0.598",\n    "RecYDS": "1004",\n    "RecTD": "11",\n    "REC": "74",\n    "TGT": "107",\n    "YPT": "9.38",\n    "YPR": "13.57",\n    "YAC/REC": "3",\n    "Rec1D": "53",\n    "YPRR": "2.41",\n    "1DRR": "0.127",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "31",\n    "posRK": "12",\n    "Player": "Davante Adams",\n    "POS": "WR",\n    "TM": "NYJ",\n    "PPR": "239.3",\n    "PPR/G": "17.1",\n    "PPR/OPP": "1.77",\n    "CSTY": "57.1",\n    "CLNG": "30.9",\n    "G": "14",\n    "OPP": "135",\n    "YDS(t)": "1063",\n    "TD(t)": "8",\n    "1D(t)": "49",\n    "LNG": "71",\n    "BP": "16",\n    "IMP(t)": "57",\n    "IMP%": "0.422",\n    "RecYDS": "1063",\n    "RecTD": "8",\n    "REC": "85",\n    "TGT": "135",\n    "YPT": "7.87",\n    "YPR": "12.51",\n    "YAC/REC": "5.51",\n    "Rec1D": "49",\n    "YPRR": "2.04",\n    "1DRR": "0.094",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "32",\n    "posRK": "13",\n    "Player": "Ladd McConkey",\n    "POS": "WR",\n    "TM": "LAC",\n    "PPR": "238.9",\n    "PPR/G": "14.9",\n    "PPR/OPP": "2.17",\n    "CSTY": "62.5",\n    "CLNG": "26.4",\n    "G": "16",\n    "OPP": "110",\n    "YDS(t)": "1149",\n    "TD(t)": "7",\n    "1D(t)": "52",\n    "LNG": "60",\n    "BP": "15",\n    "IMP(t)": "59",\n    "IMP%": "0.536",\n    "RecYDS": "1149",\n    "RecTD": "7",\n    "REC": "82",\n    "TGT": "110",\n    "YPT": "10.45",\n    "YPR": "14.01",\n    "YAC/REC": "4.84",\n    "Rec1D": "52",\n    "YPRR": "2.38",\n    "1DRR": "0.108",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "33",\n    "posRK": "14",\n    "Player": "DJ Moore",\n    "POS": "WR",\n    "TM": "CHI",\n    "PPR": "238.1",\n    "PPR/G": "14.0",\n    "PPR/OPP": "1.58",\n    "CSTY": "52.9",\n    "CLNG": "25.5",\n    "G": "17",\n    "OPP": "151",\n    "YDS(t)": "1041",\n    "TD(t)": "6",\n    "1D(t)": "46",\n    "LNG": "75",\n    "BP": "17",\n    "IMP(t)": "52",\n    "IMP%": "0.344",\n    "RecYDS": "966",\n    "RecTD": "6",\n    "REC": "98",\n    "TGT": "137",\n    "YPT": "7.05",\n    "YPR": "9.86",\n    "YAC/REC": "6.08",\n    "Rec1D": "43",\n    "YPRR": "1.44",\n    "1DRR": "0.064",\n    "CAR": "14",\n    "RuYDS": "75",\n    "YPC": "5.36",\n    "RuTD": "0",\n    "Ru1D": "3",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "34",\n    "posRK": "15",\n    "Player": "Courtland Sutton",\n    "POS": "WR",\n    "TM": "DEN",\n    "PPR": "237.1",\n    "PPR/G": "13.9",\n    "PPR/OPP": "1.80",\n    "CSTY": "70.6",\n    "CLNG": "23.2",\n    "G": "17",\n    "OPP": "132",\n    "YDS(t)": "1081",\n    "TD(t)": "8",\n    "1D(t)": "57",\n    "LNG": "47",\n    "BP": "17",\n    "IMP(t)": "65",\n    "IMP%": "0.492",\n    "RecYDS": "1081",\n    "RecTD": "8",\n    "REC": "81",\n    "TGT": "132",\n    "YPT": "8.19",\n    "YPR": "13.35",\n    "YAC/REC": "2.28",\n    "Rec1D": "57",\n    "YPRR": "1.84",\n    "1DRR": "0.097",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "35",\n    "posRK": "16",\n    "Player": "Jerry Jeudy",\n    "POS": "WR",\n    "TM": "CLE",\n    "PPR": "236.9",\n    "PPR/G": "13.9",\n    "PPR/OPP": "1.67",\n    "CSTY": "64.7",\n    "CLNG": "28.8",\n    "G": "17",\n    "OPP": "142",\n    "YDS(t)": "1229",\n    "TD(t)": "4",\n    "1D(t)": "57",\n    "LNG": "89",\n    "BP": "13",\n    "IMP(t)": "61",\n    "IMP%": "0.430",\n    "RecYDS": "1229",\n    "RecTD": "4",\n    "REC": "90",\n    "TGT": "142",\n    "YPT": "8.65",\n    "YPR": "13.66",\n    "YAC/REC": "4.34",\n    "Rec1D": "57",\n    "YPRR": "1.72",\n    "1DRR": "0.080",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "36",\n    "posRK": "3",\n    "Player": "George Kittle",\n    "POS": "TE",\n    "TM": "SF",\n    "PPR": "236.6",\n    "PPR/G": "15.8",\n    "PPR/OPP": "2.57",\n    "CSTY": "73.3",\n    "CLNG": "22.9",\n    "G": "15",\n    "OPP": "92",\n    "YDS(t)": "1106",\n    "TD(t)": "8",\n    "1D(t)": "50",\n    "LNG": "43",\n    "BP": "21",\n    "IMP(t)": "58",\n    "IMP%": "0.630",\n    "RecYDS": "1106",\n    "RecTD": "8",\n    "REC": "78",\n    "TGT": "92",\n    "YPT": "12.02",\n    "YPR": "14.18",\n    "YAC/REC": "6.56",\n    "Rec1D": "50",\n    "YPRR": "2.62",\n    "1DRR": "0.118",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "37",\n    "posRK": "4",\n    "Player": "Jonnu Smith",\n    "POS": "TE",\n    "TM": "MIA",\n    "PPR": "224.5",\n    "PPR/G": "13.2",\n    "PPR/OPP": "2.02",\n    "CSTY": "47.1",\n    "CLNG": "24.8",\n    "G": "17",\n    "OPP": "111",\n    "YDS(t)": "885",\n    "TD(t)": "8",\n    "1D(t)": "55",\n    "LNG": "38",\n    "BP": "9",\n    "IMP(t)": "63",\n    "IMP%": "0.568",\n    "RecYDS": "886",\n    "RecTD": "8",\n    "REC": "88",\n    "TGT": "109",\n    "YPT": "8.13",\n    "YPR": "10.07",\n    "YAC/REC": "5.92",\n    "Rec1D": "55",\n    "YPRR": "1.95",\n    "1DRR": "0.121",\n    "CAR": "2",\n    "RuYDS": "-1",\n    "YPC": "-0.50",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "38",\n    "posRK": "17",\n    "Player": "Tee Higgins",\n    "POS": "WR",\n    "TM": "CIN",\n    "PPR": "224.1",\n    "PPR/G": "18.7",\n    "PPR/OPP": "2.15",\n    "CSTY": "75.0",\n    "CLNG": "33.7",\n    "G": "12",\n    "OPP": "104",\n    "YDS(t)": "911",\n    "TD(t)": "10",\n    "1D(t)": "48",\n    "LNG": "80",\n    "BP": "12",\n    "IMP(t)": "58",\n    "IMP%": "0.558",\n    "RecYDS": "911",\n    "RecTD": "10",\n    "REC": "73",\n    "TGT": "104",\n    "YPT": "8.76",\n    "YPR": "12.48",\n    "YAC/REC": "3.07",\n    "Rec1D": "48",\n    "YPRR": "2.05",\n    "1DRR": "0.108",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "39",\n    "posRK": "18",\n    "Player": "David Montgomery",\n    "POS": "RB",\n    "TM": "DET",\n    "PPR": "219.6",\n    "PPR/G": "15.7",\n    "PPR/OPP": "0.99",\n    "CSTY": "78.6",\n    "CLNG": "22.2",\n    "G": "14",\n    "OPP": "222",\n    "YDS(t)": "1116",\n    "TD(t)": "12",\n    "1D(t)": "66",\n    "LNG": "40",\n    "BP": "11",\n    "IMP(t)": "78",\n    "IMP%": "0.351",\n    "RecYDS": "341",\n    "RecTD": "0",\n    "REC": "36",\n    "TGT": "37",\n    "YPT": "9.22",\n    "YPR": "9.47",\n    "YAC/REC": "10.08",\n    "Rec1D": "16",\n    "YPRR": "2.24",\n    "1DRR": "0.105",\n    "CAR": "185",\n    "RuYDS": "775",\n    "YPC": "4.19",\n    "RuTD": "12",\n    "Ru1D": "50",\n    "ELU": "0.445",\n    "MTF/A": "0.211",\n    "YCO/A": "3.12"\n  },\n  {\n    "RK": "40",\n    "posRK": "18",\n    "Player": "Tyreek Hill",\n    "POS": "WR",\n    "TM": "MIA",\n    "PPR": "218.2",\n    "PPR/G": "12.8",\n    "PPR/OPP": "1.69",\n    "CSTY": "47.1",\n    "CLNG": "24.8",\n    "G": "17",\n    "OPP": "129",\n    "YDS(t)": "1012",\n    "TD(t)": "6",\n    "1D(t)": "56",\n    "LNG": "64",\n    "BP": "11",\n    "IMP(t)": "62",\n    "IMP%": "0.481",\n    "RecYDS": "959",\n    "RecTD": "6",\n    "REC": "81",\n    "TGT": "121",\n    "YPT": "7.93",\n    "YPR": "11.84",\n    "YAC/REC": "3.54",\n    "Rec1D": "54",\n    "YPRR": "1.75",\n    "1DRR": "0.099",\n    "CAR": "8",\n    "RuYDS": "53",\n    "YPC": "6.63",\n    "RuTD": "0",\n    "Ru1D": "2",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "41",\n    "posRK": "19",\n    "Player": "A.J. Brown",\n    "POS": "WR",\n    "TM": "PHI",\n    "PPR": "216.9",\n    "PPR/G": "16.7",\n    "PPR/OPP": "2.28",\n    "CSTY": "69.2",\n    "CLNG": "24.1",\n    "G": "13",\n    "OPP": "95",\n    "YDS(t)": "1079",\n    "TD(t)": "7",\n    "1D(t)": "51",\n    "LNG": "67",\n    "BP": "17",\n    "IMP(t)": "58",\n    "IMP%": "0.611",\n    "RecYDS": "1079",\n    "RecTD": "7",\n    "REC": "67",\n    "TGT": "95",\n    "YPT": "11.36",\n    "YPR": "16.1",\n    "YAC/REC": "5.33",\n    "Rec1D": "51",\n    "YPRR": "2.99",\n    "1DRR": "0.141",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "42",\n    "posRK": "20",\n    "Player": "Jakobi Meyers",\n    "POS": "WR",\n    "TM": "LV",\n    "PPR": "216.0",\n    "PPR/G": "14.4",\n    "PPR/OPP": "1.69",\n    "CSTY": "60.0",\n    "CLNG": "22.9",\n    "G": "15",\n    "OPP": "128",\n    "YDS(t)": "1050",\n    "TD(t)": "4",\n    "1D(t)": "53",\n    "LNG": "43",\n    "BP": "17",\n    "IMP(t)": "57",\n    "IMP%": "0.445",\n    "RecYDS": "1027",\n    "RecTD": "4",\n    "REC": "87",\n    "TGT": "126",\n    "YPT": "8.15",\n    "YPR": "11.8",\n    "YAC/REC": "3.43",\n    "Rec1D": "52",\n    "YPRR": "1.76",\n    "1DRR": "0.089",\n    "CAR": "2",\n    "RuYDS": "23",\n    "YPC": "11.50",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "43",\n    "posRK": "21",\n    "Player": "Jordan Addison",\n    "POS": "WR",\n    "TM": "MIN",\n    "PPR": "212.5",\n    "PPR/G": "14.2",\n    "PPR/OPP": "2.24",\n    "CSTY": "53.3",\n    "CLNG": "30.8",\n    "G": "15",\n    "OPP": "95",\n    "YDS(t)": "895",\n    "TD(t)": "10",\n    "1D(t)": "40",\n    "LNG": "69",\n    "BP": "13",\n    "IMP(t)": "50",\n    "IMP%": "0.526",\n    "RecYDS": "875",\n    "RecTD": "9",\n    "REC": "63",\n    "TGT": "92",\n    "YPT": "9.51",\n    "YPR": "13.89",\n    "YAC/REC": "3.54",\n    "Rec1D": "39",\n    "YPRR": "1.74",\n    "1DRR": "0.077",\n    "CAR": "3",\n    "RuYDS": "20",\n    "YPC": "6.67",\n    "RuTD": "1",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "43",\n    "posRK": "19",\n    "Player": "D\'Andre Swift",\n    "POS": "RB",\n    "TM": "CHI",\n    "PPR": "212.5",\n    "PPR/G": "12.5",\n    "PPR/OPP": "0.70",\n    "CSTY": "47.1",\n    "CLNG": "23.8",\n    "G": "17",\n    "OPP": "303",\n    "YDS(t)": "1345",\n    "TD(t)": "6",\n    "1D(t)": "55",\n    "LNG": "56",\n    "BP": "10",\n    "IMP(t)": "61",\n    "IMP%": "0.201",\n    "RecYDS": "386",\n    "RecTD": "0",\n    "REC": "42",\n    "TGT": "50",\n    "YPT": "7.72",\n    "YPR": "9.19",\n    "YAC/REC": "9.95",\n    "Rec1D": "12",\n    "YPRR": "1.09",\n    "1DRR": "0.034",\n    "CAR": "253",\n    "RuYDS": "959",\n    "YPC": "3.79",\n    "RuTD": "6",\n    "Ru1D": "43",\n    "ELU": "0.335",\n    "MTF/A": "0.150",\n    "YCO/A": "2.46"\n  },\n  {\n    "RK": "45",\n    "posRK": "22",\n    "Player": "Jameson Williams",\n    "POS": "WR",\n    "TM": "DET",\n    "PPR": "212.2",\n    "PPR/G": "14.1",\n    "PPR/OPP": "2.14",\n    "CSTY": "60.0",\n    "CLNG": "25.0",\n    "G": "15",\n    "OPP": "99",\n    "YDS(t)": "1062",\n    "TD(t)": "8",\n    "1D(t)": "47",\n    "LNG": "82",\n    "BP": "17",\n    "IMP(t)": "55",\n    "IMP%": "0.556",\n    "RecYDS": "1001",\n    "RecTD": "7",\n    "REC": "58",\n    "TGT": "88",\n    "YPT": "11.38",\n    "YPR": "17.26",\n    "YAC/REC": "8.45",\n    "Rec1D": "42",\n    "YPRR": "2.1",\n    "1DRR": "0.088",\n    "CAR": "11",\n    "RuYDS": "61",\n    "YPC": "5.55",\n    "RuTD": "1",\n    "Ru1D": "5",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "46",\n    "posRK": "23",\n    "Player": "Nico Collins",\n    "POS": "WR",\n    "TM": "HOU",\n    "PPR": "210.6",\n    "PPR/G": "17.6",\n    "PPR/OPP": "2.13",\n    "CSTY": "83.3",\n    "CLNG": "26.9",\n    "G": "12",\n    "OPP": "99",\n    "YDS(t)": "1006",\n    "TD(t)": "7",\n    "1D(t)": "48",\n    "LNG": "67",\n    "BP": "14",\n    "IMP(t)": "55",\n    "IMP%": "0.556",\n    "RecYDS": "1006",\n    "RecTD": "7",\n    "REC": "68",\n    "TGT": "99",\n    "YPT": "10.16",\n    "YPR": "14.79",\n    "YAC/REC": "5.32",\n    "Rec1D": "48",\n    "YPRR": "2.87",\n    "1DRR": "0.137",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "47",\n    "posRK": "24",\n    "Player": "Jauan Jennings",\n    "POS": "WR",\n    "TM": "SF",\n    "PPR": "210.5",\n    "PPR/G": "14.0",\n    "PPR/OPP": "1.90",\n    "CSTY": "40.0",\n    "CLNG": "33.2",\n    "G": "15",\n    "OPP": "111",\n    "YDS(t)": "975",\n    "TD(t)": "6",\n    "1D(t)": "47",\n    "LNG": "68",\n    "BP": "12",\n    "IMP(t)": "53",\n    "IMP%": "0.477",\n    "RecYDS": "975",\n    "RecTD": "6",\n    "REC": "77",\n    "TGT": "111",\n    "YPT": "8.78",\n    "YPR": "12.66",\n    "YAC/REC": "3.1",\n    "Rec1D": "47",\n    "YPRR": "2.26",\n    "1DRR": "0.109",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "48",\n    "posRK": "25",\n    "Player": "Zay Flowers",\n    "POS": "WR",\n    "TM": "BAL",\n    "PPR": "209.5",\n    "PPR/G": "12.3",\n    "PPR/OPP": "1.73",\n    "CSTY": "35.3",\n    "CLNG": "24.7",\n    "G": "17",\n    "OPP": "121",\n    "YDS(t)": "1115",\n    "TD(t)": "4",\n    "1D(t)": "49",\n    "LNG": "53",\n    "BP": "19",\n    "IMP(t)": "53",\n    "IMP%": "0.438",\n    "RecYDS": "1059",\n    "RecTD": "4",\n    "REC": "74",\n    "TGT": "112",\n    "YPT": "9.46",\n    "YPR": "14.31",\n    "YAC/REC": "6.31",\n    "Rec1D": "48",\n    "YPRR": "2.25",\n    "1DRR": "0.102",\n    "CAR": "9",\n    "RuYDS": "56",\n    "YPC": "6.22",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "49",\n    "posRK": "26",\n    "Player": "Puka Nacua",\n    "POS": "WR",\n    "TM": "LAR",\n    "PPR": "206.6",\n    "PPR/G": "18.8",\n    "PPR/OPP": "1.81",\n    "CSTY": "81.8",\n    "CLNG": "30.0",\n    "G": "11",\n    "OPP": "114",\n    "YDS(t)": "1036",\n    "TD(t)": "4",\n    "1D(t)": "49",\n    "LNG": "79",\n    "BP": "11",\n    "IMP(t)": "53",\n    "IMP%": "0.465",\n    "RecYDS": "990",\n    "RecTD": "3",\n    "REC": "79",\n    "TGT": "103",\n    "YPT": "9.61",\n    "YPR": "12.53",\n    "YAC/REC": "6.58",\n    "Rec1D": "47",\n    "YPRR": "3.56",\n    "1DRR": "0.169",\n    "CAR": "11",\n    "RuYDS": "46",\n    "YPC": "4.18",\n    "RuTD": "1",\n    "Ru1D": "2",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "50",\n    "posRK": "20",\n    "Player": "Rachaad White",\n    "POS": "RB",\n    "TM": "TB",\n    "PPR": "205.6",\n    "PPR/G": "12.9",\n    "PPR/OPP": "1.03",\n    "CSTY": "50.0",\n    "CLNG": "24.3",\n    "G": "16",\n    "OPP": "199",\n    "YDS(t)": "1006",\n    "TD(t)": "9",\n    "1D(t)": "53",\n    "LNG": "35",\n    "BP": "10",\n    "IMP(t)": "62",\n    "IMP%": "0.312",\n    "RecYDS": "393",\n    "RecTD": "6",\n    "REC": "51",\n    "TGT": "55",\n    "YPT": "7.15",\n    "YPR": "7.71",\n    "YAC/REC": "10.14",\n    "Rec1D": "18",\n    "YPRR": "1.32",\n    "1DRR": "0.060",\n    "CAR": "144",\n    "RuYDS": "613",\n    "YPC": "4.26",\n    "RuTD": "3",\n    "Ru1D": "35",\n    "ELU": "0.401",\n    "MTF/A": "0.167",\n    "YCO/A": "3.13"\n  },\n  {\n    "RK": "51",\n    "posRK": "21",\n    "Player": "Najee Harris",\n    "POS": "RB",\n    "TM": "PIT",\n    "PPR": "204.6",\n    "PPR/G": "12.0",\n    "PPR/OPP": "0.66",\n    "CSTY": "41.2",\n    "CLNG": "20.4",\n    "G": "17",\n    "OPP": "309",\n    "YDS(t)": "1326",\n    "TD(t)": "6",\n    "1D(t)": "64",\n    "LNG": "36",\n    "BP": "13",\n    "IMP(t)": "70",\n    "IMP%": "0.227",\n    "RecYDS": "283",\n    "RecTD": "0",\n    "REC": "36",\n    "TGT": "46",\n    "YPT": "6.15",\n    "YPR": "7.86",\n    "YAC/REC": "9.25",\n    "Rec1D": "13",\n    "YPRR": "1.29",\n    "1DRR": "0.059",\n    "CAR": "263",\n    "RuYDS": "1043",\n    "YPC": "3.97",\n    "RuTD": "6",\n    "Ru1D": "51",\n    "ELU": "0.457",\n    "MTF/A": "0.240",\n    "YCO/A": "2.90"\n  },\n  {\n    "RK": "52",\n    "posRK": "22",\n    "Player": "Tony Pollard",\n    "POS": "RB",\n    "TM": "TEN",\n    "PPR": "202.7",\n    "PPR/G": "12.7",\n    "PPR/OPP": "0.64",\n    "CSTY": "50.0",\n    "CLNG": "19.7",\n    "G": "16",\n    "OPP": "315",\n    "YDS(t)": "1317",\n    "TD(t)": "5",\n    "1D(t)": "62",\n    "LNG": "41",\n    "BP": "8",\n    "IMP(t)": "67",\n    "IMP%": "0.213",\n    "RecYDS": "238",\n    "RecTD": "0",\n    "REC": "41",\n    "TGT": "55",\n    "YPT": "4.33",\n    "YPR": "5.8",\n    "YAC/REC": "5.76",\n    "Rec1D": "9",\n    "YPRR": "0.79",\n    "1DRR": "0.030",\n    "CAR": "260",\n    "RuYDS": "1079",\n    "YPC": "4.15",\n    "RuTD": "5",\n    "Ru1D": "53",\n    "ELU": "0.405",\n    "MTF/A": "0.150",\n    "YCO/A": "3.40"\n  },\n  {\n    "RK": "53",\n    "posRK": "23",\n    "Player": "Rico Dowdle",\n    "POS": "RB",\n    "TM": "DAL",\n    "PPR": "201.8",\n    "PPR/G": "12.6",\n    "PPR/OPP": "0.71",\n    "CSTY": "50.0",\n    "CLNG": "20.8",\n    "G": "16",\n    "OPP": "284",\n    "YDS(t)": "1328",\n    "TD(t)": "5",\n    "1D(t)": "66",\n    "LNG": "27",\n    "BP": "23",\n    "IMP(t)": "71",\n    "IMP%": "0.250",\n    "RecYDS": "249",\n    "RecTD": "3",\n    "REC": "39",\n    "TGT": "49",\n    "YPT": "5.08",\n    "YPR": "6.38",\n    "YAC/REC": "7",\n    "Rec1D": "13",\n    "YPRR": "0.88",\n    "1DRR": "0.046",\n    "CAR": "235",\n    "RuYDS": "1079",\n    "YPC": "4.59",\n    "RuTD": "2",\n    "Ru1D": "53",\n    "ELU": "0.437",\n    "MTF/A": "0.191",\n    "YCO/A": "3.28"\n  },\n  {\n    "RK": "54",\n    "posRK": "27",\n    "Player": "Calvin Ridley",\n    "POS": "WR",\n    "TM": "TEN",\n    "PPR": "200.5",\n    "PPR/G": "11.8",\n    "PPR/OPP": "1.67",\n    "CSTY": "47.1",\n    "CLNG": "24.9",\n    "G": "17",\n    "OPP": "120",\n    "YDS(t)": "1065",\n    "TD(t)": "5",\n    "1D(t)": "43",\n    "LNG": "63",\n    "BP": "19",\n    "IMP(t)": "48",\n    "IMP%": "0.400",\n    "RecYDS": "1017",\n    "RecTD": "4",\n    "REC": "64",\n    "TGT": "113",\n    "YPT": "9",\n    "YPR": "15.89",\n    "YAC/REC": "3.64",\n    "Rec1D": "40",\n    "YPRR": "1.86",\n    "1DRR": "0.073",\n    "CAR": "7",\n    "RuYDS": "48",\n    "YPC": "6.86",\n    "RuTD": "1",\n    "Ru1D": "3",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "55",\n    "posRK": "28",\n    "Player": "DeVonta Smith",\n    "POS": "WR",\n    "TM": "PHI",\n    "PPR": "199.4",\n    "PPR/G": "15.3",\n    "PPR/OPP": "2.35",\n    "CSTY": "69.2",\n    "CLNG": "26.2",\n    "G": "13",\n    "OPP": "85",\n    "YDS(t)": "834",\n    "TD(t)": "8",\n    "1D(t)": "42",\n    "LNG": "49",\n    "BP": "12",\n    "IMP(t)": "50",\n    "IMP%": "0.588",\n    "RecYDS": "833",\n    "RecTD": "8",\n    "REC": "68",\n    "TGT": "84",\n    "YPT": "9.92",\n    "YPR": "12.25",\n    "YAC/REC": "4.29",\n    "Rec1D": "42",\n    "YPRR": "2.11",\n    "1DRR": "0.106",\n    "CAR": "1",\n    "RuYDS": "1",\n    "YPC": "1.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "56",\n    "posRK": "29",\n    "Player": "Jayden Reed",\n    "POS": "WR",\n    "TM": "GB",\n    "PPR": "199.0",\n    "PPR/G": "11.7",\n    "PPR/OPP": "2.09",\n    "CSTY": "35.3",\n    "CLNG": "26.6",\n    "G": "17",\n    "OPP": "95",\n    "YDS(t)": "1020",\n    "TD(t)": "7",\n    "1D(t)": "36",\n    "LNG": "70",\n    "BP": "18",\n    "IMP(t)": "43",\n    "IMP%": "0.453",\n    "RecYDS": "857",\n    "RecTD": "6",\n    "REC": "55",\n    "TGT": "75",\n    "YPT": "11.43",\n    "YPR": "15.58",\n    "YAC/REC": "7.11",\n    "Rec1D": "29",\n    "YPRR": "2.2",\n    "1DRR": "0.075",\n    "CAR": "20",\n    "RuYDS": "163",\n    "YPC": "8.15",\n    "RuTD": "1",\n    "Ru1D": "7",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "57",\n    "posRK": "30",\n    "Player": "Marvin Harrison Jr.",\n    "POS": "WR",\n    "TM": "ARI",\n    "PPR": "198.5",\n    "PPR/G": "11.7",\n    "PPR/OPP": "1.74",\n    "CSTY": "47.1",\n    "CLNG": "23.2",\n    "G": "17",\n    "OPP": "114",\n    "YDS(t)": "885",\n    "TD(t)": "8",\n    "1D(t)": "43",\n    "LNG": "42",\n    "BP": "14",\n    "IMP(t)": "51",\n    "IMP%": "0.447",\n    "RecYDS": "885",\n    "RecTD": "8",\n    "REC": "62",\n    "TGT": "114",\n    "YPT": "7.76",\n    "YPR": "14.27",\n    "YAC/REC": "2.4",\n    "Rec1D": "43",\n    "YPRR": "1.63",\n    "1DRR": "0.079",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "58",\n    "posRK": "5",\n    "Player": "Travis Kelce",\n    "POS": "TE",\n    "TM": "KC",\n    "PPR": "197.4",\n    "PPR/G": "12.3",\n    "PPR/OPP": "1.50",\n    "CSTY": "50.0",\n    "CLNG": "23.8",\n    "G": "16",\n    "OPP": "132",\n    "YDS(t)": "824",\n    "TD(t)": "3",\n    "1D(t)": "46",\n    "LNG": "57",\n    "BP": "4",\n    "IMP(t)": "49",\n    "IMP%": "0.371",\n    "RecYDS": "823",\n    "RecTD": "3",\n    "REC": "97",\n    "TGT": "131",\n    "YPT": "6.28",\n    "YPR": "8.48",\n    "YAC/REC": "3.53",\n    "Rec1D": "46",\n    "YPRR": "1.43",\n    "1DRR": "0.080",\n    "CAR": "1",\n    "RuYDS": "1",\n    "YPC": "1.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "59",\n    "posRK": "31",\n    "Player": "D.K. Metcalf",\n    "POS": "WR",\n    "TM": "SEA",\n    "PPR": "195.2",\n    "PPR/G": "13.0",\n    "PPR/OPP": "1.81",\n    "CSTY": "46.7",\n    "CLNG": "23.1",\n    "G": "15",\n    "OPP": "108",\n    "YDS(t)": "992",\n    "TD(t)": "5",\n    "1D(t)": "35",\n    "LNG": "71",\n    "BP": "20",\n    "IMP(t)": "40",\n    "IMP%": "0.370",\n    "RecYDS": "992",\n    "RecTD": "5",\n    "REC": "66",\n    "TGT": "108",\n    "YPT": "9.19",\n    "YPR": "15.03",\n    "YAC/REC": "3.97",\n    "Rec1D": "35",\n    "YPRR": "1.81",\n    "1DRR": "0.064",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "60",\n    "posRK": "32",\n    "Player": "Darnell Mooney",\n    "POS": "WR",\n    "TM": "ATL",\n    "PPR": "193.2",\n    "PPR/G": "12.1",\n    "PPR/OPP": "1.93",\n    "CSTY": "50.0",\n    "CLNG": "23.8",\n    "G": "16",\n    "OPP": "100",\n    "YDS(t)": "992",\n    "TD(t)": "5",\n    "1D(t)": "48",\n    "LNG": "49",\n    "BP": "21",\n    "IMP(t)": "53",\n    "IMP%": "0.530",\n    "RecYDS": "992",\n    "RecTD": "5",\n    "REC": "64",\n    "TGT": "100",\n    "YPT": "9.92",\n    "YPR": "15.5",\n    "YAC/REC": "4.17",\n    "Rec1D": "48",\n    "YPRR": "1.88",\n    "1DRR": "0.091",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "61",\n    "posRK": "24",\n    "Player": "J.K. Dobbins",\n    "POS": "RB",\n    "TM": "LAC",\n    "PPR": "191.8",\n    "PPR/G": "14.8",\n    "PPR/OPP": "0.83",\n    "CSTY": "53.8",\n    "CLNG": "22.5",\n    "G": "13",\n    "OPP": "231",\n    "YDS(t)": "1058",\n    "TD(t)": "9",\n    "1D(t)": "53",\n    "LNG": "61",\n    "BP": "5",\n    "IMP(t)": "62",\n    "IMP%": "0.268",\n    "RecYDS": "153",\n    "RecTD": "0",\n    "REC": "32",\n    "TGT": "36",\n    "YPT": "4.25",\n    "YPR": "4.78",\n    "YAC/REC": "6.41",\n    "Rec1D": "6",\n    "YPRR": "0.72",\n    "1DRR": "0.028",\n    "CAR": "195",\n    "RuYDS": "905",\n    "YPC": "4.64",\n    "RuTD": "9",\n    "Ru1D": "47",\n    "ELU": "0.418",\n    "MTF/A": "0.190",\n    "YCO/A": "3.04"\n  },\n  {\n    "RK": "62",\n    "posRK": "6",\n    "Player": "Mark Andrews",\n    "POS": "TE",\n    "TM": "BAL",\n    "PPR": "188.8",\n    "PPR/G": "11.1",\n    "PPR/OPP": "2.59",\n    "CSTY": "52.9",\n    "CLNG": "19.3",\n    "G": "17",\n    "OPP": "73",\n    "YDS(t)": "678",\n    "TD(t)": "11",\n    "1D(t)": "42",\n    "LNG": "47",\n    "BP": "10",\n    "IMP(t)": "53",\n    "IMP%": "0.726",\n    "RecYDS": "673",\n    "RecTD": "11",\n    "REC": "55",\n    "TGT": "69",\n    "YPT": "9.75",\n    "YPR": "12.24",\n    "YAC/REC": "3.58",\n    "Rec1D": "39",\n    "YPRR": "1.88",\n    "1DRR": "0.109",\n    "CAR": "4",\n    "RuYDS": "5",\n    "YPC": "1.25",\n    "RuTD": "0",\n    "Ru1D": "3",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "63",\n    "posRK": "33",\n    "Player": "Xavier Worthy",\n    "POS": "WR",\n    "TM": "KC",\n    "PPR": "187.2",\n    "PPR/G": "11.0",\n    "PPR/OPP": "1.66",\n    "CSTY": "41.2",\n    "CLNG": "21.4",\n    "G": "17",\n    "OPP": "113",\n    "YDS(t)": "742",\n    "TD(t)": "9",\n    "1D(t)": "40",\n    "LNG": "56",\n    "BP": "10",\n    "IMP(t)": "49",\n    "IMP%": "0.434",\n    "RecYDS": "638",\n    "RecTD": "6",\n    "REC": "59",\n    "TGT": "93",\n    "YPT": "6.86",\n    "YPR": "10.81",\n    "YAC/REC": "7.05",\n    "Rec1D": "36",\n    "YPRR": "1.24",\n    "1DRR": "0.070",\n    "CAR": "20",\n    "RuYDS": "104",\n    "YPC": "5.20",\n    "RuTD": "3",\n    "Ru1D": "4",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "64",\n    "posRK": "34",\n    "Player": "Keenan Allen",\n    "POS": "WR",\n    "TM": "CHI",\n    "PPR": "186.4",\n    "PPR/G": "12.4",\n    "PPR/OPP": "1.59",\n    "CSTY": "33.3",\n    "CLNG": "25.7",\n    "G": "15",\n    "OPP": "117",\n    "YDS(t)": "744",\n    "TD(t)": "7",\n    "1D(t)": "43",\n    "LNG": "44",\n    "BP": "11",\n    "IMP(t)": "50",\n    "IMP%": "0.427",\n    "RecYDS": "744",\n    "RecTD": "7",\n    "REC": "70",\n    "TGT": "117",\n    "YPT": "6.36",\n    "YPR": "10.63",\n    "YAC/REC": "3.44",\n    "Rec1D": "43",\n    "YPRR": "1.36",\n    "1DRR": "0.079",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "65",\n    "posRK": "25",\n    "Player": "Tyrone Tracy",\n    "POS": "RB",\n    "TM": "NYG",\n    "PPR": "186.3",\n    "PPR/G": "11.0",\n    "PPR/OPP": "0.77",\n    "CSTY": "41.2",\n    "CLNG": "21.7",\n    "G": "17",\n    "OPP": "242",\n    "YDS(t)": "1123",\n    "TD(t)": "6",\n    "1D(t)": "52",\n    "LNG": "42",\n    "BP": "3",\n    "IMP(t)": "58",\n    "IMP%": "0.240",\n    "RecYDS": "284",\n    "RecTD": "1",\n    "REC": "38",\n    "TGT": "50",\n    "YPT": "5.68",\n    "YPR": "7.47",\n    "YAC/REC": "7.5",\n    "Rec1D": "13",\n    "YPRR": "0.92",\n    "1DRR": "0.042",\n    "CAR": "192",\n    "RuYDS": "839",\n    "YPC": "4.37",\n    "RuTD": "5",\n    "Ru1D": "39",\n    "ELU": "0.390",\n    "MTF/A": "0.177",\n    "YCO/A": "2.84"\n  },\n  {\n    "RK": "66",\n    "posRK": "26",\n    "Player": "Zach Charbonnet",\n    "POS": "RB",\n    "TM": "SEA",\n    "PPR": "183.7",\n    "PPR/G": "10.8",\n    "PPR/OPP": "1.01",\n    "CSTY": "35.3",\n    "CLNG": "27.3",\n    "G": "17",\n    "OPP": "182",\n    "YDS(t)": "877",\n    "TD(t)": "9",\n    "1D(t)": "40",\n    "LNG": "50",\n    "BP": "10",\n    "IMP(t)": "49",\n    "IMP%": "0.269",\n    "RecYDS": "308",\n    "RecTD": "1",\n    "REC": "42",\n    "TGT": "47",\n    "YPT": "6.55",\n    "YPR": "7.33",\n    "YAC/REC": "8.21",\n    "Rec1D": "7",\n    "YPRR": "1.08",\n    "1DRR": "0.025",\n    "CAR": "135",\n    "RuYDS": "569",\n    "YPC": "4.21",\n    "RuTD": "8",\n    "Ru1D": "33",\n    "ELU": "0.488",\n    "MTF/A": "0.237",\n    "YCO/A": "3.35"\n  },\n  {\n    "RK": "67",\n    "posRK": "35",\n    "Player": "Josh Downs",\n    "POS": "WR",\n    "TM": "IND",\n    "PPR": "183.5",\n    "PPR/G": "13.1",\n    "PPR/OPP": "1.78",\n    "CSTY": "64.3",\n    "CLNG": "21.3",\n    "G": "14",\n    "OPP": "103",\n    "YDS(t)": "815",\n    "TD(t)": "5",\n    "1D(t)": "41",\n    "LNG": "60",\n    "BP": "12",\n    "IMP(t)": "46",\n    "IMP%": "0.447",\n    "RecYDS": "803",\n    "RecTD": "5",\n    "REC": "72",\n    "TGT": "102",\n    "YPT": "7.87",\n    "YPR": "11.15",\n    "YAC/REC": "5.6",\n    "Rec1D": "40",\n    "YPRR": "2.2",\n    "1DRR": "0.110",\n    "CAR": "1",\n    "RuYDS": "12",\n    "YPC": "12.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "68",\n    "posRK": "36",\n    "Player": "Wan\'Dale Robinson",\n    "POS": "WR",\n    "TM": "NYG",\n    "PPR": "182.7",\n    "PPR/G": "10.7",\n    "PPR/OPP": "1.35",\n    "CSTY": "35.3",\n    "CLNG": "17.4",\n    "G": "17",\n    "OPP": "135",\n    "YDS(t)": "717",\n    "TD(t)": "3",\n    "1D(t)": "37",\n    "LNG": "50",\n    "BP": "6",\n    "IMP(t)": "40",\n    "IMP%": "0.296",\n    "RecYDS": "699",\n    "RecTD": "3",\n    "REC": "93",\n    "TGT": "132",\n    "YPT": "5.3",\n    "YPR": "7.52",\n    "YAC/REC": "4.02",\n    "Rec1D": "36",\n    "YPRR": "1.21",\n    "1DRR": "0.062",\n    "CAR": "3",\n    "RuYDS": "18",\n    "YPC": "6.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "69",\n    "posRK": "37",\n    "Player": "Khalil Shakir",\n    "POS": "WR",\n    "TM": "BUF",\n    "PPR": "182.5",\n    "PPR/G": "12.2",\n    "PPR/OPP": "1.88",\n    "CSTY": "46.7",\n    "CLNG": "20.2",\n    "G": "15",\n    "OPP": "97",\n    "YDS(t)": "825",\n    "TD(t)": "4",\n    "1D(t)": "35",\n    "LNG": "55",\n    "BP": "11",\n    "IMP(t)": "39",\n    "IMP%": "0.402",\n    "RecYDS": "821",\n    "RecTD": "4",\n    "REC": "76",\n    "TGT": "95",\n    "YPT": "8.64",\n    "YPR": "10.8",\n    "YAC/REC": "7.96",\n    "Rec1D": "35",\n    "YPRR": "2.15",\n    "1DRR": "0.092",\n    "CAR": "2",\n    "RuYDS": "4",\n    "YPC": "2.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "70",\n    "posRK": "27",\n    "Player": "Kenneth Walker III",\n    "POS": "RB",\n    "TM": "SEA",\n    "PPR": "181.2",\n    "PPR/G": "16.5",\n    "PPR/OPP": "0.88",\n    "CSTY": "81.8",\n    "CLNG": "25.9",\n    "G": "11",\n    "OPP": "205",\n    "YDS(t)": "872",\n    "TD(t)": "8",\n    "1D(t)": "47",\n    "LNG": "56",\n    "BP": "3",\n    "IMP(t)": "55",\n    "IMP%": "0.268",\n    "RecYDS": "299",\n    "RecTD": "1",\n    "REC": "46",\n    "TGT": "52",\n    "YPT": "5.75",\n    "YPR": "6.5",\n    "YAC/REC": "7.98",\n    "Rec1D": "19",\n    "YPRR": "1.33",\n    "1DRR": "0.085",\n    "CAR": "153",\n    "RuYDS": "573",\n    "YPC": "3.75",\n    "RuTD": "7",\n    "Ru1D": "28",\n    "ELU": "0.627",\n    "MTF/A": "0.399",\n    "YCO/A": "3.05"\n  },\n  {\n    "RK": "71",\n    "posRK": "28",\n    "Player": "Rhamondre Stevenson",\n    "POS": "RB",\n    "TM": "NE",\n    "PPR": "177.9",\n    "PPR/G": "11.9",\n    "PPR/OPP": "0.72",\n    "CSTY": "53.3",\n    "CLNG": "21.8",\n    "G": "15",\n    "OPP": "246",\n    "YDS(t)": "969",\n    "TD(t)": "8",\n    "1D(t)": "49",\n    "LNG": "45",\n    "BP": "6",\n    "IMP(t)": "57",\n    "IMP%": "0.232",\n    "RecYDS": "168",\n    "RecTD": "1",\n    "REC": "33",\n    "TGT": "39",\n    "YPT": "4.31",\n    "YPR": "5.09",\n    "YAC/REC": "7.39",\n    "Rec1D": "8",\n    "YPRR": "0.62",\n    "1DRR": "0.029",\n    "CAR": "207",\n    "RuYDS": "801",\n    "YPC": "3.87",\n    "RuTD": "7",\n    "Ru1D": "41",\n    "ELU": "0.416",\n    "MTF/A": "0.198",\n    "YCO/A": "2.90"\n  },\n  {\n    "RK": "72",\n    "posRK": "38",\n    "Player": "Cooper Kupp",\n    "POS": "WR",\n    "TM": "LAR",\n    "PPR": "175.0",\n    "PPR/G": "14.6",\n    "PPR/OPP": "1.77",\n    "CSTY": "58.3",\n    "CLNG": "27.3",\n    "G": "12",\n    "OPP": "99",\n    "YDS(t)": "720",\n    "TD(t)": "6",\n    "1D(t)": "29",\n    "LNG": "49",\n    "BP": "14",\n    "IMP(t)": "35",\n    "IMP%": "0.354",\n    "RecYDS": "710",\n    "RecTD": "6",\n    "REC": "67",\n    "TGT": "97",\n    "YPT": "7.32",\n    "YPR": "10.6",\n    "YAC/REC": "3.97",\n    "Rec1D": "28",\n    "YPRR": "1.99",\n    "1DRR": "0.078",\n    "CAR": "2",\n    "RuYDS": "10",\n    "YPC": "5.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "73",\n    "posRK": "39",\n    "Player": "Quentin Johnston",\n    "POS": "WR",\n    "TM": "LAC",\n    "PPR": "174.7",\n    "PPR/G": "11.6",\n    "PPR/OPP": "1.92",\n    "CSTY": "46.7",\n    "CLNG": "25.2",\n    "G": "15",\n    "OPP": "91",\n    "YDS(t)": "717",\n    "TD(t)": "8",\n    "1D(t)": "32",\n    "LNG": "44",\n    "BP": "8",\n    "IMP(t)": "40",\n    "IMP%": "0.440",\n    "RecYDS": "711",\n    "RecTD": "8",\n    "REC": "55",\n    "TGT": "88",\n    "YPT": "8.08",\n    "YPR": "12.93",\n    "YAC/REC": "5.69",\n    "Rec1D": "32",\n    "YPRR": "1.77",\n    "1DRR": "0.080",\n    "CAR": "3",\n    "RuYDS": "6",\n    "YPC": "2.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "74",\n    "posRK": "7",\n    "Player": "Sam LaPorta",\n    "POS": "TE",\n    "TM": "DET",\n    "PPR": "174.6",\n    "PPR/G": "10.9",\n    "PPR/OPP": "2.24",\n    "CSTY": "50.0",\n    "CLNG": "17.8",\n    "G": "16",\n    "OPP": "78",\n    "YDS(t)": "726",\n    "TD(t)": "7",\n    "1D(t)": "39",\n    "LNG": "52",\n    "BP": "8",\n    "IMP(t)": "46",\n    "IMP%": "0.590",\n    "RecYDS": "726",\n    "RecTD": "7",\n    "REC": "60",\n    "TGT": "78",\n    "YPT": "9.31",\n    "YPR": "12.1",\n    "YAC/REC": "5.77",\n    "Rec1D": "39",\n    "YPRR": "1.61",\n    "1DRR": "0.086",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "74",\n    "posRK": "40",\n    "Player": "Rashod Bateman",\n    "POS": "WR",\n    "TM": "BAL",\n    "PPR": "174.6",\n    "PPR/G": "10.3",\n    "PPR/OPP": "2.61",\n    "CSTY": "35.3",\n    "CLNG": "21.2",\n    "G": "17",\n    "OPP": "67",\n    "YDS(t)": "756",\n    "TD(t)": "9",\n    "1D(t)": "35",\n    "LNG": "63",\n    "BP": "12",\n    "IMP(t)": "44",\n    "IMP%": "0.657",\n    "RecYDS": "756",\n    "RecTD": "9",\n    "REC": "45",\n    "TGT": "67",\n    "YPT": "11.28",\n    "YPR": "16.8",\n    "YAC/REC": "4.13",\n    "Rec1D": "35",\n    "YPRR": "1.69",\n    "1DRR": "0.078",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "76",\n    "posRK": "8",\n    "Player": "Zach Ertz",\n    "POS": "TE",\n    "TM": "WAS",\n    "PPR": "173.4",\n    "PPR/G": "10.2",\n    "PPR/OPP": "1.99",\n    "CSTY": "41.2",\n    "CLNG": "19.2",\n    "G": "17",\n    "OPP": "87",\n    "YDS(t)": "654",\n    "TD(t)": "7",\n    "1D(t)": "38",\n    "LNG": "49",\n    "BP": "7",\n    "IMP(t)": "45",\n    "IMP%": "0.517",\n    "RecYDS": "654",\n    "RecTD": "7",\n    "REC": "66",\n    "TGT": "87",\n    "YPT": "7.52",\n    "YPR": "9.91",\n    "YAC/REC": "3.02",\n    "Rec1D": "38",\n    "YPRR": "1.3",\n    "1DRR": "0.075",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "77",\n    "posRK": "9",\n    "Player": "Pat Freiermuth",\n    "POS": "TE",\n    "TM": "PIT",\n    "PPR": "172.3",\n    "PPR/G": "10.1",\n    "PPR/OPP": "2.33",\n    "CSTY": "29.4",\n    "CLNG": "19.3",\n    "G": "17",\n    "OPP": "74",\n    "YDS(t)": "653",\n    "TD(t)": "7",\n    "1D(t)": "32",\n    "LNG": "65",\n    "BP": "11",\n    "IMP(t)": "39",\n    "IMP%": "0.527",\n    "RecYDS": "653",\n    "RecTD": "7",\n    "REC": "65",\n    "TGT": "74",\n    "YPT": "8.82",\n    "YPR": "10.05",\n    "YAC/REC": "4.32",\n    "Rec1D": "32",\n    "YPRR": "1.46",\n    "1DRR": "0.071",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "78",\n    "posRK": "41",\n    "Player": "Michael Pittman Jr.",\n    "POS": "WR",\n    "TM": "IND",\n    "PPR": "167.8",\n    "PPR/G": "10.5",\n    "PPR/OPP": "1.58",\n    "CSTY": "37.5",\n    "CLNG": "19.6",\n    "G": "16",\n    "OPP": "106",\n    "YDS(t)": "808",\n    "TD(t)": "3",\n    "1D(t)": "35",\n    "LNG": "52",\n    "BP": "9",\n    "IMP(t)": "38",\n    "IMP%": "0.358",\n    "RecYDS": "808",\n    "RecTD": "3",\n    "REC": "69",\n    "TGT": "106",\n    "YPT": "7.62",\n    "YPR": "11.71",\n    "YAC/REC": "3.78",\n    "Rec1D": "35",\n    "YPRR": "1.68",\n    "1DRR": "0.073",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "79",\n    "posRK": "42",\n    "Player": "George Pickens",\n    "POS": "WR",\n    "TM": "PIT",\n    "PPR": "166.4",\n    "PPR/G": "11.9",\n    "PPR/OPP": "1.63",\n    "CSTY": "42.9",\n    "CLNG": "20.3",\n    "G": "14",\n    "OPP": "102",\n    "YDS(t)": "894",\n    "TD(t)": "3",\n    "1D(t)": "37",\n    "LNG": "69",\n    "BP": "13",\n    "IMP(t)": "40",\n    "IMP%": "0.392",\n    "RecYDS": "900",\n    "RecTD": "3",\n    "REC": "59",\n    "TGT": "100",\n    "YPT": "9",\n    "YPR": "15.25",\n    "YAC/REC": "3.97",\n    "Rec1D": "37",\n    "YPRR": "2.06",\n    "1DRR": "0.085",\n    "CAR": "2",\n    "RuYDS": "-6",\n    "YPC": "-3.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "80",\n    "posRK": "29",\n    "Player": "Brian Robinson",\n    "POS": "RB",\n    "TM": "WAS",\n    "PPR": "163.8",\n    "PPR/G": "11.7",\n    "PPR/OPP": "0.78",\n    "CSTY": "50.0",\n    "CLNG": "18.7",\n    "G": "14",\n    "OPP": "211",\n    "YDS(t)": "958",\n    "TD(t)": "8",\n    "1D(t)": "52",\n    "LNG": "33",\n    "BP": "2",\n    "IMP(t)": "60",\n    "IMP%": "0.284",\n    "RecYDS": "159",\n    "RecTD": "0",\n    "REC": "20",\n    "TGT": "24",\n    "YPT": "6.63",\n    "YPR": "7.95",\n    "YAC/REC": "9.3",\n    "Rec1D": "5",\n    "YPRR": "0.85",\n    "1DRR": "0.027",\n    "CAR": "187",\n    "RuYDS": "799",\n    "YPC": "4.27",\n    "RuTD": "8",\n    "Ru1D": "47",\n    "ELU": "0.385",\n    "MTF/A": "0.155",\n    "YCO/A": "3.07"\n  },\n  {\n    "RK": "81",\n    "posRK": "10",\n    "Player": "Tucker Kraft",\n    "POS": "TE",\n    "TM": "GB",\n    "PPR": "163.3",\n    "PPR/G": "9.6",\n    "PPR/OPP": "2.40",\n    "CSTY": "35.3",\n    "CLNG": "19.6",\n    "G": "17",\n    "OPP": "68",\n    "YDS(t)": "713",\n    "TD(t)": "7",\n    "1D(t)": "33",\n    "LNG": "55",\n    "BP": "7",\n    "IMP(t)": "40",\n    "IMP%": "0.588",\n    "RecYDS": "707",\n    "RecTD": "7",\n    "REC": "50",\n    "TGT": "65",\n    "YPT": "10.88",\n    "YPR": "14.14",\n    "YAC/REC": "9.3",\n    "Rec1D": "30",\n    "YPRR": "1.61",\n    "1DRR": "0.068",\n    "CAR": "3",\n    "RuYDS": "6",\n    "YPC": "2.00",\n    "RuTD": "0",\n    "Ru1D": "3",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "82",\n    "posRK": "30",\n    "Player": "Javonte Williams",\n    "POS": "RB",\n    "TM": "DEN",\n    "PPR": "161.9",\n    "PPR/G": "9.5",\n    "PPR/OPP": "0.79",\n    "CSTY": "23.5",\n    "CLNG": "20.3",\n    "G": "17",\n    "OPP": "205",\n    "YDS(t)": "859",\n    "TD(t)": "4",\n    "1D(t)": "44",\n    "LNG": "34",\n    "BP": "8",\n    "IMP(t)": "48",\n    "IMP%": "0.234",\n    "RecYDS": "346",\n    "RecTD": "0",\n    "REC": "52",\n    "TGT": "66",\n    "YPT": "5.24",\n    "YPR": "6.65",\n    "YAC/REC": "7.67",\n    "Rec1D": "14",\n    "YPRR": "1.22",\n    "1DRR": "0.049",\n    "CAR": "139",\n    "RuYDS": "513",\n    "YPC": "3.69",\n    "RuTD": "4",\n    "Ru1D": "30",\n    "ELU": "0.330",\n    "MTF/A": "0.151",\n    "YCO/A": "2.38"\n  },\n  {\n    "RK": "83",\n    "posRK": "43",\n    "Player": "Alec Pierce",\n    "POS": "WR",\n    "TM": "IND",\n    "PPR": "161.4",\n    "PPR/G": "10.1",\n    "PPR/OPP": "2.45",\n    "CSTY": "37.5",\n    "CLNG": "22.7",\n    "G": "16",\n    "OPP": "66",\n    "YDS(t)": "824",\n    "TD(t)": "7",\n    "1D(t)": "32",\n    "LNG": "52",\n    "BP": "14",\n    "IMP(t)": "39",\n    "IMP%": "0.591",\n    "RecYDS": "824",\n    "RecTD": "7",\n    "REC": "37",\n    "TGT": "66",\n    "YPT": "12.48",\n    "YPR": "22.27",\n    "YAC/REC": "3.19",\n    "Rec1D": "32",\n    "YPRR": "1.82",\n    "1DRR": "0.071",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "84",\n    "posRK": "44",\n    "Player": "Deebo Samuel",\n    "POS": "WR",\n    "TM": "SF",\n    "PPR": "155.6",\n    "PPR/G": "10.4",\n    "PPR/OPP": "1.28",\n    "CSTY": "40.0",\n    "CLNG": "21.5",\n    "G": "15",\n    "OPP": "122",\n    "YDS(t)": "806",\n    "TD(t)": "4",\n    "1D(t)": "33",\n    "LNG": "77",\n    "BP": "13",\n    "IMP(t)": "37",\n    "IMP%": "0.303",\n    "RecYDS": "670",\n    "RecTD": "3",\n    "REC": "51",\n    "TGT": "80",\n    "YPT": "8.38",\n    "YPR": "13.14",\n    "YAC/REC": "8.18",\n    "Rec1D": "28",\n    "YPRR": "1.6",\n    "1DRR": "0.067",\n    "CAR": "42",\n    "RuYDS": "136",\n    "YPC": "3.24",\n    "RuTD": "1",\n    "Ru1D": "5",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "85",\n    "posRK": "31",\n    "Player": "Kareem Hunt",\n    "POS": "RB",\n    "TM": "KC",\n    "PPR": "155.4",\n    "PPR/G": "12.0",\n    "PPR/OPP": "0.68",\n    "CSTY": "46.2",\n    "CLNG": "19.9",\n    "G": "13",\n    "OPP": "227",\n    "YDS(t)": "904",\n    "TD(t)": "7",\n    "1D(t)": "52",\n    "LNG": "65",\n    "BP": "4",\n    "IMP(t)": "59",\n    "IMP%": "0.260",\n    "RecYDS": "176",\n    "RecTD": "0",\n    "REC": "23",\n    "TGT": "27",\n    "YPT": "6.52",\n    "YPR": "7.65",\n    "YAC/REC": "9.52",\n    "Rec1D": "10",\n    "YPRR": "0.83",\n    "1DRR": "0.047",\n    "CAR": "200",\n    "RuYDS": "728",\n    "YPC": "3.64",\n    "RuTD": "7",\n    "Ru1D": "42",\n    "ELU": "0.298",\n    "MTF/A": "0.110",\n    "YCO/A": "2.50"\n  },\n  {\n    "RK": "86",\n    "posRK": "45",\n    "Player": "Jalen Tolbert",\n    "POS": "WR",\n    "TM": "DAL",\n    "PPR": "152.0",\n    "PPR/G": "8.9",\n    "PPR/OPP": "2.05",\n    "CSTY": "29.4",\n    "CLNG": "16.6",\n    "G": "17",\n    "OPP": "74",\n    "YDS(t)": "610",\n    "TD(t)": "7",\n    "1D(t)": "29",\n    "LNG": "43",\n    "BP": "5",\n    "IMP(t)": "36",\n    "IMP%": "0.486",\n    "RecYDS": "610",\n    "RecTD": "7",\n    "REC": "49",\n    "TGT": "74",\n    "YPT": "8.24",\n    "YPR": "12.45",\n    "YAC/REC": "3.57",\n    "Rec1D": "29",\n    "YPRR": "1.1",\n    "1DRR": "0.052",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "87",\n    "posRK": "46",\n    "Player": "Demario Douglas",\n    "POS": "WR",\n    "TM": "NE",\n    "PPR": "147.7",\n    "PPR/G": "8.7",\n    "PPR/OPP": "1.70",\n    "CSTY": "17.6",\n    "CLNG": "16.9",\n    "G": "17",\n    "OPP": "87",\n    "YDS(t)": "637",\n    "TD(t)": "3",\n    "1D(t)": "31",\n    "LNG": "52",\n    "BP": "9",\n    "IMP(t)": "34",\n    "IMP%": "0.391",\n    "RecYDS": "621",\n    "RecTD": "3",\n    "REC": "66",\n    "TGT": "84",\n    "YPT": "7.39",\n    "YPR": "9.41",\n    "YAC/REC": "5.61",\n    "Rec1D": "31",\n    "YPRR": "1.4",\n    "1DRR": "0.070",\n    "CAR": "3",\n    "RuYDS": "16",\n    "YPC": "5.33",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "88",\n    "posRK": "47",\n    "Player": "DeAndre Hopkins",\n    "POS": "WR",\n    "TM": "KC",\n    "PPR": "147.0",\n    "PPR/G": "9.2",\n    "PPR/OPP": "1.88",\n    "CSTY": "31.3",\n    "CLNG": "20.8",\n    "G": "16",\n    "OPP": "78",\n    "YDS(t)": "610",\n    "TD(t)": "5",\n    "1D(t)": "35",\n    "LNG": "64",\n    "BP": "14",\n    "IMP(t)": "40",\n    "IMP%": "0.513",\n    "RecYDS": "610",\n    "RecTD": "5",\n    "REC": "56",\n    "TGT": "78",\n    "YPT": "7.82",\n    "YPR": "10.89",\n    "YAC/REC": "1.96",\n    "Rec1D": "35",\n    "YPRR": "1.71",\n    "1DRR": "0.098",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "89",\n    "posRK": "48",\n    "Player": "Rome Odunze",\n    "POS": "WR",\n    "TM": "CHI",\n    "PPR": "146.9",\n    "PPR/G": "8.6",\n    "PPR/OPP": "1.48",\n    "CSTY": "23.5",\n    "CLNG": "19.7",\n    "G": "17",\n    "OPP": "99",\n    "YDS(t)": "749",\n    "TD(t)": "3",\n    "1D(t)": "38",\n    "LNG": "71",\n    "BP": "15",\n    "IMP(t)": "41",\n    "IMP%": "0.414",\n    "RecYDS": "734",\n    "RecTD": "3",\n    "REC": "54",\n    "TGT": "96",\n    "YPT": "7.65",\n    "YPR": "13.59",\n    "YAC/REC": "4.83",\n    "Rec1D": "37",\n    "YPRR": "1.18",\n    "1DRR": "0.059",\n    "CAR": "3",\n    "RuYDS": "15",\n    "YPC": "5.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "90",\n    "posRK": "49",\n    "Player": "Jaylen Waddle",\n    "POS": "WR",\n    "TM": "MIA",\n    "PPR": "145.6",\n    "PPR/G": "9.7",\n    "PPR/OPP": "1.67",\n    "CSTY": "20.0",\n    "CLNG": "21.2",\n    "G": "15",\n    "OPP": "87",\n    "YDS(t)": "756",\n    "TD(t)": "2",\n    "1D(t)": "39",\n    "LNG": "67",\n    "BP": "16",\n    "IMP(t)": "41",\n    "IMP%": "0.471",\n    "RecYDS": "744",\n    "RecTD": "2",\n    "REC": "58",\n    "TGT": "83",\n    "YPT": "8.96",\n    "YPR": "12.83",\n    "YAC/REC": "4.1",\n    "Rec1D": "38",\n    "YPRR": "1.53",\n    "1DRR": "0.078",\n    "CAR": "4",\n    "RuYDS": "12",\n    "YPC": "3.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "91",\n    "posRK": "11",\n    "Player": "Hunter Henry",\n    "POS": "TE",\n    "TM": "NE",\n    "PPR": "145.4",\n    "PPR/G": "9.1",\n    "PPR/OPP": "1.63",\n    "CSTY": "43.8",\n    "CLNG": "16.9",\n    "G": "16",\n    "OPP": "89",\n    "YDS(t)": "674",\n    "TD(t)": "2",\n    "1D(t)": "40",\n    "LNG": "60",\n    "BP": "9",\n    "IMP(t)": "42",\n    "IMP%": "0.472",\n    "RecYDS": "674",\n    "RecTD": "2",\n    "REC": "66",\n    "TGT": "89",\n    "YPT": "7.57",\n    "YPR": "10.21",\n    "YAC/REC": "4.15",\n    "Rec1D": "40",\n    "YPRR": "1.39",\n    "1DRR": "0.082",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "92",\n    "posRK": "12",\n    "Player": "David Njoku",\n    "POS": "TE",\n    "TM": "CLE",\n    "PPR": "144.5",\n    "PPR/G": "13.1",\n    "PPR/OPP": "1.61",\n    "CSTY": "54.5",\n    "CLNG": "22.3",\n    "G": "11",\n    "OPP": "90",\n    "YDS(t)": "505",\n    "TD(t)": "5",\n    "1D(t)": "23",\n    "LNG": "29",\n    "BP": "4",\n    "IMP(t)": "28",\n    "IMP%": "0.311",\n    "RecYDS": "505",\n    "RecTD": "5",\n    "REC": "64",\n    "TGT": "90",\n    "YPT": "5.61",\n    "YPR": "7.89",\n    "YAC/REC": "3.97",\n    "Rec1D": "23",\n    "YPRR": "1.33",\n    "1DRR": "0.061",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "92",\n    "posRK": "50",\n    "Player": "Ray-Ray McCloud III",\n    "POS": "WR",\n    "TM": "ATL",\n    "PPR": "144.5",\n    "PPR/G": "8.5",\n    "PPR/OPP": "1.59",\n    "CSTY": "23.5",\n    "CLNG": "14.7",\n    "G": "17",\n    "OPP": "91",\n    "YDS(t)": "765",\n    "TD(t)": "1",\n    "1D(t)": "32",\n    "LNG": "45",\n    "BP": "5",\n    "IMP(t)": "33",\n    "IMP%": "0.363",\n    "RecYDS": "686",\n    "RecTD": "1",\n    "REC": "62",\n    "TGT": "81",\n    "YPT": "8.47",\n    "YPR": "11.06",\n    "YAC/REC": "5.52",\n    "Rec1D": "29",\n    "YPRR": "1.25",\n    "1DRR": "0.053",\n    "CAR": "10",\n    "RuYDS": "79",\n    "YPC": "7.90",\n    "RuTD": "0",\n    "Ru1D": "3",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "94",\n    "posRK": "13",\n    "Player": "Mike Gesicki",\n    "POS": "TE",\n    "TM": "CIN",\n    "PPR": "143.5",\n    "PPR/G": "8.4",\n    "PPR/OPP": "1.75",\n    "CSTY": "29.4",\n    "CLNG": "20.6",\n    "G": "17",\n    "OPP": "82",\n    "YDS(t)": "665",\n    "TD(t)": "2",\n    "1D(t)": "38",\n    "LNG": "54",\n    "BP": "6",\n    "IMP(t)": "40",\n    "IMP%": "0.488",\n    "RecYDS": "665",\n    "RecTD": "2",\n    "REC": "65",\n    "TGT": "82",\n    "YPT": "8.11",\n    "YPR": "10.23",\n    "YAC/REC": "3.77",\n    "Rec1D": "38",\n    "YPRR": "1.58",\n    "1DRR": "0.090",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "95",\n    "posRK": "14",\n    "Player": "Cade Otton",\n    "POS": "TE",\n    "TM": "TB",\n    "PPR": "142.6",\n    "PPR/G": "10.2",\n    "PPR/OPP": "1.68",\n    "CSTY": "21.4",\n    "CLNG": "22.9",\n    "G": "14",\n    "OPP": "85",\n    "YDS(t)": "596",\n    "TD(t)": "4",\n    "1D(t)": "31",\n    "LNG": "47",\n    "BP": "6",\n    "IMP(t)": "35",\n    "IMP%": "0.412",\n    "RecYDS": "600",\n    "RecTD": "4",\n    "REC": "59",\n    "TGT": "84",\n    "YPT": "7.14",\n    "YPR": "10.17",\n    "YAC/REC": "5.31",\n    "Rec1D": "31",\n    "YPRR": "1.3",\n    "1DRR": "0.067",\n    "CAR": "1",\n    "RuYDS": "-4",\n    "YPC": "-4.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "96",\n    "posRK": "51",\n    "Player": "Tank Dell",\n    "POS": "WR",\n    "TM": "HOU",\n    "PPR": "140.0",\n    "PPR/G": "10.0",\n    "PPR/OPP": "1.56",\n    "CSTY": "28.6",\n    "CLNG": "19.7",\n    "G": "14",\n    "OPP": "90",\n    "YDS(t)": "710",\n    "TD(t)": "3",\n    "1D(t)": "38",\n    "LNG": "69",\n    "BP": "14",\n    "IMP(t)": "41",\n    "IMP%": "0.456",\n    "RecYDS": "667",\n    "RecTD": "3",\n    "REC": "51",\n    "TGT": "81",\n    "YPT": "8.23",\n    "YPR": "13.08",\n    "YAC/REC": "3.2",\n    "Rec1D": "35",\n    "YPRR": "1.49",\n    "1DRR": "0.078",\n    "CAR": "9",\n    "RuYDS": "43",\n    "YPC": "4.78",\n    "RuTD": "0",\n    "Ru1D": "3",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "97",\n    "posRK": "52",\n    "Player": "Adam Thielen",\n    "POS": "WR",\n    "TM": "CAR",\n    "PPR": "139.5",\n    "PPR/G": "14.0",\n    "PPR/OPP": "2.29",\n    "CSTY": "50.0",\n    "CLNG": "23.7",\n    "G": "10",\n    "OPP": "61",\n    "YDS(t)": "615",\n    "TD(t)": "5",\n    "1D(t)": "28",\n    "LNG": "59",\n    "BP": "15",\n    "IMP(t)": "33",\n    "IMP%": "0.541",\n    "RecYDS": "615",\n    "RecTD": "5",\n    "REC": "48",\n    "TGT": "61",\n    "YPT": "10.08",\n    "YPR": "12.81",\n    "YAC/REC": "3.25",\n    "Rec1D": "28",\n    "YPRR": "2.06",\n    "1DRR": "0.094",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "98",\n    "posRK": "53",\n    "Player": "Chris Godwin",\n    "POS": "WR",\n    "TM": "TB",\n    "PPR": "137.8",\n    "PPR/G": "19.7",\n    "PPR/OPP": "2.26",\n    "CSTY": "85.7",\n    "CLNG": "27.5",\n    "G": "7",\n    "OPP": "61",\n    "YDS(t)": "578",\n    "TD(t)": "5",\n    "1D(t)": "33",\n    "LNG": "50",\n    "BP": "12",\n    "IMP(t)": "38",\n    "IMP%": "0.623",\n    "RecYDS": "576",\n    "RecTD": "5",\n    "REC": "50",\n    "TGT": "60",\n    "YPT": "9.6",\n    "YPR": "11.52",\n    "YAC/REC": "6.94",\n    "Rec1D": "32",\n    "YPRR": "2.36",\n    "1DRR": "0.131",\n    "CAR": "1",\n    "RuYDS": "2",\n    "YPC": "2.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "99",\n    "posRK": "32",\n    "Player": "Alexander Mattison",\n    "POS": "RB",\n    "TM": "LV",\n    "PPR": "137.4",\n    "PPR/G": "9.8",\n    "PPR/OPP": "0.78",\n    "CSTY": "35.7",\n    "CLNG": "16.4",\n    "G": "14",\n    "OPP": "177",\n    "YDS(t)": "714",\n    "TD(t)": "5",\n    "1D(t)": "38",\n    "LNG": "31",\n    "BP": "4",\n    "IMP(t)": "43",\n    "IMP%": "0.243",\n    "RecYDS": "294",\n    "RecTD": "1",\n    "REC": "36",\n    "TGT": "45",\n    "YPT": "6.53",\n    "YPR": "8.17",\n    "YAC/REC": "8.83",\n    "Rec1D": "13",\n    "YPRR": "1.35",\n    "1DRR": "0.060",\n    "CAR": "132",\n    "RuYDS": "420",\n    "YPC": "3.18",\n    "RuTD": "4",\n    "Ru1D": "25",\n    "ELU": "0.285",\n    "MTF/A": "0.106",\n    "YCO/A": "2.39"\n  },\n  {\n    "RK": "100",\n    "posRK": "54",\n    "Player": "Nick Westbrook-Ikhine",\n    "POS": "WR",\n    "TM": "TEN",\n    "PPR": "135.7",\n    "PPR/G": "8.0",\n    "PPR/OPP": "2.42",\n    "CSTY": "23.5",\n    "CLNG": "18.9",\n    "G": "17",\n    "OPP": "56",\n    "YDS(t)": "497",\n    "TD(t)": "9",\n    "1D(t)": "25",\n    "LNG": "98",\n    "BP": "4",\n    "IMP(t)": "34",\n    "IMP%": "0.607",\n    "RecYDS": "497",\n    "RecTD": "9",\n    "REC": "32",\n    "TGT": "56",\n    "YPT": "8.88",\n    "YPR": "15.53",\n    "YAC/REC": "4.03",\n    "Rec1D": "25",\n    "YPRR": "1.14",\n    "1DRR": "0.057",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "101",\n    "posRK": "55",\n    "Player": "Jalen McMillan",\n    "POS": "WR",\n    "TM": "TB",\n    "PPR": "135.4",\n    "PPR/G": "10.4",\n    "PPR/OPP": "2.18",\n    "CSTY": "38.5",\n    "CLNG": "21.3",\n    "G": "13",\n    "OPP": "62",\n    "YDS(t)": "504",\n    "TD(t)": "8",\n    "1D(t)": "26",\n    "LNG": "33",\n    "BP": "8",\n    "IMP(t)": "34",\n    "IMP%": "0.548",\n    "RecYDS": "461",\n    "RecTD": "8",\n    "REC": "37",\n    "TGT": "58",\n    "YPT": "7.95",\n    "YPR": "12.46",\n    "YAC/REC": "3.49",\n    "Rec1D": "23",\n    "YPRR": "1.18",\n    "1DRR": "0.059",\n    "CAR": "4",\n    "RuYDS": "43",\n    "YPC": "10.75",\n    "RuTD": "0",\n    "Ru1D": "3",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "102",\n    "posRK": "33",\n    "Player": "Jerome Ford",\n    "POS": "RB",\n    "TM": "CLE",\n    "PPR": "134.0",\n    "PPR/G": "9.6",\n    "PPR/OPP": "0.92",\n    "CSTY": "28.6",\n    "CLNG": "20.5",\n    "G": "14",\n    "OPP": "146",\n    "YDS(t)": "790",\n    "TD(t)": "3",\n    "1D(t)": "35",\n    "LNG": "51",\n    "BP": "6",\n    "IMP(t)": "38",\n    "IMP%": "0.260",\n    "RecYDS": "225",\n    "RecTD": "0",\n    "REC": "37",\n    "TGT": "42",\n    "YPT": "5.36",\n    "YPR": "6.08",\n    "YAC/REC": "7.81",\n    "Rec1D": "10",\n    "YPRR": "0.74",\n    "1DRR": "0.033",\n    "CAR": "104",\n    "RuYDS": "565",\n    "YPC": "5.43",\n    "RuTD": "3",\n    "Ru1D": "25",\n    "ELU": "0.513",\n    "MTF/A": "0.250",\n    "YCO/A": "3.50"\n  },\n  {\n    "RK": "103",\n    "posRK": "34",\n    "Player": "Austin Ekeler",\n    "POS": "RB",\n    "TM": "WAS",\n    "PPR": "132.3",\n    "PPR/G": "11.0",\n    "PPR/OPP": "1.13",\n    "CSTY": "33.3",\n    "CLNG": "17.7",\n    "G": "12",\n    "OPP": "117",\n    "YDS(t)": "733",\n    "TD(t)": "4",\n    "1D(t)": "33",\n    "LNG": "50",\n    "BP": "12",\n    "IMP(t)": "37",\n    "IMP%": "0.316",\n    "RecYDS": "366",\n    "RecTD": "0",\n    "REC": "35",\n    "TGT": "40",\n    "YPT": "9.15",\n    "YPR": "10.46",\n    "YAC/REC": "12.17",\n    "Rec1D": "14",\n    "YPRR": "1.69",\n    "1DRR": "0.065",\n    "CAR": "77",\n    "RuYDS": "367",\n    "YPC": "4.77",\n    "RuTD": "4",\n    "Ru1D": "19",\n    "ELU": "0.321",\n    "MTF/A": "0.130",\n    "YCO/A": "2.55"\n  },\n  {\n    "RK": "104",\n    "posRK": "35",\n    "Player": "Travis Etienne Jr.",\n    "POS": "RB",\n    "TM": "JAX",\n    "PPR": "132.2",\n    "PPR/G": "8.8",\n    "PPR/OPP": "0.66",\n    "CSTY": "33.3",\n    "CLNG": "13.7",\n    "G": "15",\n    "OPP": "200",\n    "YDS(t)": "812",\n    "TD(t)": "2",\n    "1D(t)": "44",\n    "LNG": "66",\n    "BP": "7",\n    "IMP(t)": "46",\n    "IMP%": "0.230",\n    "RecYDS": "254",\n    "RecTD": "0",\n    "REC": "39",\n    "TGT": "50",\n    "YPT": "5.08",\n    "YPR": "6.51",\n    "YAC/REC": "7.56",\n    "Rec1D": "13",\n    "YPRR": "1",\n    "1DRR": "0.051",\n    "CAR": "150",\n    "RuYDS": "558",\n    "YPC": "3.72",\n    "RuTD": "2",\n    "Ru1D": "31",\n    "ELU": "0.299",\n    "MTF/A": "0.113",\n    "YCO/A": "2.48"\n  },\n  {\n    "RK": "105",\n    "posRK": "15",\n    "Player": "Kyle Pitts",\n    "POS": "TE",\n    "TM": "ATL",\n    "PPR": "131.2",\n    "PPR/G": "7.7",\n    "PPR/OPP": "1.87",\n    "CSTY": "23.5",\n    "CLNG": "18.4",\n    "G": "17",\n    "OPP": "70",\n    "YDS(t)": "602",\n    "TD(t)": "4",\n    "1D(t)": "21",\n    "LNG": "61",\n    "BP": "13",\n    "IMP(t)": "25",\n    "IMP%": "0.357",\n    "RecYDS": "602",\n    "RecTD": "4",\n    "REC": "47",\n    "TGT": "70",\n    "YPT": "8.6",\n    "YPR": "12.81",\n    "YAC/REC": "5.79",\n    "Rec1D": "21",\n    "YPRR": "1.33",\n    "1DRR": "0.046",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "106",\n    "posRK": "36",\n    "Player": "Tank Bigsby",\n    "POS": "RB",\n    "TM": "JAX",\n    "PPR": "131.0",\n    "PPR/G": "8.7",\n    "PPR/OPP": "0.73",\n    "CSTY": "26.7",\n    "CLNG": "21.0",\n    "G": "15",\n    "OPP": "179",\n    "YDS(t)": "820",\n    "TD(t)": "7",\n    "1D(t)": "39",\n    "LNG": "21",\n    "BP": "1",\n    "IMP(t)": "46",\n    "IMP%": "0.257",\n    "RecYDS": "54",\n    "RecTD": "0",\n    "REC": "7",\n    "TGT": "11",\n    "YPT": "4.91",\n    "YPR": "7.71",\n    "YAC/REC": "9.43",\n    "Rec1D": "1",\n    "YPRR": "0.42",\n    "1DRR": "0.008",\n    "CAR": "168",\n    "RuYDS": "766",\n    "YPC": "4.56",\n    "RuTD": "7",\n    "Ru1D": "38",\n    "ELU": "0.554",\n    "MTF/A": "0.274",\n    "YCO/A": "3.74"\n  },\n  {\n    "RK": "107",\n    "posRK": "56",\n    "Player": "Romeo Doubs",\n    "POS": "WR",\n    "TM": "GB",\n    "PPR": "130.1",\n    "PPR/G": "10.0",\n    "PPR/OPP": "1.86",\n    "CSTY": "30.8",\n    "CLNG": "18.8",\n    "G": "13",\n    "OPP": "70",\n    "YDS(t)": "601",\n    "TD(t)": "4",\n    "1D(t)": "33",\n    "LNG": "53",\n    "BP": "7",\n    "IMP(t)": "37",\n    "IMP%": "0.529",\n    "RecYDS": "601",\n    "RecTD": "4",\n    "REC": "46",\n    "TGT": "70",\n    "YPT": "8.59",\n    "YPR": "13.07",\n    "YAC/REC": "3.07",\n    "Rec1D": "33",\n    "YPRR": "1.67",\n    "1DRR": "0.092",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "108",\n    "posRK": "57",\n    "Player": "Marvin Mims Jr.",\n    "POS": "WR",\n    "TM": "DEN",\n    "PPR": "129.5",\n    "PPR/G": "7.6",\n    "PPR/OPP": "2.06",\n    "CSTY": "23.5",\n    "CLNG": "24.1",\n    "G": "17",\n    "OPP": "63",\n    "YDS(t)": "545",\n    "TD(t)": "6",\n    "1D(t)": "17",\n    "LNG": "93",\n    "BP": "7",\n    "IMP(t)": "23",\n    "IMP%": "0.365",\n    "RecYDS": "503",\n    "RecTD": "6",\n    "REC": "39",\n    "TGT": "50",\n    "YPT": "10.06",\n    "YPR": "12.9",\n    "YAC/REC": "12.28",\n    "Rec1D": "14",\n    "YPRR": "2.57",\n    "1DRR": "0.071",\n    "CAR": "13",\n    "RuYDS": "42",\n    "YPC": "3.23",\n    "RuTD": "0",\n    "Ru1D": "3",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "109",\n    "posRK": "58",\n    "Player": "Tre Tucker",\n    "POS": "WR",\n    "TM": "LV",\n    "PPR": "129.3",\n    "PPR/G": "7.6",\n    "PPR/OPP": "1.49",\n    "CSTY": "23.5",\n    "CLNG": "17.7",\n    "G": "17",\n    "OPP": "87",\n    "YDS(t)": "583",\n    "TD(t)": "4",\n    "1D(t)": "27",\n    "LNG": "58",\n    "BP": "6",\n    "IMP(t)": "31",\n    "IMP%": "0.356",\n    "RecYDS": "539",\n    "RecTD": "3",\n    "REC": "47",\n    "TGT": "78",\n    "YPT": "6.91",\n    "YPR": "11.47",\n    "YAC/REC": "4.45",\n    "Rec1D": "24",\n    "YPRR": "0.84",\n    "1DRR": "0.038",\n    "CAR": "9",\n    "RuYDS": "44",\n    "YPC": "4.89",\n    "RuTD": "1",\n    "Ru1D": "3",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "110",\n    "posRK": "37",\n    "Player": "Ameer Abdullah",\n    "POS": "RB",\n    "TM": "LV",\n    "PPR": "127.2",\n    "PPR/G": "9.1",\n    "PPR/OPP": "1.15",\n    "CSTY": "35.7",\n    "CLNG": "18.9",\n    "G": "14",\n    "OPP": "111",\n    "YDS(t)": "572",\n    "TD(t)": "5",\n    "1D(t)": "29",\n    "LNG": "33",\n    "BP": "3",\n    "IMP(t)": "34",\n    "IMP%": "0.306",\n    "RecYDS": "261",\n    "RecTD": "3",\n    "REC": "40",\n    "TGT": "45",\n    "YPT": "5.8",\n    "YPR": "6.53",\n    "YAC/REC": "6.4",\n    "Rec1D": "16",\n    "YPRR": "1.01",\n    "1DRR": "0.062",\n    "CAR": "66",\n    "RuYDS": "311",\n    "YPC": "4.71",\n    "RuTD": "2",\n    "Ru1D": "13",\n    "ELU": "0.393",\n    "MTF/A": "0.197",\n    "YCO/A": "2.61"\n  },\n  {\n    "RK": "111",\n    "posRK": "38",\n    "Player": "Justice Hill",\n    "POS": "RB",\n    "TM": "BAL",\n    "PPR": "127.1",\n    "PPR/G": "8.5",\n    "PPR/OPP": "1.37",\n    "CSTY": "26.7",\n    "CLNG": "17.9",\n    "G": "15",\n    "OPP": "93",\n    "YDS(t)": "611",\n    "TD(t)": "4",\n    "1D(t)": "31",\n    "LNG": "61",\n    "BP": "9",\n    "IMP(t)": "35",\n    "IMP%": "0.376",\n    "RecYDS": "383",\n    "RecTD": "3",\n    "REC": "42",\n    "TGT": "46",\n    "YPT": "8.33",\n    "YPR": "9.12",\n    "YAC/REC": "10.36",\n    "Rec1D": "17",\n    "YPRR": "1.64",\n    "1DRR": "0.073",\n    "CAR": "47",\n    "RuYDS": "228",\n    "YPC": "4.85",\n    "RuTD": "1",\n    "Ru1D": "14",\n    "ELU": "0.548",\n    "MTF/A": "0.234",\n    "YCO/A": "4.19"\n  },\n  {\n    "RK": "112",\n    "posRK": "59",\n    "Player": "Michael Wilson",\n    "POS": "WR",\n    "TM": "ARI",\n    "PPR": "126.5",\n    "PPR/G": "7.9",\n    "PPR/OPP": "1.78",\n    "CSTY": "25.0",\n    "CLNG": "14.1",\n    "G": "16",\n    "OPP": "71",\n    "YDS(t)": "555",\n    "TD(t)": "4",\n    "1D(t)": "27",\n    "LNG": "41",\n    "BP": "10",\n    "IMP(t)": "31",\n    "IMP%": "0.437",\n    "RecYDS": "548",\n    "RecTD": "4",\n    "REC": "47",\n    "TGT": "70",\n    "YPT": "7.83",\n    "YPR": "11.66",\n    "YAC/REC": "2.94",\n    "Rec1D": "27",\n    "YPRR": "1.09",\n    "1DRR": "0.054",\n    "CAR": "1",\n    "RuYDS": "7",\n    "YPC": "7.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "113",\n    "posRK": "39",\n    "Player": "Jaylen Warren",\n    "POS": "RB",\n    "TM": "PIT",\n    "PPR": "126.1",\n    "PPR/G": "8.4",\n    "PPR/OPP": "0.77",\n    "CSTY": "20.0",\n    "CLNG": "15.3",\n    "G": "15",\n    "OPP": "163",\n    "YDS(t)": "821",\n    "TD(t)": "1",\n    "1D(t)": "44",\n    "LNG": "29",\n    "BP": "4",\n    "IMP(t)": "45",\n    "IMP%": "0.276",\n    "RecYDS": "310",\n    "RecTD": "0",\n    "REC": "38",\n    "TGT": "43",\n    "YPT": "7.21",\n    "YPR": "8.16",\n    "YAC/REC": "8.58",\n    "Rec1D": "16",\n    "YPRR": "1.44",\n    "1DRR": "0.074",\n    "CAR": "120",\n    "RuYDS": "511",\n    "YPC": "4.26",\n    "RuTD": "1",\n    "Ru1D": "28",\n    "ELU": "0.499",\n    "MTF/A": "0.258",\n    "YCO/A": "3.21"\n  },\n  {\n    "RK": "114",\n    "posRK": "60",\n    "Player": "Allen Lazard",\n    "POS": "WR",\n    "TM": "NYJ",\n    "PPR": "126.0",\n    "PPR/G": "10.5",\n    "PPR/OPP": "2.10",\n    "CSTY": "41.7",\n    "CLNG": "22.1",\n    "G": "12",\n    "OPP": "60",\n    "YDS(t)": "530",\n    "TD(t)": "6",\n    "1D(t)": "29",\n    "LNG": "52",\n    "BP": "8",\n    "IMP(t)": "35",\n    "IMP%": "0.583",\n    "RecYDS": "530",\n    "RecTD": "6",\n    "REC": "37",\n    "TGT": "60",\n    "YPT": "8.83",\n    "YPR": "14.32",\n    "YAC/REC": "4.24",\n    "Rec1D": "29",\n    "YPRR": "1.26",\n    "1DRR": "0.069",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "115",\n    "posRK": "16",\n    "Player": "Isaiah Likely",\n    "POS": "TE",\n    "TM": "BAL",\n    "PPR": "125.7",\n    "PPR/G": "7.9",\n    "PPR/OPP": "2.24",\n    "CSTY": "18.8",\n    "CLNG": "19.1",\n    "G": "16",\n    "OPP": "56",\n    "YDS(t)": "477",\n    "TD(t)": "6",\n    "1D(t)": "26",\n    "LNG": "49",\n    "BP": "4",\n    "IMP(t)": "32",\n    "IMP%": "0.571",\n    "RecYDS": "477",\n    "RecTD": "6",\n    "REC": "42",\n    "TGT": "56",\n    "YPT": "8.52",\n    "YPR": "11.36",\n    "YAC/REC": "6.21",\n    "Rec1D": "26",\n    "YPRR": "1.55",\n    "1DRR": "0.084",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "116",\n    "posRK": "61",\n    "Player": "Xavier Legette",\n    "POS": "WR",\n    "TM": "CAR",\n    "PPR": "125.1",\n    "PPR/G": "7.8",\n    "PPR/OPP": "1.44",\n    "CSTY": "18.8",\n    "CLNG": "15.6",\n    "G": "16",\n    "OPP": "87",\n    "YDS(t)": "521",\n    "TD(t)": "4",\n    "1D(t)": "29",\n    "LNG": "35",\n    "BP": "7",\n    "IMP(t)": "33",\n    "IMP%": "0.379",\n    "RecYDS": "497",\n    "RecTD": "4",\n    "REC": "49",\n    "TGT": "81",\n    "YPT": "6.14",\n    "YPR": "10.14",\n    "YAC/REC": "2.29",\n    "Rec1D": "27",\n    "YPRR": "1.19",\n    "1DRR": "0.065",\n    "CAR": "6",\n    "RuYDS": "24",\n    "YPC": "4.00",\n    "RuTD": "0",\n    "Ru1D": "2",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "117",\n    "posRK": "62",\n    "Player": "Demarcus Robinson",\n    "POS": "WR",\n    "TM": "LAR",\n    "PPR": "123.5",\n    "PPR/G": "7.3",\n    "PPR/OPP": "2.06",\n    "CSTY": "17.6",\n    "CLNG": "19.3",\n    "G": "17",\n    "OPP": "60",\n    "YDS(t)": "505",\n    "TD(t)": "7",\n    "1D(t)": "27",\n    "LNG": "46",\n    "BP": "9",\n    "IMP(t)": "34",\n    "IMP%": "0.567",\n    "RecYDS": "505",\n    "RecTD": "7",\n    "REC": "31",\n    "TGT": "60",\n    "YPT": "8.42",\n    "YPR": "16.29",\n    "YAC/REC": "2.45",\n    "Rec1D": "27",\n    "YPRR": "0.99",\n    "1DRR": "0.053",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "118",\n    "posRK": "17",\n    "Player": "Juwan Johnson",\n    "POS": "TE",\n    "TM": "NO",\n    "PPR": "122.8",\n    "PPR/G": "7.2",\n    "PPR/OPP": "1.92",\n    "CSTY": "23.5",\n    "CLNG": "13.9",\n    "G": "17",\n    "OPP": "64",\n    "YDS(t)": "548",\n    "TD(t)": "3",\n    "1D(t)": "27",\n    "LNG": "30",\n    "BP": "8",\n    "IMP(t)": "30",\n    "IMP%": "0.469",\n    "RecYDS": "548",\n    "RecTD": "3",\n    "REC": "50",\n    "TGT": "64",\n    "YPT": "8.56",\n    "YPR": "10.96",\n    "YAC/REC": "4.42",\n    "Rec1D": "27",\n    "YPRR": "1.34",\n    "1DRR": "0.066",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "119",\n    "posRK": "63",\n    "Player": "Amari Cooper",\n    "POS": "WR",\n    "TM": "BUF",\n    "PPR": "122.7",\n    "PPR/G": "8.8",\n    "PPR/OPP": "1.50",\n    "CSTY": "28.6",\n    "CLNG": "19.9",\n    "G": "14",\n    "OPP": "82",\n    "YDS(t)": "547",\n    "TD(t)": "4",\n    "1D(t)": "24",\n    "LNG": "30",\n    "BP": "8",\n    "IMP(t)": "28",\n    "IMP%": "0.341",\n    "RecYDS": "547",\n    "RecTD": "4",\n    "REC": "44",\n    "TGT": "82",\n    "YPT": "6.67",\n    "YPR": "12.43",\n    "YAC/REC": "2.7",\n    "Rec1D": "24",\n    "YPRR": "1.46",\n    "1DRR": "0.064",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "120",\n    "posRK": "64",\n    "Player": "Stefon Diggs",\n    "POS": "WR",\n    "TM": "HOU",\n    "PPR": "121.4",\n    "PPR/G": "15.2",\n    "PPR/OPP": "1.87",\n    "CSTY": "75.0",\n    "CLNG": "20.3",\n    "G": "8",\n    "OPP": "65",\n    "YDS(t)": "504",\n    "TD(t)": "4",\n    "1D(t)": "32",\n    "LNG": "49",\n    "BP": "5",\n    "IMP(t)": "36",\n    "IMP%": "0.554",\n    "RecYDS": "496",\n    "RecTD": "3",\n    "REC": "47",\n    "TGT": "62",\n    "YPT": "8",\n    "YPR": "10.55",\n    "YAC/REC": "3.98",\n    "Rec1D": "31",\n    "YPRR": "1.84",\n    "1DRR": "0.115",\n    "CAR": "3",\n    "RuYDS": "8",\n    "YPC": "2.67",\n    "RuTD": "1",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "121",\n    "posRK": "65",\n    "Player": "Tyler Lockett",\n    "POS": "WR",\n    "TM": "SEA",\n    "PPR": "121.0",\n    "PPR/G": "7.1",\n    "PPR/OPP": "1.73",\n    "CSTY": "17.6",\n    "CLNG": "15.2",\n    "G": "17",\n    "OPP": "70",\n    "YDS(t)": "600",\n    "TD(t)": "2",\n    "1D(t)": "36",\n    "LNG": "58",\n    "BP": "10",\n    "IMP(t)": "38",\n    "IMP%": "0.543",\n    "RecYDS": "600",\n    "RecTD": "2",\n    "REC": "49",\n    "TGT": "70",\n    "YPT": "8.57",\n    "YPR": "12.24",\n    "YAC/REC": "2.69",\n    "Rec1D": "36",\n    "YPRR": "1.1",\n    "1DRR": "0.066",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "122",\n    "posRK": "66",\n    "Player": "Elijah Moore",\n    "POS": "WR",\n    "TM": "CLE",\n    "PPR": "120.9",\n    "PPR/G": "7.1",\n    "PPR/OPP": "1.23",\n    "CSTY": "17.6",\n    "CLNG": "18.1",\n    "G": "17",\n    "OPP": "98",\n    "YDS(t)": "539",\n    "TD(t)": "1",\n    "1D(t)": "25",\n    "LNG": "44",\n    "BP": "5",\n    "IMP(t)": "26",\n    "IMP%": "0.265",\n    "RecYDS": "538",\n    "RecTD": "1",\n    "REC": "61",\n    "TGT": "97",\n    "YPT": "5.55",\n    "YPR": "8.82",\n    "YAC/REC": "2.23",\n    "Rec1D": "25",\n    "YPRR": "0.91",\n    "1DRR": "0.042",\n    "CAR": "1",\n    "RuYDS": "1",\n    "YPC": "1.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "123",\n    "posRK": "67",\n    "Player": "Kayshon Boutte",\n    "POS": "WR",\n    "TM": "NE",\n    "PPR": "119.9",\n    "PPR/G": "8.0",\n    "PPR/OPP": "1.79",\n    "CSTY": "20.0",\n    "CLNG": "20.0",\n    "G": "15",\n    "OPP": "67",\n    "YDS(t)": "589",\n    "TD(t)": "3",\n    "1D(t)": "25",\n    "LNG": "43",\n    "BP": "4",\n    "IMP(t)": "28",\n    "IMP%": "0.418",\n    "RecYDS": "589",\n    "RecTD": "3",\n    "REC": "43",\n    "TGT": "67",\n    "YPT": "8.79",\n    "YPR": "13.7",\n    "YAC/REC": "3.53",\n    "Rec1D": "25",\n    "YPRR": "1.26",\n    "1DRR": "0.054",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "123",\n    "posRK": "18",\n    "Player": "Tyler Conklin",\n    "POS": "TE",\n    "TM": "NYJ",\n    "PPR": "119.9",\n    "PPR/G": "7.5",\n    "PPR/OPP": "1.76",\n    "CSTY": "18.8",\n    "CLNG": "15.7",\n    "G": "16",\n    "OPP": "68",\n    "YDS(t)": "449",\n    "TD(t)": "4",\n    "1D(t)": "24",\n    "LNG": "27",\n    "BP": "7",\n    "IMP(t)": "28",\n    "IMP%": "0.412",\n    "RecYDS": "449",\n    "RecTD": "4",\n    "REC": "51",\n    "TGT": "67",\n    "YPT": "6.7",\n    "YPR": "8.8",\n    "YAC/REC": "5.12",\n    "Rec1D": "24",\n    "YPRR": "0.9",\n    "1DRR": "0.048",\n    "CAR": "1",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "123",\n    "posRK": "68",\n    "Player": "Andrei Iosivas",\n    "POS": "WR",\n    "TM": "CIN",\n    "PPR": "119.9",\n    "PPR/G": "7.1",\n    "PPR/OPP": "2.03",\n    "CSTY": "23.5",\n    "CLNG": "15.1",\n    "G": "17",\n    "OPP": "59",\n    "YDS(t)": "479",\n    "TD(t)": "6",\n    "1D(t)": "26",\n    "LNG": "39",\n    "BP": "7",\n    "IMP(t)": "32",\n    "IMP%": "0.542",\n    "RecYDS": "479",\n    "RecTD": "6",\n    "REC": "36",\n    "TGT": "59",\n    "YPT": "8.12",\n    "YPR": "13.31",\n    "YAC/REC": "2.08",\n    "Rec1D": "26",\n    "YPRR": "0.84",\n    "1DRR": "0.045",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "126",\n    "posRK": "19",\n    "Player": "Cole Kmet",\n    "POS": "TE",\n    "TM": "CHI",\n    "PPR": "118.4",\n    "PPR/G": "7.0",\n    "PPR/OPP": "2.15",\n    "CSTY": "17.6",\n    "CLNG": "21.0",\n    "G": "17",\n    "OPP": "55",\n    "YDS(t)": "474",\n    "TD(t)": "4",\n    "1D(t)": "25",\n    "LNG": "31",\n    "BP": "7",\n    "IMP(t)": "29",\n    "IMP%": "0.527",\n    "RecYDS": "474",\n    "RecTD": "4",\n    "REC": "47",\n    "TGT": "55",\n    "YPT": "8.62",\n    "YPR": "10.09",\n    "YAC/REC": "3.98",\n    "Rec1D": "25",\n    "YPRR": "0.91",\n    "1DRR": "0.048",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "127",\n    "posRK": "20",\n    "Player": "Dalton Schultz",\n    "POS": "TE",\n    "TM": "HOU",\n    "PPR": "118.2",\n    "PPR/G": "7.0",\n    "PPR/OPP": "1.41",\n    "CSTY": "11.8",\n    "CLNG": "14.1",\n    "G": "17",\n    "OPP": "84",\n    "YDS(t)": "532",\n    "TD(t)": "2",\n    "1D(t)": "26",\n    "LNG": "32",\n    "BP": "5",\n    "IMP(t)": "28",\n    "IMP%": "0.333",\n    "RecYDS": "532",\n    "RecTD": "2",\n    "REC": "53",\n    "TGT": "84",\n    "YPT": "6.33",\n    "YPR": "10.04",\n    "YAC/REC": "4.06",\n    "Rec1D": "26",\n    "YPRR": "1.04",\n    "1DRR": "0.051",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "128",\n    "posRK": "40",\n    "Player": "Jordan Mason",\n    "POS": "RB",\n    "TM": "SF",\n    "PPR": "117.0",\n    "PPR/G": "9.8",\n    "PPR/OPP": "0.70",\n    "CSTY": "25.0",\n    "CLNG": "21.2",\n    "G": "12",\n    "OPP": "167",\n    "YDS(t)": "880",\n    "TD(t)": "3",\n    "1D(t)": "43",\n    "LNG": "40",\n    "BP": "4",\n    "IMP(t)": "46",\n    "IMP%": "0.275",\n    "RecYDS": "91",\n    "RecTD": "0",\n    "REC": "11",\n    "TGT": "14",\n    "YPT": "6.5",\n    "YPR": "8.27",\n    "YAC/REC": "5.45",\n    "Rec1D": "5",\n    "YPRR": "0.54",\n    "1DRR": "0.029",\n    "CAR": "153",\n    "RuYDS": "789",\n    "YPC": "5.16",\n    "RuTD": "3",\n    "Ru1D": "38",\n    "ELU": "0.493",\n    "MTF/A": "0.242",\n    "YCO/A": "3.35"\n  },\n  {\n    "RK": "129",\n    "posRK": "41",\n    "Player": "Ray Davis",\n    "POS": "RB",\n    "TM": "BUF",\n    "PPR": "116.1",\n    "PPR/G": "6.8",\n    "PPR/OPP": "0.89",\n    "CSTY": "23.5",\n    "CLNG": "16.6",\n    "G": "17",\n    "OPP": "131",\n    "YDS(t)": "631",\n    "TD(t)": "6",\n    "1D(t)": "33",\n    "LNG": "58",\n    "BP": "2",\n    "IMP(t)": "39",\n    "IMP%": "0.298",\n    "RecYDS": "189",\n    "RecTD": "3",\n    "REC": "17",\n    "TGT": "18",\n    "YPT": "10.5",\n    "YPR": "11.12",\n    "YAC/REC": "9.88",\n    "Rec1D": "8",\n    "YPRR": "1.87",\n    "1DRR": "0.079",\n    "CAR": "113",\n    "RuYDS": "442",\n    "YPC": "3.91",\n    "RuTD": "3",\n    "Ru1D": "25",\n    "ELU": "0.479",\n    "MTF/A": "0.257",\n    "YCO/A": "2.97"\n  },\n  {\n    "RK": "130",\n    "posRK": "69",\n    "Player": "Calvin Austin III",\n    "POS": "WR",\n    "TM": "PIT",\n    "PPR": "114.8",\n    "PPR/G": "6.8",\n    "PPR/OPP": "2.05",\n    "CSTY": "17.6",\n    "CLNG": "16.9",\n    "G": "17",\n    "OPP": "56",\n    "YDS(t)": "548",\n    "TD(t)": "4",\n    "1D(t)": "18",\n    "LNG": "55",\n    "BP": "10",\n    "IMP(t)": "22",\n    "IMP%": "0.393",\n    "RecYDS": "548",\n    "RecTD": "4",\n    "REC": "36",\n    "TGT": "56",\n    "YPT": "9.79",\n    "YPR": "15.22",\n    "YAC/REC": "4.25",\n    "Rec1D": "18",\n    "YPRR": "1.45",\n    "1DRR": "0.048",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "131",\n    "posRK": "70",\n    "Player": "Olamide Zaccheaus",\n    "POS": "WR",\n    "TM": "WAS",\n    "PPR": "114.4",\n    "PPR/G": "6.7",\n    "PPR/OPP": "1.82",\n    "CSTY": "17.6",\n    "CLNG": "20.6",\n    "G": "17",\n    "OPP": "63",\n    "YDS(t)": "514",\n    "TD(t)": "3",\n    "1D(t)": "27",\n    "LNG": "49",\n    "BP": "5",\n    "IMP(t)": "30",\n    "IMP%": "0.476",\n    "RecYDS": "506",\n    "RecTD": "3",\n    "REC": "45",\n    "TGT": "62",\n    "YPT": "8.16",\n    "YPR": "11.24",\n    "YAC/REC": "6.36",\n    "Rec1D": "26",\n    "YPRR": "1.69",\n    "1DRR": "0.087",\n    "CAR": "1",\n    "RuYDS": "8",\n    "YPC": "8.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "132",\n    "posRK": "42",\n    "Player": "Tyjae Spears",\n    "POS": "RB",\n    "TM": "TEN",\n    "PPR": "113.6",\n    "PPR/G": "9.5",\n    "PPR/OPP": "0.96",\n    "CSTY": "25.0",\n    "CLNG": "20.7",\n    "G": "12",\n    "OPP": "118",\n    "YDS(t)": "536",\n    "TD(t)": "5",\n    "1D(t)": "28",\n    "LNG": "43",\n    "BP": "4",\n    "IMP(t)": "33",\n    "IMP%": "0.280",\n    "RecYDS": "224",\n    "RecTD": "1",\n    "REC": "30",\n    "TGT": "33",\n    "YPT": "6.79",\n    "YPR": "7.47",\n    "YAC/REC": "8.47",\n    "Rec1D": "9",\n    "YPRR": "1.34",\n    "1DRR": "0.054",\n    "CAR": "85",\n    "RuYDS": "312",\n    "YPC": "3.67",\n    "RuTD": "4",\n    "Ru1D": "19",\n    "ELU": "0.442",\n    "MTF/A": "0.235",\n    "YCO/A": "2.76"\n  },\n  {\n    "RK": "132",\n    "posRK": "21",\n    "Player": "Chigoziem Okonkwo",\n    "POS": "TE",\n    "TM": "TEN",\n    "PPR": "113.6",\n    "PPR/G": "6.7",\n    "PPR/OPP": "1.67",\n    "CSTY": "17.6",\n    "CLNG": "15.0",\n    "G": "17",\n    "OPP": "68",\n    "YDS(t)": "496",\n    "TD(t)": "2",\n    "1D(t)": "20",\n    "LNG": "70",\n    "BP": "4",\n    "IMP(t)": "22",\n    "IMP%": "0.324",\n    "RecYDS": "479",\n    "RecTD": "2",\n    "REC": "52",\n    "TGT": "67",\n    "YPT": "7.15",\n    "YPR": "9.21",\n    "YAC/REC": "4.92",\n    "Rec1D": "19",\n    "YPRR": "1.25",\n    "1DRR": "0.050",\n    "CAR": "1",\n    "RuYDS": "17",\n    "YPC": "17.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "134",\n    "posRK": "22",\n    "Player": "Noah Gray",\n    "POS": "TE",\n    "TM": "KC",\n    "PPR": "113.3",\n    "PPR/G": "6.7",\n    "PPR/OPP": "2.31",\n    "CSTY": "11.8",\n    "CLNG": "17.2",\n    "G": "17",\n    "OPP": "49",\n    "YDS(t)": "433",\n    "TD(t)": "5",\n    "1D(t)": "25",\n    "LNG": "35",\n    "BP": "6",\n    "IMP(t)": "30",\n    "IMP%": "0.612",\n    "RecYDS": "437",\n    "RecTD": "5",\n    "REC": "40",\n    "TGT": "48",\n    "YPT": "9.1",\n    "YPR": "10.93",\n    "YAC/REC": "5.17",\n    "Rec1D": "25",\n    "YPRR": "1.37",\n    "1DRR": "0.079",\n    "CAR": "1",\n    "RuYDS": "-4",\n    "YPC": "-4.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "135",\n    "posRK": "23",\n    "Player": "Austin Hooper",\n    "POS": "TE",\n    "TM": "NE",\n    "PPR": "110.6",\n    "PPR/G": "6.5",\n    "PPR/OPP": "1.87",\n    "CSTY": "11.8",\n    "CLNG": "13.2",\n    "G": "17",\n    "OPP": "59",\n    "YDS(t)": "476",\n    "TD(t)": "3",\n    "1D(t)": "25",\n    "LNG": "38",\n    "BP": "5",\n    "IMP(t)": "28",\n    "IMP%": "0.475",\n    "RecYDS": "476",\n    "RecTD": "3",\n    "REC": "45",\n    "TGT": "59",\n    "YPT": "8.07",\n    "YPR": "10.58",\n    "YAC/REC": "4.71",\n    "Rec1D": "25",\n    "YPRR": "1.65",\n    "1DRR": "0.087",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "136",\n    "posRK": "71",\n    "Player": "Dontayvion Wicks",\n    "POS": "WR",\n    "TM": "GB",\n    "PPR": "110.5",\n    "PPR/G": "6.5",\n    "PPR/OPP": "1.49",\n    "CSTY": "11.8",\n    "CLNG": "16.7",\n    "G": "17",\n    "OPP": "74",\n    "YDS(t)": "415",\n    "TD(t)": "5",\n    "1D(t)": "25",\n    "LNG": "36",\n    "BP": "4",\n    "IMP(t)": "30",\n    "IMP%": "0.405",\n    "RecYDS": "415",\n    "RecTD": "5",\n    "REC": "39",\n    "TGT": "74",\n    "YPT": "5.61",\n    "YPR": "10.64",\n    "YAC/REC": "3.79",\n    "Rec1D": "25",\n    "YPRR": "1.42",\n    "1DRR": "0.085",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "137",\n    "posRK": "24",\n    "Player": "Will Dissly",\n    "POS": "TE",\n    "TM": "LAC",\n    "PPR": "110.1",\n    "PPR/G": "7.3",\n    "PPR/OPP": "1.80",\n    "CSTY": "20.0",\n    "CLNG": "16.4",\n    "G": "15",\n    "OPP": "61",\n    "YDS(t)": "481",\n    "TD(t)": "2",\n    "1D(t)": "24",\n    "LNG": "29",\n    "BP": "5",\n    "IMP(t)": "26",\n    "IMP%": "0.426",\n    "RecYDS": "481",\n    "RecTD": "2",\n    "REC": "50",\n    "TGT": "61",\n    "YPT": "7.89",\n    "YPR": "9.62",\n    "YAC/REC": "6.02",\n    "Rec1D": "24",\n    "YPRR": "1.65",\n    "1DRR": "0.082",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "138",\n    "posRK": "72",\n    "Player": "Darius Slayton",\n    "POS": "WR",\n    "TM": "NYG",\n    "PPR": "110.0",\n    "PPR/G": "6.9",\n    "PPR/OPP": "1.53",\n    "CSTY": "12.5",\n    "CLNG": "17.6",\n    "G": "16",\n    "OPP": "72",\n    "YDS(t)": "590",\n    "TD(t)": "2",\n    "1D(t)": "31",\n    "LNG": "54",\n    "BP": "9",\n    "IMP(t)": "33",\n    "IMP%": "0.458",\n    "RecYDS": "573",\n    "RecTD": "2",\n    "REC": "39",\n    "TGT": "70",\n    "YPT": "8.19",\n    "YPR": "14.69",\n    "YAC/REC": "3.46",\n    "Rec1D": "30",\n    "YPRR": "1.08",\n    "1DRR": "0.056",\n    "CAR": "2",\n    "RuYDS": "17",\n    "YPC": "8.50",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "139",\n    "posRK": "73",\n    "Player": "Keon Coleman",\n    "POS": "WR",\n    "TM": "BUF",\n    "PPR": "109.5",\n    "PPR/G": "8.4",\n    "PPR/OPP": "1.92",\n    "CSTY": "15.4",\n    "CLNG": "15.5",\n    "G": "13",\n    "OPP": "57",\n    "YDS(t)": "565",\n    "TD(t)": "4",\n    "1D(t)": "21",\n    "LNG": "55",\n    "BP": "7",\n    "IMP(t)": "25",\n    "IMP%": "0.439",\n    "RecYDS": "556",\n    "RecTD": "4",\n    "REC": "29",\n    "TGT": "56",\n    "YPT": "9.93",\n    "YPR": "19.17",\n    "YAC/REC": "7.66",\n    "Rec1D": "21",\n    "YPRR": "1.71",\n    "1DRR": "0.064",\n    "CAR": "1",\n    "RuYDS": "9",\n    "YPC": "9.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "140",\n    "posRK": "25",\n    "Player": "Jake Ferguson",\n    "POS": "TE",\n    "TM": "DAL",\n    "PPR": "108.4",\n    "PPR/G": "7.7",\n    "PPR/OPP": "1.34",\n    "CSTY": "21.4",\n    "CLNG": "14.2",\n    "G": "14",\n    "OPP": "81",\n    "YDS(t)": "494",\n    "TD(t)": "0",\n    "1D(t)": "18",\n    "LNG": "27",\n    "BP": "6",\n    "IMP(t)": "18",\n    "IMP%": "0.222",\n    "RecYDS": "494",\n    "RecTD": "0",\n    "REC": "59",\n    "TGT": "81",\n    "YPT": "6.1",\n    "YPR": "8.37",\n    "YAC/REC": "5.56",\n    "Rec1D": "18",\n    "YPRR": "1.27",\n    "1DRR": "0.046",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "141",\n    "posRK": "74",\n    "Player": "Devaughn Vele",\n    "POS": "WR",\n    "TM": "DEN",\n    "PPR": "106.5",\n    "PPR/G": "8.2",\n    "PPR/OPP": "1.97",\n    "CSTY": "23.1",\n    "CLNG": "14.3",\n    "G": "13",\n    "OPP": "54",\n    "YDS(t)": "475",\n    "TD(t)": "3",\n    "1D(t)": "26",\n    "LNG": "37",\n    "BP": "7",\n    "IMP(t)": "29",\n    "IMP%": "0.537",\n    "RecYDS": "475",\n    "RecTD": "3",\n    "REC": "41",\n    "TGT": "54",\n    "YPT": "8.8",\n    "YPR": "11.59",\n    "YAC/REC": "3.22",\n    "Rec1D": "26",\n    "YPRR": "1.51",\n    "1DRR": "0.083",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "142",\n    "posRK": "26",\n    "Player": "Taysom Hill",\n    "POS": "TE",\n    "TM": "NO",\n    "PPR": "105.5",\n    "PPR/G": "13.2",\n    "PPR/OPP": "1.51",\n    "CSTY": "37.5",\n    "CLNG": "25.1",\n    "G": "8",\n    "OPP": "70",\n    "YDS(t)": "465",\n    "TD(t)": "6",\n    "1D(t)": "26",\n    "LNG": "41",\n    "BP": "4",\n    "IMP(t)": "32",\n    "IMP%": "0.457",\n    "RecYDS": "187",\n    "RecTD": "0",\n    "REC": "23",\n    "TGT": "31",\n    "YPT": "6.03",\n    "YPR": "8.13",\n    "YAC/REC": "6.04",\n    "Rec1D": "8",\n    "YPRR": "1.68",\n    "1DRR": "0.072",\n    "CAR": "39",\n    "RuYDS": "278",\n    "YPC": "7.13",\n    "RuTD": "6",\n    "Ru1D": "18",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "143",\n    "posRK": "75",\n    "Player": "Christian Watson",\n    "POS": "WR",\n    "TM": "GB",\n    "PPR": "105.3",\n    "PPR/G": "7.0",\n    "PPR/OPP": "1.91",\n    "CSTY": "20.0",\n    "CLNG": "16.7",\n    "G": "15",\n    "OPP": "55",\n    "YDS(t)": "643",\n    "TD(t)": "2",\n    "1D(t)": "22",\n    "LNG": "68",\n    "BP": "12",\n    "IMP(t)": "24",\n    "IMP%": "0.436",\n    "RecYDS": "620",\n    "RecTD": "2",\n    "REC": "29",\n    "TGT": "51",\n    "YPT": "12.16",\n    "YPR": "21.38",\n    "YAC/REC": "5.34",\n    "Rec1D": "21",\n    "YPRR": "2.26",\n    "1DRR": "0.077",\n    "CAR": "4",\n    "RuYDS": "23",\n    "YPC": "5.75",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "144",\n    "posRK": "76",\n    "Player": "Jalen Nailor",\n    "POS": "WR",\n    "TM": "MIN",\n    "PPR": "105.0",\n    "PPR/G": "6.2",\n    "PPR/OPP": "2.33",\n    "CSTY": "17.6",\n    "CLNG": "15.3",\n    "G": "17",\n    "OPP": "45",\n    "YDS(t)": "410",\n    "TD(t)": "6",\n    "1D(t)": "23",\n    "LNG": "33",\n    "BP": "8",\n    "IMP(t)": "29",\n    "IMP%": "0.644",\n    "RecYDS": "414",\n    "RecTD": "6",\n    "REC": "28",\n    "TGT": "42",\n    "YPT": "9.86",\n    "YPR": "14.79",\n    "YAC/REC": "3.68",\n    "Rec1D": "22",\n    "YPRR": "1.07",\n    "1DRR": "0.057",\n    "CAR": "3",\n    "RuYDS": "-4",\n    "YPC": "-1.33",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "145",\n    "posRK": "43",\n    "Player": "Tyler Allgeier",\n    "POS": "RB",\n    "TM": "ATL",\n    "PPR": "104.2",\n    "PPR/G": "6.1",\n    "PPR/OPP": "0.69",\n    "CSTY": "11.8",\n    "CLNG": "13.4",\n    "G": "17",\n    "OPP": "150",\n    "YDS(t)": "732",\n    "TD(t)": "3",\n    "1D(t)": "45",\n    "LNG": "20",\n    "BP": "1",\n    "IMP(t)": "48",\n    "IMP%": "0.320",\n    "RecYDS": "88",\n    "RecTD": "0",\n    "REC": "13",\n    "TGT": "13",\n    "YPT": "6.77",\n    "YPR": "6.77",\n    "YAC/REC": "7.38",\n    "Rec1D": "2",\n    "YPRR": "0.95",\n    "1DRR": "0.022",\n    "CAR": "137",\n    "RuYDS": "644",\n    "YPC": "4.70",\n    "RuTD": "3",\n    "Ru1D": "43",\n    "ELU": "0.541",\n    "MTF/A": "0.270",\n    "YCO/A": "3.61"\n  },\n  {\n    "RK": "146",\n    "posRK": "27",\n    "Player": "Noah Fant",\n    "POS": "TE",\n    "TM": "SEA",\n    "PPR": "104.0",\n    "PPR/G": "7.4",\n    "PPR/OPP": "1.68",\n    "CSTY": "21.4",\n    "CLNG": "13.9",\n    "G": "14",\n    "OPP": "62",\n    "YDS(t)": "500",\n    "TD(t)": "1",\n    "1D(t)": "25",\n    "LNG": "32",\n    "BP": "3",\n    "IMP(t)": "26",\n    "IMP%": "0.419",\n    "RecYDS": "500",\n    "RecTD": "1",\n    "REC": "48",\n    "TGT": "62",\n    "YPT": "8.06",\n    "YPR": "10.42",\n    "YAC/REC": "5.88",\n    "Rec1D": "25",\n    "YPRR": "1.29",\n    "1DRR": "0.065",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "147",\n    "posRK": "28",\n    "Player": "Dallas Goedert",\n    "POS": "TE",\n    "TM": "PHI",\n    "PPR": "103.6",\n    "PPR/G": "10.4",\n    "PPR/OPP": "2.03",\n    "CSTY": "30.0",\n    "CLNG": "17.6",\n    "G": "10",\n    "OPP": "51",\n    "YDS(t)": "496",\n    "TD(t)": "2",\n    "1D(t)": "20",\n    "LNG": "61",\n    "BP": "6",\n    "IMP(t)": "22",\n    "IMP%": "0.431",\n    "RecYDS": "496",\n    "RecTD": "2",\n    "REC": "42",\n    "TGT": "51",\n    "YPT": "9.73",\n    "YPR": "11.81",\n    "YAC/REC": "6.1",\n    "Rec1D": "20",\n    "YPRR": "2.2",\n    "1DRR": "0.089",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "148",\n    "posRK": "77",\n    "Player": "Joshua Palmer",\n    "POS": "WR",\n    "TM": "LAC",\n    "PPR": "103.4",\n    "PPR/G": "6.9",\n    "PPR/OPP": "1.64",\n    "CSTY": "13.3",\n    "CLNG": "12.8",\n    "G": "15",\n    "OPP": "63",\n    "YDS(t)": "584",\n    "TD(t)": "1",\n    "1D(t)": "28",\n    "LNG": "48",\n    "BP": "8",\n    "IMP(t)": "29",\n    "IMP%": "0.460",\n    "RecYDS": "584",\n    "RecTD": "1",\n    "REC": "39",\n    "TGT": "63",\n    "YPT": "9.27",\n    "YPR": "14.97",\n    "YAC/REC": "2.62",\n    "Rec1D": "28",\n    "YPRR": "1.49",\n    "1DRR": "0.072",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "148",\n    "posRK": "44",\n    "Player": "Antonio Gibson",\n    "POS": "RB",\n    "TM": "NE",\n    "PPR": "103.4",\n    "PPR/G": "6.1",\n    "PPR/OPP": "0.69",\n    "CSTY": "5.9",\n    "CLNG": "11.5",\n    "G": "17",\n    "OPP": "149",\n    "YDS(t)": "744",\n    "TD(t)": "1",\n    "1D(t)": "34",\n    "LNG": "50",\n    "BP": "4",\n    "IMP(t)": "35",\n    "IMP%": "0.235",\n    "RecYDS": "206",\n    "RecTD": "0",\n    "REC": "23",\n    "TGT": "29",\n    "YPT": "7.1",\n    "YPR": "8.96",\n    "YAC/REC": "9.3",\n    "Rec1D": "11",\n    "YPRR": "1.26",\n    "1DRR": "0.067",\n    "CAR": "120",\n    "RuYDS": "538",\n    "YPC": "4.48",\n    "RuTD": "1",\n    "Ru1D": "23",\n    "ELU": "0.627",\n    "MTF/A": "0.333",\n    "YCO/A": "3.91"\n  },\n  {\n    "RK": "150",\n    "posRK": "29",\n    "Player": "Foster Moreau",\n    "POS": "TE",\n    "TM": "NO",\n    "PPR": "103.3",\n    "PPR/G": "6.1",\n    "PPR/OPP": "2.46",\n    "CSTY": "17.6",\n    "CLNG": "14.0",\n    "G": "17",\n    "OPP": "42",\n    "YDS(t)": "413",\n    "TD(t)": "5",\n    "1D(t)": "21",\n    "LNG": "41",\n    "BP": "7",\n    "IMP(t)": "26",\n    "IMP%": "0.619",\n    "RecYDS": "413",\n    "RecTD": "5",\n    "REC": "32",\n    "TGT": "42",\n    "YPT": "9.83",\n    "YPR": "12.91",\n    "YAC/REC": "4.81",\n    "Rec1D": "21",\n    "YPRR": "1.43",\n    "1DRR": "0.073",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "151",\n    "posRK": "30",\n    "Player": "Dalton Kincaid",\n    "POS": "TE",\n    "TM": "BUF",\n    "PPR": "100.8",\n    "PPR/G": "7.8",\n    "PPR/OPP": "1.42",\n    "CSTY": "15.4",\n    "CLNG": "12.4",\n    "G": "13",\n    "OPP": "71",\n    "YDS(t)": "448",\n    "TD(t)": "2",\n    "1D(t)": "23",\n    "LNG": "29",\n    "BP": "5",\n    "IMP(t)": "25",\n    "IMP%": "0.352",\n    "RecYDS": "448",\n    "RecTD": "2",\n    "REC": "44",\n    "TGT": "71",\n    "YPT": "6.31",\n    "YPR": "10.18",\n    "YAC/REC": "6.52",\n    "Rec1D": "23",\n    "YPRR": "1.62",\n    "1DRR": "0.083",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "152",\n    "posRK": "45",\n    "Player": "Devin Singletary",\n    "POS": "RB",\n    "TM": "NYG",\n    "PPR": "100.6",\n    "PPR/G": "6.7",\n    "PPR/OPP": "0.73",\n    "CSTY": "20.0",\n    "CLNG": "16.8",\n    "G": "15",\n    "OPP": "137",\n    "YDS(t)": "556",\n    "TD(t)": "4",\n    "1D(t)": "28",\n    "LNG": "23",\n    "BP": "2",\n    "IMP(t)": "32",\n    "IMP%": "0.234",\n    "RecYDS": "119",\n    "RecTD": "0",\n    "REC": "21",\n    "TGT": "24",\n    "YPT": "4.96",\n    "YPR": "5.67",\n    "YAC/REC": "8.52",\n    "Rec1D": "4",\n    "YPRR": "0.73",\n    "1DRR": "0.024",\n    "CAR": "113",\n    "RuYDS": "437",\n    "YPC": "3.87",\n    "RuTD": "4",\n    "Ru1D": "24",\n    "ELU": "0.432",\n    "MTF/A": "0.221",\n    "YCO/A": "2.81"\n  },\n  {\n    "RK": "153",\n    "posRK": "46",\n    "Player": "Jaleel McLaughlin",\n    "POS": "RB",\n    "TM": "DEN",\n    "PPR": "99.2",\n    "PPR/G": "6.2",\n    "PPR/OPP": "0.72",\n    "CSTY": "6.3",\n    "CLNG": "11.2",\n    "G": "16",\n    "OPP": "138",\n    "YDS(t)": "572",\n    "TD(t)": "3",\n    "1D(t)": "28",\n    "LNG": "29",\n    "BP": "5",\n    "IMP(t)": "31",\n    "IMP%": "0.225",\n    "RecYDS": "76",\n    "RecTD": "2",\n    "REC": "24",\n    "TGT": "25",\n    "YPT": "3.04",\n    "YPR": "3.17",\n    "YAC/REC": "7.08",\n    "Rec1D": "3",\n    "YPRR": "0.54",\n    "1DRR": "0.021",\n    "CAR": "113",\n    "RuYDS": "496",\n    "YPC": "4.39",\n    "RuTD": "1",\n    "Ru1D": "25",\n    "ELU": "0.441",\n    "MTF/A": "0.248",\n    "YCO/A": "2.58"\n  },\n  {\n    "RK": "154",\n    "posRK": "78",\n    "Player": "Tutu Atwell",\n    "POS": "WR",\n    "TM": "LAR",\n    "PPR": "98.9",\n    "PPR/G": "5.8",\n    "PPR/OPP": "1.57",\n    "CSTY": "17.6",\n    "CLNG": "12.7",\n    "G": "17",\n    "OPP": "63",\n    "YDS(t)": "569",\n    "TD(t)": "0",\n    "1D(t)": "29",\n    "LNG": "52",\n    "BP": "6",\n    "IMP(t)": "29",\n    "IMP%": "0.460",\n    "RecYDS": "562",\n    "RecTD": "0",\n    "REC": "42",\n    "TGT": "61",\n    "YPT": "9.21",\n    "YPR": "13.38",\n    "YAC/REC": "2.95",\n    "Rec1D": "29",\n    "YPRR": "2.19",\n    "1DRR": "0.113",\n    "CAR": "2",\n    "RuYDS": "7",\n    "YPC": "3.50",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "155",\n    "posRK": "79",\n    "Player": "Mack Hollins",\n    "POS": "WR",\n    "TM": "BUF",\n    "PPR": "98.8",\n    "PPR/G": "5.8",\n    "PPR/OPP": "2.06",\n    "CSTY": "17.6",\n    "CLNG": "14.1",\n    "G": "17",\n    "OPP": "48",\n    "YDS(t)": "378",\n    "TD(t)": "5",\n    "1D(t)": "25",\n    "LNG": "44",\n    "BP": "4",\n    "IMP(t)": "30",\n    "IMP%": "0.625",\n    "RecYDS": "378",\n    "RecTD": "5",\n    "REC": "31",\n    "TGT": "48",\n    "YPT": "7.88",\n    "YPR": "12.19",\n    "YAC/REC": "3",\n    "Rec1D": "25",\n    "YPRR": "0.92",\n    "1DRR": "0.061",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "156",\n    "posRK": "47",\n    "Player": "Isaac Guerendo",\n    "POS": "RB",\n    "TM": "SF",\n    "PPR": "96.2",\n    "PPR/G": "6.4",\n    "PPR/OPP": "0.96",\n    "CSTY": "20.0",\n    "CLNG": "20.0",\n    "G": "15",\n    "OPP": "100",\n    "YDS(t)": "572",\n    "TD(t)": "4",\n    "1D(t)": "25",\n    "LNG": "76",\n    "BP": "2",\n    "IMP(t)": "29",\n    "IMP%": "0.290",\n    "RecYDS": "152",\n    "RecTD": "0",\n    "REC": "15",\n    "TGT": "16",\n    "YPT": "9.5",\n    "YPR": "10.13",\n    "YAC/REC": "7.33",\n    "Rec1D": "7",\n    "YPRR": "1.42",\n    "1DRR": "0.065",\n    "CAR": "84",\n    "RuYDS": "420",\n    "YPC": "5.00",\n    "RuTD": "4",\n    "Ru1D": "18",\n    "ELU": "0.395",\n    "MTF/A": "0.167",\n    "YCO/A": "3.04"\n  },\n  {\n    "RK": "157",\n    "posRK": "48",\n    "Player": "Emanuel Wilson",\n    "POS": "RB",\n    "TM": "GB",\n    "PPR": "96.0",\n    "PPR/G": "5.6",\n    "PPR/OPP": "0.83",\n    "CSTY": "17.6",\n    "CLNG": "14.4",\n    "G": "17",\n    "OPP": "115",\n    "YDS(t)": "550",\n    "TD(t)": "5",\n    "1D(t)": "30",\n    "LNG": "22",\n    "BP": "1",\n    "IMP(t)": "35",\n    "IMP%": "0.304",\n    "RecYDS": "48",\n    "RecTD": "1",\n    "REC": "11",\n    "TGT": "12",\n    "YPT": "4",\n    "YPR": "4.36",\n    "YAC/REC": "9.09",\n    "Rec1D": "3",\n    "YPRR": "0.48",\n    "1DRR": "0.030",\n    "CAR": "103",\n    "RuYDS": "502",\n    "YPC": "4.87",\n    "RuTD": "4",\n    "Ru1D": "27",\n    "ELU": "0.482",\n    "MTF/A": "0.262",\n    "YCO/A": "2.93"\n  },\n  {\n    "RK": "158",\n    "posRK": "49",\n    "Player": "Cam Akers",\n    "POS": "RB",\n    "TM": "MIN",\n    "PPR": "95.2",\n    "PPR/G": "6.3",\n    "PPR/OPP": "0.79",\n    "CSTY": "6.7",\n    "CLNG": "11.9",\n    "G": "15",\n    "OPP": "120",\n    "YDS(t)": "512",\n    "TD(t)": "5",\n    "1D(t)": "25",\n    "LNG": "24",\n    "BP": "2",\n    "IMP(t)": "30",\n    "IMP%": "0.250",\n    "RecYDS": "68",\n    "RecTD": "3",\n    "REC": "14",\n    "TGT": "16",\n    "YPT": "4.25",\n    "YPR": "4.86",\n    "YAC/REC": "6.14",\n    "Rec1D": "4",\n    "YPRR": "0.56",\n    "1DRR": "0.033",\n    "CAR": "104",\n    "RuYDS": "444",\n    "YPC": "4.27",\n    "RuTD": "2",\n    "Ru1D": "21",\n    "ELU": "0.428",\n    "MTF/A": "0.212",\n    "YCO/A": "2.89"\n  },\n  {\n    "RK": "159",\n    "posRK": "80",\n    "Player": "KaVontae Turpin",\n    "POS": "WR",\n    "TM": "DAL",\n    "PPR": "94.2",\n    "PPR/G": "5.5",\n    "PPR/OPP": "1.47",\n    "CSTY": "11.8",\n    "CLNG": "13.8",\n    "G": "17",\n    "OPP": "64",\n    "YDS(t)": "512",\n    "TD(t)": "2",\n    "1D(t)": "23",\n    "LNG": "64",\n    "BP": "6",\n    "IMP(t)": "25",\n    "IMP%": "0.391",\n    "RecYDS": "420",\n    "RecTD": "2",\n    "REC": "31",\n    "TGT": "48",\n    "YPT": "8.75",\n    "YPR": "13.55",\n    "YAC/REC": "8.52",\n    "Rec1D": "18",\n    "YPRR": "2.06",\n    "1DRR": "0.088",\n    "CAR": "16",\n    "RuYDS": "92",\n    "YPC": "5.75",\n    "RuTD": "0",\n    "Ru1D": "5",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "160",\n    "posRK": "81",\n    "Player": "Ricky Pearsall",\n    "POS": "WR",\n    "TM": "SF",\n    "PPR": "93.5",\n    "PPR/G": "8.5",\n    "PPR/OPP": "1.99",\n    "CSTY": "27.3",\n    "CLNG": "21.6",\n    "G": "11",\n    "OPP": "47",\n    "YDS(t)": "445",\n    "TD(t)": "3",\n    "1D(t)": "20",\n    "LNG": "46",\n    "BP": "5",\n    "IMP(t)": "23",\n    "IMP%": "0.489",\n    "RecYDS": "400",\n    "RecTD": "3",\n    "REC": "31",\n    "TGT": "44",\n    "YPT": "9.09",\n    "YPR": "12.9",\n    "YAC/REC": "3.55",\n    "Rec1D": "19",\n    "YPRR": "1.31",\n    "1DRR": "0.062",\n    "CAR": "3",\n    "RuYDS": "45",\n    "YPC": "15.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "161",\n    "posRK": "31",\n    "Player": "Brenton Strange",\n    "POS": "TE",\n    "TM": "JAX",\n    "PPR": "93.1",\n    "PPR/G": "5.5",\n    "PPR/OPP": "1.72",\n    "CSTY": "11.8",\n    "CLNG": "13.9",\n    "G": "17",\n    "OPP": "54",\n    "YDS(t)": "411",\n    "TD(t)": "2",\n    "1D(t)": "21",\n    "LNG": "30",\n    "BP": "7",\n    "IMP(t)": "23",\n    "IMP%": "0.426",\n    "RecYDS": "411",\n    "RecTD": "2",\n    "REC": "40",\n    "TGT": "54",\n    "YPT": "7.61",\n    "YPR": "10.28",\n    "YAC/REC": "4.72",\n    "Rec1D": "21",\n    "YPRR": "1.49",\n    "1DRR": "0.076",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "162",\n    "posRK": "82",\n    "Player": "Greg Dortch",\n    "POS": "WR",\n    "TM": "ARI",\n    "PPR": "92.3",\n    "PPR/G": "5.4",\n    "PPR/OPP": "1.81",\n    "CSTY": "5.9",\n    "CLNG": "14.0",\n    "G": "17",\n    "OPP": "51",\n    "YDS(t)": "373",\n    "TD(t)": "3",\n    "1D(t)": "16",\n    "LNG": "39",\n    "BP": "2",\n    "IMP(t)": "19",\n    "IMP%": "0.373",\n    "RecYDS": "342",\n    "RecTD": "3",\n    "REC": "37",\n    "TGT": "46",\n    "YPT": "7.43",\n    "YPR": "9.24",\n    "YAC/REC": "8.03",\n    "Rec1D": "16",\n    "YPRR": "1.18",\n    "1DRR": "0.055",\n    "CAR": "5",\n    "RuYDS": "31",\n    "YPC": "6.20",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "163",\n    "posRK": "83",\n    "Player": "Jalen Coker",\n    "POS": "WR",\n    "TM": "CAR",\n    "PPR": "91.8",\n    "PPR/G": "8.3",\n    "PPR/OPP": "2.04",\n    "CSTY": "27.3",\n    "CLNG": "17.3",\n    "G": "11",\n    "OPP": "45",\n    "YDS(t)": "478",\n    "TD(t)": "2",\n    "1D(t)": "23",\n    "LNG": "83",\n    "BP": "6",\n    "IMP(t)": "25",\n    "IMP%": "0.556",\n    "RecYDS": "478",\n    "RecTD": "2",\n    "REC": "32",\n    "TGT": "45",\n    "YPT": "10.62",\n    "YPR": "14.94",\n    "YAC/REC": "5.5",\n    "Rec1D": "23",\n    "YPRR": "1.72",\n    "1DRR": "0.083",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "164",\n    "posRK": "50",\n    "Player": "Ty Johnson",\n    "POS": "RB",\n    "TM": "BUF",\n    "PPR": "91.7",\n    "PPR/G": "5.4",\n    "PPR/OPP": "1.39",\n    "CSTY": "17.6",\n    "CLNG": "14.8",\n    "G": "17",\n    "OPP": "66",\n    "YDS(t)": "497",\n    "TD(t)": "4",\n    "1D(t)": "27",\n    "LNG": "45",\n    "BP": "11",\n    "IMP(t)": "31",\n    "IMP%": "0.470",\n    "RecYDS": "284",\n    "RecTD": "3",\n    "REC": "18",\n    "TGT": "25",\n    "YPT": "11.36",\n    "YPR": "15.78",\n    "YAC/REC": "9.28",\n    "Rec1D": "14",\n    "YPRR": "1.49",\n    "1DRR": "0.073",\n    "CAR": "41",\n    "RuYDS": "213",\n    "YPC": "5.20",\n    "RuTD": "1",\n    "Ru1D": "13",\n    "ELU": "0.354",\n    "MTF/A": "0.122",\n    "YCO/A": "3.10"\n  },\n  {\n    "RK": "165",\n    "posRK": "32",\n    "Player": "Jordan Akins",\n    "POS": "TE",\n    "TM": "CLE",\n    "PPR": "91.0",\n    "PPR/G": "5.4",\n    "PPR/OPP": "1.69",\n    "CSTY": "#VALUE!",\n    "CLNG": "NA",\n    "G": "17",\n    "OPP": "54",\n    "YDS(t)": "390",\n    "TD(t)": "2",\n    "1D(t)": "20",\n    "LNG": "21",\n    "BP": "3",\n    "IMP(t)": "22",\n    "IMP%": "0.407",\n    "RecYDS": "390",\n    "RecTD": "2",\n    "REC": "40",\n    "TGT": "54",\n    "YPT": "7.22",\n    "YPR": "9.75",\n    "YAC/REC": "4.58",\n    "Rec1D": "20",\n    "YPRR": "1.24",\n    "1DRR": "0.064",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "166",\n    "posRK": "84",\n    "Player": "Tim Patrick",\n    "POS": "WR",\n    "TM": "DET",\n    "PPR": "90.4",\n    "PPR/G": "5.7",\n    "PPR/OPP": "2.01",\n    "CSTY": "12.5",\n    "CLNG": "15.0",\n    "G": "16",\n    "OPP": "45",\n    "YDS(t)": "394",\n    "TD(t)": "3",\n    "1D(t)": "20",\n    "LNG": "42",\n    "BP": "6",\n    "IMP(t)": "23",\n    "IMP%": "0.511",\n    "RecYDS": "394",\n    "RecTD": "3",\n    "REC": "33",\n    "TGT": "45",\n    "YPT": "8.76",\n    "YPR": "11.94",\n    "YAC/REC": "4.27",\n    "Rec1D": "20",\n    "YPRR": "1.15",\n    "1DRR": "0.058",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "167",\n    "posRK": "33",\n    "Player": "Evan Engram",\n    "POS": "TE",\n    "TM": "JAX",\n    "PPR": "89.5",\n    "PPR/G": "9.9",\n    "PPR/OPP": "1.44",\n    "CSTY": "22.2",\n    "CLNG": "15.0",\n    "G": "9",\n    "OPP": "62",\n    "YDS(t)": "365",\n    "TD(t)": "1",\n    "1D(t)": "17",\n    "LNG": "24",\n    "BP": "2",\n    "IMP(t)": "18",\n    "IMP%": "0.290",\n    "RecYDS": "365",\n    "RecTD": "1",\n    "REC": "47",\n    "TGT": "62",\n    "YPT": "5.89",\n    "YPR": "7.77",\n    "YAC/REC": "3.28",\n    "Rec1D": "17",\n    "YPRR": "1.51",\n    "1DRR": "0.070",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "168",\n    "posRK": "85",\n    "Player": "Diontae Johnson",\n    "POS": "WR",\n    "TM": "HOU",\n    "PPR": "89.1",\n    "PPR/G": "7.4",\n    "PPR/OPP": "1.31",\n    "CSTY": "25.0",\n    "CLNG": "22.4",\n    "G": "12",\n    "OPP": "68",\n    "YDS(t)": "381",\n    "TD(t)": "3",\n    "1D(t)": "22",\n    "LNG": "39",\n    "BP": "5",\n    "IMP(t)": "25",\n    "IMP%": "0.368",\n    "RecYDS": "375",\n    "RecTD": "3",\n    "REC": "33",\n    "TGT": "66",\n    "YPT": "5.68",\n    "YPR": "11.36",\n    "YAC/REC": "2.94",\n    "Rec1D": "21",\n    "YPRR": "1.52",\n    "1DRR": "0.085",\n    "CAR": "2",\n    "RuYDS": "6",\n    "YPC": "3.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "169",\n    "posRK": "86",\n    "Player": "Parker Washington",\n    "POS": "WR",\n    "TM": "JAX",\n    "PPR": "89.0",\n    "PPR/G": "5.2",\n    "PPR/OPP": "1.75",\n    "CSTY": "11.8",\n    "CLNG": "15.3",\n    "G": "17",\n    "OPP": "51",\n    "YDS(t)": "390",\n    "TD(t)": "3",\n    "1D(t)": "19",\n    "LNG": "30",\n    "BP": "6",\n    "IMP(t)": "22",\n    "IMP%": "0.431",\n    "RecYDS": "390",\n    "RecTD": "3",\n    "REC": "32",\n    "TGT": "51",\n    "YPT": "7.65",\n    "YPR": "12.19",\n    "YAC/REC": "3.38",\n    "Rec1D": "19",\n    "YPRR": "1.02",\n    "1DRR": "0.050",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "170",\n    "posRK": "34",\n    "Player": "T.J. Hockenson",\n    "POS": "TE",\n    "TM": "MIN",\n    "PPR": "86.5",\n    "PPR/G": "8.7",\n    "PPR/OPP": "1.47",\n    "CSTY": "20.0",\n    "CLNG": "15.1",\n    "G": "10",\n    "OPP": "59",\n    "YDS(t)": "455",\n    "TD(t)": "0",\n    "1D(t)": "30",\n    "LNG": "34",\n    "BP": "5",\n    "IMP(t)": "30",\n    "IMP%": "0.508",\n    "RecYDS": "455",\n    "RecTD": "0",\n    "REC": "41",\n    "TGT": "59",\n    "YPT": "7.71",\n    "YPR": "11.1",\n    "YAC/REC": "3.68",\n    "Rec1D": "30",\n    "YPRR": "1.52",\n    "1DRR": "0.100",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "171",\n    "posRK": "87",\n    "Player": "Noah Brown",\n    "POS": "WR",\n    "TM": "WAS",\n    "PPR": "86.3",\n    "PPR/G": "7.8",\n    "PPR/OPP": "1.60",\n    "CSTY": "18.2",\n    "CLNG": "13.5",\n    "G": "11",\n    "OPP": "54",\n    "YDS(t)": "453",\n    "TD(t)": "1",\n    "1D(t)": "21",\n    "LNG": "52",\n    "BP": "4",\n    "IMP(t)": "22",\n    "IMP%": "0.407",\n    "RecYDS": "453",\n    "RecTD": "1",\n    "REC": "35",\n    "TGT": "54",\n    "YPT": "8.39",\n    "YPR": "12.94",\n    "YAC/REC": "2.51",\n    "Rec1D": "21",\n    "YPRR": "1.63",\n    "1DRR": "0.076",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "172",\n    "posRK": "51",\n    "Player": "Braelon Allen",\n    "POS": "RB",\n    "TM": "NYJ",\n    "PPR": "85.2",\n    "PPR/G": "5.0",\n    "PPR/OPP": "0.72",\n    "CSTY": "11.8",\n    "CLNG": "13.8",\n    "G": "17",\n    "OPP": "118",\n    "YDS(t)": "482",\n    "TD(t)": "3",\n    "1D(t)": "30",\n    "LNG": "40",\n    "BP": "1",\n    "IMP(t)": "33",\n    "IMP%": "0.280",\n    "RecYDS": "148",\n    "RecTD": "1",\n    "REC": "19",\n    "TGT": "26",\n    "YPT": "5.69",\n    "YPR": "7.79",\n    "YAC/REC": "8.63",\n    "Rec1D": "8",\n    "YPRR": "1.1",\n    "1DRR": "0.060",\n    "CAR": "92",\n    "RuYDS": "334",\n    "YPC": "3.63",\n    "RuTD": "2",\n    "Ru1D": "22",\n    "ELU": "0.323",\n    "MTF/A": "0.109",\n    "YCO/A": "2.86"\n  },\n  {\n    "RK": "173",\n    "posRK": "88",\n    "Player": "David Moore",\n    "POS": "WR",\n    "TM": "CAR",\n    "PPR": "85.1",\n    "PPR/G": "5.0",\n    "PPR/OPP": "1.52",\n    "CSTY": "5.9",\n    "CLNG": "13.7",\n    "G": "17",\n    "OPP": "56",\n    "YDS(t)": "351",\n    "TD(t)": "3",\n    "1D(t)": "18",\n    "LNG": "21",\n    "BP": "2",\n    "IMP(t)": "21",\n    "IMP%": "0.375",\n    "RecYDS": "351",\n    "RecTD": "3",\n    "REC": "32",\n    "TGT": "55",\n    "YPT": "6.38",\n    "YPR": "10.97",\n    "YAC/REC": "2.03",\n    "Rec1D": "18",\n    "YPRR": "1.04",\n    "1DRR": "0.053",\n    "CAR": "1",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "174",\n    "posRK": "89",\n    "Player": "Marquez Valdes-Scantling",\n    "POS": "WR",\n    "TM": "NO",\n    "PPR": "84.5",\n    "PPR/G": "6.0",\n    "PPR/OPP": "2.01",\n    "CSTY": "14.3",\n    "CLNG": "18.1",\n    "G": "14",\n    "OPP": "42",\n    "YDS(t)": "415",\n    "TD(t)": "4",\n    "1D(t)": "14",\n    "LNG": "71",\n    "BP": "8",\n    "IMP(t)": "18",\n    "IMP%": "0.429",\n    "RecYDS": "411",\n    "RecTD": "4",\n    "REC": "19",\n    "TGT": "41",\n    "YPT": "10.02",\n    "YPR": "21.63",\n    "YAC/REC": "7.42",\n    "Rec1D": "14",\n    "YPRR": "1.42",\n    "1DRR": "0.048",\n    "CAR": "1",\n    "RuYDS": "4",\n    "YPC": "4.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "175",\n    "posRK": "52",\n    "Player": "Zack Moss",\n    "POS": "RB",\n    "TM": "CIN",\n    "PPR": "83.9",\n    "PPR/G": "10.5",\n    "PPR/OPP": "0.83",\n    "CSTY": "37.5",\n    "CLNG": "17.5",\n    "G": "8",\n    "OPP": "101",\n    "YDS(t)": "429",\n    "TD(t)": "3",\n    "1D(t)": "24",\n    "LNG": "24",\n    "BP": "3",\n    "IMP(t)": "27",\n    "IMP%": "0.267",\n    "RecYDS": "187",\n    "RecTD": "1",\n    "REC": "23",\n    "TGT": "27",\n    "YPT": "6.93",\n    "YPR": "8.13",\n    "YAC/REC": "8.78",\n    "Rec1D": "11",\n    "YPRR": "1.21",\n    "1DRR": "0.071",\n    "CAR": "74",\n    "RuYDS": "242",\n    "YPC": "3.27",\n    "RuTD": "2",\n    "Ru1D": "13",\n    "ELU": "0.281",\n    "MTF/A": "0.122",\n    "YCO/A": "2.12"\n  },\n  {\n    "RK": "176",\n    "posRK": "90",\n    "Player": "Cedric Tillman",\n    "POS": "WR",\n    "TM": "CLE",\n    "PPR": "80.4",\n    "PPR/G": "7.3",\n    "PPR/OPP": "1.75",\n    "CSTY": "27.3",\n    "CLNG": "21.5",\n    "G": "11",\n    "OPP": "46",\n    "YDS(t)": "334",\n    "TD(t)": "3",\n    "1D(t)": "15",\n    "LNG": "38",\n    "BP": "6",\n    "IMP(t)": "18",\n    "IMP%": "0.391",\n    "RecYDS": "339",\n    "RecTD": "3",\n    "REC": "29",\n    "TGT": "45",\n    "YPT": "7.53",\n    "YPR": "11.69",\n    "YAC/REC": "3.83",\n    "Rec1D": "15",\n    "YPRR": "1.22",\n    "1DRR": "0.054",\n    "CAR": "1",\n    "RuYDS": "-5",\n    "YPC": "-5.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "177",\n    "posRK": "91",\n    "Player": "Chris Olave",\n    "POS": "WR",\n    "TM": "NO",\n    "PPR": "78.7",\n    "PPR/G": "9.8",\n    "PPR/OPP": "1.79",\n    "CSTY": "50.0",\n    "CLNG": "18.7",\n    "G": "8",\n    "OPP": "44",\n    "YDS(t)": "407",\n    "TD(t)": "1",\n    "1D(t)": "23",\n    "LNG": "39",\n    "BP": "4",\n    "IMP(t)": "24",\n    "IMP%": "0.545",\n    "RecYDS": "400",\n    "RecTD": "1",\n    "REC": "32",\n    "TGT": "43",\n    "YPT": "9.3",\n    "YPR": "12.5",\n    "YAC/REC": "3.69",\n    "Rec1D": "22",\n    "YPRR": "2.13",\n    "1DRR": "0.117",\n    "CAR": "1",\n    "RuYDS": "7",\n    "YPC": "7.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "178",\n    "posRK": "92",\n    "Player": "Sterling Shepard",\n    "POS": "WR",\n    "TM": "TB",\n    "PPR": "78.3",\n    "PPR/G": "5.6",\n    "PPR/OPP": "1.37",\n    "CSTY": "0.0",\n    "CLNG": "9.9",\n    "G": "14",\n    "OPP": "57",\n    "YDS(t)": "403",\n    "TD(t)": "1",\n    "1D(t)": "20",\n    "LNG": "30",\n    "BP": "4",\n    "IMP(t)": "21",\n    "IMP%": "0.368",\n    "RecYDS": "334",\n    "RecTD": "1",\n    "REC": "32",\n    "TGT": "49",\n    "YPT": "6.82",\n    "YPR": "10.44",\n    "YAC/REC": "2.94",\n    "Rec1D": "16",\n    "YPRR": "0.96",\n    "1DRR": "0.046",\n    "CAR": "8",\n    "RuYDS": "69",\n    "YPC": "8.63",\n    "RuTD": "0",\n    "Ru1D": "4",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "179",\n    "posRK": "53",\n    "Player": "Roschon Johnson",\n    "POS": "RB",\n    "TM": "CHI",\n    "PPR": "77.4",\n    "PPR/G": "6.0",\n    "PPR/OPP": "1.08",\n    "CSTY": "7.7",\n    "CLNG": "11.9",\n    "G": "13",\n    "OPP": "72",\n    "YDS(t)": "254",\n    "TD(t)": "6",\n    "1D(t)": "23",\n    "LNG": "0",\n    "BP": "0",\n    "IMP(t)": "29",\n    "IMP%": "0.403",\n    "RecYDS": "104",\n    "RecTD": "0",\n    "REC": "16",\n    "TGT": "17",\n    "YPT": "6.12",\n    "YPR": "6.5",\n    "YAC/REC": "6.31",\n    "Rec1D": "6",\n    "YPRR": "0.76",\n    "1DRR": "0.044",\n    "CAR": "55",\n    "RuYDS": "150",\n    "YPC": "2.73",\n    "RuTD": "6",\n    "Ru1D": "17",\n    "ELU": "0.246",\n    "MTF/A": "0.091",\n    "YCO/A": "2.07"\n  },\n  {\n    "RK": "180",\n    "posRK": "54",\n    "Player": "Miles Sanders",\n    "POS": "RB",\n    "TM": "CAR",\n    "PPR": "77.3",\n    "PPR/G": "7.0",\n    "PPR/OPP": "0.93",\n    "CSTY": "9.1",\n    "CLNG": "16.4",\n    "G": "11",\n    "OPP": "83",\n    "YDS(t)": "353",\n    "TD(t)": "3",\n    "1D(t)": "17",\n    "LNG": "38",\n    "BP": "9",\n    "IMP(t)": "20",\n    "IMP%": "0.241",\n    "RecYDS": "148",\n    "RecTD": "1",\n    "REC": "24",\n    "TGT": "28",\n    "YPT": "5.29",\n    "YPR": "6.17",\n    "YAC/REC": "6.25",\n    "Rec1D": "5",\n    "YPRR": "1.14",\n    "1DRR": "0.038",\n    "CAR": "55",\n    "RuYDS": "205",\n    "YPC": "3.73",\n    "RuTD": "2",\n    "Ru1D": "12",\n    "ELU": "0.370",\n    "MTF/A": "0.182",\n    "YCO/A": "2.51"\n  },\n  {\n    "RK": "181",\n    "posRK": "93",\n    "Player": "Rashid Shaheed",\n    "POS": "WR",\n    "TM": "NO",\n    "PPR": "75.8",\n    "PPR/G": "12.6",\n    "PPR/OPP": "1.65",\n    "CSTY": "66.7",\n    "CLNG": "19.1",\n    "G": "6",\n    "OPP": "46",\n    "YDS(t)": "378",\n    "TD(t)": "3",\n    "1D(t)": "14",\n    "LNG": "70",\n    "BP": "5",\n    "IMP(t)": "17",\n    "IMP%": "0.370",\n    "RecYDS": "349",\n    "RecTD": "3",\n    "REC": "20",\n    "TGT": "40",\n    "YPT": "8.72",\n    "YPR": "17.45",\n    "YAC/REC": "5.1",\n    "Rec1D": "12",\n    "YPRR": "2.04",\n    "1DRR": "0.070",\n    "CAR": "6",\n    "RuYDS": "29",\n    "YPC": "4.83",\n    "RuTD": "0",\n    "Ru1D": "2",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "182",\n    "posRK": "55",\n    "Player": "Raheem Mostert",\n    "POS": "RB",\n    "TM": "MIA",\n    "PPR": "74.9",\n    "PPR/G": "5.8",\n    "PPR/OPP": "0.71",\n    "CSTY": "7.7",\n    "CLNG": "12.9",\n    "G": "13",\n    "OPP": "106",\n    "YDS(t)": "439",\n    "TD(t)": "2",\n    "1D(t)": "25",\n    "LNG": "92",\n    "BP": "2",\n    "IMP(t)": "27",\n    "IMP%": "0.255",\n    "RecYDS": "161",\n    "RecTD": "0",\n    "REC": "19",\n    "TGT": "21",\n    "YPT": "7.67",\n    "YPR": "8.47",\n    "YAC/REC": "7.53",\n    "Rec1D": "10",\n    "YPRR": "1.04",\n    "1DRR": "0.065",\n    "CAR": "85",\n    "RuYDS": "278",\n    "YPC": "3.27",\n    "RuTD": "2",\n    "Ru1D": "15",\n    "ELU": "0.394",\n    "MTF/A": "0.188",\n    "YCO/A": "2.74"\n  },\n  {\n    "RK": "183",\n    "posRK": "94",\n    "Player": "Christian Kirk",\n    "POS": "WR",\n    "TM": "JAX",\n    "PPR": "70.9",\n    "PPR/G": "8.9",\n    "PPR/OPP": "1.51",\n    "CSTY": "37.5",\n    "CLNG": "15.9",\n    "G": "8",\n    "OPP": "47",\n    "YDS(t)": "379",\n    "TD(t)": "1",\n    "1D(t)": "18",\n    "LNG": "61",\n    "BP": "7",\n    "IMP(t)": "19",\n    "IMP%": "0.404",\n    "RecYDS": "379",\n    "RecTD": "1",\n    "REC": "27",\n    "TGT": "47",\n    "YPT": "8.06",\n    "YPR": "14.04",\n    "YAC/REC": "4.22",\n    "Rec1D": "18",\n    "YPRR": "1.72",\n    "1DRR": "0.082",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "184",\n    "posRK": "95",\n    "Player": "Brandin Cooks",\n    "POS": "WR",\n    "TM": "DAL",\n    "PPR": "69.6",\n    "PPR/G": "7.0",\n    "PPR/OPP": "1.31",\n    "CSTY": "10.0",\n    "CLNG": "11.4",\n    "G": "10",\n    "OPP": "53",\n    "YDS(t)": "256",\n    "TD(t)": "3",\n    "1D(t)": "19",\n    "LNG": "29",\n    "BP": "3",\n    "IMP(t)": "22",\n    "IMP%": "0.415",\n    "RecYDS": "259",\n    "RecTD": "3",\n    "REC": "26",\n    "TGT": "50",\n    "YPT": "5.18",\n    "YPR": "9.96",\n    "YAC/REC": "2.19",\n    "Rec1D": "19",\n    "YPRR": "0.89",\n    "1DRR": "0.066",\n    "CAR": "3",\n    "RuYDS": "-3",\n    "YPC": "-1.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "185",\n    "posRK": "56",\n    "Player": "Sean Tucker",\n    "POS": "RB",\n    "TM": "TB",\n    "PPR": "68.7",\n    "PPR/G": "5.7",\n    "PPR/OPP": "1.13",\n    "CSTY": "8.3",\n    "CLNG": "15.9",\n    "G": "12",\n    "OPP": "61",\n    "YDS(t)": "417",\n    "TD(t)": "3",\n    "1D(t)": "23",\n    "LNG": "20",\n    "BP": "1",\n    "IMP(t)": "26",\n    "IMP%": "0.426",\n    "RecYDS": "109",\n    "RecTD": "1",\n    "REC": "9",\n    "TGT": "11",\n    "YPT": "9.91",\n    "YPR": "12.11",\n    "YAC/REC": "11.44",\n    "Rec1D": "6",\n    "YPRR": "2.6",\n    "1DRR": "0.143",\n    "CAR": "50",\n    "RuYDS": "308",\n    "YPC": "6.16",\n    "RuTD": "2",\n    "Ru1D": "17",\n    "ELU": "0.345",\n    "MTF/A": "0.100",\n    "YCO/A": "3.26"\n  },\n  {\n    "RK": "186",\n    "posRK": "35",\n    "Player": "Theo Johnson",\n    "POS": "TE",\n    "TM": "NYG",\n    "PPR": "68.1",\n    "PPR/G": "5.7",\n    "PPR/OPP": "1.58",\n    "CSTY": "8.3",\n    "CLNG": "11.4",\n    "G": "12",\n    "OPP": "43",\n    "YDS(t)": "331",\n    "TD(t)": "1",\n    "1D(t)": "16",\n    "LNG": "35",\n    "BP": "4",\n    "IMP(t)": "17",\n    "IMP%": "0.395",\n    "RecYDS": "331",\n    "RecTD": "1",\n    "REC": "29",\n    "TGT": "43",\n    "YPT": "7.7",\n    "YPR": "11.41",\n    "YAC/REC": "5.52",\n    "Rec1D": "16",\n    "YPRR": "0.9",\n    "1DRR": "0.044",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "187",\n    "posRK": "57",\n    "Player": "Nick Chubb",\n    "POS": "RB",\n    "TM": "CLE",\n    "PPR": "65.3",\n    "PPR/G": "8.2",\n    "PPR/OPP": "0.59",\n    "CSTY": "25.0",\n    "CLNG": "13.9",\n    "G": "8",\n    "OPP": "111",\n    "YDS(t)": "363",\n    "TD(t)": "4",\n    "1D(t)": "20",\n    "LNG": "34",\n    "BP": "1",\n    "IMP(t)": "24",\n    "IMP%": "0.216",\n    "RecYDS": "31",\n    "RecTD": "1",\n    "REC": "5",\n    "TGT": "9",\n    "YPT": "3.44",\n    "YPR": "6.2",\n    "YAC/REC": "6.2",\n    "Rec1D": "3",\n    "YPRR": "0.36",\n    "1DRR": "0.034",\n    "CAR": "102",\n    "RuYDS": "332",\n    "YPC": "3.25",\n    "RuTD": "3",\n    "Ru1D": "17",\n    "ELU": "0.398",\n    "MTF/A": "0.196",\n    "YCO/A": "2.69"\n  },\n  {\n    "RK": "188",\n    "posRK": "96",\n    "Player": "Kendrick Bourne",\n    "POS": "WR",\n    "TM": "NE",\n    "PPR": "65.1",\n    "PPR/G": "5.4",\n    "PPR/OPP": "1.71",\n    "CSTY": "8.3",\n    "CLNG": "11.2",\n    "G": "12",\n    "OPP": "38",\n    "YDS(t)": "311",\n    "TD(t)": "1",\n    "1D(t)": "14",\n    "LNG": "37",\n    "BP": "2",\n    "IMP(t)": "15",\n    "IMP%": "0.395",\n    "RecYDS": "305",\n    "RecTD": "1",\n    "REC": "28",\n    "TGT": "37",\n    "YPT": "8.24",\n    "YPR": "10.89",\n    "YAC/REC": "3.46",\n    "Rec1D": "13",\n    "YPRR": "1.06",\n    "1DRR": "0.045",\n    "CAR": "1",\n    "RuYDS": "6",\n    "YPC": "6.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "189",\n    "posRK": "97",\n    "Player": "Rashee Rice",\n    "POS": "WR",\n    "TM": "KC",\n    "PPR": "64.9",\n    "PPR/G": "16.2",\n    "PPR/OPP": "2.16",\n    "CSTY": "75.0",\n    "CLNG": "21.6",\n    "G": "4",\n    "OPP": "30",\n    "YDS(t)": "289",\n    "TD(t)": "2",\n    "1D(t)": "16",\n    "LNG": "44",\n    "BP": "3",\n    "IMP(t)": "18",\n    "IMP%": "0.600",\n    "RecYDS": "288",\n    "RecTD": "2",\n    "REC": "24",\n    "TGT": "29",\n    "YPT": "9.93",\n    "YPR": "12",\n    "YAC/REC": "7.71",\n    "Rec1D": "15",\n    "YPRR": "3.16",\n    "1DRR": "0.165",\n    "CAR": "1",\n    "RuYDS": "1",\n    "YPC": "1.00",\n    "RuTD": "0",\n    "Ru1D": "1",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "190",\n    "posRK": "58",\n    "Player": "Gus Edwards",\n    "POS": "RB",\n    "TM": "LAC",\n    "PPR": "64.1",\n    "PPR/G": "5.8",\n    "PPR/OPP": "0.61",\n    "CSTY": "9.1",\n    "CLNG": "12.3",\n    "G": "11",\n    "OPP": "105",\n    "YDS(t)": "371",\n    "TD(t)": "4",\n    "1D(t)": "17",\n    "LNG": "23",\n    "BP": "1",\n    "IMP(t)": "21",\n    "IMP%": "0.200",\n    "RecYDS": "6",\n    "RecTD": "0",\n    "REC": "3",\n    "TGT": "4",\n    "YPT": "1.5",\n    "YPR": "2",\n    "YAC/REC": "3.33",\n    "Rec1D": "0",\n    "YPRR": "0.09",\n    "1DRR": "0.000",\n    "CAR": "101",\n    "RuYDS": "365",\n    "YPC": "3.61",\n    "RuTD": "4",\n    "Ru1D": "17",\n    "ELU": "0.328",\n    "MTF/A": "0.129",\n    "YCO/A": "2.66"\n  },\n  {\n    "RK": "191",\n    "posRK": "98",\n    "Player": "Brandon Aiyuk",\n    "POS": "WR",\n    "TM": "SF",\n    "PPR": "62.4",\n    "PPR/G": "8.9",\n    "PPR/OPP": "1.39",\n    "CSTY": "14.3",\n    "CLNG": "13.6",\n    "G": "7",\n    "OPP": "45",\n    "YDS(t)": "374",\n    "TD(t)": "0",\n    "1D(t)": "19",\n    "LNG": "53",\n    "BP": "5",\n    "IMP(t)": "19",\n    "IMP%": "0.422",\n    "RecYDS": "374",\n    "RecTD": "0",\n    "REC": "25",\n    "TGT": "45",\n    "YPT": "8.31",\n    "YPR": "14.96",\n    "YAC/REC": "4.16",\n    "Rec1D": "19",\n    "YPRR": "1.74",\n    "1DRR": "0.088",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "192",\n    "posRK": "59",\n    "Player": "Isiah Pacheco",\n    "POS": "RB",\n    "TM": "KC",\n    "PPR": "56.9",\n    "PPR/G": "8.1",\n    "PPR/OPP": "0.57",\n    "CSTY": "#VALUE!",\n    "CLNG": "NA",\n    "G": "7",\n    "OPP": "99",\n    "YDS(t)": "389",\n    "TD(t)": "1",\n    "1D(t)": "18",\n    "LNG": "41",\n    "BP": "4",\n    "IMP(t)": "19",\n    "IMP%": "0.192",\n    "RecYDS": "79",\n    "RecTD": "0",\n    "REC": "12",\n    "TGT": "16",\n    "YPT": "4.94",\n    "YPR": "6.58",\n    "YAC/REC": "9.92",\n    "Rec1D": "4",\n    "YPRR": "0.81",\n    "1DRR": "0.041",\n    "CAR": "83",\n    "RuYDS": "310",\n    "YPC": "3.73",\n    "RuTD": "1",\n    "Ru1D": "14",\n    "ELU": "0.227",\n    "MTF/A": "0.048",\n    "YCO/A": "2.39"\n  },\n  {\n    "RK": "193",\n    "posRK": "99",\n    "Player": "Gabe Davis",\n    "POS": "WR",\n    "TM": "JAX",\n    "PPR": "55.9",\n    "PPR/G": "5.6",\n    "PPR/OPP": "1.33",\n    "CSTY": "#VALUE!",\n    "CLNG": "NA",\n    "G": "10",\n    "OPP": "42",\n    "YDS(t)": "239",\n    "TD(t)": "2",\n    "1D(t)": "13",\n    "LNG": "22",\n    "BP": "6",\n    "IMP(t)": "15",\n    "IMP%": "0.357",\n    "RecYDS": "239",\n    "RecTD": "2",\n    "REC": "20",\n    "TGT": "42",\n    "YPT": "5.69",\n    "YPR": "11.95",\n    "YAC/REC": "2.15",\n    "Rec1D": "13",\n    "YPRR": "0.95",\n    "1DRR": "0.052",\n    "CAR": "0",\n    "RuYDS": "0",\n    "YPC": "0.00",\n    "RuTD": "0",\n    "Ru1D": "0",\n    "ELU": "NA",\n    "MTF/A": "NA",\n    "YCO/A": "NA"\n  },\n  {\n    "RK": "194",\n    "posRK": "60",\n    "Player": "Christian McCaffrey",\n    "POS": "RB",\n    "TM": "SF",\n    "PPR": "49.8",\n    "PPR/G": "12.5",\n    "PPR/OPP": "0.72",\n    "CSTY": "#VALUE!",\n    "CLNG": "NA",\n    "G": "4",\n    "OPP": "69",\n    "YDS(t)": "348",\n    "TD(t)": "0",\n    "1D(t)": "18",\n    "LNG": "21",\n    "BP": "1",\n    "IMP(t)": "18",\n    "IMP%": "0.261",\n    "RecYDS": "146",\n    "RecTD": "0",\n    "REC": "15",\n    "TGT": "19",\n    "YPT": "7.68",\n    "YPR": "9.73",\n    "YAC/REC": "6.73",\n    "Rec1D": "6",\n    "YPRR": "1.6",\n    "1DRR": "0.066",\n    "CAR": "50",\n    "RuYDS": "202",\n    "YPC": "4.04",\n    "RuTD": "0",\n    "Ru1D": "12",\n    "ELU": "0.303",\n    "MTF/A": "0.100",\n    "YCO/A": "2.70"\n  },\n  {\n    "RK": "195",\n    "posRK": "61",\n    "Player": "Isaiah Davis",\n    "POS": "RB",\n    "TM": "NYJ",\n    "PPR": "45.9",\n    "PPR/G": "5.1",\n    "PPR/OPP": "1.09",\n    "CSTY": "#VALUE!",\n    "CLNG": "NA",\n    "G": "9",\n    "OPP": "42",\n    "YDS(t)": "249",\n    "TD(t)": "2",\n    "1D(t)": "14",\n    "LNG": "66",\n    "BP": "5",\n    "IMP(t)": "16",\n    "IMP%": "0.381",\n    "RecYDS": "75",\n    "RecTD": "1",\n    "REC": "9",\n    "TGT": "12",\n    "YPT": "6.25",\n    "YPR": "8.33",\n    "YAC/REC": "8.33",\n    "Rec1D": "4",\n    "YPRR": "1.25",\n    "1DRR": "0.067",\n    "CAR": "30",\n    "RuYDS": "174",\n    "YPC": "5.80",\n    "RuTD": "1",\n    "Ru1D": "10",\n    "ELU": "0.515",\n    "MTF/A": "0.200",\n    "YCO/A": "4.20"\n  },\n  {\n    "RK": "196",\n    "posRK": "62",\n    "Player": "Sincere McCormick",\n    "POS": "RB",\n    "TM": "LV",\n    "PPR": "27.2",\n    "PPR/G": "6.8",\n    "PPR/OPP": "0.60",\n    "CSTY": "#VALUE!",\n    "CLNG": "NA",\n    "G": "4",\n    "OPP": "45",\n    "YDS(t)": "212",\n    "TD(t)": "0",\n    "1D(t)": "12",\n    "LNG": "28",\n    "BP": "5",\n    "IMP(t)": "12",\n    "IMP%": "0.267",\n    "RecYDS": "29",\n    "RecTD": "0",\n    "REC": "6",\n    "TGT": "6",\n    "YPT": "4.83",\n    "YPR": "4.83",\n    "YAC/REC": "4.5",\n    "Rec1D": "2",\n    "YPRR": "1.16",\n    "1DRR": "0.080",\n    "CAR": "39",\n    "RuYDS": "183",\n    "YPC": "4.69",\n    "RuTD": "0",\n    "Ru1D": "10",\n    "ELU": "0.446",\n    "MTF/A": "0.205",\n    "YCO/A": "3.21"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicColumnProperties={{ formatByIndex: "auto", labelByIndex: "f" }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      headerTextWrap={true}
      linkedFilterId=""
      primaryKeyColumnId="3466d"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      style={{
        headerFontFamily: "Michroma",
        fontWeight: "100",
        rowSeparator: "rgba(130, 138, 179, 0.04)",
        border: "rgba(130, 138, 179, 0.2)",
        hoverRowBackground: "rgba(87, 0, 255, 0.4)",
        alternateRowBackground: "rgba(26, 26, 50, 1)",
        background: "rgba(23, 23, 44, 1)",
        cellText: "rgba(255, 255, 255, 1)",
        fontSize: "12px",
        fontFamily: "Google Sans",
        headerFontWeight: "400",
        headerBackground: "#141a32",
        headerFontSize: "10px",
      }}
    >
      <Column
        id="78407"
        alignment="center"
        format="tag"
        formatOptions={{ automaticColors: false, color: "#acafc521" }}
        groupAggregationMode="none"
        key="RK"
        label="RK"
        placeholder="Select option"
        position="left"
        size={108}
        summaryAggregationMode="none"
        textColor="{{  currentSourceRow.RK < 13 ? '#00ffc4' :

  currentSourceRow.RK < 25 ? '#85fff3' :

  currentSourceRow.RK < 37 ? '#7dd1ff' :

  currentSourceRow.RK < 49 ? '#48a6ff' :

  currentSourceRow.RK < 61 ? '#957cff' :

  currentSourceRow.RK < 73 ? '#a642ff' :

  currentSourceRow.RK < 97 ? '#cf60ff' :

  currentSourceRow.RK < 121 ? '#ff6fe1' :

  currentSourceRow.RK < 157 ? '#ff2eb2' :

  currentSourceRow.RK < 201 ? '#ff0080' :  '' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPPR Rank [FPTS]\n</div>'
        }
      />
      <Column
        id="3466d"
        alignment="left"
        editable={false}
        format="string"
        groupAggregationMode="none"
        key="Player"
        label="PLAYER"
        placeholder="Enter value"
        position="left"
        size={125.640625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPlayer Name\n</div>'
        }
      />
      <Column
        id="9aeb4"
        alignment="center"
        format="tag"
        formatOptions={{ automaticColors: false, color: "#999dbebb", icon: "" }}
        groupAggregationMode="none"
        key="posRK"
        label="POS • RK"
        placeholder="Select option"
        position="left"
        size={80.484375}
        summaryAggregationMode="none"
        textColor="{{ currentSourceRow.POS == 'RB' ? '#33FFA4' :
  currentSourceRow.POS == 'WR' ? '#00f5fF' :
  currentSourceRow.POS == 'TE' ? '#6300ff' :  '' }}
"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nRank by Position [FPTS]\n</div>'
        }
        valueOverride="{{ currentSourceRow.POS }} • {{ item }}"
      />
      <Column
        id="50caa"
        alignment="center"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="none"
        key="TM"
        label="TM"
        optionList={{
          mode: "mapped",
          mappedData:
            '[\n  { value: "ARI", color: "#97233F", textColor: "#ffffff" },  // red ⟡ yellow :contentReference[oaicite:0]{index=0}\n  { value: "ATL", color: "#Aa1930", textColor: "#000000" },  // red ⟡ black :contentReference[oaicite:1]{index=1}\n  { value: "BAL", color: "#341793", textColor: "#9E7C2C" },  // purple ⟡ gold :contentReference[oaicite:2]{index=2}\n  { value: "BUF", color: "#00338D99", textColor: "#C61C30ef" },  // royal ⟡ red :contentReference[oaicite:3]{index=3}\n  { value: "CAR", color: "#0085CAcc", textColor: "#000000" },  // blue ⟡ black :contentReference[oaicite:4]{index=4}\n  { value: "CHI", color: "#0B162A", textColor: "#f64F00" },  // navy ⟡ orange :contentReference[oaicite:5]{index=5}\n  { value: "CIN", color: "#FB3F14ef", textColor: "#000000" },  // orange ⟡ black :contentReference[oaicite:6]{index=6}\n  { value: "CLE", color: "#DF3C20", textColor: "#101010" },  // orange ⟡ brown :contentReference[oaicite:7]{index=7}\n  { value: "DAL", color: "#003594cd", textColor: "#A5ACAF" },  // navy ⟡ silver :contentReference[oaicite:8]{index=8}\n  { value: "DEN", color: "#FB2F14da", textColor: "#002244" },  // orange ⟡ navy :contentReference[oaicite:9]{index=9}\n  { value: "DET", color: "#0076B6aa", textColor: "#B0B7BC" },  // honolulu ⟡ silver :contentReference[oaicite:10]{index=10}\n  { value: "GB",  color: "#203731", textColor: "#FFB612" },  // green ⟡ gold :contentReference[oaicite:11]{index=11}\n  { value: "HOU", color: "#03202F", textColor: "#D71930ee" },  // deep blue ⟡ red :contentReference[oaicite:12]{index=12}\n  { value: "IND", color: "#002C5F", textColor: "#F2FAFD" },  // royal ⟡ gray :contentReference[oaicite:13]{index=13}\n  { value: "JAX", color: "#006778aa", textColor: "#D7A22A" },  // teal ⟡ gold :contentReference[oaicite:14]{index=14}\n  { value: "KC",  color: "#E31837cc", textColor: "#FFB612" },  // red ⟡ gold :contentReference[oaicite:15]{index=15}\n  { value: "LAC", color: "#0080C6aa", textColor: "#FFC20E" },  // powder ⟡ sunshine :contentReference[oaicite:16]{index=16}\n  { value: "LAR", color: "#003594bb", textColor: "#FFA300ec" },  // royal ⟡ sol :contentReference[oaicite:17]{index=17}\n  { value: "LV",  color: "#000000", textColor: "#A5ACAF" },  // black ⟡ silver :contentReference[oaicite:18]{index=18}\n  { value: "MIA", color: "#008E87aa", textColor: "#FC5C02" },  // aqua ⟡ orange :contentReference[oaicite:19]{index=19}\n  { value: "MIN", color: "#4F2683", textColor: "#FFC62F" },  // purple ⟡ gold :contentReference[oaicite:20]{index=20}\n  { value: "NE",  color: "#041E62", textColor: "#D60F51" },  // blue ⟡ red :contentReference[oaicite:21]{index=21}\n  { value: "NO",  color: "#D3BC8D", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:22]{index=22}\n  { value: "NYG", color: "#0B2265", textColor: "#DFDFDF" },  // blue ⟡ red :contentReference[oaicite:23]{index=23}\n  { value: "NYJ", color: "#125740ac", textColor: "#FFFFFF" },  // green ⟡ white :contentReference[oaicite:24]{index=24}\n  { value: "PHI", color: "#004C54cc", textColor: "#A5ACAF" },  // midnight ⟡ silver :contentReference[oaicite:25]{index=25}\n  { value: "PIT", color: "#FFB612cc", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:26]{index=26}\n  { value: "SEA", color: "#002244", textColor: "#69BE28" },  // navy ⟡ action-green :contentReference[oaicite:27]{index=27}\n  { value: "SF",  color: "#AA0000ac", textColor: "#B3995D" },  // scarlet ⟡ gold :contentReference[oaicite:28]{index=28}\n  { value: "TB",  color: "#D50A0Aec", textColor: "#0A0A08" },  // red ⟡ pewter :contentReference[oaicite:29]{index=29}\n  { value: "TEN", color: "#0C2340", textColor: "#4B92DB" },  // navy ⟡ titan-blue :contentReference[oaicite:30]{index=30}\n  { value: "WAS", color: "#5A1414ac", textColor: "#FFB612ee" },  // burgundy ⟡ gold :contentReference[oaicite:31]{index=31}\n  { value: "UDF", color: "#9E9E9E", textColor: "#FFFFFF" }  // neutral grey\n]',
          valueByIndex: "{{ item.value }}",
          labelByIndex: "{{ item.value }}",
          colorByIndex: "{{ item.color }}",
          textColorByIndex: "{{ item.textColor }}",
        }}
        placeholder="Select option"
        position="left"
        size={54.390625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTeam [NFL]\n</div>'
        }
      />
      <Column
        id="f83ae"
        alignment="right"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        hidden="true"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              ordered: [
                { value: "QB" },
                { color: "#ff2a6d" },
                { textColor: "rgba(18, 18, 18, 1)" },
                { icon: "" },
                { label: "" },
              ],
            },
            {
              value: "WR",
              color: "rgba(88, 167, 255, 0)",
              textColor: "#58a7ff",
              icon: "bold/computer-connection-usb-port",
              caption: "aa",
            },
            {
              value: "RB",
              icon: "bold/travel-transportation-bus",
              color: "rgba(34, 228, 176, 0)",
              textColor: "rgba(54, 224, 186, 1)",
            },
            {
              value: "TE",
              textColor: "#8300ff",
              color: "rgba(0, 0, 0, 0)",
              icon: "bold/interface-security-shield-4",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="center"
        size={65.859375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPosition\n</div>'
        }
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="b67b8"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#d8fcff"
        key="PPR"
        label="FPTS"
        placeholder="Enter value"
        position="center"
        size={72}
        summaryAggregationMode="none"
        textColor="{{  currentSourceRow.RK < 13 ? '#00ffc4' :

  currentSourceRow.RK < 25 ? '#85fff3' :

  currentSourceRow.RK < 37 ? '#7dd1ff' :

  currentSourceRow.RK < 49 ? '#48a6ff' :

  currentSourceRow.RK < 61 ? '#957cff' :

  currentSourceRow.RK < 73 ? '#a642ff' :

  currentSourceRow.RK < 97 ? '#cf60ff' :

  currentSourceRow.RK < 121 ? '#ff6fe1' :

  currentSourceRow.RK < 157 ? '#ff2eb2' :

  currentSourceRow.RK < 201 ? '#ff0080' :  '' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nFantasy Points [PPR]\n</div>'
        }
      />
      <Column
        id="681f4"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="rgba(216, 252, 255, 1)"
        key="PPR/G"
        label="PPG"
        optionList={{
          mode: "manual",
          mappedData: "{{  }}",
          textColorByIndex: "",
          colorByIndex: "",
        }}
        placeholder="Enter value"
        position="center"
        size={61.53125}
        summaryAggregationMode="none"
        textColor={
          "{{  currentSourceRow[\"PPR/G\"] > 17.6 ? '#00ffc4' :\n  currentSourceRow[\"PPR/G\"] > 16.5 ? '#85fff3' :\n  currentSourceRow[\"PPR/G\"] > 15.2 ? '#7dd1ff' :\n  currentSourceRow[\"PPR/G\"] > 14 ? '#48a6ff' :\n  currentSourceRow[\"PPR/G\"] > 12.7 ? '#957cff' :\n  currentSourceRow[\"PPR/G\"] > 11.9 ? '#a642ff' :\n  currentSourceRow[\"PPR/G\"] > 10.1 ? '#cf60ff' :\n  currentSourceRow[\"PPR/G\"] > 8.5 ? '#ff6fe1' :\n  currentSourceRow[\"PPR/G\"] > 6.9 ? '#ff2eb2' :\n  currentSourceRow[\"PPR/G\"] > 5 ? '#ff0080' :  '' }}"
        }
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nFantasy Points per Game [PPR]\n</div>'
        }
      />
      <Column
        id="c8555"
        alignment="center"
        format="tag"
        formatOptions={{ automaticColors: false, color: "#4b527cc0" }}
        groupAggregationMode="none"
        key="CSTY"
        label="CSTY ⌊𐘳⌉"
        placeholder="Select option"
        position="center"
        size={85}
        summaryAggregationMode="none"
        textColor="{{  currentSourceRow.CSTY > 99.0 ? '#00ffc4' :
  currentSourceRow.CSTY > 74.0 ? '#85fff3' :
  currentSourceRow.CSTY > 61.5 ? '#7dd1ff' :
  currentSourceRow.CSTY > 49.0 ? '#48a6ff' :
  currentSourceRow.CSTY > 41.1 ? '#957cff' :
  currentSourceRow.CSTY > 34.3 ? '#a642ff' :
  currentSourceRow.CSTY > 25.0 ? '#cf60ff' :
  currentSourceRow.CSTY > 20.4 ? '#ff6fe1' :
  currentSourceRow.CSTY > 16.6 ? '#ff2eb2' :
  currentSourceRow.CSTY > 0 ? '#ff0080' :  '' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nConsistency [#G>12FPTS/G]\n</div>'
        }
        valueOverride="{{ item }}%"
      />
      <Column
        id="31136"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="tag"
        formatOptions={{ automaticColors: false, color: "#4B527CC0" }}
        groupAggregationMode="sum"
        key="CLNG"
        label="CLNG ⌊ℂ⌉"
        placeholder="Select option"
        position="center"
        size={87}
        summaryAggregationMode="none"
        textColor="{{  currentSourceRow.CLNG > 46.3 ? '#00ffc4' :
  currentSourceRow.CLNG > 28.2 ? '#85fff3' :
  currentSourceRow.CLNG > 24.9 ? '#7dd1ff' :
  currentSourceRow.CLNG > 22.8 ? '#48a6ff' :
  currentSourceRow.CLNG > 20.5 ? '#957cff' :
  currentSourceRow.CLNG > 19.3 ? '#a642ff' :
  currentSourceRow.CLNG > 17.9 ? '#cf60ff' :
  currentSourceRow.CLNG > 15.8 ? '#ff6fe1' :
  currentSourceRow.CLNG > 14.0 ? '#ff2eb2' :
  currentSourceRow.CLNG > 0 ? '#ff0080' :  '' }}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nCeiling\n</div>'
        }
      />
      <Column
        id="6beae"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="G"
        label="G"
        optionList={{ mode: "mapped", mappedData: "{{  }}" }}
        placeholder="Enter value"
        position="center"
        size={34.6875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nGames Played\n</div>'
        }
      />
      <Column
        id="e9438"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(181, 161, 254, 1)"
        key="YDS(t)"
        label="YDS ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={70.734375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [Total]\n</div>'
        }
      />
      <Column
        id="37293"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="TD(t)"
        label="TD
 ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={60.25}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [Total]\n</div>'
        }
      />
      <Column
        id="7ab93"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="1D(t)"
        label="1D
⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={62}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nFirst Downs [Total]\n</div>'
        }
      />
      <Column
        id="32948"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#b5a1fe"
        key="OPP"
        label="OPP"
        placeholder="Enter value"
        position="center"
        size={47}
        summaryAggregationMode="none"
      />
      <Column
        id="e0da0"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#b5a1fe"
        key="PPR/OPP"
        label="FPTS/ OPP"
        placeholder="Enter value"
        position="center"
        size={70}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.9em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nFantasy Points per Opportunity [PPR]\n</div>'
        }
      />
      <Column
        id="0bf1a"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#b5a1fe"
        key="IMP(t)"
        label="IMP ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={67}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nImpact Plays [TD+1D]\n</div>'
        }
      />
      <Column
        id="1c968"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a32"
        headerTextColor="#b5a1fe"
        key="IMP%"
        label="IMP/ OPP"
        placeholder="Enter value"
        position="center"
        size={65}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 0px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.9em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nImpact Plays per Opportunity\n</div>'
        }
      />
      <Column
        id="1f54b"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#b5a1fe"
        key="LNG"
        label="LNG"
        placeholder="Enter value"
        position="center"
        size={51}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nLongest Play [total]\n</div>'
        }
      />
      <Column
        id="d7d6b"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#b5a1fe"
        key="BP"
        label="BP"
        placeholder="Enter value"
        position="center"
        size={49}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nBig Plays [20+YDS]\n</div>'
        }
      />
      <Column
        id="3620d"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="TGT"
        label="TGT"
        placeholder="Enter value"
        position="center"
        size={56}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n Targets\n</div>'
        }
      />
      <Column
        id="38694"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="REC"
        label="REC"
        placeholder="Enter value"
        position="center"
        size={59}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n Receptions\n</div>'
        }
      />
      <Column
        id="94082"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="RecYDS"
        label="YDS ⌊rec⌉"
        placeholder="Enter value"
        position="center"
        size={77}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n Yards [Receiving]\n</div>'
        }
      />
      <Column
        id="3a17f"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="RecTD"
        label="TD ⌊rec⌉"
        placeholder="Enter value"
        position="center"
        size={66}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n Touchdowns [Receiving]\n</div>'
        }
      />
      <Column
        id="2f46e"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="Rec1D"
        label="1D ⌊rec⌉"
        placeholder="Enter value"
        position="center"
        size={68}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n First Downs [Receiving]\n</div>'
        }
      />
      <Column
        id="c40d1"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YPRR"
        label="YPRR"
        placeholder="Enter value"
        position="center"
        size={68}
        summaryAggregationMode="none"
        textColor="{{
(() => {
 const v = parseFloat(String(item).replace(/[^0-9.-]/g, ''));
 if (!isFinite(v)) return null;
 const rules = [
  [2.7, '#00ffc4'],
  [2.4, '#85fff3'],
  [2.3, '#7dd1ff'],
  [2.1, '#957cff'],
  [1.9, '#a642ff'],
  [1.7, '#cf60ff'],
  [1.5, '#ff6fe1'],
 ];
 for (const [t, c] of rules) if (v >= t) return c;
 return '#ff2eb2';
})()
}}"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n Yards per Route Run </div>'
        }
      />
      <Column
        id="a3530"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="1DRR"
        label="1DRR"
        placeholder="Enter value"
        position="center"
        size={61}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n First Downs per Route Run </div>'
        }
      />
      <Column
        id="fe787"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YPR"
        label="YPR"
        placeholder="Enter value"
        position="center"
        size={54}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n Yards per Reception </div>'
        }
      />
      <Column
        id="ab276"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YPT"
        label="YPT"
        placeholder="Enter value"
        position="center"
        size={52}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n Yards per Target\n</div>'
        }
      />
      <Column
        id="40be6"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YAC/REC"
        label="YAC/REC"
        placeholder="Enter value"
        position="center"
        size={83}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n Yards after Catch per Reception\n</div>'
        }
      />
      <Column
        id="89a9d"
        alignment="center"
        backgroundColor="rgba(127, 154, 150, 0.01)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="CAR"
        label="CAR"
        placeholder="Enter value"
        position="center"
        size={52.640625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nCarries\n</div>'
        }
      />
      <Column
        id="9c113"
        alignment="center"
        backgroundColor="rgba(127, 154, 150, 0.01)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="RuYDS"
        label="YDS ⌊ru⌉"
        placeholder="Enter value"
        position="center"
        size={64}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [rushing]\n</div>'
        }
      />
      <Column
        id="c7beb"
        alignment="center"
        backgroundColor="rgba(127, 154, 150, 0.01)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="YPC"
        label="YPC"
        placeholder="Enter value"
        position="center"
        size={51.71875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards per Carry\n</div>'
        }
      />
      <Column
        id="a01c4"
        alignment="center"
        backgroundColor="rgba(127, 154, 150, 0.01)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="RuTD"
        label="TD ⌊ru⌉"
        placeholder="Enter value"
        position="center"
        size={56}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [rushing]\n</div>'
        }
      />
      <Column
        id="d2990"
        alignment="center"
        backgroundColor="rgba(127, 154, 150, 0.01)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="Ru1D"
        label="1D ⌊ru⌉"
        placeholder="Enter value"
        position="center"
        size={59}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nFirst Downs [rushing]\n</div>'
        }
      />
      <Column
        id="76cd8"
        alignment="center"
        backgroundColor="rgba(127, 154, 150, 0.01)"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "3",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="rgba(198, 255, 232, 1)"
        key="ELU"
        label="ELU"
        placeholder="Enter value"
        position="center"
        size={69}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow.ELU == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nElusiveness Rating\n</div>'
        }
      />
      <Column
        id="62123"
        alignment="center"
        backgroundColor="rgba(127, 154, 150, 0.01)"
        format="string"
        formatOptions={{ automaticColors: true, notation: "standard" }}
        groupAggregationMode="none"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="MTF/A"
        label="MTF/A"
        placeholder="Select option"
        position="center"
        size={67}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow.ELU == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nMissed Tackles Forced per Attempt\n</div>'
        }
      />
      <Column
        id="ce4d0"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="YCO/A"
        label="YCO/A"
        placeholder="Enter value"
        position="center"
        size={74}
        summaryAggregationMode="none"
        textColor={"{{ currentSourceRow[\"MTF/A\"] == \"NA\" ? '#8F8F8F':'' }}"}
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards after Contact per Attempt\n</div>'
        }
      />
      <Event
        event="selectRow"
        method=""
        params={{}}
        pluginId=""
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Table>
  </View>
  <View
    id="9fb35"
    icon="bold/interface-user-multiple"
    iconPosition="left"
    viewKey="ALL"
  >
    <Table
      id="table7"
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ query18.data }}"
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicColumnProperties={{ formatByIndex: "auto" }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      linkedFilterId=""
      primaryKeyColumnId="8ba81"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showFooter={true}
      showHeader={true}
      style={{
        headerFontFamily: "h6Font",
        fontWeight: "500",
        border: "rgba(30, 33, 50, 0)",
        alternateRowBackground: "#1c1f37",
        background: "#141627",
        fontSize: "13px",
        fontFamily: "Quicksand",
        headerFontWeight: "h6Font",
        headerText: "#ffffffff",
        headerBackground: "rgba(1, 9, 23, 1)",
        headerFontSize: "h6Font",
      }}
    >
      <Column
        id="8ba81"
        alignment="left"
        backgroundColor="rgba(204, 204, 204, 0.05)"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="PLYR"
        label="PLYR"
        placeholder="Enter value"
        position="left"
        size={159.6875}
        summaryAggregationMode="none"
      />
      <Column
        id="45cb7"
        alignment="center"
        editable="false"
        format="avatar"
        groupAggregationMode="none"
        hidden="false"
        key="TM"
        label="TM"
        optionList={{
          manualData: [
            { value: "CIN", color: "rgba(230, 87, 4, 1)" },
            { value: "TB", color: "rgba(101, 0, 0, 1)" },
            { value: "BUF", color: "rgba(189, 4, 4, 1)" },
            { value: "DET", color: "rgba(5, 182, 255, 1)" },
            { map: { value: "WAS" } },
            { map: { value: "PHI" } },
            { map: { value: "ATL" } },
            { map: { value: "BLT" } },
            { map: { value: "MIN" } },
            { map: { value: "DEN" } },
            { map: { value: "ARZ" } },
            { map: { value: "MIA" } },
            { map: { value: "GB" } },
            { map: { value: "KC" } },
            { map: { value: "LAC" } },
            { map: { value: "Option 16" } },
            { map: { value: "SF" } },
            { map: { value: "SEA" } },
            { map: { value: "JAX" } },
            { map: { value: "LA" } },
            { map: { value: "NYG" } },
            { map: { value: "NYJ" } },
            { map: { value: "Option 17" } },
            { map: { value: "Option 18" } },
          ],
        }}
        placeholder="No user"
        position="center"
        size={81.78125}
        summaryAggregationMode="none"
      />
      <Column
        id="f83ae"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "QB",
              color: "#ff2a6d",
              textColor: "#ffffff",
              icon: "",
              label: "",
            },
            { value: "WR", color: "#58a7ff", textColor: "#ffffff" },
            { value: "RB", textColor: "#ffffff" },
            { value: "TE", textColor: "#ffffff" },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="center"
        size={77.5625}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="6beae"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="G"
        label="G"
        placeholder="Enter value"
        position="center"
        size={89.046875}
        summaryAggregationMode="none"
      />
      <Column
        id="3f013"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="PPR"
        label="PPR(t)"
        placeholder="Enter value"
        position="center"
        size={87.328125}
        summaryAggregationMode="none"
        textColor="rgba(231, 244, 208, 1)"
      />
      <Column
        id="85367"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        key="PPR/G"
        label="PPR/G"
        placeholder="Enter value"
        position="center"
        size={97.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="7ff17"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        key="PPR/OPP"
        label="PPR/OPP"
        placeholder="Enter value"
        position="center"
        size={100.046875}
        summaryAggregationMode="none"
      />
      <Column
        id="615b7"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="OPP"
        label="OPP"
        placeholder="Enter value"
        position="center"
        size={99.703125}
        summaryAggregationMode="none"
      />
      <Column
        id="e9438"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="YDS(t)"
        label="YDS(t)"
        placeholder="Enter value"
        position="center"
        size={89.921875}
        summaryAggregationMode="none"
      />
      <Column
        id="2973f"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        key="YDS/G"
        label="YDS/G"
        placeholder="Enter value"
        position="center"
        size={95.59375}
        summaryAggregationMode="none"
      />
      <Column
        id="6b1d9"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        key="YDS/OPP"
        label="YDS/OPP"
        placeholder="Enter value"
        position="center"
        size={102.109375}
        summaryAggregationMode="none"
      />
      <Column
        id="37293"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="TD(t)"
        label="TD(t)"
        placeholder="Enter value"
        position="center"
        size={90.359375}
        summaryAggregationMode="none"
      />
      <Column
        id="1cd6c"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="1D(t)"
        label="1D(t)"
        placeholder="Enter value"
        position="center"
        size={93.28125}
        summaryAggregationMode="none"
      />
      <Column
        id="b71e4"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="IMP"
        label="IMP"
        placeholder="Enter value"
        position="center"
        size={84.09375}
        summaryAggregationMode="none"
      />
      <Column
        id="63db1"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        key="IMP%"
        label="IMP%"
        placeholder="Enter value"
        position="center"
        size={86.09375}
        summaryAggregationMode="none"
      />
      <Column
        id="aea60"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        key="IMP/G"
        label="IMP/G"
        placeholder="Enter value"
        position="center"
        size={99.09375}
        summaryAggregationMode="none"
      />
      <Column
        id="b2f7e"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="LNG(t)"
        label="LNG(t)"
        placeholder="Enter value"
        position="center"
        size={83.09375}
        summaryAggregationMode="none"
      />
      <Column
        id="f62c8"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="BP(t)"
        label="BP(t)"
        placeholder="Enter value"
        position="center"
        size={68.375}
        summaryAggregationMode="none"
      />
    </Table>
  </View>
  <View
    id="87617"
    disabled={false}
    hidden={false}
    icon="bold/travel-map-location-target-1"
    iconPosition="left"
    viewKey="QB"
  />
  <View
    id="3eee2"
    disabled={false}
    hidden={false}
    icon="bold/travel-transportation-bus"
    iconPosition="left"
    label="RB"
    viewKey="RB"
  />
  <View
    id="da965"
    disabled={false}
    hidden={false}
    icon="bold/computer-connection-usb-port"
    iconPosition="left"
    label="WR"
    viewKey="WR2"
  >
    <Table
      id="table94"
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "Player": "Ja\'Marr Chase",\n    "POS": "WR",\n    "TM": "CIN",\n    "PPR": 403,\n    "PPR/G": 23.7,\n    "PPR/OPP": 2.32,\n    "G": 17,\n    "OPP": 174,\n    "YDS(t)": 1740,\n    "TD(t)": 17,\n    "IMP(t)": 94,\n    "IMP%": 0.54,\n    "TGT": 171,\n    "REC": 127,\n    "RecYDS": 1708,\n    "RecTD": 17,\n    "Rec1D": 75,\n    "YPRR": 2.41,\n    "1DRR": 0.106,\n    "REC%": 74.3,\n    "DRP": 10,\n    "IMP\\n[rec]": 92,\n    "IMP/OPP [rec]": 0.538,\n    "YPT": 9.99,\n    "YPR": 13.45,\n    "YAC": 797,\n    "YAC/REC": 6.28,\n    "RR": 709,\n    "RecLNG": 70,\n    "RecBP": 19,\n    "CAR": 3,\n    "RuYDS": 32,\n    "RuTD": 0,\n    "Ru1D": 2\n  },\n  {\n    "Player": "Justin Jefferson",\n    "POS": "WR",\n    "TM": "MIN",\n    "PPR": 316.6,\n    "PPR/G": 18.6,\n    "PPR/OPP": 2.1,\n    "G": 17,\n    "OPP": 151,\n    "YDS(t)": 1536,\n    "TD(t)": 10,\n    "IMP(t)": 72,\n    "IMP%": 0.477,\n    "TGT": 150,\n    "REC": 103,\n    "RecYDS": 1533,\n    "RecTD": 10,\n    "Rec1D": 62,\n    "YPRR": 2.5,\n    "1DRR": 0.101,\n    "REC%": 68.7,\n    "DRP": 6,\n    "IMP\\n[rec]": 72,\n    "IMP/OPP [rec]": 0.48,\n    "YPT": 10.22,\n    "YPR": 14.88,\n    "YAC": 482,\n    "YAC/REC": 4.68,\n    "RR": 612,\n    "RecLNG": 97,\n    "RecBP": 28,\n    "CAR": 1,\n    "RuYDS": 3,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Amon-Ra St. Brown",\n    "POS": "WR",\n    "TM": "DET",\n    "PPR": 313.9,\n    "PPR/G": 18.5,\n    "PPR/OPP": 2.24,\n    "G": 17,\n    "OPP": 140,\n    "YDS(t)": 1269,\n    "TD(t)": 12,\n    "IMP(t)": 84,\n    "IMP%": 0.6,\n    "TGT": 138,\n    "REC": 115,\n    "RecYDS": 1263,\n    "RecTD": 12,\n    "Rec1D": 71,\n    "YPRR": 2.29,\n    "1DRR": 0.129,\n    "REC%": 83.3,\n    "DRP": 1,\n    "IMP\\n[rec]": 83,\n    "IMP/OPP [rec]": 0.601,\n    "YPT": 9.15,\n    "YPR": 10.98,\n    "YAC": 406,\n    "YAC/REC": 3.53,\n    "RR": 551,\n    "RecLNG": 66,\n    "RecBP": 14,\n    "CAR": 2,\n    "RuYDS": 6,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Drake London",\n    "POS": "WR",\n    "TM": "ATL",\n    "PPR": 280.8,\n    "PPR/G": 16.5,\n    "PPR/OPP": 1.87,\n    "G": 17,\n    "OPP": 150,\n    "YDS(t)": 1268,\n    "TD(t)": 9,\n    "IMP(t)": 76,\n    "IMP%": 0.507,\n    "TGT": 149,\n    "REC": 100,\n    "RecYDS": 1271,\n    "RecTD": 9,\n    "Rec1D": 67,\n    "YPRR": 2.32,\n    "1DRR": 0.122,\n    "REC%": 67.1,\n    "DRP": 5,\n    "IMP\\n[rec]": 76,\n    "IMP/OPP [rec]": 0.51,\n    "YPT": 8.53,\n    "YPR": 12.71,\n    "YAC": 328,\n    "YAC/REC": 3.28,\n    "RR": 548,\n    "RecLNG": 39,\n    "RecBP": 12,\n    "CAR": 1,\n    "RuYDS": -3,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Brian Thomas Jr.",\n    "POS": "WR",\n    "TM": "JAX",\n    "PPR": 280,\n    "PPR/G": 16.5,\n    "PPR/OPP": 2.07,\n    "G": 17,\n    "OPP": 135,\n    "YDS(t)": 1330,\n    "TD(t)": 10,\n    "IMP(t)": 66,\n    "IMP%": 0.489,\n    "TGT": 129,\n    "REC": 87,\n    "RecYDS": 1282,\n    "RecTD": 10,\n    "Rec1D": 53,\n    "YPRR": 2.45,\n    "1DRR": 0.101,\n    "REC%": 67.4,\n    "DRP": 6,\n    "IMP\\n[rec]": 63,\n    "IMP/OPP [rec]": 0.488,\n    "YPT": 9.94,\n    "YPR": 14.74,\n    "YAC": 572,\n    "YAC/REC": 6.57,\n    "RR": 523,\n    "RecLNG": 85,\n    "RecBP": 18,\n    "CAR": 6,\n    "RuYDS": 48,\n    "RuTD": 0,\n    "Ru1D": 3\n  },\n  {\n    "Player": "Malik Nabers",\n    "POS": "WR",\n    "TM": "NYG",\n    "PPR": 271.6,\n    "PPR/G": 18.1,\n    "PPR/OPP": 1.6,\n    "G": 15,\n    "OPP": 170,\n    "YDS(t)": 1206,\n    "TD(t)": 7,\n    "IMP(t)": 63,\n    "IMP%": 0.371,\n    "TGT": 165,\n    "REC": 109,\n    "RecYDS": 1204,\n    "RecTD": 7,\n    "Rec1D": 55,\n    "YPRR": 2.17,\n    "1DRR": 0.099,\n    "REC%": 66.1,\n    "DRP": 8,\n    "IMP\\n[rec]": 62,\n    "IMP/OPP [rec]": 0.376,\n    "YPT": 7.3,\n    "YPR": 11.05,\n    "YAC": 475,\n    "YAC/REC": 4.36,\n    "RR": 556,\n    "RecLNG": 59,\n    "RecBP": 16,\n    "CAR": 5,\n    "RuYDS": 2,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Terry McLaurin",\n    "POS": "WR",\n    "TM": "WAS",\n    "PPR": 269.8,\n    "PPR/G": 15.9,\n    "PPR/OPP": 2.31,\n    "G": 17,\n    "OPP": 117,\n    "YDS(t)": 1098,\n    "TD(t)": 13,\n    "IMP(t)": 69,\n    "IMP%": 0.59,\n    "TGT": 115,\n    "REC": 82,\n    "RecYDS": 1096,\n    "RecTD": 13,\n    "Rec1D": 56,\n    "YPRR": 1.98,\n    "1DRR": 0.101,\n    "REC%": 71.3,\n    "DRP": 5,\n    "IMP\\n[rec]": 69,\n    "IMP/OPP [rec]": 0.6,\n    "YPT": 9.53,\n    "YPR": 13.37,\n    "YAC": 295,\n    "YAC/REC": 3.6,\n    "RR": 553,\n    "RecLNG": 86,\n    "RecBP": 12,\n    "CAR": 2,\n    "RuYDS": 2,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "CeeDee Lamb",\n    "POS": "WR",\n    "TM": "DAL",\n    "PPR": 263.4,\n    "PPR/G": 17.6,\n    "PPR/OPP": 1.65,\n    "G": 15,\n    "OPP": 160,\n    "YDS(t)": 1264,\n    "TD(t)": 6,\n    "IMP(t)": 64,\n    "IMP%": 0.4,\n    "TGT": 146,\n    "REC": 101,\n    "RecYDS": 1194,\n    "RecTD": 6,\n    "Rec1D": 54,\n    "YPRR": 2.27,\n    "1DRR": 0.103,\n    "REC%": 69.2,\n    "DRP": 11,\n    "IMP\\n[rec]": 60,\n    "IMP/OPP [rec]": 0.411,\n    "YPT": 8.18,\n    "YPR": 11.82,\n    "YAC": 544,\n    "YAC/REC": 5.39,\n    "RR": 526,\n    "RecLNG": 65,\n    "RecBP": 16,\n    "CAR": 14,\n    "RuYDS": 70,\n    "RuTD": 0,\n    "Ru1D": 4\n  },\n  {\n    "Player": "Garrett Wilson",\n    "POS": "WR",\n    "TM": "NYJ",\n    "PPR": 253.9,\n    "PPR/G": 14.9,\n    "PPR/OPP": 1.65,\n    "G": 17,\n    "OPP": 154,\n    "YDS(t)": 1109,\n    "TD(t)": 7,\n    "IMP(t)": 68,\n    "IMP%": 0.442,\n    "TGT": 152,\n    "REC": 101,\n    "RecYDS": 1104,\n    "RecTD": 7,\n    "Rec1D": 60,\n    "YPRR": 1.69,\n    "1DRR": 0.092,\n    "REC%": 66.4,\n    "DRP": 6,\n    "IMP\\n[rec]": 67,\n    "IMP/OPP [rec]": 0.441,\n    "YPT": 7.26,\n    "YPR": 10.93,\n    "YAC": 446,\n    "YAC/REC": 4.42,\n    "RR": 653,\n    "RecLNG": 42,\n    "RecBP": 16,\n    "CAR": 2,\n    "RuYDS": 5,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Jaxon Smith-Njigba",\n    "POS": "WR",\n    "TM": "SEA",\n    "PPR": 251.6,\n    "PPR/G": 14.8,\n    "PPR/OPP": 1.82,\n    "G": 17,\n    "OPP": 138,\n    "YDS(t)": 1156,\n    "TD(t)": 6,\n    "IMP(t)": 63,\n    "IMP%": 0.457,\n    "TGT": 133,\n    "REC": 100,\n    "RecYDS": 1130,\n    "RecTD": 6,\n    "Rec1D": 56,\n    "YPRR": 1.81,\n    "1DRR": 0.09,\n    "REC%": 75.2,\n    "DRP": 2,\n    "IMP\\n[rec]": 62,\n    "IMP/OPP [rec]": 0.466,\n    "YPT": 8.5,\n    "YPR": 11.3,\n    "YAC": 482,\n    "YAC/REC": 4.82,\n    "RR": 625,\n    "RecLNG": 46,\n    "RecBP": 14,\n    "CAR": 5,\n    "RuYDS": 26,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Mike Evans",\n    "POS": "WR",\n    "TM": "TB",\n    "PPR": 240.4,\n    "PPR/G": 17.2,\n    "PPR/OPP": 2.25,\n    "G": 14,\n    "OPP": 107,\n    "YDS(t)": 1004,\n    "TD(t)": 11,\n    "IMP(t)": 64,\n    "IMP%": 0.598,\n    "TGT": 107,\n    "REC": 74,\n    "RecYDS": 1004,\n    "RecTD": 11,\n    "Rec1D": 53,\n    "YPRR": 2.41,\n    "1DRR": 0.127,\n    "REC%": 69.2,\n    "DRP": 4,\n    "IMP\\n[rec]": 64,\n    "IMP/OPP [rec]": 0.598,\n    "YPT": 9.38,\n    "YPR": 13.57,\n    "YAC": 222,\n    "YAC/REC": 3,\n    "RR": 416,\n    "RecLNG": 57,\n    "RecBP": 15,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Davante Adams",\n    "POS": "WR",\n    "TM": "NYJ",\n    "PPR": 239.3,\n    "PPR/G": 17.1,\n    "PPR/OPP": 1.77,\n    "G": 14,\n    "OPP": 135,\n    "YDS(t)": 1063,\n    "TD(t)": 8,\n    "IMP(t)": 57,\n    "IMP%": 0.422,\n    "TGT": 135,\n    "REC": 85,\n    "RecYDS": 1063,\n    "RecTD": 8,\n    "Rec1D": 49,\n    "YPRR": 2.04,\n    "1DRR": 0.094,\n    "REC%": 63,\n    "DRP": 10,\n    "IMP\\n[rec]": 57,\n    "IMP/OPP [rec]": 0.422,\n    "YPT": 7.87,\n    "YPR": 12.51,\n    "YAC": 468,\n    "YAC/REC": 5.51,\n    "RR": 522,\n    "RecLNG": 71,\n    "RecBP": 16,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Ladd McConkey",\n    "POS": "WR",\n    "TM": "LAC",\n    "PPR": 238.9,\n    "PPR/G": 14.9,\n    "PPR/OPP": 2.17,\n    "G": 16,\n    "OPP": 110,\n    "YDS(t)": 1149,\n    "TD(t)": 7,\n    "IMP(t)": 59,\n    "IMP%": 0.536,\n    "TGT": 110,\n    "REC": 82,\n    "RecYDS": 1149,\n    "RecTD": 7,\n    "Rec1D": 52,\n    "YPRR": 2.38,\n    "1DRR": 0.108,\n    "REC%": 74.5,\n    "DRP": 6,\n    "IMP\\n[rec]": 59,\n    "IMP/OPP [rec]": 0.536,\n    "YPT": 10.45,\n    "YPR": 14.01,\n    "YAC": 397,\n    "YAC/REC": 4.84,\n    "RR": 482,\n    "RecLNG": 60,\n    "RecBP": 15,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "DJ Moore",\n    "POS": "WR",\n    "TM": "CHI",\n    "PPR": 238.1,\n    "PPR/G": 14,\n    "PPR/OPP": 1.58,\n    "G": 17,\n    "OPP": 151,\n    "YDS(t)": 1041,\n    "TD(t)": 6,\n    "IMP(t)": 52,\n    "IMP%": 0.344,\n    "TGT": 137,\n    "REC": 98,\n    "RecYDS": 966,\n    "RecTD": 6,\n    "Rec1D": 43,\n    "YPRR": 1.44,\n    "1DRR": 0.064,\n    "REC%": 71.5,\n    "DRP": 3,\n    "IMP\\n[rec]": 49,\n    "IMP/OPP [rec]": 0.358,\n    "YPT": 7.05,\n    "YPR": 9.86,\n    "YAC": 596,\n    "YAC/REC": 6.08,\n    "RR": 669,\n    "RecLNG": 75,\n    "RecBP": 17,\n    "CAR": 14,\n    "RuYDS": 75,\n    "RuTD": 0,\n    "Ru1D": 3\n  },\n  {\n    "Player": "Courtland Sutton",\n    "POS": "WR",\n    "TM": "DEN",\n    "PPR": 237.1,\n    "PPR/G": 13.9,\n    "PPR/OPP": 1.8,\n    "G": 17,\n    "OPP": 132,\n    "YDS(t)": 1081,\n    "TD(t)": 8,\n    "IMP(t)": 65,\n    "IMP%": 0.492,\n    "TGT": 132,\n    "REC": 81,\n    "RecYDS": 1081,\n    "RecTD": 8,\n    "Rec1D": 57,\n    "YPRR": 1.84,\n    "1DRR": 0.097,\n    "REC%": 61.4,\n    "DRP": 10,\n    "IMP\\n[rec]": 65,\n    "IMP/OPP [rec]": 0.492,\n    "YPT": 8.19,\n    "YPR": 13.35,\n    "YAC": 185,\n    "YAC/REC": 2.28,\n    "RR": 587,\n    "RecLNG": 47,\n    "RecBP": 17,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jerry Jeudy",\n    "POS": "WR",\n    "TM": "CLE",\n    "PPR": 236.9,\n    "PPR/G": 13.9,\n    "PPR/OPP": 1.67,\n    "G": 17,\n    "OPP": 142,\n    "YDS(t)": 1229,\n    "TD(t)": 4,\n    "IMP(t)": 61,\n    "IMP%": 0.43,\n    "TGT": 142,\n    "REC": 90,\n    "RecYDS": 1229,\n    "RecTD": 4,\n    "Rec1D": 57,\n    "YPRR": 1.72,\n    "1DRR": 0.08,\n    "REC%": 63.4,\n    "DRP": 10,\n    "IMP\\n[rec]": 61,\n    "IMP/OPP [rec]": 0.43,\n    "YPT": 8.65,\n    "YPR": 13.66,\n    "YAC": 391,\n    "YAC/REC": 4.34,\n    "RR": 714,\n    "RecLNG": 89,\n    "RecBP": 13,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Tee Higgins",\n    "POS": "WR",\n    "TM": "CIN",\n    "PPR": 224.1,\n    "PPR/G": 18.7,\n    "PPR/OPP": 2.15,\n    "G": 12,\n    "OPP": 104,\n    "YDS(t)": 911,\n    "TD(t)": 10,\n    "IMP(t)": 58,\n    "IMP%": 0.558,\n    "TGT": 104,\n    "REC": 73,\n    "RecYDS": 911,\n    "RecTD": 10,\n    "Rec1D": 48,\n    "YPRR": 2.05,\n    "1DRR": 0.108,\n    "REC%": 70.2,\n    "DRP": 2,\n    "IMP\\n[rec]": 58,\n    "IMP/OPP [rec]": 0.558,\n    "YPT": 8.76,\n    "YPR": 12.48,\n    "YAC": 224,\n    "YAC/REC": 3.07,\n    "RR": 445,\n    "RecLNG": 80,\n    "RecBP": 12,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Tyreek Hill",\n    "POS": "WR",\n    "TM": "MIA",\n    "PPR": 218.2,\n    "PPR/G": 12.8,\n    "PPR/OPP": 1.69,\n    "G": 17,\n    "OPP": 129,\n    "YDS(t)": 1012,\n    "TD(t)": 6,\n    "IMP(t)": 62,\n    "IMP%": 0.481,\n    "TGT": 121,\n    "REC": 81,\n    "RecYDS": 959,\n    "RecTD": 6,\n    "Rec1D": 54,\n    "YPRR": 1.75,\n    "1DRR": 0.099,\n    "REC%": 66.9,\n    "DRP": 3,\n    "IMP\\n[rec]": 60,\n    "IMP/OPP [rec]": 0.496,\n    "YPT": 7.93,\n    "YPR": 11.84,\n    "YAC": 287,\n    "YAC/REC": 3.54,\n    "RR": 547,\n    "RecLNG": 64,\n    "RecBP": 11,\n    "CAR": 8,\n    "RuYDS": 53,\n    "RuTD": 0,\n    "Ru1D": 2\n  },\n  {\n    "Player": "A.J. Brown",\n    "POS": "WR",\n    "TM": "PHI",\n    "PPR": 216.9,\n    "PPR/G": 16.7,\n    "PPR/OPP": 2.28,\n    "G": 13,\n    "OPP": 95,\n    "YDS(t)": 1079,\n    "TD(t)": 7,\n    "IMP(t)": 58,\n    "IMP%": 0.611,\n    "TGT": 95,\n    "REC": 67,\n    "RecYDS": 1079,\n    "RecTD": 7,\n    "Rec1D": 51,\n    "YPRR": 2.99,\n    "1DRR": 0.141,\n    "REC%": 70.5,\n    "DRP": 0,\n    "IMP\\n[rec]": 58,\n    "IMP/OPP [rec]": 0.611,\n    "YPT": 11.36,\n    "YPR": 16.1,\n    "YAC": 357,\n    "YAC/REC": 5.33,\n    "RR": 361,\n    "RecLNG": 67,\n    "RecBP": 17,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jakobi Meyers",\n    "POS": "WR",\n    "TM": "LV",\n    "PPR": 216,\n    "PPR/G": 14.4,\n    "PPR/OPP": 1.69,\n    "G": 15,\n    "OPP": 128,\n    "YDS(t)": 1050,\n    "TD(t)": 4,\n    "IMP(t)": 57,\n    "IMP%": 0.445,\n    "TGT": 126,\n    "REC": 87,\n    "RecYDS": 1027,\n    "RecTD": 4,\n    "Rec1D": 52,\n    "YPRR": 1.76,\n    "1DRR": 0.089,\n    "REC%": 69,\n    "DRP": 0,\n    "IMP\\n[rec]": 56,\n    "IMP/OPP [rec]": 0.444,\n    "YPT": 8.15,\n    "YPR": 11.8,\n    "YAC": 298,\n    "YAC/REC": 3.43,\n    "RR": 584,\n    "RecLNG": 43,\n    "RecBP": 16,\n    "CAR": 2,\n    "RuYDS": 23,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Jordan Addison",\n    "POS": "WR",\n    "TM": "MIN",\n    "PPR": 212.5,\n    "PPR/G": 14.2,\n    "PPR/OPP": 2.24,\n    "G": 15,\n    "OPP": 95,\n    "YDS(t)": 895,\n    "TD(t)": 10,\n    "IMP(t)": 50,\n    "IMP%": 0.526,\n    "TGT": 92,\n    "REC": 63,\n    "RecYDS": 875,\n    "RecTD": 9,\n    "Rec1D": 39,\n    "YPRR": 1.74,\n    "1DRR": 0.077,\n    "REC%": 68.5,\n    "DRP": 3,\n    "IMP\\n[rec]": 48,\n    "IMP/OPP [rec]": 0.522,\n    "YPT": 9.51,\n    "YPR": 13.89,\n    "YAC": 223,\n    "YAC/REC": 3.54,\n    "RR": 504,\n    "RecLNG": 69,\n    "RecBP": 13,\n    "CAR": 3,\n    "RuYDS": 20,\n    "RuTD": 1,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Jameson Williams",\n    "POS": "WR",\n    "TM": "DET",\n    "PPR": 212.2,\n    "PPR/G": 14.1,\n    "PPR/OPP": 2.14,\n    "G": 15,\n    "OPP": 99,\n    "YDS(t)": 1062,\n    "TD(t)": 8,\n    "IMP(t)": 55,\n    "IMP%": 0.556,\n    "TGT": 88,\n    "REC": 58,\n    "RecYDS": 1001,\n    "RecTD": 7,\n    "Rec1D": 42,\n    "YPRR": 2.1,\n    "1DRR": 0.088,\n    "REC%": 65.9,\n    "DRP": 2,\n    "IMP\\n[rec]": 49,\n    "IMP/OPP [rec]": 0.557,\n    "YPT": 11.38,\n    "YPR": 17.26,\n    "YAC": 490,\n    "YAC/REC": 8.45,\n    "RR": 477,\n    "RecLNG": 82,\n    "RecBP": 17,\n    "CAR": 11,\n    "RuYDS": 61,\n    "RuTD": 1,\n    "Ru1D": 5\n  },\n  {\n    "Player": "Nico Collins",\n    "POS": "WR",\n    "TM": "HOU",\n    "PPR": 210.6,\n    "PPR/G": 17.6,\n    "PPR/OPP": 2.13,\n    "G": 12,\n    "OPP": 99,\n    "YDS(t)": 1006,\n    "TD(t)": 7,\n    "IMP(t)": 55,\n    "IMP%": 0.556,\n    "TGT": 99,\n    "REC": 68,\n    "RecYDS": 1006,\n    "RecTD": 7,\n    "Rec1D": 48,\n    "YPRR": 2.87,\n    "1DRR": 0.137,\n    "REC%": 68.7,\n    "DRP": 4,\n    "IMP\\n[rec]": 55,\n    "IMP/OPP [rec]": 0.556,\n    "YPT": 10.16,\n    "YPR": 14.79,\n    "YAC": 362,\n    "YAC/REC": 5.32,\n    "RR": 350,\n    "RecLNG": 67,\n    "RecBP": 14,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jauan Jennings",\n    "POS": "WR",\n    "TM": "SF",\n    "PPR": 210.5,\n    "PPR/G": 14,\n    "PPR/OPP": 1.9,\n    "G": 15,\n    "OPP": 111,\n    "YDS(t)": 975,\n    "TD(t)": 6,\n    "IMP(t)": 53,\n    "IMP%": 0.477,\n    "TGT": 111,\n    "REC": 77,\n    "RecYDS": 975,\n    "RecTD": 6,\n    "Rec1D": 47,\n    "YPRR": 2.26,\n    "1DRR": 0.109,\n    "REC%": 69.4,\n    "DRP": 4,\n    "IMP\\n[rec]": 53,\n    "IMP/OPP [rec]": 0.477,\n    "YPT": 8.78,\n    "YPR": 12.66,\n    "YAC": 239,\n    "YAC/REC": 3.1,\n    "RR": 432,\n    "RecLNG": 68,\n    "RecBP": 12,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Zay Flowers",\n    "POS": "WR",\n    "TM": "BAL",\n    "PPR": 209.5,\n    "PPR/G": 12.3,\n    "PPR/OPP": 1.73,\n    "G": 17,\n    "OPP": 121,\n    "YDS(t)": 1115,\n    "TD(t)": 4,\n    "IMP(t)": 53,\n    "IMP%": 0.438,\n    "TGT": 112,\n    "REC": 74,\n    "RecYDS": 1059,\n    "RecTD": 4,\n    "Rec1D": 48,\n    "YPRR": 2.25,\n    "1DRR": 0.102,\n    "REC%": 66.1,\n    "DRP": 5,\n    "IMP\\n[rec]": 52,\n    "IMP/OPP [rec]": 0.464,\n    "YPT": 9.46,\n    "YPR": 14.31,\n    "YAC": 467,\n    "YAC/REC": 6.31,\n    "RR": 470,\n    "RecLNG": 53,\n    "RecBP": 19,\n    "CAR": 9,\n    "RuYDS": 56,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Puka Nacua",\n    "POS": "WR",\n    "TM": "LAR",\n    "PPR": 206.6,\n    "PPR/G": 18.8,\n    "PPR/OPP": 1.81,\n    "G": 11,\n    "OPP": 114,\n    "YDS(t)": 1036,\n    "TD(t)": 4,\n    "IMP(t)": 53,\n    "IMP%": 0.465,\n    "TGT": 103,\n    "REC": 79,\n    "RecYDS": 990,\n    "RecTD": 3,\n    "Rec1D": 47,\n    "YPRR": 3.56,\n    "1DRR": 0.169,\n    "REC%": 76.7,\n    "DRP": 3,\n    "IMP\\n[rec]": 50,\n    "IMP/OPP [rec]": 0.485,\n    "YPT": 9.61,\n    "YPR": 12.53,\n    "YAC": 520,\n    "YAC/REC": 6.58,\n    "RR": 278,\n    "RecLNG": 79,\n    "RecBP": 11,\n    "CAR": 11,\n    "RuYDS": 46,\n    "RuTD": 1,\n    "Ru1D": 2\n  },\n  {\n    "Player": "Calvin Ridley",\n    "POS": "WR",\n    "TM": "TEN",\n    "PPR": 200.5,\n    "PPR/G": 11.8,\n    "PPR/OPP": 1.67,\n    "G": 17,\n    "OPP": 120,\n    "YDS(t)": 1065,\n    "TD(t)": 5,\n    "IMP(t)": 48,\n    "IMP%": 0.4,\n    "TGT": 113,\n    "REC": 64,\n    "RecYDS": 1017,\n    "RecTD": 4,\n    "Rec1D": 40,\n    "YPRR": 1.86,\n    "1DRR": 0.073,\n    "REC%": 56.6,\n    "DRP": 8,\n    "IMP\\n[rec]": 44,\n    "IMP/OPP [rec]": 0.389,\n    "YPT": 9,\n    "YPR": 15.89,\n    "YAC": 233,\n    "YAC/REC": 3.64,\n    "RR": 546,\n    "RecLNG": 63,\n    "RecBP": 19,\n    "CAR": 7,\n    "RuYDS": 48,\n    "RuTD": 1,\n    "Ru1D": 3\n  },\n  {\n    "Player": "DeVonta Smith",\n    "POS": "WR",\n    "TM": "PHI",\n    "PPR": 199.4,\n    "PPR/G": 15.3,\n    "PPR/OPP": 2.35,\n    "G": 13,\n    "OPP": 85,\n    "YDS(t)": 834,\n    "TD(t)": 8,\n    "IMP(t)": 50,\n    "IMP%": 0.588,\n    "TGT": 84,\n    "REC": 68,\n    "RecYDS": 833,\n    "RecTD": 8,\n    "Rec1D": 42,\n    "YPRR": 2.11,\n    "1DRR": 0.106,\n    "REC%": 81,\n    "DRP": 4,\n    "IMP\\n[rec]": 50,\n    "IMP/OPP [rec]": 0.595,\n    "YPT": 9.92,\n    "YPR": 12.25,\n    "YAC": 292,\n    "YAC/REC": 4.29,\n    "RR": 395,\n    "RecLNG": 49,\n    "RecBP": 12,\n    "CAR": 1,\n    "RuYDS": 1,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jayden Reed",\n    "POS": "WR",\n    "TM": "GB",\n    "PPR": 199,\n    "PPR/G": 11.7,\n    "PPR/OPP": 2.09,\n    "G": 17,\n    "OPP": 95,\n    "YDS(t)": 1020,\n    "TD(t)": 7,\n    "IMP(t)": 43,\n    "IMP%": 0.453,\n    "TGT": 75,\n    "REC": 55,\n    "RecYDS": 857,\n    "RecTD": 6,\n    "Rec1D": 29,\n    "YPRR": 2.2,\n    "1DRR": 0.075,\n    "REC%": 73.3,\n    "DRP": 10,\n    "IMP\\n[rec]": 35,\n    "IMP/OPP [rec]": 0.467,\n    "YPT": 11.43,\n    "YPR": 15.58,\n    "YAC": 391,\n    "YAC/REC": 7.11,\n    "RR": 389,\n    "RecLNG": 70,\n    "RecBP": 15,\n    "CAR": 20,\n    "RuYDS": 163,\n    "RuTD": 1,\n    "Ru1D": 7\n  },\n  {\n    "Player": "Marvin Harrison Jr.",\n    "POS": "WR",\n    "TM": "ARI",\n    "PPR": 198.5,\n    "PPR/G": 11.7,\n    "PPR/OPP": 1.74,\n    "G": 17,\n    "OPP": 114,\n    "YDS(t)": 885,\n    "TD(t)": 8,\n    "IMP(t)": 51,\n    "IMP%": 0.447,\n    "TGT": 114,\n    "REC": 62,\n    "RecYDS": 885,\n    "RecTD": 8,\n    "Rec1D": 43,\n    "YPRR": 1.63,\n    "1DRR": 0.079,\n    "REC%": 54.4,\n    "DRP": 1,\n    "IMP\\n[rec]": 51,\n    "IMP/OPP [rec]": 0.447,\n    "YPT": 7.76,\n    "YPR": 14.27,\n    "YAC": 149,\n    "YAC/REC": 2.4,\n    "RR": 543,\n    "RecLNG": 42,\n    "RecBP": 14,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "D.K. Metcalf",\n    "POS": "WR",\n    "TM": "SEA",\n    "PPR": 195.2,\n    "PPR/G": 13,\n    "PPR/OPP": 1.81,\n    "G": 15,\n    "OPP": 108,\n    "YDS(t)": 992,\n    "TD(t)": 5,\n    "IMP(t)": 40,\n    "IMP%": 0.37,\n    "TGT": 108,\n    "REC": 66,\n    "RecYDS": 992,\n    "RecTD": 5,\n    "Rec1D": 35,\n    "YPRR": 1.81,\n    "1DRR": 0.064,\n    "REC%": 61.1,\n    "DRP": 3,\n    "IMP\\n[rec]": 40,\n    "IMP/OPP [rec]": 0.37,\n    "YPT": 9.19,\n    "YPR": 15.03,\n    "YAC": 262,\n    "YAC/REC": 3.97,\n    "RR": 549,\n    "RecLNG": 71,\n    "RecBP": 20,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Darnell Mooney",\n    "POS": "WR",\n    "TM": "ATL",\n    "PPR": 193.2,\n    "PPR/G": 12.1,\n    "PPR/OPP": 1.93,\n    "G": 16,\n    "OPP": 100,\n    "YDS(t)": 992,\n    "TD(t)": 5,\n    "IMP(t)": 53,\n    "IMP%": 0.53,\n    "TGT": 100,\n    "REC": 64,\n    "RecYDS": 992,\n    "RecTD": 5,\n    "Rec1D": 48,\n    "YPRR": 1.88,\n    "1DRR": 0.091,\n    "REC%": 64,\n    "DRP": 5,\n    "IMP\\n[rec]": 53,\n    "IMP/OPP [rec]": 0.53,\n    "YPT": 9.92,\n    "YPR": 15.5,\n    "YAC": 267,\n    "YAC/REC": 4.17,\n    "RR": 527,\n    "RecLNG": 49,\n    "RecBP": 21,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Xavier Worthy",\n    "POS": "WR",\n    "TM": "KC",\n    "PPR": 187.2,\n    "PPR/G": 11,\n    "PPR/OPP": 1.66,\n    "G": 17,\n    "OPP": 113,\n    "YDS(t)": 742,\n    "TD(t)": 9,\n    "IMP(t)": 49,\n    "IMP%": 0.434,\n    "TGT": 93,\n    "REC": 59,\n    "RecYDS": 638,\n    "RecTD": 6,\n    "Rec1D": 36,\n    "YPRR": 1.24,\n    "1DRR": 0.07,\n    "REC%": 63.4,\n    "DRP": 5,\n    "IMP\\n[rec]": 42,\n    "IMP/OPP [rec]": 0.452,\n    "YPT": 6.86,\n    "YPR": 10.81,\n    "YAC": 416,\n    "YAC/REC": 7.05,\n    "RR": 516,\n    "RecLNG": 56,\n    "RecBP": 8,\n    "CAR": 20,\n    "RuYDS": 104,\n    "RuTD": 3,\n    "Ru1D": 4\n  },\n  {\n    "Player": "Keenan Allen",\n    "POS": "WR",\n    "TM": "CHI",\n    "PPR": 186.4,\n    "PPR/G": 12.4,\n    "PPR/OPP": 1.59,\n    "G": 15,\n    "OPP": 117,\n    "YDS(t)": 744,\n    "TD(t)": 7,\n    "IMP(t)": 50,\n    "IMP%": 0.427,\n    "TGT": 117,\n    "REC": 70,\n    "RecYDS": 744,\n    "RecTD": 7,\n    "Rec1D": 43,\n    "YPRR": 1.36,\n    "1DRR": 0.079,\n    "REC%": 59.8,\n    "DRP": 8,\n    "IMP\\n[rec]": 50,\n    "IMP/OPP [rec]": 0.427,\n    "YPT": 6.36,\n    "YPR": 10.63,\n    "YAC": 241,\n    "YAC/REC": 3.44,\n    "RR": 546,\n    "RecLNG": 44,\n    "RecBP": 11,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Josh Downs",\n    "POS": "WR",\n    "TM": "IND",\n    "PPR": 183.5,\n    "PPR/G": 13.1,\n    "PPR/OPP": 1.78,\n    "G": 14,\n    "OPP": 103,\n    "YDS(t)": 815,\n    "TD(t)": 5,\n    "IMP(t)": 46,\n    "IMP%": 0.447,\n    "TGT": 102,\n    "REC": 72,\n    "RecYDS": 803,\n    "RecTD": 5,\n    "Rec1D": 40,\n    "YPRR": 2.2,\n    "1DRR": 0.11,\n    "REC%": 70.6,\n    "DRP": 4,\n    "IMP\\n[rec]": 45,\n    "IMP/OPP [rec]": 0.441,\n    "YPT": 7.87,\n    "YPR": 11.15,\n    "YAC": 403,\n    "YAC/REC": 5.6,\n    "RR": 365,\n    "RecLNG": 60,\n    "RecBP": 12,\n    "CAR": 1,\n    "RuYDS": 12,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Wan\'Dale Robinson",\n    "POS": "WR",\n    "TM": "NYG",\n    "PPR": 182.7,\n    "PPR/G": 10.7,\n    "PPR/OPP": 1.35,\n    "G": 17,\n    "OPP": 135,\n    "YDS(t)": 717,\n    "TD(t)": 3,\n    "IMP(t)": 40,\n    "IMP%": 0.296,\n    "TGT": 132,\n    "REC": 93,\n    "RecYDS": 699,\n    "RecTD": 3,\n    "Rec1D": 36,\n    "YPRR": 1.21,\n    "1DRR": 0.062,\n    "REC%": 70.5,\n    "DRP": 7,\n    "IMP\\n[rec]": 39,\n    "IMP/OPP [rec]": 0.295,\n    "YPT": 5.3,\n    "YPR": 7.52,\n    "YAC": 374,\n    "YAC/REC": 4.02,\n    "RR": 579,\n    "RecLNG": 50,\n    "RecBP": 6,\n    "CAR": 3,\n    "RuYDS": 18,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Khalil Shakir",\n    "POS": "WR",\n    "TM": "BUF",\n    "PPR": 182.5,\n    "PPR/G": 12.2,\n    "PPR/OPP": 1.88,\n    "G": 15,\n    "OPP": 97,\n    "YDS(t)": 825,\n    "TD(t)": 4,\n    "IMP(t)": 39,\n    "IMP%": 0.402,\n    "TGT": 95,\n    "REC": 76,\n    "RecYDS": 821,\n    "RecTD": 4,\n    "Rec1D": 35,\n    "YPRR": 2.15,\n    "1DRR": 0.092,\n    "REC%": 80,\n    "DRP": 2,\n    "IMP\\n[rec]": 39,\n    "IMP/OPP [rec]": 0.411,\n    "YPT": 8.64,\n    "YPR": 10.8,\n    "YAC": 605,\n    "YAC/REC": 7.96,\n    "RR": 382,\n    "RecLNG": 55,\n    "RecBP": 11,\n    "CAR": 2,\n    "RuYDS": 4,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Cooper Kupp",\n    "POS": "WR",\n    "TM": "LAR",\n    "PPR": 175,\n    "PPR/G": 14.6,\n    "PPR/OPP": 1.77,\n    "G": 12,\n    "OPP": 99,\n    "YDS(t)": 720,\n    "TD(t)": 6,\n    "IMP(t)": 35,\n    "IMP%": 0.354,\n    "TGT": 97,\n    "REC": 67,\n    "RecYDS": 710,\n    "RecTD": 6,\n    "Rec1D": 28,\n    "YPRR": 1.99,\n    "1DRR": 0.078,\n    "REC%": 69.1,\n    "DRP": 2,\n    "IMP\\n[rec]": 34,\n    "IMP/OPP [rec]": 0.351,\n    "YPT": 7.32,\n    "YPR": 10.6,\n    "YAC": 266,\n    "YAC/REC": 3.97,\n    "RR": 357,\n    "RecLNG": 49,\n    "RecBP": 14,\n    "CAR": 2,\n    "RuYDS": 10,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Quentin Johnston",\n    "POS": "WR",\n    "TM": "LAC",\n    "PPR": 174.7,\n    "PPR/G": 11.6,\n    "PPR/OPP": 1.92,\n    "G": 15,\n    "OPP": 91,\n    "YDS(t)": 717,\n    "TD(t)": 8,\n    "IMP(t)": 40,\n    "IMP%": 0.44,\n    "TGT": 88,\n    "REC": 55,\n    "RecYDS": 711,\n    "RecTD": 8,\n    "Rec1D": 32,\n    "YPRR": 1.77,\n    "1DRR": 0.08,\n    "REC%": 62.5,\n    "DRP": 5,\n    "IMP\\n[rec]": 40,\n    "IMP/OPP [rec]": 0.455,\n    "YPT": 8.08,\n    "YPR": 12.93,\n    "YAC": 313,\n    "YAC/REC": 5.69,\n    "RR": 401,\n    "RecLNG": 44,\n    "RecBP": 8,\n    "CAR": 3,\n    "RuYDS": 6,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Rashod Bateman",\n    "POS": "WR",\n    "TM": "BAL",\n    "PPR": 174.6,\n    "PPR/G": 10.3,\n    "PPR/OPP": 2.61,\n    "G": 17,\n    "OPP": 67,\n    "YDS(t)": 756,\n    "TD(t)": 9,\n    "IMP(t)": 44,\n    "IMP%": 0.657,\n    "TGT": 67,\n    "REC": 45,\n    "RecYDS": 756,\n    "RecTD": 9,\n    "Rec1D": 35,\n    "YPRR": 1.69,\n    "1DRR": 0.078,\n    "REC%": 67.2,\n    "DRP": 4,\n    "IMP\\n[rec]": 44,\n    "IMP/OPP [rec]": 0.657,\n    "YPT": 11.28,\n    "YPR": 16.8,\n    "YAC": 186,\n    "YAC/REC": 4.13,\n    "RR": 447,\n    "RecLNG": 63,\n    "RecBP": 12,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Michael Pittman Jr.",\n    "POS": "WR",\n    "TM": "IND",\n    "PPR": 167.8,\n    "PPR/G": 10.5,\n    "PPR/OPP": 1.58,\n    "G": 16,\n    "OPP": 106,\n    "YDS(t)": 808,\n    "TD(t)": 3,\n    "IMP(t)": 38,\n    "IMP%": 0.358,\n    "TGT": 106,\n    "REC": 69,\n    "RecYDS": 808,\n    "RecTD": 3,\n    "Rec1D": 35,\n    "YPRR": 1.68,\n    "1DRR": 0.073,\n    "REC%": 65.1,\n    "DRP": 3,\n    "IMP\\n[rec]": 38,\n    "IMP/OPP [rec]": 0.358,\n    "YPT": 7.62,\n    "YPR": 11.71,\n    "YAC": 261,\n    "YAC/REC": 3.78,\n    "RR": 481,\n    "RecLNG": 52,\n    "RecBP": 9,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "George Pickens",\n    "POS": "WR",\n    "TM": "PIT",\n    "PPR": 166.4,\n    "PPR/G": 11.9,\n    "PPR/OPP": 1.63,\n    "G": 14,\n    "OPP": 102,\n    "YDS(t)": 894,\n    "TD(t)": 3,\n    "IMP(t)": 40,\n    "IMP%": 0.392,\n    "TGT": 100,\n    "REC": 59,\n    "RecYDS": 900,\n    "RecTD": 3,\n    "Rec1D": 37,\n    "YPRR": 2.06,\n    "1DRR": 0.085,\n    "REC%": 59,\n    "DRP": 9,\n    "IMP\\n[rec]": 40,\n    "IMP/OPP [rec]": 0.4,\n    "YPT": 9,\n    "YPR": 15.25,\n    "YAC": 234,\n    "YAC/REC": 3.97,\n    "RR": 436,\n    "RecLNG": 69,\n    "RecBP": 13,\n    "CAR": 2,\n    "RuYDS": -6,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Alec Pierce",\n    "POS": "WR",\n    "TM": "IND",\n    "PPR": 161.4,\n    "PPR/G": 10.1,\n    "PPR/OPP": 2.45,\n    "G": 16,\n    "OPP": 66,\n    "YDS(t)": 824,\n    "TD(t)": 7,\n    "IMP(t)": 39,\n    "IMP%": 0.591,\n    "TGT": 66,\n    "REC": 37,\n    "RecYDS": 824,\n    "RecTD": 7,\n    "Rec1D": 32,\n    "YPRR": 1.82,\n    "1DRR": 0.071,\n    "REC%": 56.1,\n    "DRP": 3,\n    "IMP\\n[rec]": 39,\n    "IMP/OPP [rec]": 0.591,\n    "YPT": 12.48,\n    "YPR": 22.27,\n    "YAC": 118,\n    "YAC/REC": 3.19,\n    "RR": 452,\n    "RecLNG": 52,\n    "RecBP": 14,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Deebo Samuel",\n    "POS": "WR",\n    "TM": "SF",\n    "PPR": 155.6,\n    "PPR/G": 10.4,\n    "PPR/OPP": 1.28,\n    "G": 15,\n    "OPP": 122,\n    "YDS(t)": 806,\n    "TD(t)": 4,\n    "IMP(t)": 37,\n    "IMP%": 0.303,\n    "TGT": 80,\n    "REC": 51,\n    "RecYDS": 670,\n    "RecTD": 3,\n    "Rec1D": 28,\n    "YPRR": 1.6,\n    "1DRR": 0.067,\n    "REC%": 63.7,\n    "DRP": 5,\n    "IMP\\n[rec]": 31,\n    "IMP/OPP [rec]": 0.388,\n    "YPT": 8.38,\n    "YPR": 13.14,\n    "YAC": 417,\n    "YAC/REC": 8.18,\n    "RR": 420,\n    "RecLNG": 77,\n    "RecBP": 13,\n    "CAR": 42,\n    "RuYDS": 136,\n    "RuTD": 1,\n    "Ru1D": 5\n  },\n  {\n    "Player": "Jalen Tolbert",\n    "POS": "WR",\n    "TM": "DAL",\n    "PPR": 152,\n    "PPR/G": 8.9,\n    "PPR/OPP": 2.05,\n    "G": 17,\n    "OPP": 74,\n    "YDS(t)": 610,\n    "TD(t)": 7,\n    "IMP(t)": 36,\n    "IMP%": 0.486,\n    "TGT": 74,\n    "REC": 49,\n    "RecYDS": 610,\n    "RecTD": 7,\n    "Rec1D": 29,\n    "YPRR": 1.1,\n    "1DRR": 0.052,\n    "REC%": 66.2,\n    "DRP": 4,\n    "IMP\\n[rec]": 36,\n    "IMP/OPP [rec]": 0.486,\n    "YPT": 8.24,\n    "YPR": 12.45,\n    "YAC": 175,\n    "YAC/REC": 3.57,\n    "RR": 553,\n    "RecLNG": 43,\n    "RecBP": 5,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Demario Douglas",\n    "POS": "WR",\n    "TM": "NE",\n    "PPR": 147.7,\n    "PPR/G": 8.7,\n    "PPR/OPP": 1.7,\n    "G": 17,\n    "OPP": 87,\n    "YDS(t)": 637,\n    "TD(t)": 3,\n    "IMP(t)": 34,\n    "IMP%": 0.391,\n    "TGT": 84,\n    "REC": 66,\n    "RecYDS": 621,\n    "RecTD": 3,\n    "Rec1D": 31,\n    "YPRR": 1.4,\n    "1DRR": 0.07,\n    "REC%": 78.6,\n    "DRP": 1,\n    "IMP\\n[rec]": 34,\n    "IMP/OPP [rec]": 0.405,\n    "YPT": 7.39,\n    "YPR": 9.41,\n    "YAC": 370,\n    "YAC/REC": 5.61,\n    "RR": 442,\n    "RecLNG": 52,\n    "RecBP": 9,\n    "CAR": 3,\n    "RuYDS": 16,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "DeAndre Hopkins",\n    "POS": "WR",\n    "TM": "KC",\n    "PPR": 147,\n    "PPR/G": 9.2,\n    "PPR/OPP": 1.88,\n    "G": 16,\n    "OPP": 78,\n    "YDS(t)": 610,\n    "TD(t)": 5,\n    "IMP(t)": 40,\n    "IMP%": 0.513,\n    "TGT": 78,\n    "REC": 56,\n    "RecYDS": 610,\n    "RecTD": 5,\n    "Rec1D": 35,\n    "YPRR": 1.71,\n    "1DRR": 0.098,\n    "REC%": 71.8,\n    "DRP": 2,\n    "IMP\\n[rec]": 40,\n    "IMP/OPP [rec]": 0.513,\n    "YPT": 7.82,\n    "YPR": 10.89,\n    "YAC": 110,\n    "YAC/REC": 1.96,\n    "RR": 357,\n    "RecLNG": 64,\n    "RecBP": 14,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Rome Odunze",\n    "POS": "WR",\n    "TM": "CHI",\n    "PPR": 146.9,\n    "PPR/G": 8.6,\n    "PPR/OPP": 1.48,\n    "G": 17,\n    "OPP": 99,\n    "YDS(t)": 749,\n    "TD(t)": 3,\n    "IMP(t)": 41,\n    "IMP%": 0.414,\n    "TGT": 96,\n    "REC": 54,\n    "RecYDS": 734,\n    "RecTD": 3,\n    "Rec1D": 37,\n    "YPRR": 1.18,\n    "1DRR": 0.059,\n    "REC%": 56.3,\n    "DRP": 5,\n    "IMP\\n[rec]": 40,\n    "IMP/OPP [rec]": 0.417,\n    "YPT": 7.65,\n    "YPR": 13.59,\n    "YAC": 261,\n    "YAC/REC": 4.83,\n    "RR": 624,\n    "RecLNG": 71,\n    "RecBP": 15,\n    "CAR": 3,\n    "RuYDS": 15,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Jaylen Waddle",\n    "POS": "WR",\n    "TM": "MIA",\n    "PPR": 145.6,\n    "PPR/G": 9.7,\n    "PPR/OPP": 1.67,\n    "G": 15,\n    "OPP": 87,\n    "YDS(t)": 756,\n    "TD(t)": 2,\n    "IMP(t)": 41,\n    "IMP%": 0.471,\n    "TGT": 83,\n    "REC": 58,\n    "RecYDS": 744,\n    "RecTD": 2,\n    "Rec1D": 38,\n    "YPRR": 1.53,\n    "1DRR": 0.078,\n    "REC%": 69.9,\n    "DRP": 6,\n    "IMP\\n[rec]": 40,\n    "IMP/OPP [rec]": 0.482,\n    "YPT": 8.96,\n    "YPR": 12.83,\n    "YAC": 238,\n    "YAC/REC": 4.1,\n    "RR": 486,\n    "RecLNG": 67,\n    "RecBP": 16,\n    "CAR": 4,\n    "RuYDS": 12,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Ray-Ray McCloud III",\n    "POS": "WR",\n    "TM": "ATL",\n    "PPR": 144.5,\n    "PPR/G": 8.5,\n    "PPR/OPP": 1.59,\n    "G": 17,\n    "OPP": 91,\n    "YDS(t)": 765,\n    "TD(t)": 1,\n    "IMP(t)": 33,\n    "IMP%": 0.363,\n    "TGT": 81,\n    "REC": 62,\n    "RecYDS": 686,\n    "RecTD": 1,\n    "Rec1D": 29,\n    "YPRR": 1.25,\n    "1DRR": 0.053,\n    "REC%": 76.5,\n    "DRP": 3,\n    "IMP\\n[rec]": 30,\n    "IMP/OPP [rec]": 0.37,\n    "YPT": 8.47,\n    "YPR": 11.06,\n    "YAC": 342,\n    "YAC/REC": 5.52,\n    "RR": 547,\n    "RecLNG": 45,\n    "RecBP": 5,\n    "CAR": 10,\n    "RuYDS": 79,\n    "RuTD": 0,\n    "Ru1D": 3\n  },\n  {\n    "Player": "Tank Dell",\n    "POS": "WR",\n    "TM": "HOU",\n    "PPR": 140,\n    "PPR/G": 10,\n    "PPR/OPP": 1.56,\n    "G": 14,\n    "OPP": 90,\n    "YDS(t)": 710,\n    "TD(t)": 3,\n    "IMP(t)": 41,\n    "IMP%": 0.456,\n    "TGT": 81,\n    "REC": 51,\n    "RecYDS": 667,\n    "RecTD": 3,\n    "Rec1D": 35,\n    "YPRR": 1.49,\n    "1DRR": 0.078,\n    "REC%": 63,\n    "DRP": 5,\n    "IMP\\n[rec]": 38,\n    "IMP/OPP [rec]": 0.469,\n    "YPT": 8.23,\n    "YPR": 13.08,\n    "YAC": 163,\n    "YAC/REC": 3.2,\n    "RR": 447,\n    "RecLNG": 69,\n    "RecBP": 14,\n    "CAR": 9,\n    "RuYDS": 43,\n    "RuTD": 0,\n    "Ru1D": 3\n  },\n  {\n    "Player": "Adam Thielen",\n    "POS": "WR",\n    "TM": "CAR",\n    "PPR": 139.5,\n    "PPR/G": 14,\n    "PPR/OPP": 2.29,\n    "G": 10,\n    "OPP": 61,\n    "YDS(t)": 615,\n    "TD(t)": 5,\n    "IMP(t)": 33,\n    "IMP%": 0.541,\n    "TGT": 61,\n    "REC": 48,\n    "RecYDS": 615,\n    "RecTD": 5,\n    "Rec1D": 28,\n    "YPRR": 2.06,\n    "1DRR": 0.094,\n    "REC%": 78.7,\n    "DRP": 2,\n    "IMP\\n[rec]": 33,\n    "IMP/OPP [rec]": 0.541,\n    "YPT": 10.08,\n    "YPR": 12.81,\n    "YAC": 156,\n    "YAC/REC": 3.25,\n    "RR": 299,\n    "RecLNG": 59,\n    "RecBP": 15,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Chris Godwin",\n    "POS": "WR",\n    "TM": "TB",\n    "PPR": 137.8,\n    "PPR/G": 19.7,\n    "PPR/OPP": 2.26,\n    "G": 7,\n    "OPP": 61,\n    "YDS(t)": 578,\n    "TD(t)": 5,\n    "IMP(t)": 38,\n    "IMP%": 0.623,\n    "TGT": 60,\n    "REC": 50,\n    "RecYDS": 576,\n    "RecTD": 5,\n    "Rec1D": 32,\n    "YPRR": 2.36,\n    "1DRR": 0.131,\n    "REC%": 83.3,\n    "DRP": 0,\n    "IMP\\n[rec]": 37,\n    "IMP/OPP [rec]": 0.617,\n    "YPT": 9.6,\n    "YPR": 11.52,\n    "YAC": 347,\n    "YAC/REC": 6.94,\n    "RR": 244,\n    "RecLNG": 50,\n    "RecBP": 12,\n    "CAR": 1,\n    "RuYDS": 2,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Nick Westbrook-Ikhine",\n    "POS": "WR",\n    "TM": "TEN",\n    "PPR": 135.7,\n    "PPR/G": 8,\n    "PPR/OPP": 2.42,\n    "G": 17,\n    "OPP": 56,\n    "YDS(t)": 497,\n    "TD(t)": 9,\n    "IMP(t)": 34,\n    "IMP%": 0.607,\n    "TGT": 56,\n    "REC": 32,\n    "RecYDS": 497,\n    "RecTD": 9,\n    "Rec1D": 25,\n    "YPRR": 1.14,\n    "1DRR": 0.057,\n    "REC%": 57.1,\n    "DRP": 3,\n    "IMP\\n[rec]": 34,\n    "IMP/OPP [rec]": 0.607,\n    "YPT": 8.88,\n    "YPR": 15.53,\n    "YAC": 129,\n    "YAC/REC": 4.03,\n    "RR": 435,\n    "RecLNG": 98,\n    "RecBP": 4,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jalen McMillan",\n    "POS": "WR",\n    "TM": "TB",\n    "PPR": 135.4,\n    "PPR/G": 10.4,\n    "PPR/OPP": 2.18,\n    "G": 13,\n    "OPP": 62,\n    "YDS(t)": 504,\n    "TD(t)": 8,\n    "IMP(t)": 34,\n    "IMP%": 0.548,\n    "TGT": 58,\n    "REC": 37,\n    "RecYDS": 461,\n    "RecTD": 8,\n    "Rec1D": 23,\n    "YPRR": 1.18,\n    "1DRR": 0.059,\n    "REC%": 63.8,\n    "DRP": 4,\n    "IMP\\n[rec]": 31,\n    "IMP/OPP [rec]": 0.534,\n    "YPT": 7.95,\n    "YPR": 12.46,\n    "YAC": 129,\n    "YAC/REC": 3.49,\n    "RR": 391,\n    "RecLNG": 33,\n    "RecBP": 8,\n    "CAR": 4,\n    "RuYDS": 43,\n    "RuTD": 0,\n    "Ru1D": 3\n  },\n  {\n    "Player": "Romeo Doubs",\n    "POS": "WR",\n    "TM": "GB",\n    "PPR": 130.1,\n    "PPR/G": 10,\n    "PPR/OPP": 1.86,\n    "G": 13,\n    "OPP": 70,\n    "YDS(t)": 601,\n    "TD(t)": 4,\n    "IMP(t)": 37,\n    "IMP%": 0.529,\n    "TGT": 70,\n    "REC": 46,\n    "RecYDS": 601,\n    "RecTD": 4,\n    "Rec1D": 33,\n    "YPRR": 1.67,\n    "1DRR": 0.092,\n    "REC%": 65.7,\n    "DRP": 5,\n    "IMP\\n[rec]": 37,\n    "IMP/OPP [rec]": 0.529,\n    "YPT": 8.59,\n    "YPR": 13.07,\n    "YAC": 141,\n    "YAC/REC": 3.07,\n    "RR": 360,\n    "RecLNG": 53,\n    "RecBP": 7,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Marvin Mims Jr.",\n    "POS": "WR",\n    "TM": "DEN",\n    "PPR": 129.5,\n    "PPR/G": 7.6,\n    "PPR/OPP": 2.06,\n    "G": 17,\n    "OPP": 63,\n    "YDS(t)": 545,\n    "TD(t)": 6,\n    "IMP(t)": 23,\n    "IMP%": 0.365,\n    "TGT": 50,\n    "REC": 39,\n    "RecYDS": 503,\n    "RecTD": 6,\n    "Rec1D": 14,\n    "YPRR": 2.57,\n    "1DRR": 0.071,\n    "REC%": 78,\n    "DRP": 2,\n    "IMP\\n[rec]": 20,\n    "IMP/OPP [rec]": 0.4,\n    "YPT": 10.06,\n    "YPR": 12.9,\n    "YAC": 479,\n    "YAC/REC": 12.28,\n    "RR": 196,\n    "RecLNG": 93,\n    "RecBP": 7,\n    "CAR": 13,\n    "RuYDS": 42,\n    "RuTD": 0,\n    "Ru1D": 3\n  },\n  {\n    "Player": "Tre Tucker",\n    "POS": "WR",\n    "TM": "LV",\n    "PPR": 129.3,\n    "PPR/G": 7.6,\n    "PPR/OPP": 1.49,\n    "G": 17,\n    "OPP": 87,\n    "YDS(t)": 583,\n    "TD(t)": 4,\n    "IMP(t)": 31,\n    "IMP%": 0.356,\n    "TGT": 78,\n    "REC": 47,\n    "RecYDS": 539,\n    "RecTD": 3,\n    "Rec1D": 24,\n    "YPRR": 0.84,\n    "1DRR": 0.038,\n    "REC%": 60.3,\n    "DRP": 2,\n    "IMP\\n[rec]": 27,\n    "IMP/OPP [rec]": 0.346,\n    "YPT": 6.91,\n    "YPR": 11.47,\n    "YAC": 209,\n    "YAC/REC": 4.45,\n    "RR": 640,\n    "RecLNG": 58,\n    "RecBP": 6,\n    "CAR": 9,\n    "RuYDS": 44,\n    "RuTD": 1,\n    "Ru1D": 3\n  },\n  {\n    "Player": "Michael Wilson",\n    "POS": "WR",\n    "TM": "ARI",\n    "PPR": 126.5,\n    "PPR/G": 7.9,\n    "PPR/OPP": 1.78,\n    "G": 16,\n    "OPP": 71,\n    "YDS(t)": 555,\n    "TD(t)": 4,\n    "IMP(t)": 31,\n    "IMP%": 0.437,\n    "TGT": 70,\n    "REC": 47,\n    "RecYDS": 548,\n    "RecTD": 4,\n    "Rec1D": 27,\n    "YPRR": 1.09,\n    "1DRR": 0.054,\n    "REC%": 67.1,\n    "DRP": 2,\n    "IMP\\n[rec]": 31,\n    "IMP/OPP [rec]": 0.443,\n    "YPT": 7.83,\n    "YPR": 11.66,\n    "YAC": 138,\n    "YAC/REC": 2.94,\n    "RR": 501,\n    "RecLNG": 41,\n    "RecBP": 10,\n    "CAR": 1,\n    "RuYDS": 7,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Allen Lazard",\n    "POS": "WR",\n    "TM": "NYJ",\n    "PPR": 126,\n    "PPR/G": 10.5,\n    "PPR/OPP": 2.1,\n    "G": 12,\n    "OPP": 60,\n    "YDS(t)": 530,\n    "TD(t)": 6,\n    "IMP(t)": 35,\n    "IMP%": 0.583,\n    "TGT": 60,\n    "REC": 37,\n    "RecYDS": 530,\n    "RecTD": 6,\n    "Rec1D": 29,\n    "YPRR": 1.26,\n    "1DRR": 0.069,\n    "REC%": 61.7,\n    "DRP": 8,\n    "IMP\\n[rec]": 35,\n    "IMP/OPP [rec]": 0.583,\n    "YPT": 8.83,\n    "YPR": 14.32,\n    "YAC": 157,\n    "YAC/REC": 4.24,\n    "RR": 421,\n    "RecLNG": 52,\n    "RecBP": 8,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Xavier Legette",\n    "POS": "WR",\n    "TM": "CAR",\n    "PPR": 125.1,\n    "PPR/G": 7.8,\n    "PPR/OPP": 1.44,\n    "G": 16,\n    "OPP": 87,\n    "YDS(t)": 521,\n    "TD(t)": 4,\n    "IMP(t)": 33,\n    "IMP%": 0.379,\n    "TGT": 81,\n    "REC": 49,\n    "RecYDS": 497,\n    "RecTD": 4,\n    "Rec1D": 27,\n    "YPRR": 1.19,\n    "1DRR": 0.065,\n    "REC%": 60.5,\n    "DRP": 8,\n    "IMP\\n[rec]": 31,\n    "IMP/OPP [rec]": 0.383,\n    "YPT": 6.14,\n    "YPR": 10.14,\n    "YAC": 112,\n    "YAC/REC": 2.29,\n    "RR": 417,\n    "RecLNG": 35,\n    "RecBP": 7,\n    "CAR": 6,\n    "RuYDS": 24,\n    "RuTD": 0,\n    "Ru1D": 2\n  },\n  {\n    "Player": "Demarcus Robinson",\n    "POS": "WR",\n    "TM": "LAR",\n    "PPR": 123.5,\n    "PPR/G": 7.3,\n    "PPR/OPP": 2.06,\n    "G": 17,\n    "OPP": 60,\n    "YDS(t)": 505,\n    "TD(t)": 7,\n    "IMP(t)": 34,\n    "IMP%": 0.567,\n    "TGT": 60,\n    "REC": 31,\n    "RecYDS": 505,\n    "RecTD": 7,\n    "Rec1D": 27,\n    "YPRR": 0.99,\n    "1DRR": 0.053,\n    "REC%": 51.7,\n    "DRP": 1,\n    "IMP\\n[rec]": 34,\n    "IMP/OPP [rec]": 0.567,\n    "YPT": 8.42,\n    "YPR": 16.29,\n    "YAC": 76,\n    "YAC/REC": 2.45,\n    "RR": 512,\n    "RecLNG": 46,\n    "RecBP": 9,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Amari Cooper",\n    "POS": "WR",\n    "TM": "BUF",\n    "PPR": 122.7,\n    "PPR/G": 8.8,\n    "PPR/OPP": 1.5,\n    "G": 14,\n    "OPP": 82,\n    "YDS(t)": 547,\n    "TD(t)": 4,\n    "IMP(t)": 28,\n    "IMP%": 0.341,\n    "TGT": 82,\n    "REC": 44,\n    "RecYDS": 547,\n    "RecTD": 4,\n    "Rec1D": 24,\n    "YPRR": 1.46,\n    "1DRR": 0.064,\n    "REC%": 53.7,\n    "DRP": 8,\n    "IMP\\n[rec]": 28,\n    "IMP/OPP [rec]": 0.341,\n    "YPT": 6.67,\n    "YPR": 12.43,\n    "YAC": 119,\n    "YAC/REC": 2.7,\n    "RR": 375,\n    "RecLNG": 30,\n    "RecBP": 8,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Stefon Diggs",\n    "POS": "WR",\n    "TM": "HOU",\n    "PPR": 121.4,\n    "PPR/G": 15.2,\n    "PPR/OPP": 1.87,\n    "G": 8,\n    "OPP": 65,\n    "YDS(t)": 504,\n    "TD(t)": 4,\n    "IMP(t)": 36,\n    "IMP%": 0.554,\n    "TGT": 62,\n    "REC": 47,\n    "RecYDS": 496,\n    "RecTD": 3,\n    "Rec1D": 31,\n    "YPRR": 1.84,\n    "1DRR": 0.115,\n    "REC%": 75.8,\n    "DRP": 2,\n    "IMP\\n[rec]": 34,\n    "IMP/OPP [rec]": 0.548,\n    "YPT": 8,\n    "YPR": 10.55,\n    "YAC": 187,\n    "YAC/REC": 3.98,\n    "RR": 270,\n    "RecLNG": 49,\n    "RecBP": 5,\n    "CAR": 3,\n    "RuYDS": 8,\n    "RuTD": 1,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Tyler Lockett",\n    "POS": "WR",\n    "TM": "SEA",\n    "PPR": 121,\n    "PPR/G": 7.1,\n    "PPR/OPP": 1.73,\n    "G": 17,\n    "OPP": 70,\n    "YDS(t)": 600,\n    "TD(t)": 2,\n    "IMP(t)": 38,\n    "IMP%": 0.543,\n    "TGT": 70,\n    "REC": 49,\n    "RecYDS": 600,\n    "RecTD": 2,\n    "Rec1D": 36,\n    "YPRR": 1.1,\n    "1DRR": 0.066,\n    "REC%": 70,\n    "DRP": 3,\n    "IMP\\n[rec]": 38,\n    "IMP/OPP [rec]": 0.543,\n    "YPT": 8.57,\n    "YPR": 12.24,\n    "YAC": 132,\n    "YAC/REC": 2.69,\n    "RR": 545,\n    "RecLNG": 58,\n    "RecBP": 10,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Elijah Moore",\n    "POS": "WR",\n    "TM": "CLE",\n    "PPR": 120.9,\n    "PPR/G": 7.1,\n    "PPR/OPP": 1.23,\n    "G": 17,\n    "OPP": 98,\n    "YDS(t)": 539,\n    "TD(t)": 1,\n    "IMP(t)": 26,\n    "IMP%": 0.265,\n    "TGT": 97,\n    "REC": 61,\n    "RecYDS": 538,\n    "RecTD": 1,\n    "Rec1D": 25,\n    "YPRR": 0.91,\n    "1DRR": 0.042,\n    "REC%": 62.9,\n    "DRP": 4,\n    "IMP\\n[rec]": 26,\n    "IMP/OPP [rec]": 0.268,\n    "YPT": 5.55,\n    "YPR": 8.82,\n    "YAC": 136,\n    "YAC/REC": 2.23,\n    "RR": 594,\n    "RecLNG": 44,\n    "RecBP": 5,\n    "CAR": 1,\n    "RuYDS": 1,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Kayshon Boutte",\n    "POS": "WR",\n    "TM": "NE",\n    "PPR": 119.9,\n    "PPR/G": 8,\n    "PPR/OPP": 1.79,\n    "G": 15,\n    "OPP": 67,\n    "YDS(t)": 589,\n    "TD(t)": 3,\n    "IMP(t)": 28,\n    "IMP%": 0.418,\n    "TGT": 67,\n    "REC": 43,\n    "RecYDS": 589,\n    "RecTD": 3,\n    "Rec1D": 25,\n    "YPRR": 1.26,\n    "1DRR": 0.054,\n    "REC%": 64.2,\n    "DRP": 5,\n    "IMP\\n[rec]": 28,\n    "IMP/OPP [rec]": 0.418,\n    "YPT": 8.79,\n    "YPR": 13.7,\n    "YAC": 152,\n    "YAC/REC": 3.53,\n    "RR": 466,\n    "RecLNG": 43,\n    "RecBP": 4,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Andrei Iosivas",\n    "POS": "WR",\n    "TM": "CIN",\n    "PPR": 119.9,\n    "PPR/G": 7.1,\n    "PPR/OPP": 2.03,\n    "G": 17,\n    "OPP": 59,\n    "YDS(t)": 479,\n    "TD(t)": 6,\n    "IMP(t)": 32,\n    "IMP%": 0.542,\n    "TGT": 59,\n    "REC": 36,\n    "RecYDS": 479,\n    "RecTD": 6,\n    "Rec1D": 26,\n    "YPRR": 0.84,\n    "1DRR": 0.045,\n    "REC%": 61,\n    "DRP": 4,\n    "IMP\\n[rec]": 32,\n    "IMP/OPP [rec]": 0.542,\n    "YPT": 8.12,\n    "YPR": 13.31,\n    "YAC": 75,\n    "YAC/REC": 2.08,\n    "RR": 573,\n    "RecLNG": 39,\n    "RecBP": 7,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Calvin Austin III",\n    "POS": "WR",\n    "TM": "PIT",\n    "PPR": 114.8,\n    "PPR/G": 6.8,\n    "PPR/OPP": 2.05,\n    "G": 17,\n    "OPP": 56,\n    "YDS(t)": 548,\n    "TD(t)": 4,\n    "IMP(t)": 22,\n    "IMP%": 0.393,\n    "TGT": 56,\n    "REC": 36,\n    "RecYDS": 548,\n    "RecTD": 4,\n    "Rec1D": 18,\n    "YPRR": 1.45,\n    "1DRR": 0.048,\n    "REC%": 64.3,\n    "DRP": 2,\n    "IMP\\n[rec]": 22,\n    "IMP/OPP [rec]": 0.393,\n    "YPT": 9.79,\n    "YPR": 15.22,\n    "YAC": 153,\n    "YAC/REC": 4.25,\n    "RR": 377,\n    "RecLNG": 55,\n    "RecBP": 10,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Olamide Zaccheaus",\n    "POS": "WR",\n    "TM": "WAS",\n    "PPR": 114.4,\n    "PPR/G": 6.7,\n    "PPR/OPP": 1.82,\n    "G": 17,\n    "OPP": 63,\n    "YDS(t)": 514,\n    "TD(t)": 3,\n    "IMP(t)": 30,\n    "IMP%": 0.476,\n    "TGT": 62,\n    "REC": 45,\n    "RecYDS": 506,\n    "RecTD": 3,\n    "Rec1D": 26,\n    "YPRR": 1.69,\n    "1DRR": 0.087,\n    "REC%": 72.6,\n    "DRP": 5,\n    "IMP\\n[rec]": 29,\n    "IMP/OPP [rec]": 0.468,\n    "YPT": 8.16,\n    "YPR": 11.24,\n    "YAC": 286,\n    "YAC/REC": 6.36,\n    "RR": 300,\n    "RecLNG": 49,\n    "RecBP": 5,\n    "CAR": 1,\n    "RuYDS": 8,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Dontayvion Wicks",\n    "POS": "WR",\n    "TM": "GB",\n    "PPR": 110.5,\n    "PPR/G": 6.5,\n    "PPR/OPP": 1.49,\n    "G": 17,\n    "OPP": 74,\n    "YDS(t)": 415,\n    "TD(t)": 5,\n    "IMP(t)": 30,\n    "IMP%": 0.405,\n    "TGT": 74,\n    "REC": 39,\n    "RecYDS": 415,\n    "RecTD": 5,\n    "Rec1D": 25,\n    "YPRR": 1.42,\n    "1DRR": 0.085,\n    "REC%": 52.7,\n    "DRP": 8,\n    "IMP\\n[rec]": 30,\n    "IMP/OPP [rec]": 0.405,\n    "YPT": 5.61,\n    "YPR": 10.64,\n    "YAC": 148,\n    "YAC/REC": 3.79,\n    "RR": 293,\n    "RecLNG": 36,\n    "RecBP": 4,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Darius Slayton",\n    "POS": "WR",\n    "TM": "NYG",\n    "PPR": 110,\n    "PPR/G": 6.9,\n    "PPR/OPP": 1.53,\n    "G": 16,\n    "OPP": 72,\n    "YDS(t)": 590,\n    "TD(t)": 2,\n    "IMP(t)": 33,\n    "IMP%": 0.458,\n    "TGT": 70,\n    "REC": 39,\n    "RecYDS": 573,\n    "RecTD": 2,\n    "Rec1D": 30,\n    "YPRR": 1.08,\n    "1DRR": 0.056,\n    "REC%": 55.7,\n    "DRP": 7,\n    "IMP\\n[rec]": 32,\n    "IMP/OPP [rec]": 0.457,\n    "YPT": 8.19,\n    "YPR": 14.69,\n    "YAC": 135,\n    "YAC/REC": 3.46,\n    "RR": 531,\n    "RecLNG": 54,\n    "RecBP": 9,\n    "CAR": 2,\n    "RuYDS": 17,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Keon Coleman",\n    "POS": "WR",\n    "TM": "BUF",\n    "PPR": 109.5,\n    "PPR/G": 8.4,\n    "PPR/OPP": 1.92,\n    "G": 13,\n    "OPP": 57,\n    "YDS(t)": 565,\n    "TD(t)": 4,\n    "IMP(t)": 25,\n    "IMP%": 0.439,\n    "TGT": 56,\n    "REC": 29,\n    "RecYDS": 556,\n    "RecTD": 4,\n    "Rec1D": 21,\n    "YPRR": 1.71,\n    "1DRR": 0.064,\n    "REC%": 51.8,\n    "DRP": 5,\n    "IMP\\n[rec]": 25,\n    "IMP/OPP [rec]": 0.446,\n    "YPT": 9.93,\n    "YPR": 19.17,\n    "YAC": 222,\n    "YAC/REC": 7.66,\n    "RR": 326,\n    "RecLNG": 55,\n    "RecBP": 7,\n    "CAR": 1,\n    "RuYDS": 9,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Devaughn Vele",\n    "POS": "WR",\n    "TM": "DEN",\n    "PPR": 106.5,\n    "PPR/G": 8.2,\n    "PPR/OPP": 1.97,\n    "G": 13,\n    "OPP": 54,\n    "YDS(t)": 475,\n    "TD(t)": 3,\n    "IMP(t)": 29,\n    "IMP%": 0.537,\n    "TGT": 54,\n    "REC": 41,\n    "RecYDS": 475,\n    "RecTD": 3,\n    "Rec1D": 26,\n    "YPRR": 1.51,\n    "1DRR": 0.083,\n    "REC%": 75.9,\n    "DRP": 2,\n    "IMP\\n[rec]": 29,\n    "IMP/OPP [rec]": 0.537,\n    "YPT": 8.8,\n    "YPR": 11.59,\n    "YAC": 132,\n    "YAC/REC": 3.22,\n    "RR": 315,\n    "RecLNG": 37,\n    "RecBP": 7,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Christian Watson",\n    "POS": "WR",\n    "TM": "GB",\n    "PPR": 105.3,\n    "PPR/G": 7,\n    "PPR/OPP": 1.91,\n    "G": 15,\n    "OPP": 55,\n    "YDS(t)": 643,\n    "TD(t)": 2,\n    "IMP(t)": 24,\n    "IMP%": 0.436,\n    "TGT": 51,\n    "REC": 29,\n    "RecYDS": 620,\n    "RecTD": 2,\n    "Rec1D": 21,\n    "YPRR": 2.26,\n    "1DRR": 0.077,\n    "REC%": 56.9,\n    "DRP": 2,\n    "IMP\\n[rec]": 23,\n    "IMP/OPP [rec]": 0.451,\n    "YPT": 12.16,\n    "YPR": 21.38,\n    "YAC": 155,\n    "YAC/REC": 5.34,\n    "RR": 274,\n    "RecLNG": 68,\n    "RecBP": 12,\n    "CAR": 4,\n    "RuYDS": 23,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Jalen Nailor",\n    "POS": "WR",\n    "TM": "MIN",\n    "PPR": 105,\n    "PPR/G": 6.2,\n    "PPR/OPP": 2.33,\n    "G": 17,\n    "OPP": 45,\n    "YDS(t)": 410,\n    "TD(t)": 6,\n    "IMP(t)": 29,\n    "IMP%": 0.644,\n    "TGT": 42,\n    "REC": 28,\n    "RecYDS": 414,\n    "RecTD": 6,\n    "Rec1D": 22,\n    "YPRR": 1.07,\n    "1DRR": 0.057,\n    "REC%": 66.7,\n    "DRP": 4,\n    "IMP\\n[rec]": 28,\n    "IMP/OPP [rec]": 0.667,\n    "YPT": 9.86,\n    "YPR": 14.79,\n    "YAC": 103,\n    "YAC/REC": 3.68,\n    "RR": 386,\n    "RecLNG": 33,\n    "RecBP": 8,\n    "CAR": 3,\n    "RuYDS": -4,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Joshua Palmer",\n    "POS": "WR",\n    "TM": "LAC",\n    "PPR": 103.4,\n    "PPR/G": 6.9,\n    "PPR/OPP": 1.64,\n    "G": 15,\n    "OPP": 63,\n    "YDS(t)": 584,\n    "TD(t)": 1,\n    "IMP(t)": 29,\n    "IMP%": 0.46,\n    "TGT": 63,\n    "REC": 39,\n    "RecYDS": 584,\n    "RecTD": 1,\n    "Rec1D": 28,\n    "YPRR": 1.49,\n    "1DRR": 0.072,\n    "REC%": 61.9,\n    "DRP": 4,\n    "IMP\\n[rec]": 29,\n    "IMP/OPP [rec]": 0.46,\n    "YPT": 9.27,\n    "YPR": 14.97,\n    "YAC": 102,\n    "YAC/REC": 2.62,\n    "RR": 391,\n    "RecLNG": 48,\n    "RecBP": 8,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Tutu Atwell",\n    "POS": "WR",\n    "TM": "LAR",\n    "PPR": 98.9,\n    "PPR/G": 5.8,\n    "PPR/OPP": 1.57,\n    "G": 17,\n    "OPP": 63,\n    "YDS(t)": 569,\n    "TD(t)": 0,\n    "IMP(t)": 29,\n    "IMP%": 0.46,\n    "TGT": 61,\n    "REC": 42,\n    "RecYDS": 562,\n    "RecTD": 0,\n    "Rec1D": 29,\n    "YPRR": 2.19,\n    "1DRR": 0.113,\n    "REC%": 68.9,\n    "DRP": 3,\n    "IMP\\n[rec]": 29,\n    "IMP/OPP [rec]": 0.475,\n    "YPT": 9.21,\n    "YPR": 13.38,\n    "YAC": 124,\n    "YAC/REC": 2.95,\n    "RR": 257,\n    "RecLNG": 52,\n    "RecBP": 6,\n    "CAR": 2,\n    "RuYDS": 7,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Mack Hollins",\n    "POS": "WR",\n    "TM": "BUF",\n    "PPR": 98.8,\n    "PPR/G": 5.8,\n    "PPR/OPP": 2.06,\n    "G": 17,\n    "OPP": 48,\n    "YDS(t)": 378,\n    "TD(t)": 5,\n    "IMP(t)": 30,\n    "IMP%": 0.625,\n    "TGT": 48,\n    "REC": 31,\n    "RecYDS": 378,\n    "RecTD": 5,\n    "Rec1D": 25,\n    "YPRR": 0.92,\n    "1DRR": 0.061,\n    "REC%": 64.6,\n    "DRP": 1,\n    "IMP\\n[rec]": 30,\n    "IMP/OPP [rec]": 0.625,\n    "YPT": 7.88,\n    "YPR": 12.19,\n    "YAC": 93,\n    "YAC/REC": 3,\n    "RR": 413,\n    "RecLNG": 44,\n    "RecBP": 4,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "KaVontae Turpin",\n    "POS": "WR",\n    "TM": "DAL",\n    "PPR": 94.2,\n    "PPR/G": 5.5,\n    "PPR/OPP": 1.47,\n    "G": 17,\n    "OPP": 64,\n    "YDS(t)": 512,\n    "TD(t)": 2,\n    "IMP(t)": 25,\n    "IMP%": 0.391,\n    "TGT": 48,\n    "REC": 31,\n    "RecYDS": 420,\n    "RecTD": 2,\n    "Rec1D": 18,\n    "YPRR": 2.06,\n    "1DRR": 0.088,\n    "REC%": 64.6,\n    "DRP": 4,\n    "IMP\\n[rec]": 20,\n    "IMP/OPP [rec]": 0.417,\n    "YPT": 8.75,\n    "YPR": 13.55,\n    "YAC": 264,\n    "YAC/REC": 8.52,\n    "RR": 204,\n    "RecLNG": 64,\n    "RecBP": 6,\n    "CAR": 16,\n    "RuYDS": 92,\n    "RuTD": 0,\n    "Ru1D": 5\n  },\n  {\n    "Player": "Ricky Pearsall",\n    "POS": "WR",\n    "TM": "SF",\n    "PPR": 93.5,\n    "PPR/G": 8.5,\n    "PPR/OPP": 1.99,\n    "G": 11,\n    "OPP": 47,\n    "YDS(t)": 445,\n    "TD(t)": 3,\n    "IMP(t)": 23,\n    "IMP%": 0.489,\n    "TGT": 44,\n    "REC": 31,\n    "RecYDS": 400,\n    "RecTD": 3,\n    "Rec1D": 19,\n    "YPRR": 1.31,\n    "1DRR": 0.062,\n    "REC%": 70.5,\n    "DRP": 1,\n    "IMP\\n[rec]": 22,\n    "IMP/OPP [rec]": 0.5,\n    "YPT": 9.09,\n    "YPR": 12.9,\n    "YAC": 110,\n    "YAC/REC": 3.55,\n    "RR": 306,\n    "RecLNG": 46,\n    "RecBP": 5,\n    "CAR": 3,\n    "RuYDS": 45,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Greg Dortch",\n    "POS": "WR",\n    "TM": "ARI",\n    "PPR": 92.3,\n    "PPR/G": 5.4,\n    "PPR/OPP": 1.81,\n    "G": 17,\n    "OPP": 51,\n    "YDS(t)": 373,\n    "TD(t)": 3,\n    "IMP(t)": 19,\n    "IMP%": 0.373,\n    "TGT": 46,\n    "REC": 37,\n    "RecYDS": 342,\n    "RecTD": 3,\n    "Rec1D": 16,\n    "YPRR": 1.18,\n    "1DRR": 0.055,\n    "REC%": 80.4,\n    "DRP": 2,\n    "IMP\\n[rec]": 19,\n    "IMP/OPP [rec]": 0.413,\n    "YPT": 7.43,\n    "YPR": 9.24,\n    "YAC": 297,\n    "YAC/REC": 8.03,\n    "RR": 290,\n    "RecLNG": 39,\n    "RecBP": 2,\n    "CAR": 5,\n    "RuYDS": 31,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jalen Coker",\n    "POS": "WR",\n    "TM": "CAR",\n    "PPR": 91.8,\n    "PPR/G": 8.3,\n    "PPR/OPP": 2.04,\n    "G": 11,\n    "OPP": 45,\n    "YDS(t)": 478,\n    "TD(t)": 2,\n    "IMP(t)": 25,\n    "IMP%": 0.556,\n    "TGT": 45,\n    "REC": 32,\n    "RecYDS": 478,\n    "RecTD": 2,\n    "Rec1D": 23,\n    "YPRR": 1.72,\n    "1DRR": 0.083,\n    "REC%": 71.1,\n    "DRP": 1,\n    "IMP\\n[rec]": 25,\n    "IMP/OPP [rec]": 0.556,\n    "YPT": 10.62,\n    "YPR": 14.94,\n    "YAC": 176,\n    "YAC/REC": 5.5,\n    "RR": 278,\n    "RecLNG": 83,\n    "RecBP": 6,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Tim Patrick",\n    "POS": "WR",\n    "TM": "DET",\n    "PPR": 90.4,\n    "PPR/G": 5.7,\n    "PPR/OPP": 2.01,\n    "G": 16,\n    "OPP": 45,\n    "YDS(t)": 394,\n    "TD(t)": 3,\n    "IMP(t)": 23,\n    "IMP%": 0.511,\n    "TGT": 45,\n    "REC": 33,\n    "RecYDS": 394,\n    "RecTD": 3,\n    "Rec1D": 20,\n    "YPRR": 1.15,\n    "1DRR": 0.058,\n    "REC%": 73.3,\n    "DRP": 0,\n    "IMP\\n[rec]": 23,\n    "IMP/OPP [rec]": 0.511,\n    "YPT": 8.76,\n    "YPR": 11.94,\n    "YAC": 141,\n    "YAC/REC": 4.27,\n    "RR": 342,\n    "RecLNG": 42,\n    "RecBP": 6,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Diontae Johnson",\n    "POS": "WR",\n    "TM": "HOU",\n    "PPR": 89.1,\n    "PPR/G": 7.4,\n    "PPR/OPP": 1.31,\n    "G": 12,\n    "OPP": 68,\n    "YDS(t)": 381,\n    "TD(t)": 3,\n    "IMP(t)": 25,\n    "IMP%": 0.368,\n    "TGT": 66,\n    "REC": 33,\n    "RecYDS": 375,\n    "RecTD": 3,\n    "Rec1D": 21,\n    "YPRR": 1.52,\n    "1DRR": 0.085,\n    "REC%": 50,\n    "DRP": 2,\n    "IMP\\n[rec]": 24,\n    "IMP/OPP [rec]": 0.364,\n    "YPT": 5.68,\n    "YPR": 11.36,\n    "YAC": 97,\n    "YAC/REC": 2.94,\n    "RR": 247,\n    "RecLNG": 39,\n    "RecBP": 5,\n    "CAR": 2,\n    "RuYDS": 6,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Parker Washington",\n    "POS": "WR",\n    "TM": "JAX",\n    "PPR": 89,\n    "PPR/G": 5.2,\n    "PPR/OPP": 1.75,\n    "G": 17,\n    "OPP": 51,\n    "YDS(t)": 390,\n    "TD(t)": 3,\n    "IMP(t)": 22,\n    "IMP%": 0.431,\n    "TGT": 51,\n    "REC": 32,\n    "RecYDS": 390,\n    "RecTD": 3,\n    "Rec1D": 19,\n    "YPRR": 1.02,\n    "1DRR": 0.05,\n    "REC%": 62.7,\n    "DRP": 3,\n    "IMP\\n[rec]": 22,\n    "IMP/OPP [rec]": 0.431,\n    "YPT": 7.65,\n    "YPR": 12.19,\n    "YAC": 108,\n    "YAC/REC": 3.38,\n    "RR": 383,\n    "RecLNG": 30,\n    "RecBP": 6,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Noah Brown",\n    "POS": "WR",\n    "TM": "WAS",\n    "PPR": 86.3,\n    "PPR/G": 7.8,\n    "PPR/OPP": 1.6,\n    "G": 11,\n    "OPP": 54,\n    "YDS(t)": 453,\n    "TD(t)": 1,\n    "IMP(t)": 22,\n    "IMP%": 0.407,\n    "TGT": 54,\n    "REC": 35,\n    "RecYDS": 453,\n    "RecTD": 1,\n    "Rec1D": 21,\n    "YPRR": 1.63,\n    "1DRR": 0.076,\n    "REC%": 64.8,\n    "DRP": 2,\n    "IMP\\n[rec]": 22,\n    "IMP/OPP [rec]": 0.407,\n    "YPT": 8.39,\n    "YPR": 12.94,\n    "YAC": 88,\n    "YAC/REC": 2.51,\n    "RR": 278,\n    "RecLNG": 52,\n    "RecBP": 4,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "David Moore",\n    "POS": "WR",\n    "TM": "CAR",\n    "PPR": 85.1,\n    "PPR/G": 5,\n    "PPR/OPP": 1.52,\n    "G": 17,\n    "OPP": 56,\n    "YDS(t)": 351,\n    "TD(t)": 3,\n    "IMP(t)": 21,\n    "IMP%": 0.375,\n    "TGT": 55,\n    "REC": 32,\n    "RecYDS": 351,\n    "RecTD": 3,\n    "Rec1D": 18,\n    "YPRR": 1.04,\n    "1DRR": 0.053,\n    "REC%": 58.2,\n    "DRP": 4,\n    "IMP\\n[rec]": 21,\n    "IMP/OPP [rec]": 0.382,\n    "YPT": 6.38,\n    "YPR": 10.97,\n    "YAC": 65,\n    "YAC/REC": 2.03,\n    "RR": 337,\n    "RecLNG": 21,\n    "RecBP": 2,\n    "CAR": 1,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Marquez Valdes-Scantling",\n    "POS": "WR",\n    "TM": "NO",\n    "PPR": 84.5,\n    "PPR/G": 6,\n    "PPR/OPP": 2.01,\n    "G": 14,\n    "OPP": 42,\n    "YDS(t)": 415,\n    "TD(t)": 4,\n    "IMP(t)": 18,\n    "IMP%": 0.429,\n    "TGT": 41,\n    "REC": 19,\n    "RecYDS": 411,\n    "RecTD": 4,\n    "Rec1D": 14,\n    "YPRR": 1.42,\n    "1DRR": 0.048,\n    "REC%": 46.3,\n    "DRP": 3,\n    "IMP\\n[rec]": 18,\n    "IMP/OPP [rec]": 0.439,\n    "YPT": 10.02,\n    "YPR": 21.63,\n    "YAC": 141,\n    "YAC/REC": 7.42,\n    "RR": 290,\n    "RecLNG": 71,\n    "RecBP": 8,\n    "CAR": 1,\n    "RuYDS": 4,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Cedric Tillman",\n    "POS": "WR",\n    "TM": "CLE",\n    "PPR": 80.4,\n    "PPR/G": 7.3,\n    "PPR/OPP": 1.75,\n    "G": 11,\n    "OPP": 46,\n    "YDS(t)": 334,\n    "TD(t)": 3,\n    "IMP(t)": 18,\n    "IMP%": 0.391,\n    "TGT": 45,\n    "REC": 29,\n    "RecYDS": 339,\n    "RecTD": 3,\n    "Rec1D": 15,\n    "YPRR": 1.22,\n    "1DRR": 0.054,\n    "REC%": 64.4,\n    "DRP": 2,\n    "IMP\\n[rec]": 18,\n    "IMP/OPP [rec]": 0.4,\n    "YPT": 7.53,\n    "YPR": 11.69,\n    "YAC": 111,\n    "YAC/REC": 3.83,\n    "RR": 278,\n    "RecLNG": 38,\n    "RecBP": 6,\n    "CAR": 1,\n    "RuYDS": -5,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Chris Olave",\n    "POS": "WR",\n    "TM": "NO",\n    "PPR": 78.7,\n    "PPR/G": 9.8,\n    "PPR/OPP": 1.79,\n    "G": 8,\n    "OPP": 44,\n    "YDS(t)": 407,\n    "TD(t)": 1,\n    "IMP(t)": 24,\n    "IMP%": 0.545,\n    "TGT": 43,\n    "REC": 32,\n    "RecYDS": 400,\n    "RecTD": 1,\n    "Rec1D": 22,\n    "YPRR": 2.13,\n    "1DRR": 0.117,\n    "REC%": 74.4,\n    "DRP": 1,\n    "IMP\\n[rec]": 23,\n    "IMP/OPP [rec]": 0.535,\n    "YPT": 9.3,\n    "YPR": 12.5,\n    "YAC": 118,\n    "YAC/REC": 3.69,\n    "RR": 188,\n    "RecLNG": 39,\n    "RecBP": 4,\n    "CAR": 1,\n    "RuYDS": 7,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Tyler Boyd",\n    "POS": "WR",\n    "TM": "TEN",\n    "PPR": 78.3,\n    "PPR/G": 4.9,\n    "PPR/OPP": 1.37,\n    "G": 16,\n    "OPP": 57,\n    "YDS(t)": 393,\n    "TD(t)": 0,\n    "IMP(t)": 21,\n    "IMP%": 0.368,\n    "TGT": 56,\n    "REC": 39,\n    "RecYDS": 390,\n    "RecTD": 0,\n    "Rec1D": 20,\n    "YPRR": 0.91,\n    "1DRR": 0.047,\n    "REC%": 69.6,\n    "DRP": 1,\n    "IMP\\n[rec]": 20,\n    "IMP/OPP [rec]": 0.357,\n    "YPT": 6.96,\n    "YPR": 10,\n    "YAC": 199,\n    "YAC/REC": 5.1,\n    "RR": 429,\n    "RecLNG": 40,\n    "RecBP": 4,\n    "CAR": 1,\n    "RuYDS": 3,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Sterling Shepard",\n    "POS": "WR",\n    "TM": "TB",\n    "PPR": 78.3,\n    "PPR/G": 5.6,\n    "PPR/OPP": 1.37,\n    "G": 14,\n    "OPP": 57,\n    "YDS(t)": 403,\n    "TD(t)": 1,\n    "IMP(t)": 21,\n    "IMP%": 0.368,\n    "TGT": 49,\n    "REC": 32,\n    "RecYDS": 334,\n    "RecTD": 1,\n    "Rec1D": 16,\n    "YPRR": 0.96,\n    "1DRR": 0.046,\n    "REC%": 65.3,\n    "DRP": 4,\n    "IMP\\n[rec]": 17,\n    "IMP/OPP [rec]": 0.347,\n    "YPT": 6.82,\n    "YPR": 10.44,\n    "YAC": 94,\n    "YAC/REC": 2.94,\n    "RR": 348,\n    "RecLNG": 30,\n    "RecBP": 4,\n    "CAR": 8,\n    "RuYDS": 69,\n    "RuTD": 0,\n    "Ru1D": 4\n  },\n  {\n    "Player": "Rashid Shaheed",\n    "POS": "WR",\n    "TM": "NO",\n    "PPR": 75.8,\n    "PPR/G": 12.6,\n    "PPR/OPP": 1.65,\n    "G": 6,\n    "OPP": 46,\n    "YDS(t)": 378,\n    "TD(t)": 3,\n    "IMP(t)": 17,\n    "IMP%": 0.37,\n    "TGT": 40,\n    "REC": 20,\n    "RecYDS": 349,\n    "RecTD": 3,\n    "Rec1D": 12,\n    "YPRR": 2.04,\n    "1DRR": 0.07,\n    "REC%": 50,\n    "DRP": 0,\n    "IMP\\n[rec]": 15,\n    "IMP/OPP [rec]": 0.375,\n    "YPT": 8.72,\n    "YPR": 17.45,\n    "YAC": 102,\n    "YAC/REC": 5.1,\n    "RR": 171,\n    "RecLNG": 70,\n    "RecBP": 5,\n    "CAR": 6,\n    "RuYDS": 29,\n    "RuTD": 0,\n    "Ru1D": 2\n  },\n  {\n    "Player": "Christian Kirk",\n    "POS": "WR",\n    "TM": "JAX",\n    "PPR": 70.9,\n    "PPR/G": 8.9,\n    "PPR/OPP": 1.51,\n    "G": 8,\n    "OPP": 47,\n    "YDS(t)": 379,\n    "TD(t)": 1,\n    "IMP(t)": 19,\n    "IMP%": 0.404,\n    "TGT": 47,\n    "REC": 27,\n    "RecYDS": 379,\n    "RecTD": 1,\n    "Rec1D": 18,\n    "YPRR": 1.72,\n    "1DRR": 0.082,\n    "REC%": 57.4,\n    "DRP": 3,\n    "IMP\\n[rec]": 19,\n    "IMP/OPP [rec]": 0.404,\n    "YPT": 8.06,\n    "YPR": 14.04,\n    "YAC": 114,\n    "YAC/REC": 4.22,\n    "RR": 220,\n    "RecLNG": 61,\n    "RecBP": 7,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Brandin Cooks",\n    "POS": "WR",\n    "TM": "DAL",\n    "PPR": 69.6,\n    "PPR/G": 7,\n    "PPR/OPP": 1.31,\n    "G": 10,\n    "OPP": 53,\n    "YDS(t)": 256,\n    "TD(t)": 3,\n    "IMP(t)": 22,\n    "IMP%": 0.415,\n    "TGT": 50,\n    "REC": 26,\n    "RecYDS": 259,\n    "RecTD": 3,\n    "Rec1D": 19,\n    "YPRR": 0.89,\n    "1DRR": 0.066,\n    "REC%": 52,\n    "DRP": 0,\n    "IMP\\n[rec]": 22,\n    "IMP/OPP [rec]": 0.44,\n    "YPT": 5.18,\n    "YPR": 9.96,\n    "YAC": 57,\n    "YAC/REC": 2.19,\n    "RR": 290,\n    "RecLNG": 29,\n    "RecBP": 3,\n    "CAR": 3,\n    "RuYDS": -3,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Dyami Brown",\n    "POS": "WR",\n    "TM": "WAS",\n    "PPR": 69.4,\n    "PPR/G": 4.3,\n    "PPR/OPP": 1.69,\n    "G": 16,\n    "OPP": 41,\n    "YDS(t)": 334,\n    "TD(t)": 1,\n    "IMP(t)": 15,\n    "IMP%": 0.366,\n    "TGT": 38,\n    "REC": 30,\n    "RecYDS": 308,\n    "RecTD": 1,\n    "Rec1D": 13,\n    "YPRR": 1.19,\n    "1DRR": 0.05,\n    "REC%": 78.9,\n    "DRP": 2,\n    "IMP\\n[rec]": 14,\n    "IMP/OPP [rec]": 0.368,\n    "YPT": 8.11,\n    "YPR": 10.27,\n    "YAC": 229,\n    "YAC/REC": 7.63,\n    "RR": 258,\n    "RecLNG": 51,\n    "RecBP": 5,\n    "CAR": 3,\n    "RuYDS": 26,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Troy Franklin",\n    "POS": "WR",\n    "TM": "DEN",\n    "PPR": 67.1,\n    "PPR/G": 4.2,\n    "PPR/OPP": 1.32,\n    "G": 16,\n    "OPP": 51,\n    "YDS(t)": 271,\n    "TD(t)": 2,\n    "IMP(t)": 13,\n    "IMP%": 0.255,\n    "TGT": 49,\n    "REC": 28,\n    "RecYDS": 263,\n    "RecTD": 2,\n    "Rec1D": 11,\n    "YPRR": 0.99,\n    "1DRR": 0.042,\n    "REC%": 57.1,\n    "DRP": 3,\n    "IMP\\n[rec]": 13,\n    "IMP/OPP [rec]": 0.265,\n    "YPT": 5.37,\n    "YPR": 9.39,\n    "YAC": 159,\n    "YAC/REC": 5.68,\n    "RR": 265,\n    "RecLNG": 30,\n    "RecBP": 5,\n    "CAR": 2,\n    "RuYDS": 8,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Lil\'Jordan Humphrey",\n    "POS": "WR",\n    "TM": "DEN",\n    "PPR": 66.3,\n    "PPR/G": 3.9,\n    "PPR/OPP": 1.54,\n    "G": 17,\n    "OPP": 43,\n    "YDS(t)": 293,\n    "TD(t)": 1,\n    "IMP(t)": 13,\n    "IMP%": 0.302,\n    "TGT": 43,\n    "REC": 31,\n    "RecYDS": 293,\n    "RecTD": 1,\n    "Rec1D": 12,\n    "YPRR": 1.01,\n    "1DRR": 0.041,\n    "REC%": 72.1,\n    "DRP": 1,\n    "IMP\\n[rec]": 13,\n    "IMP/OPP [rec]": 0.302,\n    "YPT": 6.81,\n    "YPR": 9.45,\n    "YAC": 192,\n    "YAC/REC": 6.19,\n    "RR": 290,\n    "RecLNG": 41,\n    "RecBP": 5,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Kendrick Bourne",\n    "POS": "WR",\n    "TM": "NE",\n    "PPR": 65.1,\n    "PPR/G": 5.4,\n    "PPR/OPP": 1.71,\n    "G": 12,\n    "OPP": 38,\n    "YDS(t)": 311,\n    "TD(t)": 1,\n    "IMP(t)": 15,\n    "IMP%": 0.395,\n    "TGT": 37,\n    "REC": 28,\n    "RecYDS": 305,\n    "RecTD": 1,\n    "Rec1D": 13,\n    "YPRR": 1.06,\n    "1DRR": 0.045,\n    "REC%": 75.7,\n    "DRP": 1,\n    "IMP\\n[rec]": 14,\n    "IMP/OPP [rec]": 0.378,\n    "YPT": 8.24,\n    "YPR": 10.89,\n    "YAC": 97,\n    "YAC/REC": 3.46,\n    "RR": 289,\n    "RecLNG": 37,\n    "RecBP": 2,\n    "CAR": 1,\n    "RuYDS": 6,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Rashee Rice",\n    "POS": "WR",\n    "TM": "KC",\n    "PPR": 64.9,\n    "PPR/G": 16.2,\n    "PPR/OPP": 2.16,\n    "G": 4,\n    "OPP": 30,\n    "YDS(t)": 289,\n    "TD(t)": 2,\n    "IMP(t)": 18,\n    "IMP%": 0.6,\n    "TGT": 29,\n    "REC": 24,\n    "RecYDS": 288,\n    "RecTD": 2,\n    "Rec1D": 15,\n    "YPRR": 3.16,\n    "1DRR": 0.165,\n    "REC%": 82.8,\n    "DRP": 1,\n    "IMP\\n[rec]": 17,\n    "IMP/OPP [rec]": 0.586,\n    "YPT": 9.93,\n    "YPR": 12,\n    "YAC": 185,\n    "YAC/REC": 7.71,\n    "RR": 91,\n    "RecLNG": 44,\n    "RecBP": 3,\n    "CAR": 1,\n    "RuYDS": 1,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Curtis Samuel",\n    "POS": "WR",\n    "TM": "BUF",\n    "PPR": 63.7,\n    "PPR/G": 4.6,\n    "PPR/OPP": 1.3,\n    "G": 14,\n    "OPP": 49,\n    "YDS(t)": 267,\n    "TD(t)": 1,\n    "IMP(t)": 10,\n    "IMP%": 0.204,\n    "TGT": 44,\n    "REC": 31,\n    "RecYDS": 253,\n    "RecTD": 1,\n    "Rec1D": 9,\n    "YPRR": 1.11,\n    "1DRR": 0.04,\n    "REC%": 70.5,\n    "DRP": 1,\n    "IMP\\n[rec]": 10,\n    "IMP/OPP [rec]": 0.227,\n    "YPT": 5.75,\n    "YPR": 8.16,\n    "YAC": 164,\n    "YAC/REC": 5.29,\n    "RR": 227,\n    "RecLNG": 38,\n    "RecBP": 2,\n    "CAR": 5,\n    "RuYDS": 14,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Van Jefferson",\n    "POS": "WR",\n    "TM": "PIT",\n    "PPR": 63.6,\n    "PPR/G": 3.7,\n    "PPR/OPP": 1.59,\n    "G": 17,\n    "OPP": 40,\n    "YDS(t)": 276,\n    "TD(t)": 2,\n    "IMP(t)": 14,\n    "IMP%": 0.35,\n    "TGT": 40,\n    "REC": 24,\n    "RecYDS": 276,\n    "RecTD": 2,\n    "Rec1D": 12,\n    "YPRR": 0.72,\n    "1DRR": 0.031,\n    "REC%": 60,\n    "DRP": 2,\n    "IMP\\n[rec]": 14,\n    "IMP/OPP [rec]": 0.35,\n    "YPT": 6.9,\n    "YPR": 11.5,\n    "YAC": 80,\n    "YAC/REC": 3.33,\n    "RR": 381,\n    "RecLNG": 43,\n    "RecBP": 4,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Justin Watson",\n    "POS": "WR",\n    "TM": "KC",\n    "PPR": 62.9,\n    "PPR/G": 3.7,\n    "PPR/OPP": 2.03,\n    "G": 17,\n    "OPP": 31,\n    "YDS(t)": 289,\n    "TD(t)": 2,\n    "IMP(t)": 15,\n    "IMP%": 0.484,\n    "TGT": 31,\n    "REC": 22,\n    "RecYDS": 289,\n    "RecTD": 2,\n    "Rec1D": 13,\n    "YPRR": 0.72,\n    "1DRR": 0.033,\n    "REC%": 71,\n    "DRP": 1,\n    "IMP\\n[rec]": 15,\n    "IMP/OPP [rec]": 0.484,\n    "YPT": 9.32,\n    "YPR": 13.14,\n    "YAC": 64,\n    "YAC/REC": 2.91,\n    "RR": 399,\n    "RecLNG": 49,\n    "RecBP": 2,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Brandon Aiyuk",\n    "POS": "WR",\n    "TM": "SF",\n    "PPR": 62.4,\n    "PPR/G": 8.9,\n    "PPR/OPP": 1.39,\n    "G": 7,\n    "OPP": 45,\n    "YDS(t)": 374,\n    "TD(t)": 0,\n    "IMP(t)": 19,\n    "IMP%": 0.422,\n    "TGT": 45,\n    "REC": 25,\n    "RecYDS": 374,\n    "RecTD": 0,\n    "Rec1D": 19,\n    "YPRR": 1.74,\n    "1DRR": 0.088,\n    "REC%": 55.6,\n    "DRP": 3,\n    "IMP\\n[rec]": 19,\n    "IMP/OPP [rec]": 0.422,\n    "YPT": 8.31,\n    "YPR": 14.96,\n    "YAC": 104,\n    "YAC/REC": 4.16,\n    "RR": 215,\n    "RecLNG": 53,\n    "RecBP": 5,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Tyler Johnson",\n    "POS": "WR",\n    "TM": "LAR",\n    "PPR": 61.1,\n    "PPR/G": 4.1,\n    "PPR/OPP": 1.57,\n    "G": 15,\n    "OPP": 39,\n    "YDS(t)": 291,\n    "TD(t)": 1,\n    "IMP(t)": 11,\n    "IMP%": 0.282,\n    "TGT": 39,\n    "REC": 26,\n    "RecYDS": 291,\n    "RecTD": 1,\n    "Rec1D": 10,\n    "YPRR": 1.46,\n    "1DRR": 0.05,\n    "REC%": 66.7,\n    "DRP": 0,\n    "IMP\\n[rec]": 11,\n    "IMP/OPP [rec]": 0.282,\n    "YPT": 7.46,\n    "YPR": 11.19,\n    "YAC": 184,\n    "YAC/REC": 7.08,\n    "RR": 199,\n    "RecLNG": 63,\n    "RecBP": 4,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Mike Williams",\n    "POS": "WR",\n    "TM": "PIT",\n    "PPR": 56.8,\n    "PPR/G": 3.2,\n    "PPR/OPP": 1.67,\n    "G": 18,\n    "OPP": 34,\n    "YDS(t)": 298,\n    "TD(t)": 1,\n    "IMP(t)": 15,\n    "IMP%": 0.441,\n    "TGT": 34,\n    "REC": 21,\n    "RecYDS": 298,\n    "RecTD": 1,\n    "Rec1D": 14,\n    "YPRR": 0.87,\n    "1DRR": 0.041,\n    "REC%": 61.8,\n    "DRP": 1,\n    "IMP\\n[rec]": 15,\n    "IMP/OPP [rec]": 0.441,\n    "YPT": 8.76,\n    "YPR": 14.19,\n    "YAC": 32,\n    "YAC/REC": 1.52,\n    "RR": 341,\n    "RecLNG": 32,\n    "RecBP": 6,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Malik Washington",\n    "POS": "WR",\n    "TM": "MIA",\n    "PPR": 56.8,\n    "PPR/G": 4.1,\n    "PPR/OPP": 1.39,\n    "G": 14,\n    "OPP": 41,\n    "YDS(t)": 248,\n    "TD(t)": 1,\n    "IMP(t)": 15,\n    "IMP%": 0.366,\n    "TGT": 36,\n    "REC": 26,\n    "RecYDS": 223,\n    "RecTD": 0,\n    "Rec1D": 13,\n    "YPRR": 0.86,\n    "1DRR": 0.05,\n    "REC%": 72.2,\n    "DRP": 2,\n    "IMP\\n[rec]": 13,\n    "IMP/OPP [rec]": 0.361,\n    "YPT": 6.19,\n    "YPR": 8.58,\n    "YAC": 123,\n    "YAC/REC": 4.73,\n    "RR": 258,\n    "RecLNG": 20,\n    "RecBP": 2,\n    "CAR": 5,\n    "RuYDS": 25,\n    "RuTD": 1,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Gabe Davis",\n    "POS": "WR",\n    "TM": "JAX",\n    "PPR": 55.9,\n    "PPR/G": 5.6,\n    "PPR/OPP": 1.33,\n    "G": 10,\n    "OPP": 42,\n    "YDS(t)": 239,\n    "TD(t)": 2,\n    "IMP(t)": 15,\n    "IMP%": 0.357,\n    "TGT": 42,\n    "REC": 20,\n    "RecYDS": 239,\n    "RecTD": 2,\n    "Rec1D": 13,\n    "YPRR": 0.95,\n    "1DRR": 0.052,\n    "REC%": 47.6,\n    "DRP": 2,\n    "IMP\\n[rec]": 15,\n    "IMP/OPP [rec]": 0.357,\n    "YPT": 5.69,\n    "YPR": 11.95,\n    "YAC": 43,\n    "YAC/REC": 2.15,\n    "RR": 252,\n    "RecLNG": 22,\n    "RecBP": 6,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "John Metchie III",\n    "POS": "WR",\n    "TM": "HOU",\n    "PPR": 55.4,\n    "PPR/G": 4.3,\n    "PPR/OPP": 1.54,\n    "G": 13,\n    "OPP": 36,\n    "YDS(t)": 254,\n    "TD(t)": 1,\n    "IMP(t)": 12,\n    "IMP%": 0.333,\n    "TGT": 36,\n    "REC": 24,\n    "RecYDS": 254,\n    "RecTD": 1,\n    "Rec1D": 11,\n    "YPRR": 1.05,\n    "1DRR": 0.045,\n    "REC%": 66.7,\n    "DRP": 1,\n    "IMP\\n[rec]": 12,\n    "IMP/OPP [rec]": 0.333,\n    "YPT": 7.06,\n    "YPR": 10.58,\n    "YAC": 65,\n    "YAC/REC": 2.71,\n    "RR": 242,\n    "RecLNG": 28,\n    "RecBP": 3,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Adonai Mitchell",\n    "POS": "WR",\n    "TM": "IND",\n    "PPR": 54.8,\n    "PPR/G": 3.2,\n    "PPR/OPP": 1,\n    "G": 17,\n    "OPP": 55,\n    "YDS(t)": 318,\n    "TD(t)": 0,\n    "IMP(t)": 17,\n    "IMP%": 0.309,\n    "TGT": 51,\n    "REC": 23,\n    "RecYDS": 312,\n    "RecTD": 0,\n    "Rec1D": 16,\n    "YPRR": 1.51,\n    "1DRR": 0.078,\n    "REC%": 45.1,\n    "DRP": 4,\n    "IMP\\n[rec]": 16,\n    "IMP/OPP [rec]": 0.314,\n    "YPT": 6.12,\n    "YPR": 13.57,\n    "YAC": 104,\n    "YAC/REC": 4.52,\n    "RR": 206,\n    "RecLNG": 36,\n    "RecBP": 4,\n    "CAR": 4,\n    "RuYDS": 6,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "JuJu Smith-Schuster",\n    "POS": "WR",\n    "TM": "KC",\n    "PPR": 53.1,\n    "PPR/G": 3.8,\n    "PPR/OPP": 2.12,\n    "G": 14,\n    "OPP": 25,\n    "YDS(t)": 231,\n    "TD(t)": 2,\n    "IMP(t)": 13,\n    "IMP%": 0.52,\n    "TGT": 25,\n    "REC": 18,\n    "RecYDS": 231,\n    "RecTD": 2,\n    "Rec1D": 11,\n    "YPRR": 0.89,\n    "1DRR": 0.042,\n    "REC%": 72,\n    "DRP": 0,\n    "IMP\\n[rec]": 13,\n    "IMP/OPP [rec]": 0.52,\n    "YPT": 9.24,\n    "YPR": 12.83,\n    "YAC": 157,\n    "YAC/REC": 8.72,\n    "RR": 261,\n    "RecLNG": 50,\n    "RecBP": 3,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jordan Whittington",\n    "POS": "WR",\n    "TM": "LAR",\n    "PPR": 52.5,\n    "PPR/G": 3.8,\n    "PPR/OPP": 1.75,\n    "G": 14,\n    "OPP": 30,\n    "YDS(t)": 305,\n    "TD(t)": 0,\n    "IMP(t)": 16,\n    "IMP%": 0.533,\n    "TGT": 28,\n    "REC": 22,\n    "RecYDS": 293,\n    "RecTD": 0,\n    "Rec1D": 14,\n    "YPRR": 2.5,\n    "1DRR": 0.12,\n    "REC%": 78.6,\n    "DRP": 0,\n    "IMP\\n[rec]": 14,\n    "IMP/OPP [rec]": 0.5,\n    "YPT": 10.46,\n    "YPR": 13.32,\n    "YAC": 206,\n    "YAC/REC": 9.36,\n    "RR": 117,\n    "RecLNG": 50,\n    "RecBP": 4,\n    "CAR": 2,\n    "RuYDS": 12,\n    "RuTD": 0,\n    "Ru1D": 2\n  },\n  {\n    "Player": "Kalif Raymond",\n    "POS": "WR",\n    "TM": "DET",\n    "PPR": 50.5,\n    "PPR/G": 4.2,\n    "PPR/OPP": 2.2,\n    "G": 12,\n    "OPP": 23,\n    "YDS(t)": 215,\n    "TD(t)": 2,\n    "IMP(t)": 13,\n    "IMP%": 0.565,\n    "TGT": 21,\n    "REC": 17,\n    "RecYDS": 215,\n    "RecTD": 2,\n    "Rec1D": 10,\n    "YPRR": 1.68,\n    "1DRR": 0.078,\n    "REC%": 81,\n    "DRP": 0,\n    "IMP\\n[rec]": 12,\n    "IMP/OPP [rec]": 0.571,\n    "YPT": 10.24,\n    "YPR": 12.65,\n    "YAC": 137,\n    "YAC/REC": 8.06,\n    "RR": 128,\n    "RecLNG": 38,\n    "RecBP": 3,\n    "CAR": 2,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Nelson Agholor",\n    "POS": "WR",\n    "TM": "BAL",\n    "PPR": 49.1,\n    "PPR/G": 3.5,\n    "PPR/OPP": 1.75,\n    "G": 14,\n    "OPP": 28,\n    "YDS(t)": 231,\n    "TD(t)": 2,\n    "IMP(t)": 12,\n    "IMP%": 0.429,\n    "TGT": 28,\n    "REC": 14,\n    "RecYDS": 231,\n    "RecTD": 2,\n    "Rec1D": 10,\n    "YPRR": 1.11,\n    "1DRR": 0.048,\n    "REC%": 50,\n    "DRP": 1,\n    "IMP\\n[rec]": 12,\n    "IMP/OPP [rec]": 0.429,\n    "YPT": 8.25,\n    "YPR": 16.5,\n    "YAC": 87,\n    "YAC/REC": 6.21,\n    "RR": 208,\n    "RecLNG": 56,\n    "RecBP": 5,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Cedrick Wilson Jr.",\n    "POS": "WR",\n    "TM": "NO",\n    "PPR": 47.1,\n    "PPR/G": 3.1,\n    "PPR/OPP": 1.68,\n    "G": 15,\n    "OPP": 28,\n    "YDS(t)": 211,\n    "TD(t)": 1,\n    "IMP(t)": 9,\n    "IMP%": 0.321,\n    "TGT": 28,\n    "REC": 20,\n    "RecYDS": 211,\n    "RecTD": 1,\n    "Rec1D": 8,\n    "YPRR": 1.04,\n    "1DRR": 0.04,\n    "REC%": 71.4,\n    "DRP": 2,\n    "IMP\\n[rec]": 9,\n    "IMP/OPP [rec]": 0.321,\n    "YPT": 7.54,\n    "YPR": 10.55,\n    "YAC": 87,\n    "YAC/REC": 4.35,\n    "RR": 202,\n    "RecLNG": 25,\n    "RecBP": 1,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "DJ Turner",\n    "POS": "WR",\n    "TM": "LV",\n    "PPR": 47.1,\n    "PPR/G": 3.9,\n    "PPR/OPP": 1.43,\n    "G": 12,\n    "OPP": 33,\n    "YDS(t)": 191,\n    "TD(t)": 2,\n    "IMP(t)": 13,\n    "IMP%": 0.394,\n    "TGT": 28,\n    "REC": 16,\n    "RecYDS": 158,\n    "RecTD": 1,\n    "Rec1D": 10,\n    "YPRR": 0.66,\n    "1DRR": 0.042,\n    "REC%": 57.1,\n    "DRP": 0,\n    "IMP\\n[rec]": 11,\n    "IMP/OPP [rec]": 0.393,\n    "YPT": 5.64,\n    "YPR": 9.88,\n    "YAC": 83,\n    "YAC/REC": 5.19,\n    "RR": 238,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 5,\n    "RuYDS": 33,\n    "RuTD": 1,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Jahan Dotson",\n    "POS": "WR",\n    "TM": "PHI",\n    "PPR": 41.9,\n    "PPR/G": 2.5,\n    "PPR/OPP": 1.31,\n    "G": 17,\n    "OPP": 32,\n    "YDS(t)": 229,\n    "TD(t)": 0,\n    "IMP(t)": 13,\n    "IMP%": 0.406,\n    "TGT": 31,\n    "REC": 19,\n    "RecYDS": 216,\n    "RecTD": 0,\n    "Rec1D": 12,\n    "YPRR": 0.53,\n    "1DRR": 0.03,\n    "REC%": 61.3,\n    "DRP": 0,\n    "IMP\\n[rec]": 12,\n    "IMP/OPP [rec]": 0.387,\n    "YPT": 6.97,\n    "YPR": 11.37,\n    "YAC": 73,\n    "YAC/REC": 3.84,\n    "RR": 405,\n    "RecLNG": 36,\n    "RecBP": 2,\n    "CAR": 1,\n    "RuYDS": 13,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Robert Woods",\n    "POS": "WR",\n    "TM": "HOU",\n    "PPR": 40.3,\n    "PPR/G": 2.7,\n    "PPR/OPP": 1.34,\n    "G": 15,\n    "OPP": 30,\n    "YDS(t)": 203,\n    "TD(t)": 0,\n    "IMP(t)": 12,\n    "IMP%": 0.4,\n    "TGT": 30,\n    "REC": 20,\n    "RecYDS": 203,\n    "RecTD": 0,\n    "Rec1D": 12,\n    "YPRR": 1.05,\n    "1DRR": 0.062,\n    "REC%": 66.7,\n    "DRP": 1,\n    "IMP\\n[rec]": 12,\n    "IMP/OPP [rec]": 0.4,\n    "YPT": 6.77,\n    "YPR": 10.15,\n    "YAC": 73,\n    "YAC/REC": 3.65,\n    "RR": 193,\n    "RecLNG": 32,\n    "RecBP": 2,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Derius Davis",\n    "POS": "WR",\n    "TM": "LAC",\n    "PPR": 40.1,\n    "PPR/G": 2.9,\n    "PPR/OPP": 1.49,\n    "G": 14,\n    "OPP": 27,\n    "YDS(t)": 151,\n    "TD(t)": 2,\n    "IMP(t)": 9,\n    "IMP%": 0.333,\n    "TGT": 15,\n    "REC": 13,\n    "RecYDS": 112,\n    "RecTD": 2,\n    "Rec1D": 5,\n    "YPRR": 1.51,\n    "1DRR": 0.068,\n    "REC%": 86.7,\n    "DRP": 0,\n    "IMP\\n[rec]": 7,\n    "IMP/OPP [rec]": 0.467,\n    "YPT": 7.47,\n    "YPR": 8.62,\n    "YAC": 118,\n    "YAC/REC": 9.08,\n    "RR": 74,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 12,\n    "RuYDS": 39,\n    "RuTD": 0,\n    "Ru1D": 2\n  },\n  {\n    "Player": "Josh Reynolds",\n    "POS": "WR",\n    "TM": "JAX",\n    "PPR": 38.4,\n    "PPR/G": 4.3,\n    "PPR/OPP": 1.6,\n    "G": 9,\n    "OPP": 24,\n    "YDS(t)": 194,\n    "TD(t)": 1,\n    "IMP(t)": 9,\n    "IMP%": 0.375,\n    "TGT": 24,\n    "REC": 13,\n    "RecYDS": 194,\n    "RecTD": 1,\n    "Rec1D": 8,\n    "YPRR": 0.92,\n    "1DRR": 0.038,\n    "REC%": 54.2,\n    "DRP": 0,\n    "IMP\\n[rec]": 9,\n    "IMP/OPP [rec]": 0.375,\n    "YPT": 8.08,\n    "YPR": 14.92,\n    "YAC": 42,\n    "YAC/REC": 3.23,\n    "RR": 211,\n    "RecLNG": 49,\n    "RecBP": 4,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Ryan Miller",\n    "POS": "WR",\n    "TM": "TB",\n    "PPR": 36.8,\n    "PPR/G": 3.3,\n    "PPR/OPP": 1.84,\n    "G": 11,\n    "OPP": 20,\n    "YDS(t)": 128,\n    "TD(t)": 2,\n    "IMP(t)": 9,\n    "IMP%": 0.45,\n    "TGT": 20,\n    "REC": 12,\n    "RecYDS": 128,\n    "RecTD": 2,\n    "Rec1D": 7,\n    "YPRR": 0.91,\n    "1DRR": 0.05,\n    "REC%": 60,\n    "DRP": 1,\n    "IMP\\n[rec]": 9,\n    "IMP/OPP [rec]": 0.45,\n    "YPT": 6.4,\n    "YPR": 10.67,\n    "YAC": 56,\n    "YAC/REC": 4.67,\n    "RR": 140,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Tylan Wallace",\n    "POS": "WR",\n    "TM": "BAL",\n    "PPR": 36.3,\n    "PPR/G": 2.1,\n    "PPR/OPP": 3.03,\n    "G": 17,\n    "OPP": 12,\n    "YDS(t)": 193,\n    "TD(t)": 1,\n    "IMP(t)": 6,\n    "IMP%": 0.5,\n    "TGT": 12,\n    "REC": 11,\n    "RecYDS": 193,\n    "RecTD": 1,\n    "Rec1D": 5,\n    "YPRR": 1.77,\n    "1DRR": 0.046,\n    "REC%": 91.7,\n    "DRP": 0,\n    "IMP\\n[rec]": 6,\n    "IMP/OPP [rec]": 0.5,\n    "YPT": 16.08,\n    "YPR": 17.55,\n    "YAC": 127,\n    "YAC/REC": 11.55,\n    "RR": 109,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jalen Brooks",\n    "POS": "WR",\n    "TM": "DAL",\n    "PPR": 35.7,\n    "PPR/G": 2.6,\n    "PPR/OPP": 1.19,\n    "G": 14,\n    "OPP": 30,\n    "YDS(t)": 177,\n    "TD(t)": 1,\n    "IMP(t)": 9,\n    "IMP%": 0.3,\n    "TGT": 30,\n    "REC": 12,\n    "RecYDS": 177,\n    "RecTD": 1,\n    "Rec1D": 8,\n    "YPRR": 0.81,\n    "1DRR": 0.037,\n    "REC%": 40,\n    "DRP": 0,\n    "IMP\\n[rec]": 9,\n    "IMP/OPP [rec]": 0.3,\n    "YPT": 5.9,\n    "YPR": 14.75,\n    "YAC": 40,\n    "YAC/REC": 3.33,\n    "RR": 218,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Trey Palmer",\n    "POS": "WR",\n    "TM": "TB",\n    "PPR": 35.2,\n    "PPR/G": 2.3,\n    "PPR/OPP": 1.68,\n    "G": 15,\n    "OPP": 21,\n    "YDS(t)": 172,\n    "TD(t)": 1,\n    "IMP(t)": 8,\n    "IMP%": 0.381,\n    "TGT": 21,\n    "REC": 12,\n    "RecYDS": 172,\n    "RecTD": 1,\n    "Rec1D": 7,\n    "YPRR": 0.97,\n    "1DRR": 0.039,\n    "REC%": 57.1,\n    "DRP": 0,\n    "IMP\\n[rec]": 8,\n    "IMP/OPP [rec]": 0.381,\n    "YPT": 8.19,\n    "YPR": 14.33,\n    "YAC": 42,\n    "YAC/REC": 3.5,\n    "RR": 178,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Luke McCaffrey",\n    "POS": "WR",\n    "TM": "WAS",\n    "PPR": 34.8,\n    "PPR/G": 2,\n    "PPR/OPP": 1.34,\n    "G": 17,\n    "OPP": 26,\n    "YDS(t)": 168,\n    "TD(t)": 0,\n    "IMP(t)": 8,\n    "IMP%": 0.308,\n    "TGT": 26,\n    "REC": 18,\n    "RecYDS": 168,\n    "RecTD": 0,\n    "Rec1D": 8,\n    "YPRR": 0.68,\n    "1DRR": 0.032,\n    "REC%": 69.2,\n    "DRP": 1,\n    "IMP\\n[rec]": 8,\n    "IMP/OPP [rec]": 0.308,\n    "YPT": 6.46,\n    "YPR": 9.33,\n    "YAC": 96,\n    "YAC/REC": 5.33,\n    "RR": 247,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jonathan Mingo",\n    "POS": "WR",\n    "TM": "DAL",\n    "PPR": 34.2,\n    "PPR/G": 2,\n    "PPR/OPP": 0.78,\n    "G": 17,\n    "OPP": 44,\n    "YDS(t)": 172,\n    "TD(t)": 0,\n    "IMP(t)": 6,\n    "IMP%": 0.136,\n    "TGT": 42,\n    "REC": 17,\n    "RecYDS": 167,\n    "RecTD": 0,\n    "Rec1D": 6,\n    "YPRR": 0.62,\n    "1DRR": 0.022,\n    "REC%": 40.5,\n    "DRP": 2,\n    "IMP\\n[rec]": 6,\n    "IMP/OPP [rec]": 0.143,\n    "YPT": 3.98,\n    "YPR": 9.82,\n    "YAC": 69,\n    "YAC/REC": 4.06,\n    "RR": 269,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 2,\n    "RuYDS": 5,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Mecole Hardman Jr.",\n    "POS": "WR",\n    "TM": "KC",\n    "PPR": 33.2,\n    "PPR/G": 3,\n    "PPR/OPP": 1.75,\n    "G": 11,\n    "OPP": 19,\n    "YDS(t)": 152,\n    "TD(t)": 1,\n    "IMP(t)": 9,\n    "IMP%": 0.474,\n    "TGT": 14,\n    "REC": 12,\n    "RecYDS": 90,\n    "RecTD": 0,\n    "Rec1D": 6,\n    "YPRR": 1.25,\n    "1DRR": 0.083,\n    "REC%": 85.7,\n    "DRP": 0,\n    "IMP\\n[rec]": 6,\n    "IMP/OPP [rec]": 0.429,\n    "YPT": 6.43,\n    "YPR": 7.5,\n    "YAC": 101,\n    "YAC/REC": 8.42,\n    "RR": 72,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 5,\n    "RuYDS": 62,\n    "RuTD": 1,\n    "Ru1D": 2\n  },\n  {\n    "Player": "Ja\'Lynn Polk",\n    "POS": "WR",\n    "TM": "NE",\n    "PPR": 32.7,\n    "PPR/G": 2.2,\n    "PPR/OPP": 1.02,\n    "G": 15,\n    "OPP": 32,\n    "YDS(t)": 87,\n    "TD(t)": 2,\n    "IMP(t)": 6,\n    "IMP%": 0.188,\n    "TGT": 31,\n    "REC": 12,\n    "RecYDS": 87,\n    "RecTD": 2,\n    "Rec1D": 4,\n    "YPRR": 0.35,\n    "1DRR": 0.016,\n    "REC%": 38.7,\n    "DRP": 2,\n    "IMP\\n[rec]": 6,\n    "IMP/OPP [rec]": 0.194,\n    "YPT": 2.81,\n    "YPR": 7.25,\n    "YAC": 11,\n    "YAC/REC": 0.92,\n    "RR": 252,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 1,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Malik Heath",\n    "POS": "WR",\n    "TM": "GB",\n    "PPR": 31.7,\n    "PPR/G": 2.6,\n    "PPR/OPP": 2.64,\n    "G": 12,\n    "OPP": 12,\n    "YDS(t)": 97,\n    "TD(t)": 2,\n    "IMP(t)": 7,\n    "IMP%": 0.583,\n    "TGT": 12,\n    "REC": 10,\n    "RecYDS": 97,\n    "RecTD": 2,\n    "Rec1D": 5,\n    "YPRR": 1.49,\n    "1DRR": 0.077,\n    "REC%": 83.3,\n    "DRP": 0,\n    "IMP\\n[rec]": 7,\n    "IMP/OPP [rec]": 0.583,\n    "YPT": 8.08,\n    "YPR": 9.7,\n    "YAC": 25,\n    "YAC/REC": 2.5,\n    "RR": 65,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Dante Pettis",\n    "POS": "WR",\n    "TM": "NO",\n    "PPR": 30,\n    "PPR/G": 3.8,\n    "PPR/OPP": 1.25,\n    "G": 8,\n    "OPP": 24,\n    "YDS(t)": 120,\n    "TD(t)": 1,\n    "IMP(t)": 9,\n    "IMP%": 0.375,\n    "TGT": 24,\n    "REC": 12,\n    "RecYDS": 120,\n    "RecTD": 1,\n    "Rec1D": 8,\n    "YPRR": 1.21,\n    "1DRR": 0.081,\n    "REC%": 50,\n    "DRP": 0,\n    "IMP\\n[rec]": 9,\n    "IMP/OPP [rec]": 0.375,\n    "YPT": 5,\n    "YPR": 10,\n    "YAC": 35,\n    "YAC/REC": 2.92,\n    "RR": 99,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jake Bobo",\n    "POS": "WR",\n    "TM": "SEA",\n    "PPR": 29.7,\n    "PPR/G": 1.7,\n    "PPR/OPP": 1.75,\n    "G": 17,\n    "OPP": 17,\n    "YDS(t)": 107,\n    "TD(t)": 1,\n    "IMP(t)": 9,\n    "IMP%": 0.529,\n    "TGT": 17,\n    "REC": 13,\n    "RecYDS": 107,\n    "RecTD": 1,\n    "Rec1D": 8,\n    "YPRR": 0.71,\n    "1DRR": 0.053,\n    "REC%": 76.5,\n    "DRP": 1,\n    "IMP\\n[rec]": 9,\n    "IMP/OPP [rec]": 0.529,\n    "YPT": 6.29,\n    "YPR": 8.23,\n    "YAC": 27,\n    "YAC/REC": 2.08,\n    "RR": 151,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jamison Crowder",\n    "POS": "WR",\n    "TM": "WAS",\n    "PPR": 28.2,\n    "PPR/G": 4.7,\n    "PPR/OPP": 2.17,\n    "G": 6,\n    "OPP": 13,\n    "YDS(t)": 72,\n    "TD(t)": 2,\n    "IMP(t)": 6,\n    "IMP%": 0.462,\n    "TGT": 13,\n    "REC": 9,\n    "RecYDS": 72,\n    "RecTD": 2,\n    "Rec1D": 4,\n    "YPRR": 0.83,\n    "1DRR": 0.046,\n    "REC%": 69.2,\n    "DRP": 2,\n    "IMP\\n[rec]": 6,\n    "IMP/OPP [rec]": 0.462,\n    "YPT": 5.54,\n    "YPR": 8,\n    "YAC": 9,\n    "YAC/REC": 1,\n    "RR": 87,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Kevin Austin Jr.",\n    "POS": "WR",\n    "TM": "NO",\n    "PPR": 27,\n    "PPR/G": 3.4,\n    "PPR/OPP": 1.23,\n    "G": 8,\n    "OPP": 22,\n    "YDS(t)": 160,\n    "TD(t)": 0,\n    "IMP(t)": 10,\n    "IMP%": 0.455,\n    "TGT": 21,\n    "REC": 11,\n    "RecYDS": 151,\n    "RecTD": 0,\n    "Rec1D": 10,\n    "YPRR": 0.79,\n    "1DRR": 0.052,\n    "REC%": 52.4,\n    "DRP": 1,\n    "IMP\\n[rec]": 10,\n    "IMP/OPP [rec]": 0.476,\n    "YPT": 7.19,\n    "YPR": 13.73,\n    "YAC": 39,\n    "YAC/REC": 3.55,\n    "RR": 192,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 1,\n    "RuYDS": 9,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Bub Means",\n    "POS": "WR",\n    "TM": "NO",\n    "PPR": 26.8,\n    "PPR/G": 3.8,\n    "PPR/OPP": 1.79,\n    "G": 7,\n    "OPP": 15,\n    "YDS(t)": 118,\n    "TD(t)": 1,\n    "IMP(t)": 8,\n    "IMP%": 0.533,\n    "TGT": 15,\n    "REC": 9,\n    "RecYDS": 118,\n    "RecTD": 1,\n    "Rec1D": 7,\n    "YPRR": 1.31,\n    "1DRR": 0.078,\n    "REC%": 60,\n    "DRP": 0,\n    "IMP\\n[rec]": 8,\n    "IMP/OPP [rec]": 0.533,\n    "YPT": 7.87,\n    "YPR": 13.11,\n    "YAC": 20,\n    "YAC/REC": 2.22,\n    "RR": 90,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "KhaDarel Hodge",\n    "POS": "WR",\n    "TM": "ATL",\n    "PPR": 26.1,\n    "PPR/G": 1.7,\n    "PPR/OPP": 2.37,\n    "G": 15,\n    "OPP": 11,\n    "YDS(t)": 131,\n    "TD(t)": 1,\n    "IMP(t)": 7,\n    "IMP%": 0.636,\n    "TGT": 11,\n    "REC": 7,\n    "RecYDS": 131,\n    "RecTD": 1,\n    "Rec1D": 6,\n    "YPRR": 1.16,\n    "1DRR": 0.053,\n    "REC%": 63.6,\n    "DRP": 1,\n    "IMP\\n[rec]": 7,\n    "IMP/OPP [rec]": 0.636,\n    "YPT": 11.91,\n    "YPR": 18.71,\n    "YAC": 89,\n    "YAC/REC": 12.71,\n    "RR": 113,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Mason Tipton",\n    "POS": "WR",\n    "TM": "NO",\n    "PPR": 23.9,\n    "PPR/G": 2.2,\n    "PPR/OPP": 1,\n    "G": 11,\n    "OPP": 24,\n    "YDS(t)": 99,\n    "TD(t)": 0,\n    "IMP(t)": 2,\n    "IMP%": 0.083,\n    "TGT": 24,\n    "REC": 14,\n    "RecYDS": 99,\n    "RecTD": 0,\n    "Rec1D": 2,\n    "YPRR": 0.42,\n    "1DRR": 0.008,\n    "REC%": 58.3,\n    "DRP": 2,\n    "IMP\\n[rec]": 2,\n    "IMP/OPP [rec]": 0.083,\n    "YPT": 4.13,\n    "YPR": 7.07,\n    "YAC": 29,\n    "YAC/REC": 2.07,\n    "RR": 238,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Xavier Hutchinson",\n    "POS": "WR",\n    "TM": "HOU",\n    "PPR": 23.7,\n    "PPR/G": 1.5,\n    "PPR/OPP": 0.99,\n    "G": 16,\n    "OPP": 24,\n    "YDS(t)": 117,\n    "TD(t)": 0,\n    "IMP(t)": 6,\n    "IMP%": 0.25,\n    "TGT": 24,\n    "REC": 12,\n    "RecYDS": 117,\n    "RecTD": 0,\n    "Rec1D": 6,\n    "YPRR": 0.44,\n    "1DRR": 0.023,\n    "REC%": 50,\n    "DRP": 1,\n    "IMP\\n[rec]": 6,\n    "IMP/OPP [rec]": 0.25,\n    "YPT": 4.88,\n    "YPR": 9.75,\n    "YAC": 36,\n    "YAC/REC": 3,\n    "RR": 265,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Bo Melton",\n    "POS": "WR",\n    "TM": "GB",\n    "PPR": 22.5,\n    "PPR/G": 1.3,\n    "PPR/OPP": 0.94,\n    "G": 17,\n    "OPP": 24,\n    "YDS(t)": 145,\n    "TD(t)": 0,\n    "IMP(t)": 9,\n    "IMP%": 0.375,\n    "TGT": 16,\n    "REC": 8,\n    "RecYDS": 91,\n    "RecTD": 0,\n    "Rec1D": 5,\n    "YPRR": 1.02,\n    "1DRR": 0.056,\n    "REC%": 50,\n    "DRP": 0,\n    "IMP\\n[rec]": 5,\n    "IMP/OPP [rec]": 0.313,\n    "YPT": 5.69,\n    "YPR": 11.38,\n    "YAC": 8,\n    "YAC/REC": 1,\n    "RR": 89,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 8,\n    "RuYDS": 54,\n    "RuTD": 0,\n    "Ru1D": 4\n  },\n  {\n    "Player": "Trent Sherfield",\n    "POS": "WR",\n    "TM": "MIN",\n    "PPR": 22.3,\n    "PPR/G": 1.3,\n    "PPR/OPP": 2.48,\n    "G": 17,\n    "OPP": 9,\n    "YDS(t)": 83,\n    "TD(t)": 1,\n    "IMP(t)": 5,\n    "IMP%": 0.556,\n    "TGT": 9,\n    "REC": 8,\n    "RecYDS": 83,\n    "RecTD": 1,\n    "Rec1D": 4,\n    "YPRR": 1.36,\n    "1DRR": 0.066,\n    "REC%": 88.9,\n    "DRP": 0,\n    "IMP\\n[rec]": 5,\n    "IMP/OPP [rec]": 0.556,\n    "YPT": 9.22,\n    "YPR": 10.38,\n    "YAC": 38,\n    "YAC/REC": 4.75,\n    "RR": 61,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Rakim Jarrett",\n    "POS": "WR",\n    "TM": "TB",\n    "PPR": 21.4,\n    "PPR/G": 2.1,\n    "PPR/OPP": 1.95,\n    "G": 10,\n    "OPP": 11,\n    "YDS(t)": 124,\n    "TD(t)": 0,\n    "IMP(t)": 5,\n    "IMP%": 0.455,\n    "TGT": 11,\n    "REC": 9,\n    "RecYDS": 124,\n    "RecTD": 0,\n    "Rec1D": 5,\n    "YPRR": 1.16,\n    "1DRR": 0.047,\n    "REC%": 81.8,\n    "DRP": 0,\n    "IMP\\n[rec]": 5,\n    "IMP/OPP [rec]": 0.455,\n    "YPT": 11.27,\n    "YPR": 13.78,\n    "YAC": 19,\n    "YAC/REC": 2.11,\n    "RR": 107,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Devin Duvernay",\n    "POS": "WR",\n    "TM": "JAX",\n    "PPR": 19.2,\n    "PPR/G": 1.6,\n    "PPR/OPP": 0.96,\n    "G": 12,\n    "OPP": 20,\n    "YDS(t)": 82,\n    "TD(t)": 0,\n    "IMP(t)": 8,\n    "IMP%": 0.4,\n    "TGT": 16,\n    "REC": 11,\n    "RecYDS": 79,\n    "RecTD": 0,\n    "Rec1D": 7,\n    "YPRR": 0.6,\n    "1DRR": 0.053,\n    "REC%": 68.8,\n    "DRP": 0,\n    "IMP\\n[rec]": 7,\n    "IMP/OPP [rec]": 0.438,\n    "YPT": 4.94,\n    "YPR": 7.18,\n    "YAC": 65,\n    "YAC/REC": 5.91,\n    "RR": 131,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 4,\n    "RuYDS": 3,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Ashton Dulin",\n    "POS": "WR",\n    "TM": "IND",\n    "PPR": 19.2,\n    "PPR/G": 1.3,\n    "PPR/OPP": 1.48,\n    "G": 15,\n    "OPP": 13,\n    "YDS(t)": 112,\n    "TD(t)": 1,\n    "IMP(t)": 5,\n    "IMP%": 0.385,\n    "TGT": 8,\n    "REC": 2,\n    "RecYDS": 67,\n    "RecTD": 1,\n    "Rec1D": 2,\n    "YPRR": 1.1,\n    "1DRR": 0.033,\n    "REC%": 25,\n    "DRP": 0,\n    "IMP\\n[rec]": 3,\n    "IMP/OPP [rec]": 0.375,\n    "YPT": 8.38,\n    "YPR": 33.5,\n    "YAC": 43,\n    "YAC/REC": 21.5,\n    "RR": 61,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 5,\n    "RuYDS": 45,\n    "RuTD": 0,\n    "Ru1D": 2\n  },\n  {\n    "Player": "K.J. Osborn",\n    "POS": "WR",\n    "TM": "WAS",\n    "PPR": 18.7,\n    "PPR/G": 2.3,\n    "PPR/OPP": 1.1,\n    "G": 8,\n    "OPP": 17,\n    "YDS(t)": 57,\n    "TD(t)": 1,\n    "IMP(t)": 3,\n    "IMP%": 0.176,\n    "TGT": 17,\n    "REC": 7,\n    "RecYDS": 57,\n    "RecTD": 1,\n    "Rec1D": 2,\n    "YPRR": 0.43,\n    "1DRR": 0.015,\n    "REC%": 41.2,\n    "DRP": 0,\n    "IMP\\n[rec]": 3,\n    "IMP/OPP [rec]": 0.176,\n    "YPT": 3.35,\n    "YPR": 8.14,\n    "YAC": 15,\n    "YAC/REC": 2.14,\n    "RR": 133,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Marquise Brown",\n    "POS": "WR",\n    "TM": "KC",\n    "PPR": 18.1,\n    "PPR/G": 9.1,\n    "PPR/OPP": 1.21,\n    "G": 2,\n    "OPP": 15,\n    "YDS(t)": 91,\n    "TD(t)": 0,\n    "IMP(t)": 5,\n    "IMP%": 0.333,\n    "TGT": 15,\n    "REC": 9,\n    "RecYDS": 91,\n    "RecTD": 0,\n    "Rec1D": 5,\n    "YPRR": 2.68,\n    "1DRR": 0.147,\n    "REC%": 60,\n    "DRP": 0,\n    "IMP\\n[rec]": 5,\n    "IMP/OPP [rec]": 0.333,\n    "YPT": 6.07,\n    "YPR": 10.11,\n    "YAC": 46,\n    "YAC/REC": 5.11,\n    "RR": 34,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Ainias Smith",\n    "POS": "WR",\n    "TM": "PHI",\n    "PPR": 17.7,\n    "PPR/G": 2.5,\n    "PPR/OPP": 1.61,\n    "G": 7,\n    "OPP": 11,\n    "YDS(t)": 47,\n    "TD(t)": 1,\n    "IMP(t)": 3,\n    "IMP%": 0.273,\n    "TGT": 9,\n    "REC": 7,\n    "RecYDS": 41,\n    "RecTD": 1,\n    "Rec1D": 1,\n    "YPRR": 0.98,\n    "1DRR": 0.024,\n    "REC%": 77.8,\n    "DRP": 1,\n    "IMP\\n[rec]": 2,\n    "IMP/OPP [rec]": 0.222,\n    "YPT": 4.56,\n    "YPR": 5.86,\n    "YAC": 23,\n    "YAC/REC": 3.29,\n    "RR": 42,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 2,\n    "RuYDS": 6,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Jalen Reagor",\n    "POS": "WR",\n    "TM": "LAC",\n    "PPR": 16.7,\n    "PPR/G": 2.1,\n    "PPR/OPP": 1.19,\n    "G": 8,\n    "OPP": 14,\n    "YDS(t)": 97,\n    "TD(t)": 0,\n    "IMP(t)": 3,\n    "IMP%": 0.214,\n    "TGT": 11,\n    "REC": 7,\n    "RecYDS": 100,\n    "RecTD": 0,\n    "Rec1D": 3,\n    "YPRR": 1.15,\n    "1DRR": 0.034,\n    "REC%": 63.6,\n    "DRP": 0,\n    "IMP\\n[rec]": 3,\n    "IMP/OPP [rec]": 0.273,\n    "YPT": 9.09,\n    "YPR": 14.29,\n    "YAC": 26,\n    "YAC/REC": 3.71,\n    "RR": 87,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 3,\n    "RuYDS": -3,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Simi Fehoko",\n    "POS": "WR",\n    "TM": "LAC",\n    "PPR": 16.6,\n    "PPR/G": 2.1,\n    "PPR/OPP": 1.04,\n    "G": 8,\n    "OPP": 16,\n    "YDS(t)": 106,\n    "TD(t)": 0,\n    "IMP(t)": 6,\n    "IMP%": 0.375,\n    "TGT": 16,\n    "REC": 6,\n    "RecYDS": 106,\n    "RecTD": 0,\n    "Rec1D": 6,\n    "YPRR": 0.84,\n    "1DRR": 0.048,\n    "REC%": 37.5,\n    "DRP": 2,\n    "IMP\\n[rec]": 6,\n    "IMP/OPP [rec]": 0.375,\n    "YPT": 6.63,\n    "YPR": 17.67,\n    "YAC": 18,\n    "YAC/REC": 3,\n    "RR": 126,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Zay Jones",\n    "POS": "WR",\n    "TM": "ARI",\n    "PPR": 16.4,\n    "PPR/G": 1.5,\n    "PPR/OPP": 1.49,\n    "G": 11,\n    "OPP": 11,\n    "YDS(t)": 84,\n    "TD(t)": 0,\n    "IMP(t)": 5,\n    "IMP%": 0.455,\n    "TGT": 11,\n    "REC": 8,\n    "RecYDS": 84,\n    "RecTD": 0,\n    "Rec1D": 5,\n    "YPRR": 0.5,\n    "1DRR": 0.03,\n    "REC%": 72.7,\n    "DRP": 0,\n    "IMP\\n[rec]": 5,\n    "IMP/OPP [rec]": 0.455,\n    "YPT": 7.64,\n    "YPR": 10.5,\n    "YAC": 19,\n    "YAC/REC": 2.38,\n    "RR": 169,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Xavier Gipson",\n    "POS": "WR",\n    "TM": "NYJ",\n    "PPR": 16.4,\n    "PPR/G": 1,\n    "PPR/OPP": 1.49,\n    "G": 16,\n    "OPP": 11,\n    "YDS(t)": 44,\n    "TD(t)": 1,\n    "IMP(t)": 5,\n    "IMP%": 0.455,\n    "TGT": 10,\n    "REC": 6,\n    "RecYDS": 39,\n    "RecTD": 1,\n    "Rec1D": 3,\n    "YPRR": 0.3,\n    "1DRR": 0.023,\n    "REC%": 60,\n    "DRP": 1,\n    "IMP\\n[rec]": 4,\n    "IMP/OPP [rec]": 0.4,\n    "YPT": 3.9,\n    "YPR": 6.5,\n    "YAC": 22,\n    "YAC/REC": 3.67,\n    "RR": 128,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 1,\n    "RuYDS": 5,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "DeAndre Carter",\n    "POS": "WR",\n    "TM": "CHI",\n    "PPR": 16.2,\n    "PPR/G": 1.8,\n    "PPR/OPP": 1.16,\n    "G": 9,\n    "OPP": 14,\n    "YDS(t)": 72,\n    "TD(t)": 0,\n    "IMP(t)": 3,\n    "IMP%": 0.214,\n    "TGT": 14,\n    "REC": 9,\n    "RecYDS": 72,\n    "RecTD": 0,\n    "Rec1D": 3,\n    "YPRR": 0.87,\n    "1DRR": 0.036,\n    "REC%": 64.3,\n    "DRP": 0,\n    "IMP\\n[rec]": 3,\n    "IMP/OPP [rec]": 0.214,\n    "YPT": 5.14,\n    "YPR": 8,\n    "YAC": 32,\n    "YAC/REC": 3.56,\n    "RR": 83,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Bryce Oliver",\n    "POS": "WR",\n    "TM": "TEN",\n    "PPR": 15.5,\n    "PPR/G": 1.7,\n    "PPR/OPP": 2.21,\n    "G": 9,\n    "OPP": 7,\n    "YDS(t)": 95,\n    "TD(t)": 0,\n    "IMP(t)": 4,\n    "IMP%": 0.571,\n    "TGT": 7,\n    "REC": 6,\n    "RecYDS": 95,\n    "RecTD": 0,\n    "Rec1D": 4,\n    "YPRR": 2.88,\n    "1DRR": 0.121,\n    "REC%": 85.7,\n    "DRP": 0,\n    "IMP\\n[rec]": 4,\n    "IMP/OPP [rec]": 0.571,\n    "YPT": 13.57,\n    "YPR": 15.83,\n    "YAC": 28,\n    "YAC/REC": 4.67,\n    "RR": 33,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Parris Campbell",\n    "POS": "WR",\n    "TM": "PHI",\n    "PPR": 15,\n    "PPR/G": 3,\n    "PPR/OPP": 2.5,\n    "G": 5,\n    "OPP": 6,\n    "YDS(t)": 30,\n    "TD(t)": 1,\n    "IMP(t)": 2,\n    "IMP%": 0.333,\n    "TGT": 6,\n    "REC": 6,\n    "RecYDS": 30,\n    "RecTD": 1,\n    "Rec1D": 1,\n    "YPRR": 0.39,\n    "1DRR": 0.013,\n    "REC%": 100,\n    "DRP": 0,\n    "IMP\\n[rec]": 2,\n    "IMP/OPP [rec]": 0.333,\n    "YPT": 5,\n    "YPR": 5,\n    "YAC": 7,\n    "YAC/REC": 1.17,\n    "RR": 77,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Johnny Wilson",\n    "POS": "WR",\n    "TM": "PHI",\n    "PPR": 14.8,\n    "PPR/G": 0.9,\n    "PPR/OPP": 0.99,\n    "G": 16,\n    "OPP": 15,\n    "YDS(t)": 38,\n    "TD(t)": 1,\n    "IMP(t)": 4,\n    "IMP%": 0.267,\n    "TGT": 15,\n    "REC": 5,\n    "RecYDS": 38,\n    "RecTD": 1,\n    "Rec1D": 3,\n    "YPRR": 0.24,\n    "1DRR": 0.019,\n    "REC%": 33.3,\n    "DRP": 1,\n    "IMP\\n[rec]": 4,\n    "IMP/OPP [rec]": 0.267,\n    "YPT": 2.53,\n    "YPR": 7.6,\n    "YAC": 15,\n    "YAC/REC": 3,\n    "RR": 156,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jermaine Burton",\n    "POS": "WR",\n    "TM": "CIN",\n    "PPR": 14.7,\n    "PPR/G": 1.1,\n    "PPR/OPP": 1.05,\n    "G": 14,\n    "OPP": 14,\n    "YDS(t)": 107,\n    "TD(t)": 0,\n    "IMP(t)": 4,\n    "IMP%": 0.286,\n    "TGT": 14,\n    "REC": 4,\n    "RecYDS": 107,\n    "RecTD": 0,\n    "Rec1D": 4,\n    "YPRR": 1.11,\n    "1DRR": 0.042,\n    "REC%": 28.6,\n    "DRP": 0,\n    "IMP\\n[rec]": 4,\n    "IMP/OPP [rec]": 0.286,\n    "YPT": 7.64,\n    "YPR": 26.75,\n    "YAC": 18,\n    "YAC/REC": 4.5,\n    "RR": 96,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Odell Beckham Jr.",\n    "POS": "WR",\n    "TM": "MIA",\n    "PPR": 14.5,\n    "PPR/G": 1.6,\n    "PPR/OPP": 0.81,\n    "G": 9,\n    "OPP": 18,\n    "YDS(t)": 55,\n    "TD(t)": 0,\n    "IMP(t)": 3,\n    "IMP%": 0.167,\n    "TGT": 18,\n    "REC": 9,\n    "RecYDS": 55,\n    "RecTD": 0,\n    "Rec1D": 3,\n    "YPRR": 0.52,\n    "1DRR": 0.028,\n    "REC%": 50,\n    "DRP": 1,\n    "IMP\\n[rec]": 3,\n    "IMP/OPP [rec]": 0.167,\n    "YPT": 3.06,\n    "YPR": 6.11,\n    "YAC": 15,\n    "YAC/REC": 1.67,\n    "RR": 106,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jalin Hyatt",\n    "POS": "WR",\n    "TM": "NYG",\n    "PPR": 14.2,\n    "PPR/G": 0.9,\n    "PPR/OPP": 0.75,\n    "G": 16,\n    "OPP": 19,\n    "YDS(t)": 62,\n    "TD(t)": 0,\n    "IMP(t)": 3,\n    "IMP%": 0.158,\n    "TGT": 19,\n    "REC": 8,\n    "RecYDS": 62,\n    "RecTD": 0,\n    "Rec1D": 3,\n    "YPRR": 0.29,\n    "1DRR": 0.014,\n    "REC%": 42.1,\n    "DRP": 1,\n    "IMP\\n[rec]": 3,\n    "IMP/OPP [rec]": 0.158,\n    "YPT": 3.26,\n    "YPR": 7.75,\n    "YAC": 7,\n    "YAC/REC": 0.88,\n    "RR": 217,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Brandon Powell",\n    "POS": "WR",\n    "TM": "MIN",\n    "PPR": 14.1,\n    "PPR/G": 0.8,\n    "PPR/OPP": 1.41,\n    "G": 17,\n    "OPP": 10,\n    "YDS(t)": 71,\n    "TD(t)": 0,\n    "IMP(t)": 5,\n    "IMP%": 0.5,\n    "TGT": 10,\n    "REC": 7,\n    "RecYDS": 71,\n    "RecTD": 0,\n    "Rec1D": 5,\n    "YPRR": 0.6,\n    "1DRR": 0.042,\n    "REC%": 70,\n    "DRP": 0,\n    "IMP\\n[rec]": 5,\n    "IMP/OPP [rec]": 0.5,\n    "YPT": 7.1,\n    "YPR": 10.14,\n    "YAC": 11,\n    "YAC/REC": 1.57,\n    "RR": 119,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Tyrell Shavers",\n    "POS": "WR",\n    "TM": "BUF",\n    "PPR": 13.9,\n    "PPR/G": 4.6,\n    "PPR/OPP": 13.9,\n    "G": 3,\n    "OPP": 1,\n    "YDS(t)": 69,\n    "TD(t)": 1,\n    "IMP(t)": 2,\n    "IMP%": 2,\n    "TGT": 1,\n    "REC": 1,\n    "RecYDS": 69,\n    "RecTD": 1,\n    "Rec1D": 1,\n    "YPRR": 4.93,\n    "1DRR": 0.071,\n    "REC%": 100,\n    "DRP": 0,\n    "IMP\\n[rec]": 2,\n    "IMP/OPP [rec]": 2,\n    "YPT": 69,\n    "YPR": 69,\n    "YAC": 72,\n    "YAC/REC": 72,\n    "RR": 14,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Chris Conley",\n    "POS": "WR",\n    "TM": "SF",\n    "PPR": 13.6,\n    "PPR/G": 0.9,\n    "PPR/OPP": 1.13,\n    "G": 15,\n    "OPP": 12,\n    "YDS(t)": 76,\n    "TD(t)": 0,\n    "IMP(t)": 3,\n    "IMP%": 0.25,\n    "TGT": 12,\n    "REC": 6,\n    "RecYDS": 76,\n    "RecTD": 0,\n    "Rec1D": 3,\n    "YPRR": 0.66,\n    "1DRR": 0.026,\n    "REC%": 50,\n    "DRP": 0,\n    "IMP\\n[rec]": 3,\n    "IMP/OPP [rec]": 0.25,\n    "YPT": 6.33,\n    "YPR": 12.67,\n    "YAC": 21,\n    "YAC/REC": 3.5,\n    "RR": 116,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "River Cracraft",\n    "POS": "WR",\n    "TM": "MIA",\n    "PPR": 13.6,\n    "PPR/G": 1.7,\n    "PPR/OPP": 1.7,\n    "G": 8,\n    "OPP": 8,\n    "YDS(t)": 66,\n    "TD(t)": 0,\n    "IMP(t)": 4,\n    "IMP%": 0.5,\n    "TGT": 8,\n    "REC": 7,\n    "RecYDS": 66,\n    "RecTD": 0,\n    "Rec1D": 4,\n    "YPRR": 0.83,\n    "1DRR": 0.05,\n    "REC%": 87.5,\n    "DRP": 0,\n    "IMP\\n[rec]": 4,\n    "IMP/OPP [rec]": 0.5,\n    "YPT": 8.25,\n    "YPR": 9.43,\n    "YAC": 12,\n    "YAC/REC": 1.71,\n    "RR": 80,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Michael Woods II",\n    "POS": "WR",\n    "TM": "CLE",\n    "PPR": 13.5,\n    "PPR/G": 2.7,\n    "PPR/OPP": 0.75,\n    "G": 5,\n    "OPP": 18,\n    "YDS(t)": 65,\n    "TD(t)": 0,\n    "IMP(t)": 4,\n    "IMP%": 0.222,\n    "TGT": 18,\n    "REC": 7,\n    "RecYDS": 65,\n    "RecTD": 0,\n    "Rec1D": 4,\n    "YPRR": 0.33,\n    "1DRR": 0.02,\n    "REC%": 38.9,\n    "DRP": 1,\n    "IMP\\n[rec]": 4,\n    "IMP/OPP [rec]": 0.222,\n    "YPT": 3.61,\n    "YPR": 9.29,\n    "YAC": 37,\n    "YAC/REC": 5.29,\n    "RR": 198,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "DJ Chark Jr.",\n    "POS": "WR",\n    "TM": "LAC",\n    "PPR": 13.1,\n    "PPR/G": 1.9,\n    "PPR/OPP": 1.46,\n    "G": 7,\n    "OPP": 9,\n    "YDS(t)": 31,\n    "TD(t)": 1,\n    "IMP(t)": 2,\n    "IMP%": 0.222,\n    "TGT": 9,\n    "REC": 4,\n    "RecYDS": 31,\n    "RecTD": 1,\n    "Rec1D": 1,\n    "YPRR": 0.55,\n    "1DRR": 0.018,\n    "REC%": 44.4,\n    "DRP": 0,\n    "IMP\\n[rec]": 2,\n    "IMP/OPP [rec]": 0.222,\n    "YPT": 3.44,\n    "YPR": 7.75,\n    "YAC": 7,\n    "YAC/REC": 1.75,\n    "RR": 56,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Jacob Cowing",\n    "POS": "WR",\n    "TM": "SF",\n    "PPR": 12.7,\n    "PPR/G": 1.1,\n    "PPR/OPP": 2.12,\n    "G": 12,\n    "OPP": 6,\n    "YDS(t)": 87,\n    "TD(t)": 0,\n    "IMP(t)": 3,\n    "IMP%": 0.5,\n    "TGT": 5,\n    "REC": 4,\n    "RecYDS": 80,\n    "RecTD": 0,\n    "Rec1D": 3,\n    "YPRR": 1.19,\n    "1DRR": 0.045,\n    "REC%": 80,\n    "DRP": 0,\n    "IMP\\n[rec]": 3,\n    "IMP/OPP [rec]": 0.6,\n    "YPT": 16,\n    "YPR": 20,\n    "YAC": 27,\n    "YAC/REC": 6.75,\n    "RR": 67,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 1,\n    "RuYDS": 7,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Scott Miller",\n    "POS": "WR",\n    "TM": "PIT",\n    "PPR": 11.9,\n    "PPR/G": 0.9,\n    "PPR/OPP": 1.32,\n    "G": 13,\n    "OPP": 9,\n    "YDS(t)": 69,\n    "TD(t)": 0,\n    "IMP(t)": 2,\n    "IMP%": 0.222,\n    "TGT": 9,\n    "REC": 5,\n    "RecYDS": 69,\n    "RecTD": 0,\n    "Rec1D": 2,\n    "YPRR": 0.77,\n    "1DRR": 0.022,\n    "REC%": 55.6,\n    "DRP": 0,\n    "IMP\\n[rec]": 2,\n    "IMP/OPP [rec]": 0.222,\n    "YPT": 7.67,\n    "YPR": 13.8,\n    "YAC": 35,\n    "YAC/REC": 7,\n    "RR": 90,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Ben Skowronek",\n    "POS": "WR",\n    "TM": "PIT",\n    "PPR": 11.9,\n    "PPR/G": 1.3,\n    "PPR/OPP": 2.38,\n    "G": 9,\n    "OPP": 5,\n    "YDS(t)": 69,\n    "TD(t)": 0,\n    "IMP(t)": 4,\n    "IMP%": 0.8,\n    "TGT": 5,\n    "REC": 5,\n    "RecYDS": 69,\n    "RecTD": 0,\n    "Rec1D": 4,\n    "YPRR": 1.5,\n    "1DRR": 0.087,\n    "REC%": 100,\n    "DRP": 0,\n    "IMP\\n[rec]": 4,\n    "IMP/OPP [rec]": 0.8,\n    "YPT": 13.8,\n    "YPR": 13.8,\n    "YAC": 29,\n    "YAC/REC": 5.8,\n    "RR": 46,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Tay Martin",\n    "POS": "WR",\n    "TM": "TEN",\n    "PPR": 11.9,\n    "PPR/G": 11.9,\n    "PPR/OPP": 5.95,\n    "G": 1,\n    "OPP": 2,\n    "YDS(t)": 49,\n    "TD(t)": 1,\n    "IMP(t)": 2,\n    "IMP%": 1,\n    "TGT": 2,\n    "REC": 1,\n    "RecYDS": 49,\n    "RecTD": 1,\n    "Rec1D": 1,\n    "YPRR": 16.33,\n    "1DRR": 0.333,\n    "REC%": 50,\n    "DRP": 0,\n    "IMP\\n[rec]": 2,\n    "IMP/OPP [rec]": 1,\n    "YPT": 24.5,\n    "YPR": 49,\n    "YAC": 5,\n    "YAC/REC": 5,\n    "RR": 3,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Britain Covey",\n    "POS": "WR",\n    "TM": "PHI",\n    "PPR": 10.4,\n    "PPR/G": 2.1,\n    "PPR/OPP": 1.3,\n    "G": 5,\n    "OPP": 8,\n    "YDS(t)": 34,\n    "TD(t)": 0,\n    "IMP(t)": 2,\n    "IMP%": 0.25,\n    "TGT": 8,\n    "REC": 7,\n    "RecYDS": 34,\n    "RecTD": 0,\n    "Rec1D": 2,\n    "YPRR": 1.06,\n    "1DRR": 0.063,\n    "REC%": 87.5,\n    "DRP": 1,\n    "IMP\\n[rec]": 2,\n    "IMP/OPP [rec]": 0.25,\n    "YPT": 4.25,\n    "YPR": 4.86,\n    "YAC": 30,\n    "YAC/REC": 4.29,\n    "RR": 32,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Kristian Wilkerson",\n    "POS": "WR",\n    "TM": "LV",\n    "PPR": 9.8,\n    "PPR/G": 4.9,\n    "PPR/OPP": 3.27,\n    "G": 2,\n    "OPP": 3,\n    "YDS(t)": 18,\n    "TD(t)": 1,\n    "IMP(t)": 3,\n    "IMP%": 1,\n    "TGT": 3,\n    "REC": 2,\n    "RecYDS": 18,\n    "RecTD": 1,\n    "Rec1D": 2,\n    "YPRR": 0.72,\n    "1DRR": 0.08,\n    "REC%": 66.7,\n    "DRP": 0,\n    "IMP\\n[rec]": 3,\n    "IMP/OPP [rec]": 1,\n    "YPT": 6,\n    "YPR": 9,\n    "YAC": 12,\n    "YAC/REC": 6,\n    "RR": 25,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Devontez Walker",\n    "POS": "WR",\n    "TM": "BAL",\n    "PPR": 9.1,\n    "PPR/G": 1.5,\n    "PPR/OPP": 4.55,\n    "G": 6,\n    "OPP": 2,\n    "YDS(t)": 21,\n    "TD(t)": 1,\n    "IMP(t)": 2,\n    "IMP%": 1,\n    "TGT": 2,\n    "REC": 1,\n    "RecYDS": 21,\n    "RecTD": 1,\n    "Rec1D": 1,\n    "YPRR": 1.05,\n    "1DRR": 0.05,\n    "REC%": 50,\n    "DRP": 0,\n    "IMP\\n[rec]": 2,\n    "IMP/OPP [rec]": 1,\n    "YPT": 10.5,\n    "YPR": 21,\n    "YAC": 0,\n    "YAC/REC": 0,\n    "RR": 20,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Tyquan Thornton",\n    "POS": "WR",\n    "TM": "NE",\n    "PPR": 8.7,\n    "PPR/G": 1.5,\n    "PPR/OPP": 1.09,\n    "G": 6,\n    "OPP": 8,\n    "YDS(t)": 47,\n    "TD(t)": 0,\n    "IMP(t)": 2,\n    "IMP%": 0.25,\n    "TGT": 8,\n    "REC": 4,\n    "RecYDS": 47,\n    "RecTD": 0,\n    "Rec1D": 2,\n    "YPRR": 0.72,\n    "1DRR": 0.031,\n    "REC%": 50,\n    "DRP": 1,\n    "IMP\\n[rec]": 2,\n    "IMP/OPP [rec]": 0.25,\n    "YPT": 5.88,\n    "YPR": 11.75,\n    "YAC": 26,\n    "YAC/REC": 6.5,\n    "RR": 65,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Laviska Shenault Jr.",\n    "POS": "WR",\n    "TM": "LAC",\n    "PPR": 8.7,\n    "PPR/G": 0.8,\n    "PPR/OPP": 1.45,\n    "G": 11,\n    "OPP": 6,\n    "YDS(t)": 37,\n    "TD(t)": 0,\n    "IMP(t)": 2,\n    "IMP%": 0.333,\n    "TGT": 5,\n    "REC": 5,\n    "RecYDS": 36,\n    "RecTD": 0,\n    "Rec1D": 2,\n    "YPRR": 1.44,\n    "1DRR": 0.08,\n    "REC%": 100,\n    "DRP": 0,\n    "IMP\\n[rec]": 2,\n    "IMP/OPP [rec]": 0.4,\n    "YPT": 7.2,\n    "YPR": 7.2,\n    "YAC": 46,\n    "YAC/REC": 9.2,\n    "RR": 25,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 1,\n    "RuYDS": 1,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Treylon Burks",\n    "POS": "WR",\n    "TM": "TEN",\n    "PPR": 7.5,\n    "PPR/G": 1.5,\n    "PPR/OPP": 0.75,\n    "G": 5,\n    "OPP": 10,\n    "YDS(t)": 35,\n    "TD(t)": 0,\n    "IMP(t)": 3,\n    "IMP%": 0.3,\n    "TGT": 8,\n    "REC": 4,\n    "RecYDS": 34,\n    "RecTD": 0,\n    "Rec1D": 3,\n    "YPRR": 0.43,\n    "1DRR": 0.038,\n    "REC%": 50,\n    "DRP": 1,\n    "IMP\\n[rec]": 3,\n    "IMP/OPP [rec]": 0.375,\n    "YPT": 4.25,\n    "YPR": 8.5,\n    "YAC": 4,\n    "YAC/REC": 1,\n    "RR": 79,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 2,\n    "RuYDS": 1,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "D\'Wayne Eskridge",\n    "POS": "WR",\n    "TM": "MIA",\n    "PPR": 7.4,\n    "PPR/G": 1.2,\n    "PPR/OPP": 2.47,\n    "G": 6,\n    "OPP": 3,\n    "YDS(t)": 44,\n    "TD(t)": 0,\n    "IMP(t)": 2,\n    "IMP%": 0.667,\n    "TGT": 3,\n    "REC": 3,\n    "RecYDS": 44,\n    "RecTD": 0,\n    "Rec1D": 2,\n    "YPRR": 2.32,\n    "1DRR": 0.105,\n    "REC%": 100,\n    "DRP": 0,\n    "IMP\\n[rec]": 2,\n    "IMP/OPP [rec]": 0.667,\n    "YPT": 14.67,\n    "YPR": 14.67,\n    "YAC": 29,\n    "YAC/REC": 9.67,\n    "RR": 19,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Malachi Corley",\n    "POS": "WR",\n    "TM": "NYJ",\n    "PPR": 7.2,\n    "PPR/G": 1,\n    "PPR/OPP": 0.9,\n    "G": 7,\n    "OPP": 8,\n    "YDS(t)": 42,\n    "TD(t)": 0,\n    "IMP(t)": 2,\n    "IMP%": 0.25,\n    "TGT": 6,\n    "REC": 3,\n    "RecYDS": 16,\n    "RecTD": 0,\n    "Rec1D": 1,\n    "YPRR": 0.34,\n    "1DRR": 0.021,\n    "REC%": 50,\n    "DRP": 0,\n    "IMP\\n[rec]": 1,\n    "IMP/OPP [rec]": 0.167,\n    "YPT": 2.67,\n    "YPR": 5.33,\n    "YAC": 4,\n    "YAC/REC": 1.33,\n    "RR": 47,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 2,\n    "RuYDS": 26,\n    "RuTD": 0,\n    "Ru1D": 1\n  },\n  {\n    "Player": "Tim Jones",\n    "POS": "WR",\n    "TM": "JAX",\n    "PPR": 7.1,\n    "PPR/G": 0.4,\n    "PPR/OPP": 1.42,\n    "G": 16,\n    "OPP": 5,\n    "YDS(t)": 41,\n    "TD(t)": 0,\n    "IMP(t)": 3,\n    "IMP%": 0.6,\n    "TGT": 5,\n    "REC": 3,\n    "RecYDS": 41,\n    "RecTD": 0,\n    "Rec1D": 3,\n    "YPRR": 0.68,\n    "1DRR": 0.05,\n    "REC%": 60,\n    "DRP": 0,\n    "IMP\\n[rec]": 3,\n    "IMP/OPP [rec]": 0.6,\n    "YPT": 8.2,\n    "YPR": 13.67,\n    "YAC": 19,\n    "YAC/REC": 6.33,\n    "RR": 60,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  },\n  {\n    "Player": "Terrace Marshall Jr.",\n    "POS": "WR",\n    "TM": "LV",\n    "PPR": 7.1,\n    "PPR/G": 1,\n    "PPR/OPP": 1.42,\n    "G": 7,\n    "OPP": 5,\n    "YDS(t)": 41,\n    "TD(t)": 0,\n    "IMP(t)": 1,\n    "IMP%": 0.2,\n    "TGT": 5,\n    "REC": 3,\n    "RecYDS": 41,\n    "RecTD": 0,\n    "Rec1D": 1,\n    "YPRR": 0.48,\n    "1DRR": 0.012,\n    "REC%": 60,\n    "DRP": 0,\n    "IMP\\n[rec]": 1,\n    "IMP/OPP [rec]": 0.2,\n    "YPT": 8.2,\n    "YPR": 13.67,\n    "YAC": 4,\n    "YAC/REC": 1.33,\n    "RR": 85,\n    "RecLNG": 0,\n    "RecBP": 0,\n    "CAR": 0,\n    "RuYDS": 0,\n    "RuTD": 0,\n    "Ru1D": 0\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicColumnProperties={{ formatByIndex: "auto", labelByIndex: "f" }}
      dynamicRowHeights={true}
      emptyMessage="No rows found"
      enableSaveActions={true}
      headerTextWrap={true}
      linkedFilterId=""
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      style={{
        headerFontFamily: "Michroma",
        fontWeight: "100",
        rowSeparator: "rgba(130, 138, 179, 0.04)",
        border: "rgba(130, 138, 179, 0.2)",
        hoverRowBackground: "rgba(87, 0, 255, 0.4)",
        alternateRowBackground: "rgba(26, 26, 50, 1)",
        background: "rgba(23, 23, 44, 1)",
        cellText: "rgba(255, 255, 255, 1)",
        fontSize: "12px",
        fontFamily: "Product Sans",
        headerFontWeight: "400",
        headerBackground: "#141a32",
        headerFontSize: "10px",
      }}
    >
      <Column
        id="3466d"
        alignment="left"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="Player"
        label="PLAYER"
        placeholder="Enter value"
        position="left"
        size={135}
        summaryAggregationMode="none"
      />
      <Column
        id="f83ae"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              ordered: [
                { value: "QB" },
                { color: "#ff2a6d" },
                { textColor: "rgba(18, 18, 18, 1)" },
                { icon: "" },
                { label: "" },
              ],
            },
            {
              value: "WR",
              color: "rgba(88, 167, 255, 0)",
              textColor: "#58a7ff",
              icon: "bold/computer-connection-usb-port",
            },
            {
              value: "RB",
              icon: "bold/travel-transportation-bus",
              color: "rgba(34, 228, 176, 0)",
              textColor: "#22e4b0",
            },
            {
              value: "TE",
              textColor: "#8300ff",
              color: "rgba(0, 0, 0, 0)",
              icon: "bold/interface-security-shield-4",
            },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="left"
        size={66.859375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nPosition\n</div>'
        }
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="50caa"
        alignment="center"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: false }}
        groupAggregationMode="none"
        key="TM"
        label="TM"
        optionList={{
          mode: "mapped",
          mappedData:
            '[\n  { value: "ARI", color: "#97233F", textColor: "#FFB612" },  // red ⟡ yellow :contentReference[oaicite:0]{index=0}\n  { value: "ATL", color: "#A71930", textColor: "#000000" },  // red ⟡ black :contentReference[oaicite:1]{index=1}\n  { value: "BAL", color: "#241773", textColor: "#9E7C0C" },  // purple ⟡ gold :contentReference[oaicite:2]{index=2}\n  { value: "BUF", color: "#00338D", textColor: "#C60C30" },  // royal ⟡ red :contentReference[oaicite:3]{index=3}\n  { value: "CAR", color: "#0085CA", textColor: "#000000" },  // blue ⟡ black :contentReference[oaicite:4]{index=4}\n  { value: "CHI", color: "#0B162A", textColor: "#F63F00" },  // navy ⟡ orange :contentReference[oaicite:5]{index=5}\n  { value: "CIN", color: "#FB3F14", textColor: "#000000" },  // orange ⟡ black :contentReference[oaicite:6]{index=6}\n  { value: "CLE", color: "#DF3C20", textColor: "#101010" },  // orange ⟡ brown :contentReference[oaicite:7]{index=7}\n  { value: "DAL", color: "#003594", textColor: "#A5ACAF" },  // navy ⟡ silver :contentReference[oaicite:8]{index=8}\n  { value: "DEN", color: "#FB2F14", textColor: "#102274" },  // orange ⟡ navy :contentReference[oaicite:9]{index=9}\n  { value: "DET", color: "#0076B6", textColor: "#B0B7BC" },  // honolulu ⟡ silver :contentReference[oaicite:10]{index=10}\n  { value: "GB",  color: "#203731", textColor: "#FFB612" },  // green ⟡ gold :contentReference[oaicite:11]{index=11}\n  { value: "HOU", color: "#03202F", textColor: "#D71930" },  // deep blue ⟡ red :contentReference[oaicite:12]{index=12}\n  { value: "IND", color: "#002C5F", textColor: "#F2FAFD" },  // royal ⟡ gray :contentReference[oaicite:13]{index=13}\n  { value: "JAX", color: "#006778", textColor: "#D7A22A" },  // teal ⟡ gold :contentReference[oaicite:14]{index=14}\n  { value: "KC",  color: "#E31837", textColor: "#FFB612" },  // red ⟡ gold :contentReference[oaicite:15]{index=15}\n  { value: "LAC", color: "#0080C6", textColor: "#FFC20E" },  // powder ⟡ sunshine :contentReference[oaicite:16]{index=16}\n  { value: "LAR", color: "#003594", textColor: "#FFA300" },  // royal ⟡ sol :contentReference[oaicite:17]{index=17}\n  { value: "LV",  color: "#000000", textColor: "#A5ACAF" },  // black ⟡ silver :contentReference[oaicite:18]{index=18}\n  { value: "MIA", color: "#008E87", textColor: "#FC5C02" },  // aqua ⟡ orange :contentReference[oaicite:19]{index=19}\n  { value: "MIN", color: "#4F2683", textColor: "#FFC62F" },  // purple ⟡ gold :contentReference[oaicite:20]{index=20}\n  { value: "NE",  color: "#041E62", textColor: "#D60F51" },  // blue ⟡ red :contentReference[oaicite:21]{index=21}\n  { value: "NO",  color: "#D3BC8D", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:22]{index=22}\n  { value: "NYG", color: "#0B2265", textColor: "#DFDFDF" },  // blue ⟡ red :contentReference[oaicite:23]{index=23}\n  { value: "NYJ", color: "#125740", textColor: "#FFFFFF" },  // green ⟡ white :contentReference[oaicite:24]{index=24}\n  { value: "PHI", color: "#004C54", textColor: "#A5ACAF" },  // midnight ⟡ silver :contentReference[oaicite:25]{index=25}\n  { value: "PIT", color: "#FFB612", textColor: "#101820" },  // gold ⟡ black :contentReference[oaicite:26]{index=26}\n  { value: "SEA", color: "#002244", textColor: "#69BE28" },  // navy ⟡ action-green :contentReference[oaicite:27]{index=27}\n  { value: "SF",  color: "#AA0000", textColor: "#B3995D" },  // scarlet ⟡ gold :contentReference[oaicite:28]{index=28}\n  { value: "TB",  color: "#D50A0A", textColor: "#0A0A08" },  // red ⟡ pewter :contentReference[oaicite:29]{index=29}\n  { value: "TEN", color: "#0C2340", textColor: "#4B92DB" },  // navy ⟡ titan-blue :contentReference[oaicite:30]{index=30}\n  { value: "WAS", color: "#5A1414", textColor: "#FFB612" },  // burgundy ⟡ gold :contentReference[oaicite:31]{index=31}\n  { value: "UDF", color: "#9E9E9E", textColor: "#FFFFFF" }  // neutral grey\n]',
          valueByIndex: "{{ item.value }}",
          labelByIndex: "{{ item.value }}",
          colorByIndex: "{{ item.color }}",
          textColorByIndex: "{{ item.textColor }}",
        }}
        placeholder="Select option"
        position="left"
        size={62.390625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nTeam [NFL]\n</div>'
        }
      />
      <Column
        id="b67b8"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="PPR"
        label="FPTS"
        placeholder="Enter value"
        position="center"
        size={72}
        summaryAggregationMode="none"
      />
      <Column
        id="681f4"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="PPR/G"
        label="FPTS/G"
        placeholder="Enter value"
        position="center"
        size={78}
        summaryAggregationMode="none"
      />
      <Column
        id="e0da0"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        key="PPR/OPP"
        label="FPTS/OPP"
        placeholder="Enter value"
        position="center"
        size={98}
        summaryAggregationMode="none"
      />
      <Column
        id="6beae"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="G"
        label="G"
        placeholder="Enter value"
        position="center"
        size={37.6875}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\nGames Played\n</div>'
        }
      />
      <Column
        id="e9438"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="rgba(181, 161, 254, 1)"
        key="YDS(t)"
        label="YDS ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={64.734375}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [Total]\n</div>'
        }
      />
      <Column
        id="37293"
        alignment="center"
        backgroundColor="rgba(83, 0, 255, 0.02)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a36"
        headerTextColor="#b5a1fe"
        key="TD(t)"
        label="TD
 ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={50.25}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [Total]\n</div>'
        }
      />
      <Column
        id="32948"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="OPP"
        label="OPP"
        placeholder="Enter value"
        position="center"
        size={74}
        summaryAggregationMode="none"
      />
      <Column
        id="0bf1a"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="IMP(t)"
        label="IMP ⌊𝗍⌉"
        placeholder="Enter value"
        position="center"
        size={60}
        summaryAggregationMode="none"
      />
      <Column
        id="1c968"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="average"
        key="IMP%"
        label="IMP/OPP"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="3620d"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="TGT"
        label="TGT"
        placeholder="Enter value"
        position="center"
        size={56}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTargets\n</div>'
        }
      />
      <Column
        id="38694"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="REC"
        label="REC"
        placeholder="Enter value"
        position="center"
        size={59}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nReceptions\n</div>'
        }
      />
      <Column
        id="94082"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RecYDS"
        label="YDS ⌊rec⌉"
        placeholder="Enter value"
        position="center"
        size={77}
        summaryAggregationMode="none"
      />
      <Column
        id="3a17f"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RecTD"
        label="TD ⌊rec⌉"
        placeholder="Enter value"
        position="center"
        size={66}
        summaryAggregationMode="none"
      />
      <Column
        id="2f46e"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="Rec1D"
        label="1D ⌊rec⌉"
        placeholder="Enter value"
        position="center"
        size={68}
        summaryAggregationMode="none"
      />
      <Column
        id="c40d1"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YPRR"
        label="YPRR"
        placeholder="Enter value"
        position="center"
        size={68}
        summaryAggregationMode="none"
        textColor="{{
(() => {
 const v = parseFloat(String(item).replace(/[^0-9.-]/g, ''));
 if (!isFinite(v)) return null;
 const rules = [
  [2.7, '#00ffc4'],
  [2.4, '#85fff3'],
  [2.3, '#7dd1ff'],
  [2.1, '#957cff'],
  [1.9, '#a642ff'],
  [1.7, '#cf60ff'],
  [1.5, '#ff6fe1'],
 ];
 for (const [t, c] of rules) if (v >= t) return c;
 return '#ff2eb2';
})()
}}"
        tooltip={
          '<div style="\n  background-color: #2c334f;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 1em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 15px #000000 ;\n">\nYards per Route Run\n</div>'
        }
      />
      <Column
        id="a3530"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="average"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="1DRR"
        label="1DRR"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="fe787"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "1",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YPR"
        label="YPR"
        placeholder="Enter value"
        position="center"
        size={69}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards per Reception\n</div>'
        }
      />
      <Column
        id="ab276"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{
          showSeparators: true,
          notation: "standard",
          decimalPlaces: "2",
          padDecimal: true,
        }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YPT"
        label="YPT"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n Yards per Target\n</div>'
        }
      />
      <Column
        id="40be6"
        alignment="center"
        backgroundColor="rgba(0, 143, 255, 0.03)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#99cdff"
        key="YAC/REC"
        label="YAC/REC"
        placeholder="Enter value"
        position="center"
        size={83}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #39405c;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 7px;\n  margin: -6px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0px 0px 10px #000000 ;\n">\n Yards after Catch per Reception\n</div>'
        }
      />
      <Column
        id="89a9d"
        alignment="center"
        backgroundColor="rgba(127, 154, 150, 0.01)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="CAR"
        label="CAR"
        placeholder="Enter value"
        position="center"
        size={52.640625}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nCarries\n</div>'
        }
      />
      <Column
        id="9c113"
        alignment="center"
        backgroundColor="rgba(127, 154, 150, 0.01)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="RuYDS"
        label="YDS ⌊ru⌉"
        placeholder="Enter value"
        position="center"
        size={64}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nYards [rushing]\n</div>'
        }
      />
      <Column
        id="a01c4"
        alignment="center"
        backgroundColor="rgba(127, 154, 150, 0.01)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="RuTD"
        label="TD ⌊ru⌉"
        placeholder="Enter value"
        position="center"
        size={56}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nTouchdowns [rushing]\n</div>'
        }
      />
      <Column
        id="d2990"
        alignment="center"
        backgroundColor="rgba(127, 154, 150, 0.01)"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        headerBackgroundColor="#161a32"
        headerTextColor="#c6ffe8"
        key="Ru1D"
        label="1D ⌊ru⌉"
        placeholder="Enter value"
        position="center"
        size={59}
        summaryAggregationMode="none"
        tooltip={
          '<div style="\n  background-color: #7882ac;\n  color: #ffffff;\n  text-align: center;\n  padding: 1px 8px;\n  margin: -10px;\n  font-weight: 300;\n  font-size: 0.95em;\n  border-radius: 4px;\n  box-shadow: 0 2px 6px rgba(0,0,0,0.2);\n">\nFirst Downs [rushing]\n</div>'
        }
      />
      <Column
        id="d5f08"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="REC%"
        label="Rec"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="05cab"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="DRP"
        label="Drp"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="7b358"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="IMP
[rec]"
        label="Imp rec"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="72456"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="percent"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="average"
        key="IMP/OPP [rec]"
        label="Imp opp rec"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="ac5fb"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="YAC"
        label="Yac"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="c51a7"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RR"
        label="Rr"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="44403"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RecLNG"
        label="Rec lng"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="aa302"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RecBP"
        label="Rec bp"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Event
        event="selectRow"
        method=""
        params={{}}
        pluginId=""
        type="datasource"
        waitMs="0"
        waitType="debounce"
      />
    </Table>
  </View>
  <View
    id="91f98"
    disabled={false}
    hidden={false}
    icon="bold/interface-security-shield-4"
    iconPosition="left"
    viewKey="TE"
  />
  <View
    id="c73c1"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="tbd"
    viewKey="WR3"
  >
    <Table
      id="table77"
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "RK": "1",\n    "PLAYER": "Ashton Jeanty",\n    "POS": "RB",\n    "NFL": "LV",\n    "PK#": "6",\n    "RD": "1",\n    "NCAA": "BOIS",\n    "AGE": "21.3",\n    "HT": "5\'8\\"",\n    "WT": "211",\n    "ATHL": "89.00",\n    "40": null,\n    "PRD GRADE": "95.09",\n    "EFF GRADE": "94.33",\n    "ELU GRADE": "98.11",\n    "FILM GRADE": "98.0",\n    "OVR GRADE": "95.7",\n    "G": "40",\n    "YDS(t)": "5631",\n    "YpG(t)": "141",\n    "OPP(t)": "847",\n    "TD(t)": "56",\n    "1D(t)": "268"\n  },\n  {\n    "RK": "2",\n    "PLAYER": "Omarion Hampton",\n    "POS": "RB",\n    "NFL": "LAC",\n    "PK#": "22",\n    "RD": "1",\n    "NCAA": "UNC",\n    "AGE": "22.0",\n    "HT": "5\'12\\"",\n    "WT": "221",\n    "ATHL": "89.00",\n    "40": "4.46",\n    "PRD GRADE": "86.21",\n    "EFF GRADE": "82.77",\n    "ELU GRADE": "86.42",\n    "FILM GRADE": "86.0",\n    "OVR GRADE": "89.7",\n    "G": "38",\n    "YDS(t)": "4200",\n    "YpG(t)": "111",\n    "OPP(t)": "702",\n    "TD(t)": "40",\n    "1D(t)": "208"\n  },\n  {\n    "RK": "3",\n    "PLAYER": "TreVeyon Henderson",\n    "POS": "RB",\n    "NFL": "NE",\n    "PK#": "38",\n    "RD": "2",\n    "NCAA": "OSU",\n    "AGE": "22.4",\n    "HT": "5\'10\\"",\n    "WT": "202",\n    "ATHL": "94.00",\n    "40": "4.43",\n    "PRD GRADE": "89.56",\n    "EFF GRADE": "88.27",\n    "ELU GRADE": "76.15",\n    "FILM GRADE": "84.0",\n    "OVR GRADE": "87.7",\n    "G": "47",\n    "YDS(t)": "4614",\n    "YpG(t)": "98",\n    "OPP(t)": "678",\n    "TD(t)": "48",\n    "1D(t)": "200"\n  },\n  {\n    "RK": "4",\n    "PLAYER": "Cam Skattebo",\n    "POS": "RB",\n    "NFL": "NYG",\n    "PK#": "105",\n    "RD": "4",\n    "NCAA": "ARIZST",\n    "AGE": "23.1",\n    "HT": "5\'10\\"",\n    "WT": "219",\n    "ATHL": "77.00",\n    "40": null,\n    "PRD GRADE": "94.89",\n    "EFF GRADE": "86.87",\n    "ELU GRADE": "92.69",\n    "FILM GRADE": "85.0",\n    "OVR GRADE": "88.3",\n    "G": "46",\n    "YDS(t)": "5772",\n    "YpG(t)": "125",\n    "OPP(t)": "794",\n    "TD(t)": "51",\n    "1D(t)": "187"\n  },\n  {\n    "RK": "5",\n    "PLAYER": "Quinshon Judkins",\n    "POS": "RB",\n    "NFL": "CLE",\n    "PK#": "36",\n    "RD": "2",\n    "NCAA": "OSU",\n    "AGE": "21.4",\n    "HT": "5\'12\\"",\n    "WT": "221",\n    "ATHL": "95.00",\n    "40": "4.48",\n    "PRD GRADE": "89.33",\n    "EFF GRADE": "87.30",\n    "ELU GRADE": "76.01",\n    "FILM GRADE": "82.0",\n    "OVR GRADE": "86.9",\n    "G": "42",\n    "YDS(t)": "4227",\n    "YpG(t)": "101",\n    "OPP(t)": "808",\n    "TD(t)": "50",\n    "1D(t)": "244"\n  },\n  {\n    "RK": "6",\n    "PLAYER": "Kaleb Johnson",\n    "POS": "RB",\n    "NFL": "PIT",\n    "PK#": "83",\n    "RD": "3",\n    "NCAA": "IOWA",\n    "AGE": "21.6",\n    "HT": "6\'1\\"",\n    "WT": "224",\n    "ATHL": "79.00",\n    "40": "4.57",\n    "PRD GRADE": "67.64",\n    "EFF GRADE": "70.00",\n    "ELU GRADE": "82.11",\n    "FILM GRADE": "76.0",\n    "OVR GRADE": "81.6",\n    "G": "35",\n    "YDS(t)": "3019",\n    "YpG(t)": "86",\n    "OPP(t)": "543",\n    "TD(t)": "32",\n    "1D(t)": "124"\n  },\n  {\n    "RK": "7",\n    "PLAYER": "Devin Neal",\n    "POS": "RB",\n    "NFL": "NO",\n    "PK#": "184",\n    "RD": "6",\n    "NCAA": "KU",\n    "AGE": "21.6",\n    "HT": "5\'11\\"",\n    "WT": "213",\n    "ATHL": "68.00",\n    "40": "4.58",\n    "PRD GRADE": "92.11",\n    "EFF GRADE": "80.78",\n    "ELU GRADE": "68.23",\n    "FILM GRADE": "78.0",\n    "OVR GRADE": "81.4",\n    "G": "49",\n    "YDS(t)": "5054",\n    "YpG(t)": "103",\n    "OPP(t)": "861",\n    "TD(t)": "53",\n    "1D(t)": "244"\n  },\n  {\n    "RK": "8",\n    "PLAYER": "RJ Harvey",\n    "POS": "RB",\n    "NFL": "DEN",\n    "PK#": "60",\n    "RD": "2",\n    "NCAA": "UCF",\n    "AGE": "24.1",\n    "HT": "5\'8\\"",\n    "WT": "205",\n    "ATHL": "89.00",\n    "40": "4.4",\n    "PRD GRADE": "88.32",\n    "EFF GRADE": "90.23",\n    "ELU GRADE": "89.60",\n    "FILM GRADE": "79.0",\n    "OVR GRADE": "84.2",\n    "G": "41",\n    "YDS(t)": "4512",\n    "YpG(t)": "110",\n    "OPP(t)": "657",\n    "TD(t)": "47",\n    "1D(t)": "225"\n  },\n  {\n    "RK": "9",\n    "PLAYER": "DJ Giddens",\n    "POS": "RB",\n    "NFL": "IND",\n    "PK#": "151",\n    "RD": "5",\n    "NCAA": "KSU",\n    "AGE": "21.6",\n    "HT": "6\'0\\"",\n    "WT": "212",\n    "ATHL": "85.00",\n    "40": "4.43",\n    "PRD GRADE": "73.92",\n    "EFF GRADE": "82.65",\n    "ELU GRADE": "86.94",\n    "FILM GRADE": "70.0",\n    "OVR GRADE": "80.7",\n    "G": "39",\n    "YDS(t)": "3766",\n    "YpG(t)": "97",\n    "OPP(t)": "600",\n    "TD(t)": "27",\n    "1D(t)": "182"\n  },\n  {\n    "RK": "10",\n    "PLAYER": "Dylan Sampson",\n    "POS": "RB",\n    "NFL": "CLE",\n    "PK#": "126",\n    "RD": "4",\n    "NCAA": "TENN",\n    "AGE": "20.5",\n    "HT": "5\'8\\"",\n    "WT": "200",\n    "ATHL": "80.00",\n    "40": null,\n    "PRD GRADE": "70.41",\n    "EFF GRADE": "85.35",\n    "ELU GRADE": "82.46",\n    "FILM GRADE": "85.0",\n    "OVR GRADE": "81.6",\n    "G": "35",\n    "YDS(t)": "2834",\n    "YpG(t)": "81",\n    "OPP(t)": "472",\n    "TD(t)": "36",\n    "1D(t)": "149"\n  },\n  {\n    "RK": "11",\n    "PLAYER": "Damien Martinez",\n    "POS": "RB",\n    "NFL": "SEA",\n    "PK#": "223",\n    "RD": "7",\n    "NCAA": "MIA",\n    "AGE": "21.2",\n    "HT": "5\'12\\"",\n    "WT": "217",\n    "ATHL": "73.00",\n    "40": "4.51",\n    "PRD GRADE": "72.78",\n    "EFF GRADE": "84.99",\n    "ELU GRADE": "88.83",\n    "FILM GRADE": null,\n    "OVR GRADE": "80.9",\n    "G": "38",\n    "YDS(t)": "3560",\n    "YpG(t)": "94",\n    "OPP(t)": "564",\n    "TD(t)": "26",\n    "1D(t)": "188"\n  },\n  {\n    "RK": "12",\n    "PLAYER": "Tahj Brooks",\n    "POS": "RB",\n    "NFL": "CIN",\n    "PK#": "193",\n    "RD": "6",\n    "NCAA": "TTU",\n    "AGE": "22.9",\n    "HT": "5\'9\\"",\n    "WT": "214",\n    "ATHL": "86.00",\n    "40": "4.52",\n    "PRD GRADE": "91.90",\n    "EFF GRADE": "63.67",\n    "ELU GRADE": "87.90",\n    "FILM GRADE": null,\n    "OVR GRADE": "81.4",\n    "G": "56",\n    "YDS(t)": "5105",\n    "YpG(t)": "91",\n    "OPP(t)": "982",\n    "TD(t)": "47",\n    "1D(t)": "264"\n  },\n  {\n    "RK": "13",\n    "PLAYER": "Bhayshul Tuten",\n    "POS": "RB",\n    "NFL": "JAX",\n    "PK#": "104",\n    "RD": "4",\n    "NCAA": "VT",\n    "AGE": "22.1",\n    "HT": "5\'9\\"",\n    "WT": "206",\n    "ATHL": "94.00",\n    "40": "4.32",\n    "PRD GRADE": "61.92",\n    "EFF GRADE": "75.27",\n    "ELU GRADE": "90.20",\n    "FILM GRADE": "79.0",\n    "OVR GRADE": "79.8",\n    "G": "24",\n    "YDS(t)": "2342",\n    "YpG(t)": "98",\n    "OPP(t)": "422",\n    "TD(t)": "29",\n    "1D(t)": "103"\n  },\n  {\n    "RK": "14",\n    "PLAYER": "Trevor Etienne",\n    "POS": "RB",\n    "NFL": "CAR",\n    "PK#": "114",\n    "RD": "4",\n    "NCAA": "UGA",\n    "AGE": "20.7",\n    "HT": "5\'9\\"",\n    "WT": "198",\n    "ATHL": "83.00",\n    "40": "4.42",\n    "PRD GRADE": "63.40",\n    "EFF GRADE": "71.87",\n    "ELU GRADE": "86.73",\n    "FILM GRADE": "79.0",\n    "OVR GRADE": "79.8",\n    "G": "34",\n    "YDS(t)": "2513",\n    "YpG(t)": "74",\n    "OPP(t)": "434",\n    "TD(t)": "24",\n    "1D(t)": "123"\n  },\n  {\n    "RK": "15",\n    "PLAYER": "Ollie Gordon II",\n    "POS": "RB",\n    "NFL": "MIA",\n    "PK#": "179",\n    "RD": "6",\n    "NCAA": "OKST",\n    "AGE": "21.2",\n    "HT": "6\'1\\"",\n    "WT": "226",\n    "ATHL": "68.00",\n    "40": "4.61",\n    "PRD GRADE": "81.90",\n    "EFF GRADE": "70.82",\n    "ELU GRADE": "64.92",\n    "FILM GRADE": "78.0",\n    "OVR GRADE": "73.7",\n    "G": "39",\n    "YDS(t)": "3505",\n    "YpG(t)": "90",\n    "OPP(t)": "640",\n    "TD(t)": "40",\n    "1D(t)": "177"\n  },\n  {\n    "RK": "16",\n    "PLAYER": "Jordan James",\n    "POS": "RB",\n    "NFL": "SF",\n    "PK#": "147",\n    "RD": "5",\n    "NCAA": "ORE",\n    "AGE": "21.0",\n    "HT": "5\'10\\"",\n    "WT": "205",\n    "ATHL": "71.00",\n    "40": "4.55",\n    "PRD GRADE": "78.25",\n    "EFF GRADE": "81.36",\n    "ELU GRADE": "69.89",\n    "FILM GRADE": null,\n    "OVR GRADE": "76.1",\n    "G": "38",\n    "YDS(t)": "2562",\n    "YpG(t)": "67",\n    "OPP(t)": "439",\n    "TD(t)": "32",\n    "1D(t)": "165"\n  },\n  {\n    "RK": "17",\n    "PLAYER": "Brashard Smith",\n    "POS": "RB",\n    "NFL": "KC",\n    "PK#": "228",\n    "RD": "7",\n    "NCAA": "SMU",\n    "AGE": "22.0",\n    "HT": "5\'10\\"",\n    "WT": "194",\n    "ATHL": "79.00",\n    "40": "4.39",\n    "PRD GRADE": "66.55",\n    "EFF GRADE": "81.83",\n    "ELU GRADE": "59.96",\n    "FILM GRADE": null,\n    "OVR GRADE": "72.8",\n    "G": "49",\n    "YDS(t)": "2606",\n    "YpG(t)": "53",\n    "OPP(t)": "393",\n    "TD(t)": "23",\n    "1D(t)": "126"\n  },\n  {\n    "RK": "18",\n    "PLAYER": "Jaydon Blue",\n    "POS": "RB",\n    "NFL": "DAL",\n    "PK#": "149",\n    "RD": "5",\n    "NCAA": "TEX",\n    "AGE": "21.2",\n    "HT": "5\'9\\"",\n    "WT": "196",\n    "ATHL": "89.00",\n    "40": "4.38",\n    "PRD GRADE": "57.50",\n    "EFF GRADE": "68.83",\n    "ELU GRADE": "76.50",\n    "FILM GRADE": null,\n    "OVR GRADE": "74.0",\n    "G": "38",\n    "YDS(t)": "1664",\n    "YpG(t)": "44",\n    "OPP(t)": "288",\n    "TD(t)": "18",\n    "1D(t)": "83"\n  },\n  {\n    "RK": "19",\n    "PLAYER": "LeQuint Allen",\n    "POS": "RB",\n    "NFL": "JAX",\n    "PK#": "236",\n    "RD": "7",\n    "NCAA": "SYR",\n    "AGE": "20.6",\n    "HT": "6\'0\\"",\n    "WT": "204",\n    "ATHL": "70.00",\n    "40": null,\n    "PRD GRADE": "75.97",\n    "EFF GRADE": "58.63",\n    "ELU GRADE": "58.31",\n    "FILM GRADE": null,\n    "OVR GRADE": "66.7",\n    "G": "39",\n    "YDS(t)": "3207",\n    "YpG(t)": "82",\n    "OPP(t)": "660",\n    "TD(t)": "32",\n    "1D(t)": "172"\n  },\n  {\n    "RK": "20",\n    "PLAYER": "Raheim Sanders",\n    "POS": "RB",\n    "NFL": null,\n    "PK#": null,\n    "RD": null,\n    "NCAA": "SCAR",\n    "AGE": "21.8",\n    "HT": "6\'0\\"",\n    "WT": "217",\n    "ATHL": "71.00",\n    "40": "4.46",\n    "PRD GRADE": "82.28",\n    "EFF GRADE": "70.82",\n    "ELU GRADE": "81.13",\n    "FILM GRADE": null,\n    "OVR GRADE": "77.3",\n    "G": "44",\n    "YDS(t)": "3882",\n    "YpG(t)": "88",\n    "OPP(t)": "667",\n    "TD(t)": "33",\n    "1D(t)": "199"\n  },\n  {\n    "RK": "21",\n    "PLAYER": "Jarquez Hunter",\n    "POS": "RB",\n    "NFL": "LAR",\n    "PK#": "117",\n    "RD": "4",\n    "NCAA": "AUB",\n    "AGE": "22.3",\n    "HT": "5\'9\\"",\n    "WT": "204",\n    "ATHL": "71.00",\n    "40": "4.44",\n    "PRD GRADE": "79.06",\n    "EFF GRADE": "80.31",\n    "ELU GRADE": "90.10",\n    "FILM GRADE": null,\n    "OVR GRADE": "76.1",\n    "G": "49",\n    "YDS(t)": "3929",\n    "YpG(t)": "80",\n    "OPP(t)": "629",\n    "TD(t)": "29",\n    "1D(t)": "190"\n  },\n  {\n    "RK": "22",\n    "PLAYER": "Woody Marks",\n    "POS": "RB",\n    "NFL": "HOU",\n    "PK#": "116",\n    "RD": "4",\n    "NCAA": "USC",\n    "AGE": "24.2",\n    "HT": "5\'10\\"",\n    "WT": "207",\n    "ATHL": "76.00",\n    "40": "4.54",\n    "PRD GRADE": "85.40",\n    "EFF GRADE": "59.22",\n    "ELU GRADE": "55.00",\n    "FILM GRADE": null,\n    "OVR GRADE": "69.9",\n    "G": "57",\n    "YDS(t)": "4562",\n    "YpG(t)": "80",\n    "OPP(t)": "840",\n    "TD(t)": "36",\n    "1D(t)": "218"\n  },\n  {\n    "RK": "23",\n    "PLAYER": "Kyle Monangai",\n    "POS": "RB",\n    "NFL": "CHI",\n    "PK#": "233",\n    "RD": "7",\n    "NCAA": "RUT",\n    "AGE": "23.0",\n    "HT": "5\'8\\"",\n    "WT": "211",\n    "ATHL": "70.00",\n    "40": "4.6",\n    "PRD GRADE": "73.96",\n    "EFF GRADE": "64.40",\n    "ELU GRADE": "84.52",\n    "FILM GRADE": null,\n    "OVR GRADE": "74.2",\n    "G": "52",\n    "YDS(t)": "3474",\n    "YpG(t)": "67",\n    "OPP(t)": "720",\n    "TD(t)": "28",\n    "1D(t)": "197"\n  },\n  {\n    "RK": "24",\n    "PLAYER": "Kalel Mullings",\n    "POS": "RB",\n    "NFL": "TEN",\n    "PK#": "188",\n    "RD": "6",\n    "NCAA": "MICH",\n    "AGE": "22.5",\n    "HT": "6\'2\\"",\n    "WT": "226",\n    "ATHL": "78.00",\n    "40": null,\n    "PRD GRADE": "55.00",\n    "EFF GRADE": "60.86",\n    "ELU GRADE": "63.27",\n    "FILM GRADE": null,\n    "OVR GRADE": "65.3",\n    "G": "56",\n    "YDS(t)": "1268",\n    "YpG(t)": "23",\n    "OPP(t)": "245",\n    "TD(t)": "16",\n    "1D(t)": "84"\n  },\n  {\n    "RK": "25",\n    "PLAYER": "Donovan Edwards",\n    "POS": "RB",\n    "NFL": "NYJ",\n    "PK#": null,\n    "RD": null,\n    "NCAA": "MICH",\n    "AGE": "22.1",\n    "HT": "5\'11\\"",\n    "WT": "205",\n    "ATHL": "94.00",\n    "40": "4.44",\n    "PRD GRADE": "67.00",\n    "EFF GRADE": "62.15",\n    "ELU GRADE": "56.66",\n    "FILM GRADE": null,\n    "OVR GRADE": "71.0",\n    "G": "50",\n    "YDS(t)": "3048",\n    "YpG(t)": "61",\n    "OPP(t)": "528",\n    "TD(t)": "23",\n    "1D(t)": "121"\n  },\n  {\n    "RK": "26",\n    "PLAYER": "Montrell Johnson Jr.",\n    "POS": "RB",\n    "NFL": null,\n    "PK#": null,\n    "RD": null,\n    "NCAA": "FLA",\n    "AGE": "22.5",\n    "HT": "5\'11\\"",\n    "WT": "212",\n    "ATHL": "82.00",\n    "40": "4.41",\n    "PRD GRADE": "77.42",\n    "EFF GRADE": "65.31",\n    "ELU GRADE": "61.62",\n    "FILM GRADE": null,\n    "OVR GRADE": "69.2",\n    "G": "49",\n    "YDS(t)": "3500",\n    "YpG(t)": "71",\n    "OPP(t)": "652",\n    "TD(t)": "35",\n    "1D(t)": "185"\n  },\n  {\n    "RK": "27",\n    "PLAYER": "Ja\'Quinden Jackson",\n    "POS": "RB",\n    "NFL": null,\n    "PK#": null,\n    "RD": null,\n    "NCAA": "ARK",\n    "AGE": "23.5",\n    "HT": "6\'2\\"",\n    "WT": "229",\n    "ATHL": "55.00",\n    "40": null,\n    "PRD GRADE": "63.98",\n    "EFF GRADE": "72.69",\n    "ELU GRADE": "79.81",\n    "FILM GRADE": null,\n    "OVR GRADE": "61.3",\n    "G": "37",\n    "YDS(t)": "2348",\n    "YpG(t)": "63",\n    "OPP(t)": "423",\n    "TD(t)": "29",\n    "1D(t)": "149"\n  }\n]\n'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      dynamicColumnProperties={{ formatByIndex: "auto" }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      headerTextWrap={true}
      linkedFilterId=""
      primaryKeyColumnId="3220b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      showHeader={true}
      style={{
        headerFontFamily: "h6Font",
        fontWeight: "500",
        border: "rgba(18, 23, 48, 1)",
        alternateRowBackground: "#1c1f37",
        background: "#141627",
        fontSize: "13px",
        fontFamily: "Quicksand",
        headerFontWeight: "h6Font",
        headerText: "#ffffffff",
        headerBackground: "rgba(1, 9, 23, 1)",
        headerFontSize: "h6Font",
      }}
    >
      <Column
        id="d6166"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RK"
        label="Rk"
        placeholder="Enter value"
        position="center"
        size={41.46875}
        summaryAggregationMode="none"
      />
      <Column
        id="3220b"
        alignment="left"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="PLAYER"
        label="Player"
        placeholder="Enter value"
        position="center"
        size={132.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="f83ae"
        alignment="center"
        editable={false}
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              ordered: [
                { value: "QB" },
                { color: "#ff2a6d" },
                { textColor: "rgba(18, 18, 18, 1)" },
                { icon: "" },
                { label: "" },
              ],
            },
            { ordered: [{ value: "WR" }, { color: "#58a7ff" }] },
            { ordered: [{ value: "RB" }] },
            { ordered: [{ value: "TE" }] },
          ],
          mode: "manual",
        }}
        placeholder="Select option"
        position="center"
        size={47.859375}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="85342"
        alignment="center"
        editableOptions={{ allowCustomValue: true }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="NFL"
        label="TM"
        optionList={{
          mode: "manual",
          mappedData: "{{  }}",
          manualData: [
            { value: "LV", color: "rgba(13, 13, 13, 1)" },
            { value: "LAC", color: "rgba(3, 159, 196, 1)" },
            {
              value: "NE",
              color: "rgba(6, 6, 81, 1)",
              textColor: "rgba(245, 14, 14, 1)",
            },
            { value: "NYG", color: "rgba(3, 54, 236, 1)" },
            { value: "CLE", color: "rgba(70, 60, 60, 1)" },
            {
              value: "PIT",
              color: "rgba(0, 0, 0, 1)",
              textColor: "rgba(255, 243, 6, 1)",
            },
            {
              value: "NO",
              color: "rgba(0, 0, 0, 1)",
              textColor: "rgba(167, 147, 75, 1)",
            },
            {
              value: "DEN",
              color: "rgba(20, 14, 89, 1)",
              textColor: "rgba(247, 101, 16, 1)",
            },
            { map: { value: "IND" } },
            { map: { value: "SEA" } },
            { map: { value: "CIN" } },
            { map: { value: "JAX" } },
            { map: { value: "CAR" } },
            { map: { value: "MIA" } },
            { map: { value: "SF" } },
            { map: { value: "KC" } },
            { map: { value: "DAL" } },
            { map: { value: "LAR" } },
            { map: { value: "HOU" } },
            { map: { value: "CHI" } },
            { map: { value: "Option 21" } },
            { map: { value: "Option 22" } },
            { map: { value: "Option 23" } },
            { map: { value: "Option 24" } },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={72.1875}
        summaryAggregationMode="none"
      />
      <Column
        id="6beae"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="G"
        label="G"
        placeholder="Enter value"
        position="center"
        size={48.453125}
        summaryAggregationMode="none"
      />
      <Column
        id="e9438"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="YDS(t)"
        label="YDS(t)"
        placeholder="Enter value"
        position="center"
        size={71.125}
        summaryAggregationMode="none"
      />
      <Column
        id="37293"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="TD(t)"
        label="TD(t)"
        placeholder="Enter value"
        position="center"
        size={71.90625}
        summaryAggregationMode="none"
      />
      <Column
        id="1cd6c"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="1D(t)"
        label="1D(t)"
        placeholder="Enter value"
        position="center"
        size={62.109375}
        summaryAggregationMode="none"
      />
      <Column
        id="05e56"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="40"
        label="40"
        placeholder="Enter value"
        position="center"
        size={51.09375}
        summaryAggregationMode="none"
      />
      <Column
        id="95105"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="PK#"
        label="Pk"
        placeholder="Enter value"
        position="center"
        size={44.578125}
        summaryAggregationMode="none"
      />
      <Column
        id="62082"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RD"
        label="Rd"
        placeholder="Enter value"
        position="center"
        size={46.265625}
        summaryAggregationMode="none"
      />
      <Column
        id="41f3f"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="NCAA"
        label="Ncaa"
        placeholder="Enter value"
        position="center"
        size={56.515625}
        summaryAggregationMode="none"
      />
      <Column
        id="53da5"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="Age"
        placeholder="Enter value"
        position="center"
        size={51.5}
        summaryAggregationMode="none"
      />
      <Column
        id="7a71b"
        alignment="center"
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="HT"
        label="Ht"
        placeholder="Select option"
        position="center"
        size={50.125}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="f718d"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="Wt"
        placeholder="Enter value"
        position="center"
        size={51.921875}
        summaryAggregationMode="none"
      />
      <Column
        id="cf84f"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="ATHL"
        label="Athl"
        placeholder="Enter value"
        position="center"
        size={60.34375}
        summaryAggregationMode="none"
      />
      <Column
        id="93ad9"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="PRD GRADE"
        label="Prd grade"
        placeholder="Enter value"
        position="center"
        size={71.34375}
        summaryAggregationMode="none"
      />
      <Column
        id="d91e6"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="EFF GRADE"
        label="EFF GRD"
        placeholder="Enter value"
        position="center"
        size={78.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="e5243"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="ELU GRADE"
        label="Elu grade"
        placeholder="Enter value"
        position="center"
        size={68.890625}
        summaryAggregationMode="none"
      />
      <Column
        id="a88c0"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="FILM GRADE"
        label="Film grade"
        placeholder="Enter value"
        position="center"
        size={75.609375}
        summaryAggregationMode="none"
      />
      <Column
        id="a80e8"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="OVR GRADE"
        label="Ovr grade"
        placeholder="Enter value"
        position="center"
        size={72.703125}
        summaryAggregationMode="none"
      />
      <Column
        id="25637"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="YpG(t)"
        label="Yp g t"
        placeholder="Enter value"
        position="center"
        size={59.84375}
        summaryAggregationMode="none"
      />
      <Column
        id="00b31"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="OPP(t)"
        label="Opp t"
        placeholder="Enter value"
        position="center"
        size={61.09375}
        summaryAggregationMode="none"
      />
    </Table>
  </View>
</Container>
