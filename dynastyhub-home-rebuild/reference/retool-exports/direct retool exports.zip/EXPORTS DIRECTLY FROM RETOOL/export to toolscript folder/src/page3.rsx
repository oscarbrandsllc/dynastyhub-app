<Screen
  id="page3"
  _customShortcuts={[]}
  _hashParams={[]}
  _searchParams={[]}
  browserTitle=""
  title={null}
  urlSlug=""
  uuid="d780d8ee-c5e6-49f4-9670-19a6391b3e5e"
>
  <Frame
    id="$main3"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    style={{ ordered: [{ canvas: "#551498" }] }}
    type="main"
  >
    <Include src="./tabbedContainer7.rsx" />
    <Include src="./tabbedContainer11.rsx" />
    <TextArea
      id="textArea2"
      label="Dynasty Hub"
      labelPosition="top"
      margin="0"
      maxLines="1"
      minLines="1"
      placeholder="Dynasty Hub DYNASTY HUB"
      style={{
        sharedLabelFontFamily: "Roboto Flex",
        fontWeight: "100",
        text: "#ffffffff",
        background: "tertiary",
        fontSize: "20px",
        fontFamily: "Roboto Flex",
        placeholder: "rgb(255, 255, 255)",
        sharedLabelFontWeight: "100",
        sharedLabelFontSize: "30px",
      }}
    />
    <Text
      id="text23"
      heightType="fixed"
      horizontalAlign="center"
      margin="0"
      style={{
        fontSize: "22px",
        fontWeight: "100",
        fontFamily: "Roboto Flex",
        background: "tertiary",
        color: "rgba(255, 255, 255, 1)",
      }}
      value="Dynasty Hub"
      verticalAlign="center"
    />
    <ListViewBeta
      id="gridView2"
      _primaryKeys="data"
      data={
        '[\n  { \n    "title": "J. Chase", \n    "value": 47.3, \n    "description": "PPR ꜛℂeiling", \n    "desc2": "Top 3G AVG",\n    "x": "/icon:bold/interface-setting-hammer",\n    "color": "#9551fb",\n    "statp": 88.2\n  },\n  { \n    "title": "Saquon Barkley", \n    "value": 2283, \n    "description": "YDS", \n    "desc2": "12% above AVG",\n    "x": "/icon:bold/money-graph-arrow-increase",\n    "color": "#8464C3",\n    "statp": 81.3\n  },\n  { \n    "title": "J. Gibbs", \n    "value": 100, \n    "description":"% 𐘳 Rate", \n    "desc2": "8% below AVG",\n    "x": "/icon:bold/interface-award-trophy",\n    "color": "#00ceb8",\n    "statp": 100\n  },\n  { \n    "title": "JT", \n    "value": 15, \n    "description": "PPR PPG", \n    "desc2": "15% above AVG",\n    "x": "/icon:bold/interface-arrows-vertical-alternate",\n    "color": "#ff2a6d",\n    "statp": 71.4\n  }\n]'
      }
      itemWidth="200px"
      layoutType="grid"
      numColumns="2"
      padding="0"
    >
      <Container
        id="container206"
        footerPadding="4px 12px"
        headerPadding="4px 12px"
        padding="12px"
        showBody={true}
        style={{ ordered: [{ background: "primary" }] }}
      >
        <Header>
          <Text
            id="containerTitle429"
            value="#### {{ item }}"
            verticalAlign="center"
          />
        </Header>
        <View id="0945f" viewKey="View 1">
          <ProgressCircle
            id="progressCircle8"
            horizontalAlign="center"
            style={{
              background: "tertiary",
              completion: "secondary",
              fontSize: "30px",
              fill: "secondary",
              track: "surfaceSecondary",
              text: "secondary",
              fontWeight: "500",
              fontFamily: "Quicksand",
            }}
            value="{{item.statp}}"
          />
          <Statistic
            id="statistic431"
            icon="{{ item.x}}"
            label="{{item.title }}"
            labelCaption="{{ item.desc2 }}"
            positiveTrend="{{ self.value >= 0 }}"
            secondaryCurrency="USD"
            secondaryEnableTrend={true}
            secondaryFormattingStyle="percent"
            secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
            secondaryShowSeparators={true}
            secondarySignDisplay="trendArrows"
            secondaryValue={0.08}
            showSeparators={true}
            style={{
              ordered: [
                { caption: "{{item.color}}" },
                { iconBackground: "{{ item.color }}" },
                { fontSize: "15px" },
                { valueFontSize: "20px" },
              ],
            }}
            suffix="{{ item.description }}"
            value="{{item.value }}"
          />
        </View>
      </Container>
    </ListViewBeta>
  </Frame>
</Screen>
