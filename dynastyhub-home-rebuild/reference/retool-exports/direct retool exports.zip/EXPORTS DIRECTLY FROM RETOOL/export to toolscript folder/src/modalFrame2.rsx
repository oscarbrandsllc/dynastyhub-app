<ModalFrame
  id="modalFrame2"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showHeader={true}
  showHeaderBorder={false}
  showOverlay={true}
  size="fullScreen"
  style={{ ordered: [{ background: "rgba(84, 0, 255, 0.08)" }] }}
>
  <Header>
    <Text
      id="modalTitle2"
      disableMarkdown={true}
      heightType="fixed"
      horizontalAlign="center"
      margin="0"
      style={{
        ordered: [
          { fontSize: "h1Font" },
          { fontWeight: "h1Font" },
          { fontFamily: "h1Font" },
          { color: "#f24673" },
          { background: "rgb(33, 40, 67)" },
        ],
      }}
      value=" KEY"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton2"
      ariaLabel="Close"
      horizontalAlign="center"
      iconBefore="bold/interface-delete-1"
      style={{
        ordered: [
          { label: "#f24673" },
          { background: "#212843" },
          { border: "#f24673" },
          { fontSize: "22px" },
          { fontWeight: "800" },
          { fontFamily: "Audiowide" },
        ],
      }}
    >
      <Event
        event="click"
        method="setHidden"
        params={{ ordered: [{ hidden: true }] }}
        pluginId="modalFrame2"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <Table
      id="table8"
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ query25.data }}"
      defaultSelectedRow={{ mode: "none", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="5704e"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showFooter={true}
      showHeader={true}
      style={{
        headerFontFamily: "ORBITRON",
        fontWeight: "700",
        rowSeparator: "rgba(60, 66, 90, 0)",
        alternateRowBackground: "#141a32",
        background: "#212843",
        fontSize: "12px",
        fontFamily: "Quicksand",
        headerFontWeight: "600",
        headerText: "rgba(109, 0, 255, 1)",
        headerBackground: "#2c334f",
        headerFontSize: "18px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="5704e"
        alignment="center"
        backgroundColor="rgba(118, 5, 245, 0.1)"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="Abbreviation"
        label="ABBRV"
        placeholder="Enter value"
        position="center"
        size={268}
        summaryAggregationMode="none"
      />
      <Column
        id="52ec4"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="Meaning"
        label="MEANING"
        placeholder="Enter value"
        position="center"
        size={411}
        summaryAggregationMode="none"
      />
      <Column
        id="e3183"
        alignment="center"
        backgroundColor="rgba(118, 5, 245, 0.1)"
        format="string"
        groupAggregationMode="none"
        key="Abbreviation_1"
        label="ABBRV. "
        placeholder="Enter value"
        position="center"
        size={296}
        summaryAggregationMode="none"
      />
      <Column
        id="4db67"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="Meaning_1"
        label="MEANING"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
    </Table>
  </Body>
</ModalFrame>
