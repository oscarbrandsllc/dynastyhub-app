<Screen
  id="Home2"
  _customShortcuts={[]}
  _hashParams={[]}
  _searchParams={[]}
  browserTitle=""
  title="Home"
  urlSlug="Home2"
  uuid="50fc7875-16c7-46c7-b27b-6cd7e034025d"
>
  <connectResource id="query12" _componentId="table1" />
  <connectResource id="query13" _componentId="select1" />
  <GoogleSheetsQuery
    id="query14"
    notificationDuration={4.5}
    resourceDisplayName="NFL Stats CSV"
    resourceName="c8688b0e-1e30-4681-97eb-40ab13d78a08"
    sheetName="NFLStatsCSV"
    showSuccessToaster={false}
    spreadsheetId="18W7X8_mAjXmCNceTt3m0lauiLLAUQSxRh2M99R3MS0s"
  />
  <Frame
    id="$main8"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    style={{ ordered: [] }}
    type="main"
  >
    <Image
      id="image3"
      fit="contain"
      heightType="fixed"
      horizontalAlign="center"
      margin="0"
      retoolStorageFileId="08fd2d1b-af2e-4044-b68a-82e5289f5950"
      src="https://picsum.photos/id/1025/800/600"
      srcType="retoolStorageFileId"
    />
    <Navigation
      id="navigation10"
      appTargetByIndex=""
      captionByIndex=""
      data=""
      disabledByIndex=""
      hiddenByIndex=""
      highlightByIndex=""
      horizontalAlignment="center"
      iconByIndex=""
      iconPositionByIndex=""
      itemMode="static"
      itemTypeByIndex=""
      keyByIndex=""
      labels=""
      parentKeyByIndex=""
      retoolFileObject={{ ordered: [] }}
      screenTargetByIndex=""
      screenTargetIdByIndex=""
      style={{
        ordered: [
          { color: "#00ffaf" },
          { fontSize: "h6Font" },
          { fontWeight: "h6Font" },
          { fontFamily: "h6Font" },
        ],
      }}
      tooltipByIndex=""
    >
      <Option
        id="a2fe3"
        disabled={false}
        hidden={false}
        icon="bold/interface-home-2"
        iconPosition="left"
        itemType="custom"
        label="HOME"
        screenTargetId="Home"
      >
        <Event
          event="click"
          method="setCurrentView"
          params={{ ordered: [{ viewKey: " " }] }}
          pluginId="tabbedContainer5"
          type="widget"
          waitMs="0"
          waitType="debounce"
        />
      </Option>
      <Option
        id="be95e"
        icon="bold/money-graph"
        iconPosition="left"
        itemType="page"
        key="12813ad1-3eb4-4879-9356-980a8f4cafcd"
        label="CHTS"
        screenTargetId="page2"
      />
      <Option
        id="7b749"
        iconPosition="left"
        itemType="page"
        label="TBD"
        screenTargetId="page3"
      />
      <Option
        id="2fcba"
        iconPosition="left"
        itemType="page"
        key="52793"
        label="OI"
        screenTargetId="Rookies"
      />
      <Option
        id="373f4"
        disabled={false}
        hidden={false}
        iconPosition="left"
        itemType="page"
        label="IDK"
        screenTargetId="page5"
      />
      <Option
        id="a5768"
        caption="flex"
        disabled={false}
        hidden={false}
        iconPosition="left"
        itemType="page"
        label="YB"
        screenTargetId="page6"
      />
      <Event
        event="click"
        method="openPage"
        params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Navigation>
    <Text
      id="text4"
      disableMarkdown={true}
      horizontalAlign="center"
      imageWidth="fill"
      margin="0"
      style={{
        ordered: [
          { fontSize: "h1Font" },
          { fontWeight: "h1Font" },
          { fontFamily: "h1Font" },
          { color: "rgba(252, 0, 240, 1)" },
        ],
      }}
      value=" DYNASTY  HUB"
      verticalAlign="center"
    />
    <Container
      id="tabbedContainer5"
      _gap="0px"
      currentViewKey="{{ self.viewKeys[0] }}"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      heightType="fixed"
      margin="0"
      padding="0"
      showBody={true}
      showHeader={true}
      style={{
        ordered: [
          { background: "rgba(15, 15, 15, 0.3)" },
          { headerBackground: "rgba(30, 30, 30, 0.32)" },
          { borderRadius: "12px" },
          { border: "rgba(192, 192, 192, 0)" },
        ],
      }}
    >
      <Header>
        <Tabs
          id="tabs5"
          itemMode="static"
          navigateContainer={true}
          style={{
            ordered: [
              { fontSize: "h6Font" },
              { fontWeight: "h6Font" },
              { fontFamily: "h6Font" },
              { selectedBackground: "rgba(164, 164, 164, 1)" },
              { pillBorderRadius: "18px" },
            ],
          }}
          targetContainerId="tabbedContainer5"
          value="{{ self.values[0] }}"
        >
          <Option id="d0134" label="ALL" value="Tab 1" />
          <Option
            id="c1fb3"
            icon="bold/travel-map-location-target-1"
            iconPosition="left"
            value="QB"
          />
          <Option id="9c928" value="Tab 3" />
        </Tabs>
      </Header>
      <View
        id="9fb35"
        icon="bold/interface-user-multiple"
        iconPosition="left"
        viewKey="ALL"
      >
        <Table
          id="table6"
          clearChangesetOnSave={true}
          data="{{ query14.data }}"
          defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
          dynamicColumnProperties={{ formatByIndex: "auto" }}
          emptyMessage="No rows found"
          enableSaveActions={true}
          linkedFilterId=""
          primaryKeyColumnId="67fa7"
          rowBackgroundColor=""
          rowHeight="small"
          showBorder={true}
          showFooter={true}
          showHeader={true}
          style={{
            headerBackground: "tertiary",
            alternateRowBackground: "rgb(13, 16, 20)",
            background: "rgb(15, 15, 15)",
            headerFontSize: "h6Font",
            headerFontWeight: "h6Font",
            headerFontFamily: "h6Font",
          }}
        >
          <Column
            id="67fa7"
            alignment="left"
            backgroundColor="rgba(40, 49, 65, 0.35)"
            editable="false"
            format="string"
            groupAggregationMode="none"
            hidden="false"
            key="Player"
            label="Player"
            placeholder="Enter value"
            position="left"
            size={140.640625}
            summaryAggregationMode="none"
            textColor="rgba(255, 255, 255, 1)"
          />
          <Column
            id="45cb7"
            alignment="center"
            format="string"
            groupAggregationMode="none"
            key="TM"
            label="Tm"
            placeholder="Enter value"
            position="center"
            size={66}
            summaryAggregationMode="none"
          />
          <Column
            id="f83ae"
            alignment="center"
            editable="false"
            format="tag"
            formatOptions={{ automaticColors: true }}
            groupAggregationMode="none"
            key="POS"
            label="Pos"
            optionList={{
              manualData: [
                {
                  ordered: [
                    { value: "QB" },
                    { color: "#ff2a6d" },
                    { textColor: "rgba(18, 18, 18, 1)" },
                    { icon: "" },
                  ],
                },
                { ordered: [{ value: "WR" }, { color: "#58a7ff" }] },
                { ordered: [{ value: "RB" }] },
                { ordered: [{ value: "TE" }] },
              ],
              mode: "manual",
            }}
            placeholder="Select option"
            position="center"
            size={60}
            summaryAggregationMode="none"
            valueOverride="{{ _.startCase(item) }}"
          />
          <Column
            id="75f99"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="DRFT
RND"
            label="Drft rnd"
            placeholder="Enter value"
            position="center"
            size={72.765625}
            summaryAggregationMode="none"
          />
          <Column
            id="0c1a6"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="EXP"
            label="Exp"
            placeholder="Enter value"
            position="center"
            size={54.90625}
            summaryAggregationMode="none"
          />
          <Column
            id="4909f"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="AGE"
            label="Age"
            placeholder="Enter value"
            position="center"
            size={58.78125}
            summaryAggregationMode="none"
          />
          <Column
            id="3f013"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="PPR"
            label="PPR(t)"
            placeholder="Enter value"
            position="center"
            size={70}
            summaryAggregationMode="none"
          />
          <Column
            id="f04b9"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="PPG"
            label="Ppg"
            placeholder="Enter value"
            position="center"
            size={68}
            summaryAggregationMode="none"
          />
          <Column
            id="4a1f4"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="VOBA"
            label="Voba"
            placeholder="Enter value"
            position="center"
            size={54}
            summaryAggregationMode="none"
          />
          <Column
            id="2560e"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="VOBApG"
            label="Vob ap g"
            placeholder="Enter value"
            position="center"
            size={53}
            summaryAggregationMode="none"
          />
          <Column
            id="ee081"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="GM"
            label="Gm"
            placeholder="Enter value"
            position="center"
            size={63}
            summaryAggregationMode="none"
          />
          <Column
            id="0e7d5"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="SNPS"
            label="Snps"
            placeholder="Enter value"
            position="center"
            size={82}
            summaryAggregationMode="none"
          />
          <Column
            id="95a7e"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="Ttl
Yds"
            label="Ttl yds"
            placeholder="Enter value"
            position="center"
            size={68}
            summaryAggregationMode="none"
          />
          <Column
            id="ab28b"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="TTL-TD"
            label="Ttl td"
            placeholder="Enter value"
            position="center"
            size={87}
            summaryAggregationMode="none"
          />
          <Column
            id="093d3"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="P–ATT"
            label="P att"
            placeholder="Enter value"
            position="center"
            size={61}
            summaryAggregationMode="none"
          />
          <Column
            id="28c0f"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="P–YDS"
            label="P yds"
            placeholder="Enter value"
            position="center"
            size={69}
            summaryAggregationMode="none"
          />
          <Column
            id="9b199"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="P-TD"
            label="P td"
            placeholder="Enter value"
            position="center"
            size={67}
            summaryAggregationMode="none"
          />
          <Column
            id="43739"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="YpATT"
            label="Yp att"
            placeholder="Enter value"
            position="center"
            size={78}
            summaryAggregationMode="none"
          />
          <Column
            id="6a39b"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="CAR"
            label="Car"
            placeholder="Enter value"
            position="center"
            size={75}
            summaryAggregationMode="none"
          />
          <Column
            id="36214"
            alignment="right"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="R-YDS"
            label="R yds"
            placeholder="Enter value"
            position="center"
            size={50}
            summaryAggregationMode="none"
          />
          <Column
            id="13174"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="R-TD"
            label="R td"
            placeholder="Enter value"
            position="center"
            size={58}
            summaryAggregationMode="none"
          />
          <Column
            id="d130f"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="YpC"
            label="Yp c"
            placeholder="Enter value"
            position="center"
            size={60}
            summaryAggregationMode="none"
          />
          <Column
            id="e837a"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="RR"
            label="Rr"
            placeholder="Enter value"
            position="center"
            size={54}
            summaryAggregationMode="none"
          />
          <Column
            id="5c30d"
            alignment="right"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="TGT"
            label="Tgt"
            placeholder="Enter value"
            position="center"
            size={49}
            summaryAggregationMode="none"
          />
          <Column
            id="a124c"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="REC-YDS"
            label="Rec yds"
            placeholder="Enter value"
            position="center"
            size={38}
            summaryAggregationMode="none"
          />
          <Column
            id="62564"
            alignment="center"
            editableOptions={{ showStepper: true }}
            format="decimal"
            formatOptions={{ showSeparators: true, notation: "standard" }}
            groupAggregationMode="sum"
            key="REC-TD"
            label="Rec td"
            placeholder="Enter value"
            position="center"
            size={72}
            summaryAggregationMode="none"
          />
        </Table>
      </View>
      <View
        id="87617"
        disabled={false}
        hidden={false}
        icon="bold/travel-map-location-target-1"
        iconPosition="left"
        viewKey="QB"
      />
      <View
        id="9770c"
        disabled={false}
        hidden={false}
        icon="bold/travel-transportation-bus"
        iconPosition="left"
        viewKey="RB"
      />
      <View
        id="da965"
        disabled={false}
        hidden={false}
        icon="bold/interface-arrows-all-direction"
        iconPosition="left"
        viewKey="WR"
      />
      <View
        id="91f98"
        disabled={false}
        hidden={false}
        icon="bold/interface-security-shield-4"
        iconPosition="left"
        viewKey="TE"
      />
      <View
        id="325df"
        disabled={false}
        hidden={false}
        icon="bold/interface-page-controller-settings"
        iconPosition="left"
        viewKey="FLX"
      />
    </Container>
  </Frame>
</Screen>
