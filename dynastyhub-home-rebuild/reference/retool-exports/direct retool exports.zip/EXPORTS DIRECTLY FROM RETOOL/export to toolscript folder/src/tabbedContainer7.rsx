<Container
  id="tabbedContainer7"
  currentViewKey="{{ self.viewKeys[0] }}"
  footerPadding="0"
  headerPadding="0"
  heightType="fixed"
  margin="9px 9px 9px 35px"
  padding="0px 0px 0px 0px"
  showBody={true}
  showFooter={true}
  showFooterBorder={false}
  showHeader={true}
  showHeaderBorder={false}
  style={{
    background: "tertiary",
    headerBackground: "primary",
    footerBackground: "primary",
  }}
  styleContext={{ map: { primary: "primary" } }}
>
  <Header>
    <Text
      id="containerTitle12"
      horizontalAlign="center"
      margin="0"
      style={{
        background: "primary",
        fontSize: "12px",
        fontWeight: "400",
        fontFamily: "Quicksand",
      }}
      value={
        '<span style=\n"font-size: 1.15em;\ncolor: #efefef;">  2025｜TOP ROOKIE PROSPECTS</span> <br>[Production & Efficiency Percentiles]'
      }
      verticalAlign="center"
    />
    <Tabs
      id="tabs8"
      alignment="justify"
      heightType="fixed"
      itemMode="static"
      navigateContainer={true}
      style={{
        selectedBackground: "#5700ff",
        pillBorderRadius: "100px",
        fontSize: "11px",
        fontWeight: "300",
        fontFamily: "Quicksand",
        hoverBackground: "tertiary",
      }}
      targetContainerId="tabbedContainer7"
      value="{{ self.values[0] }}"
    >
      <Option id="501f8" value="Tab 1" />
      <Option id="c0dc6" value="Tab 2" />
      <Option id="08e21" value="Tab 3" />
    </Tabs>
  </Header>
  <View id="aaa75" label="Jeanty" viewKey="View 1">
    <Table
      id="table10"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">21.3</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'8\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">211</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #adb5ee;\\">BOISE ST</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1.1em; font-weight: 700; color: #6affd0;\\">96</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: '{{"/icon:bold/travel-transportation-bus"}}',
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={59.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="b555e"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        hidden="false"
        key="CFB"
        label="CFB"
        placeholder="Enter value"
        position="center"
        size={75.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={63.40625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={43.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={54.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.40625}
        summaryAggregationMode="none"
      />
    </Table>
    <Container
      id="container24"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle27"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic50"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
          }}
          suffix="%"
          value=".951"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart3"
      chartType="plotlyJson"
      margin="0px 12px 7px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [94, 94, 98, 87, 98, 87, 98, 94],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A", "YPC"],\n    "fill": "toself",\n    "name": "Ashton Jeanty",\n    "mode": "lines+markers",\n    "line": {\n      "color": "#6300ff",\n      "width": 3\n    },\n    "fillcolor": "rgba(99, 0, 255, 0.32)",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [69, 69, 75, 64, 74, 67, 79],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A"],\n    "mode": "text",\n    "text": ["94th%", "94th%", "98th%", "87th%", "98th%", "87th%", "98th%", "90th%"],\n    "textposition": "middle center",\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "color": "#d275e4",\n      "gridcolor": "grey",\n      "tickvals": [20, 40, 60, 80, 100],\n      "showline": false,\n      "showticklabels": false\n    },\n    "angularaxis": {\n      "gridcolor": "#394369",\n      "linecolor": "#48537a",\n      "tickfont": {\n        "color": "white",\n        "size": 13,\n        "family": "Quicksand"\n      },\n      "direction": "counterclockwise",\n      "rotation": -12.857,\n      "color": "white"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "plot_bgcolor": "#141a32",\n  "shapes": [\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.2,\n      "y0": 0.2,\n      "x1": 0.8,\n      "y1": 0.8,\n      "fillcolor": "rgba(255, 255, 255, 0.04)",\n      "line": { "width": 0 }\n    },\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.3,\n      "y0": 0.3,\n      "x1": 0.7,\n      "y1": 0.7,\n      "fillcolor": "rgba(255, 255, 255, 0.03)",\n      "line": { "width": 0 }\n    }\n  ],\n  "showlegend": false,\n  "title": {\n    "text": "Ashton Jeanty",\n    "font": {\n      "color": "#6300ff",\n      "weight": 300,\n      "size": 25,\n      "family": "Quicksand"\n    },\n    "y": 0.98,\n    "x": 0.5,\n    "xanchor": "center",\n    "yanchor": "top"\n  },\n  "font": {\n    "color": "#afffff",\n    "size": 11,\n    "family": "Quicksand"\n  },\n  "margin": {\n    "l": 45,\n    "r": 45,\n    "t": 60,\n    "b": 30\n  }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container14"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle16"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic41"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
          }}
          suffix="%"
          value="0.916"
        />
      </View>
    </Container>
    <Container
      id="container11"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle13"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic36"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
          }}
          suffix="%"
          value="0.982"
        />
      </View>
    </Container>
    <Container
      id="container16"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle18"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic43"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="RAS / ATHL SCORE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
          }}
          suffix="%"
          value="0.933"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart2"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "RAS"],\n    "y": [92, 98, 86, 94],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "RAS"],\n    "ticktext": ["PRD", "EFF", "ELU", "RAS"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View id="64058" label="McMillan" viewKey="View 2">
    <Table
      id="table27"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">21.3</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'8\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">211</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #adb5ee;\\">BOISE ST</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1.1em; font-weight: 700; color: #6affd0;\\">96</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: '{{"/icon:bold/travel-transportation-bus"}}',
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={59.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="b555e"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        hidden="false"
        key="CFB"
        label="CFB"
        placeholder="Enter value"
        position="center"
        size={75.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={63.40625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={43.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={54.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.40625}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart30"
      chartType="plotlyJson"
      margin="0px 12px 7px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [94, 94, 98, 87, 98, 87, 98, 94],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A", "YPC"],\n    "fill": "toself",\n    "name": "Ashton Jeanty",\n    "mode": "lines+markers",\n    "line": {\n      "color": "#6300ff",\n      "width": 3\n    },\n    "fillcolor": "rgba(99, 0, 255, 0.32)",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [69, 69, 75, 64, 74, 67, 79],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A"],\n    "mode": "text",\n    "text": ["94th%", "94th%", "98th%", "87th%", "98th%", "87th%", "98th%", "90th%"],\n    "textposition": "middle center",\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "color": "#d275e4",\n      "gridcolor": "grey",\n      "tickvals": [20, 40, 60, 80, 100],\n      "showline": false,\n      "showticklabels": false\n    },\n    "angularaxis": {\n      "gridcolor": "#394369",\n      "linecolor": "#48537a",\n      "tickfont": {\n        "color": "white",\n        "size": 13,\n        "family": "Quicksand"\n      },\n      "direction": "counterclockwise",\n      "rotation": -12.857,\n      "color": "white"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "plot_bgcolor": "#141a32",\n  "shapes": [\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.2,\n      "y0": 0.2,\n      "x1": 0.8,\n      "y1": 0.8,\n      "fillcolor": "rgba(255, 255, 255, 0.04)",\n      "line": { "width": 0 }\n    },\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.3,\n      "y0": 0.3,\n      "x1": 0.7,\n      "y1": 0.7,\n      "fillcolor": "rgba(255, 255, 255, 0.03)",\n      "line": { "width": 0 }\n    }\n  ],\n  "showlegend": false,\n  "title": {\n    "text": "Ashton Jeanty",\n    "font": {\n      "color": "#6300ff",\n      "weight": 300,\n      "size": 25,\n      "family": "Quicksand"\n    },\n    "y": 0.98,\n    "x": 0.5,\n    "xanchor": "center",\n    "yanchor": "top"\n  },\n  "font": {\n    "color": "#afffff",\n    "size": 11,\n    "family": "Quicksand"\n  },\n  "margin": {\n    "l": 45,\n    "r": 45,\n    "t": 60,\n    "b": 30\n  }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container67"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle71"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic93"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
          }}
          suffix="%"
          value=".951"
        />
      </View>
    </Container>
    <Container
      id="container68"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle72"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic94"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
          }}
          suffix="%"
          value="0.916"
        />
      </View>
    </Container>
    <Container
      id="container69"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle73"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic95"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
          }}
          suffix="%"
          value="0.982"
        />
      </View>
    </Container>
    <Container
      id="container70"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle74"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic96"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="RAS / ATHL SCORE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
          }}
          suffix="%"
          value="0.933"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart31"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "RAS"],\n    "y": [92, 98, 86, 94],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "RAS"],\n    "ticktext": ["PRD", "EFF", "ELU", "RAS"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View id="eff2c" viewKey="Hampton">
    <Table
      id="table28"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">21.3</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'8\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">211</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #adb5ee;\\">BOISE ST</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1.1em; font-weight: 700; color: #6affd0;\\">96</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: '{{"/icon:bold/travel-transportation-bus"}}',
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={59.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="b555e"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        hidden="false"
        key="CFB"
        label="CFB"
        placeholder="Enter value"
        position="center"
        size={75.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={63.40625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={43.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={54.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.40625}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart32"
      chartType="plotlyJson"
      margin="0px 12px 7px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [94, 94, 98, 87, 98, 87, 98, 94],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A", "YPC"],\n    "fill": "toself",\n    "name": "Ashton Jeanty",\n    "mode": "lines+markers",\n    "line": {\n      "color": "#6300ff",\n      "width": 3\n    },\n    "fillcolor": "rgba(99, 0, 255, 0.32)",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [69, 69, 75, 64, 74, 67, 79],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A"],\n    "mode": "text",\n    "text": ["94th%", "94th%", "98th%", "87th%", "98th%", "87th%", "98th%", "90th%"],\n    "textposition": "middle center",\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "color": "#d275e4",\n      "gridcolor": "grey",\n      "tickvals": [20, 40, 60, 80, 100],\n      "showline": false,\n      "showticklabels": false\n    },\n    "angularaxis": {\n      "gridcolor": "#394369",\n      "linecolor": "#48537a",\n      "tickfont": {\n        "color": "white",\n        "size": 13,\n        "family": "Quicksand"\n      },\n      "direction": "counterclockwise",\n      "rotation": -12.857,\n      "color": "white"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "plot_bgcolor": "#141a32",\n  "shapes": [\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.2,\n      "y0": 0.2,\n      "x1": 0.8,\n      "y1": 0.8,\n      "fillcolor": "rgba(255, 255, 255, 0.04)",\n      "line": { "width": 0 }\n    },\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.3,\n      "y0": 0.3,\n      "x1": 0.7,\n      "y1": 0.7,\n      "fillcolor": "rgba(255, 255, 255, 0.03)",\n      "line": { "width": 0 }\n    }\n  ],\n  "showlegend": false,\n  "title": {\n    "text": "Ashton Jeanty",\n    "font": {\n      "color": "#6300ff",\n      "weight": 300,\n      "size": 25,\n      "family": "Quicksand"\n    },\n    "y": 0.98,\n    "x": 0.5,\n    "xanchor": "center",\n    "yanchor": "top"\n  },\n  "font": {\n    "color": "#afffff",\n    "size": 11,\n    "family": "Quicksand"\n  },\n  "margin": {\n    "l": 45,\n    "r": 45,\n    "t": 60,\n    "b": 30\n  }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container71"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle75"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic97"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
          }}
          suffix="%"
          value=".951"
        />
      </View>
    </Container>
    <Container
      id="container72"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle76"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic98"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
          }}
          suffix="%"
          value="0.916"
        />
      </View>
    </Container>
    <Container
      id="container73"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle77"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic99"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
          }}
          suffix="%"
          value="0.982"
        />
      </View>
    </Container>
    <Container
      id="container74"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle78"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic100"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="RAS / ATHL SCORE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
          }}
          suffix="%"
          value="0.933"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart33"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "RAS"],\n    "y": [92, 98, 86, 94],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "RAS"],\n    "ticktext": ["PRD", "EFF", "ELU", "RAS"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="64854"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="T.Hunter"
    viewKey="View 5"
  >
    <Table
      id="table29"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">21.3</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'8\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">211</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #adb5ee;\\">BOISE ST</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1.1em; font-weight: 700; color: #6affd0;\\">96</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: '{{"/icon:bold/travel-transportation-bus"}}',
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={59.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="b555e"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        hidden="false"
        key="CFB"
        label="CFB"
        placeholder="Enter value"
        position="center"
        size={75.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={63.40625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={43.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={54.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.40625}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart34"
      chartType="plotlyJson"
      margin="0px 12px 7px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [94, 94, 98, 87, 98, 87, 98, 94],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A", "YPC"],\n    "fill": "toself",\n    "name": "Ashton Jeanty",\n    "mode": "lines+markers",\n    "line": {\n      "color": "#6300ff",\n      "width": 3\n    },\n    "fillcolor": "rgba(99, 0, 255, 0.32)",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [69, 69, 75, 64, 74, 67, 79],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A"],\n    "mode": "text",\n    "text": ["94th%", "94th%", "98th%", "87th%", "98th%", "87th%", "98th%", "90th%"],\n    "textposition": "middle center",\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "color": "#d275e4",\n      "gridcolor": "grey",\n      "tickvals": [20, 40, 60, 80, 100],\n      "showline": false,\n      "showticklabels": false\n    },\n    "angularaxis": {\n      "gridcolor": "#394369",\n      "linecolor": "#48537a",\n      "tickfont": {\n        "color": "white",\n        "size": 13,\n        "family": "Quicksand"\n      },\n      "direction": "counterclockwise",\n      "rotation": -12.857,\n      "color": "white"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "plot_bgcolor": "#141a32",\n  "shapes": [\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.2,\n      "y0": 0.2,\n      "x1": 0.8,\n      "y1": 0.8,\n      "fillcolor": "rgba(255, 255, 255, 0.04)",\n      "line": { "width": 0 }\n    },\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.3,\n      "y0": 0.3,\n      "x1": 0.7,\n      "y1": 0.7,\n      "fillcolor": "rgba(255, 255, 255, 0.03)",\n      "line": { "width": 0 }\n    }\n  ],\n  "showlegend": false,\n  "title": {\n    "text": "Ashton Jeanty",\n    "font": {\n      "color": "#6300ff",\n      "weight": 300,\n      "size": 25,\n      "family": "Quicksand"\n    },\n    "y": 0.98,\n    "x": 0.5,\n    "xanchor": "center",\n    "yanchor": "top"\n  },\n  "font": {\n    "color": "#afffff",\n    "size": 11,\n    "family": "Quicksand"\n  },\n  "margin": {\n    "l": 45,\n    "r": 45,\n    "t": 60,\n    "b": 30\n  }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container75"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle79"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic101"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
          }}
          suffix="%"
          value=".951"
        />
      </View>
    </Container>
    <Container
      id="container76"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle80"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic102"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
          }}
          suffix="%"
          value="0.916"
        />
      </View>
    </Container>
    <Container
      id="container77"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle81"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic103"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
          }}
          suffix="%"
          value="0.982"
        />
      </View>
    </Container>
    <Container
      id="container78"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle82"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic104"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="RAS / ATHL SCORE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
          }}
          suffix="%"
          value="0.933"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart35"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "RAS"],\n    "y": [92, 98, 86, 94],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "RAS"],\n    "ticktext": ["PRD", "EFF", "ELU", "RAS"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="0ac25"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Skattebo"
    viewKey="View 4"
  >
    <Table
      id="table30"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">21.3</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'8\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">211</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #adb5ee;\\">BOISE ST</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1.1em; font-weight: 700; color: #6affd0;\\">96</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: '{{"/icon:bold/travel-transportation-bus"}}',
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={59.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="b555e"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        hidden="false"
        key="CFB"
        label="CFB"
        placeholder="Enter value"
        position="center"
        size={75.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={63.40625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={43.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={54.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.40625}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart36"
      chartType="plotlyJson"
      margin="0px 12px 7px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [94, 94, 98, 87, 98, 87, 98, 94],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A", "YPC"],\n    "fill": "toself",\n    "name": "Ashton Jeanty",\n    "mode": "lines+markers",\n    "line": {\n      "color": "#6300ff",\n      "width": 3\n    },\n    "fillcolor": "rgba(99, 0, 255, 0.32)",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [69, 69, 75, 64, 74, 67, 79],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A"],\n    "mode": "text",\n    "text": ["94th%", "94th%", "98th%", "87th%", "98th%", "87th%", "98th%", "90th%"],\n    "textposition": "middle center",\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "color": "#d275e4",\n      "gridcolor": "grey",\n      "tickvals": [20, 40, 60, 80, 100],\n      "showline": false,\n      "showticklabels": false\n    },\n    "angularaxis": {\n      "gridcolor": "#394369",\n      "linecolor": "#48537a",\n      "tickfont": {\n        "color": "white",\n        "size": 13,\n        "family": "Quicksand"\n      },\n      "direction": "counterclockwise",\n      "rotation": -12.857,\n      "color": "white"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "plot_bgcolor": "#141a32",\n  "shapes": [\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.2,\n      "y0": 0.2,\n      "x1": 0.8,\n      "y1": 0.8,\n      "fillcolor": "rgba(255, 255, 255, 0.04)",\n      "line": { "width": 0 }\n    },\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.3,\n      "y0": 0.3,\n      "x1": 0.7,\n      "y1": 0.7,\n      "fillcolor": "rgba(255, 255, 255, 0.03)",\n      "line": { "width": 0 }\n    }\n  ],\n  "showlegend": false,\n  "title": {\n    "text": "Ashton Jeanty",\n    "font": {\n      "color": "#6300ff",\n      "weight": 300,\n      "size": 25,\n      "family": "Quicksand"\n    },\n    "y": 0.98,\n    "x": 0.5,\n    "xanchor": "center",\n    "yanchor": "top"\n  },\n  "font": {\n    "color": "#afffff",\n    "size": 11,\n    "family": "Quicksand"\n  },\n  "margin": {\n    "l": 45,\n    "r": 45,\n    "t": 60,\n    "b": 30\n  }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container79"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle83"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic105"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
          }}
          suffix="%"
          value=".951"
        />
      </View>
    </Container>
    <Container
      id="container80"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle84"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic106"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
          }}
          suffix="%"
          value="0.916"
        />
      </View>
    </Container>
    <Container
      id="container81"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle85"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic107"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
          }}
          suffix="%"
          value="0.982"
        />
      </View>
    </Container>
    <Container
      id="container82"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle86"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic108"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="RAS / ATHL SCORE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
          }}
          suffix="%"
          value="0.933"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart37"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "RAS"],\n    "y": [92, 98, 86, 94],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "RAS"],\n    "ticktext": ["PRD", "EFF", "ELU", "RAS"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="97d42"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Warren"
    viewKey="View 6"
  >
    <Table
      id="table31"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">21.3</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'8\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">211</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #adb5ee;\\">BOISE ST</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1.1em; font-weight: 700; color: #6affd0;\\">96</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: '{{"/icon:bold/travel-transportation-bus"}}',
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={59.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="b555e"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        hidden="false"
        key="CFB"
        label="CFB"
        placeholder="Enter value"
        position="center"
        size={75.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={63.40625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={43.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={54.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.40625}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart38"
      chartType="plotlyJson"
      margin="0px 12px 7px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [94, 94, 98, 87, 98, 87, 98, 94],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A", "YPC"],\n    "fill": "toself",\n    "name": "Ashton Jeanty",\n    "mode": "lines+markers",\n    "line": {\n      "color": "#6300ff",\n      "width": 3\n    },\n    "fillcolor": "rgba(99, 0, 255, 0.32)",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [69, 69, 75, 64, 74, 67, 79],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A"],\n    "mode": "text",\n    "text": ["94th%", "94th%", "98th%", "87th%", "98th%", "87th%", "98th%", "90th%"],\n    "textposition": "middle center",\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "color": "#d275e4",\n      "gridcolor": "grey",\n      "tickvals": [20, 40, 60, 80, 100],\n      "showline": false,\n      "showticklabels": false\n    },\n    "angularaxis": {\n      "gridcolor": "#394369",\n      "linecolor": "#48537a",\n      "tickfont": {\n        "color": "white",\n        "size": 13,\n        "family": "Quicksand"\n      },\n      "direction": "counterclockwise",\n      "rotation": -12.857,\n      "color": "white"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "plot_bgcolor": "#141a32",\n  "shapes": [\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.2,\n      "y0": 0.2,\n      "x1": 0.8,\n      "y1": 0.8,\n      "fillcolor": "rgba(255, 255, 255, 0.04)",\n      "line": { "width": 0 }\n    },\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.3,\n      "y0": 0.3,\n      "x1": 0.7,\n      "y1": 0.7,\n      "fillcolor": "rgba(255, 255, 255, 0.03)",\n      "line": { "width": 0 }\n    }\n  ],\n  "showlegend": false,\n  "title": {\n    "text": "Ashton Jeanty",\n    "font": {\n      "color": "#6300ff",\n      "weight": 300,\n      "size": 25,\n      "family": "Quicksand"\n    },\n    "y": 0.98,\n    "x": 0.5,\n    "xanchor": "center",\n    "yanchor": "top"\n  },\n  "font": {\n    "color": "#afffff",\n    "size": 11,\n    "family": "Quicksand"\n  },\n  "margin": {\n    "l": 45,\n    "r": 45,\n    "t": 60,\n    "b": 30\n  }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container83"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle87"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic109"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
          }}
          suffix="%"
          value=".951"
        />
      </View>
    </Container>
    <Container
      id="container84"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle88"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic110"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
          }}
          suffix="%"
          value="0.916"
        />
      </View>
    </Container>
    <Container
      id="container85"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle89"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic111"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
          }}
          suffix="%"
          value="0.982"
        />
      </View>
    </Container>
    <Container
      id="container86"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle90"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic112"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="RAS / ATHL SCORE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
          }}
          suffix="%"
          value="0.933"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart39"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "RAS"],\n    "y": [92, 98, 86, 94],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "RAS"],\n    "ticktext": ["PRD", "EFF", "ELU", "RAS"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="a8b36"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Henderson"
    viewKey="View 7"
  >
    <Table
      id="table32"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">21.3</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'8\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">211</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #adb5ee;\\">BOISE ST</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1.1em; font-weight: 700; color: #6affd0;\\">96</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: '{{"/icon:bold/travel-transportation-bus"}}',
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={59.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="b555e"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        hidden="false"
        key="CFB"
        label="CFB"
        placeholder="Enter value"
        position="center"
        size={75.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={63.40625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={43.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={54.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.40625}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart40"
      chartType="plotlyJson"
      margin="0px 12px 7px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [94, 94, 98, 87, 98, 87, 98, 94],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A", "YPC"],\n    "fill": "toself",\n    "name": "Ashton Jeanty",\n    "mode": "lines+markers",\n    "line": {\n      "color": "#6300ff",\n      "width": 3\n    },\n    "fillcolor": "rgba(99, 0, 255, 0.32)",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [69, 69, 75, 64, 74, 67, 79],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A"],\n    "mode": "text",\n    "text": ["94th%", "94th%", "98th%", "87th%", "98th%", "87th%", "98th%", "90th%"],\n    "textposition": "middle center",\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "color": "#d275e4",\n      "gridcolor": "grey",\n      "tickvals": [20, 40, 60, 80, 100],\n      "showline": false,\n      "showticklabels": false\n    },\n    "angularaxis": {\n      "gridcolor": "#394369",\n      "linecolor": "#48537a",\n      "tickfont": {\n        "color": "white",\n        "size": 13,\n        "family": "Quicksand"\n      },\n      "direction": "counterclockwise",\n      "rotation": -12.857,\n      "color": "white"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "plot_bgcolor": "#141a32",\n  "shapes": [\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.2,\n      "y0": 0.2,\n      "x1": 0.8,\n      "y1": 0.8,\n      "fillcolor": "rgba(255, 255, 255, 0.04)",\n      "line": { "width": 0 }\n    },\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.3,\n      "y0": 0.3,\n      "x1": 0.7,\n      "y1": 0.7,\n      "fillcolor": "rgba(255, 255, 255, 0.03)",\n      "line": { "width": 0 }\n    }\n  ],\n  "showlegend": false,\n  "title": {\n    "text": "Ashton Jeanty",\n    "font": {\n      "color": "#6300ff",\n      "weight": 300,\n      "size": 25,\n      "family": "Quicksand"\n    },\n    "y": 0.98,\n    "x": 0.5,\n    "xanchor": "center",\n    "yanchor": "top"\n  },\n  "font": {\n    "color": "#afffff",\n    "size": 11,\n    "family": "Quicksand"\n  },\n  "margin": {\n    "l": 45,\n    "r": 45,\n    "t": 60,\n    "b": 30\n  }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container87"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle91"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic113"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
          }}
          suffix="%"
          value=".951"
        />
      </View>
    </Container>
    <Container
      id="container88"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle92"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic114"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
          }}
          suffix="%"
          value="0.916"
        />
      </View>
    </Container>
    <Container
      id="container89"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle93"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic115"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
          }}
          suffix="%"
          value="0.982"
        />
      </View>
    </Container>
    <Container
      id="container90"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle94"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic116"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="RAS / ATHL SCORE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
          }}
          suffix="%"
          value="0.933"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart41"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "RAS"],\n    "y": [92, 98, 86, 94],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "RAS"],\n    "ticktext": ["PRD", "EFF", "ELU", "RAS"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <View
    id="1e07e"
    disabled={false}
    hidden={false}
    iconPosition="left"
    label="Egbuka"
    viewKey="View 8"
  >
    <Table
      id="table33"
      autoColumnWidth={true}
      cellSelection="none"
      clearChangesetOnSave={true}
      data={
        '[\n  {\n    "POS": "RB",\n    "AGE": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">21.3</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.7em;\\">y.o.</span>",\n    "HT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #65aeff;\\">5\'8\\\\\\"</b>",\n    "WT": "<b style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1em; color: #6affd0;\\">211</b><span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.6em;\\">lbs</span>",\n    "CFB": "<i style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #adb5ee;\\">BOISE ST</span>",\n    "OVR GRADE": "<span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 0.9em; color: #efefef;\\">OVR |</span> <span style=\\"font-family: \'Syncopate\', sans-serif; font-size: 1.1em; font-weight: 700; color: #6affd0;\\">96</span>%"\n  }\n]'
      }
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="02c2b"
      rowBackgroundColor=""
      rowHeight="small"
      rowSelection="none"
      showBorder={true}
      showColumnBorders={true}
      style={{
        fontWeight: "400",
        border: "tertiary",
        hoverRowBackground: "highlight",
        background: "primary",
        fontSize: "14px",
        fontFamily: "Syncopate",
        headerBackground: "tertiary",
        borderRadius: "9px",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="02c2b"
        alignment="center"
        editable="false"
        editableOptions={{ allowCustomValue: false }}
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="POS"
        optionList={{
          manualData: [
            {
              value: "RB",
              icon: '{{"/icon:bold/travel-transportation-bus"}}',
              label: "RB",
              color: "#00ceb8",
              textColor: "#5300ff",
              caption: "",
            },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={59.859375}
        summaryAggregationMode="none"
      />
      <Column
        id="b555e"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        hidden="false"
        key="CFB"
        label="CFB"
        placeholder="Enter value"
        position="center"
        size={75.640625}
        summaryAggregationMode="none"
      />
      <Column
        id="50c42"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editable={false}
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="AGE"
        placeholder="Enter value"
        position="center"
        size={63.40625}
        summaryAggregationMode="none"
      />
      <Column
        id="5279d"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        format="markdown"
        groupAggregationMode="none"
        key="HT"
        label="HT"
        placeholder="Enter value"
        position="center"
        size={43.984375}
        summaryAggregationMode="none"
      />
      <Column
        id="65ca7"
        alignment="center"
        backgroundColor="{{ theme.primary }}"
        editableOptions={{ showStepper: true }}
        format="markdown"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="WT"
        label="WT"
        placeholder="Enter value"
        position="center"
        size={54.015625}
        summaryAggregationMode="none"
      />
      <Column
        id="677e7"
        alignment="center"
        format="markdown"
        groupAggregationMode="none"
        key="OVR GRADE"
        label="OVR"
        placeholder="Enter value"
        position="center"
        size={86.40625}
        summaryAggregationMode="none"
      />
    </Table>
    <Chart
      id="plotlyJsonChart42"
      chartType="plotlyJson"
      margin="0px 12px 7px 13px"
      plotlyDataJson={
        '[\n  {\n    "type": "scatterpolar",\n    "r": [94, 94, 98, 87, 98, 87, 98, 94],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A", "YPC"],\n    "fill": "toself",\n    "name": "Ashton Jeanty",\n    "mode": "lines+markers",\n    "line": {\n      "color": "#6300ff",\n      "width": 3\n    },\n    "fillcolor": "rgba(99, 0, 255, 0.32)",\n    "hoverinfo": "r+theta"\n  },\n  {\n    "type": "scatterpolar",\n    "r": [69, 69, 75, 64, 74, 67, 79],\n    "theta": ["YPC", "rDMTR", "ELU", "YDS/OPP", "IMP", "recYDS", "YACO/A"],\n    "mode": "text",\n    "text": ["94th%", "94th%", "98th%", "87th%", "98th%", "87th%", "98th%", "90th%"],\n    "textposition": "middle center",\n    "hoverinfo": "skip",\n    "showlegend": false\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "polar": {\n    "bgcolor": "#141a32",\n    "radialaxis": {\n      "range": [0, 100],\n      "color": "#d275e4",\n      "gridcolor": "grey",\n      "tickvals": [20, 40, 60, 80, 100],\n      "showline": false,\n      "showticklabels": false\n    },\n    "angularaxis": {\n      "gridcolor": "#394369",\n      "linecolor": "#48537a",\n      "tickfont": {\n        "color": "white",\n        "size": 13,\n        "family": "Quicksand"\n      },\n      "direction": "counterclockwise",\n      "rotation": -12.857,\n      "color": "white"\n    }\n  },\n  "paper_bgcolor": "#141a32",\n  "plot_bgcolor": "#141a32",\n  "shapes": [\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.2,\n      "y0": 0.2,\n      "x1": 0.8,\n      "y1": 0.8,\n      "fillcolor": "rgba(255, 255, 255, 0.04)",\n      "line": { "width": 0 }\n    },\n    {\n      "type": "circle",\n      "xref": "paper",\n      "yref": "paper",\n      "x0": 0.3,\n      "y0": 0.3,\n      "x1": 0.7,\n      "y1": 0.7,\n      "fillcolor": "rgba(255, 255, 255, 0.03)",\n      "line": { "width": 0 }\n    }\n  ],\n  "showlegend": false,\n  "title": {\n    "text": "Ashton Jeanty",\n    "font": {\n      "color": "#6300ff",\n      "weight": 300,\n      "size": 25,\n      "family": "Quicksand"\n    },\n    "y": 0.98,\n    "x": 0.5,\n    "xanchor": "center",\n    "yanchor": "top"\n  },\n  "font": {\n    "color": "#afffff",\n    "size": 11,\n    "family": "Quicksand"\n  },\n  "margin": {\n    "l": 45,\n    "r": 45,\n    "t": 60,\n    "b": 30\n  }\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
    <Container
      id="container91"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2px 1px 2px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle95"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic117"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/money-graph-bar-increase"
          label=""
          labelCaption="PRODUCTION GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "rgba(232, 222, 255, 1)",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "#6e00ff",
          }}
          suffix="%"
          value=".951"
        />
      </View>
    </Container>
    <Container
      id="container92"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle96"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic118"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/shopping-store-discount-percent-increase"
          label=""
          labelCaption="EFFICIENCY GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(122, 20, 255, 1)",
          }}
          suffix="%"
          value="0.916"
        />
      </View>
    </Container>
    <Container
      id="container93"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle97"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic119"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/nature-ecology-comet"
          label=""
          labelCaption="ELUSIVENESS GRADE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(144, 3, 255, 1)",
          }}
          suffix="%"
          value="0.982"
        />
      </View>
    </Container>
    <Container
      id="container94"
      enableFullBleed={true}
      footerPadding="4px 12px"
      headerPadding="0"
      heightType="fixed"
      margin="0px 9px 5px 0px"
      overflowType="hidden"
      padding="2.2px 1px 1px 1px"
      showBody={true}
      style={{ map: { background: "primary" } }}
    >
      <Header>
        <Text
          id="containerTitle98"
          value="#### Container title"
          verticalAlign="center"
        />
      </Header>
      <View id="c0220" viewKey="View 1">
        <Statistic
          id="statistic120"
          align="center"
          decimalPlaces="1"
          formattingStyle="percent"
          icon="bold/image-flash-1"
          label=""
          labelCaption="RAS / ATHL SCORE"
          margin="0px 0px 1px 0px"
          padDecimal={true}
          positiveTrend="{{ self.value >= 0 }}"
          secondaryCurrency="USD"
          secondaryEnableTrend={true}
          secondaryFormattingStyle="percent"
          secondaryPositiveTrend="{{ self.secondaryValue >= 0 }}"
          secondaryShowSeparators={true}
          secondarySignDisplay="trendArrows"
          secondaryValue=""
          showSeparators={true}
          style={{
            caption: "#e8deff",
            fontSize: "12px",
            valueFontSize: "20px",
            color: "#6affd0",
            iconBackground: "rgba(174, 0, 255, 1)",
          }}
          suffix="%"
          value="0.933"
        />
      </View>
    </Container>
    <Chart
      id="plotlyJsonChart43"
      chartType="plotlyJson"
      margin="0px 11px 8px 0px"
      plotlyDataJson={
        '[\n  {\n    "x": ["PRD", "EFF", "ELU", "RAS"],\n    "y": [92, 98, 86, 94],\n    "type": "scatter",\n    "mode": "lines+text",\n    "textposition": "top center",\n    "textfont": {\n      "color": "white",\n      "family": "Quicksand",\n      "size": 8.5\n    },\n    "line": {\n      "color": "#5700ff",\n      "shape": "spline"\n    },\n    "cliponaxis": false,\n    "fill": "tozeroy",\n    "fillcolor": "rgba(87,0,255,0.2)"\n  }\n]\n'
      }
      plotlyLayoutJson={
        '{\n  "plot_bgcolor": "#141A32",\n  "paper_bgcolor": "#141A32",\n  "xaxis": {\n    "automargin": true,\n    "tickmode": "array",\n    "tickvals": ["PRD", "EFF", "ELU", "RAS"],\n    "ticktext": ["PRD", "EFF", "ELU", "RAS"],\n    "tickfont": {\n      "color": "white",\n      "family": "Syncopate",\n      "size": 10\n    }\n  },\n  "yaxis": {\n    "range": [70, 103],\n    "showticklabels": false\n  },\n  "margin": {\n    "l": 2,\n    "r": 2,\n    "t": 1,\n    "b": 15\n  },\n  "autosize": true\n}\n'
      }
      selectedPoints="[]"
      style={{}}
    />
  </View>
  <Footer>
    <Button
      id="prevButton1"
      disabled=""
      iconBefore="bold/interface-arrows-left-alternate"
      style={{
        border: "highlight",
        label: "#7300ff",
        fontSize: "13px",
        fontWeight: "600",
        fontFamily: "Quicksand",
      }}
      styleVariant="outline"
      text="Previous"
    >
      <Event
        event="click"
        method="showPreviousVisibleView"
        params={{ map: { wrap: false } }}
        pluginId="tabbedContainer7"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="nextButton1"
      disabled=""
      iconAfter="bold/interface-arrows-right-alternate"
      style={{ background: "highlight", borderRadius: "4px" }}
      text="Next"
    >
      <Event
        event="click"
        method="showNextVisibleView"
        params={{ map: { wrap: false } }}
        pluginId="tabbedContainer7"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Footer>
</Container>
