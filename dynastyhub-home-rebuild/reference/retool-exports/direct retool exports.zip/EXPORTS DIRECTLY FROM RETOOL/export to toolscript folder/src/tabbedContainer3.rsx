<Container
  id="tabbedContainer3"
  currentViewKey="{{ self.viewKeys[0] }}"
  footerPadding="4px 12px"
  headerPadding="4px 12px"
  padding="12px"
  showBody={true}
  showHeader={true}
  style={{ ordered: [{ background: "primary" }] }}
>
  <Header>
    <Button
      id="button8"
      iconBefore="bold/travel-transportation-bus"
      style={{
        ordered: [
          { background: "#00ceb8" },
          { label: "surfacePrimary" },
          { fontSize: "h6Font" },
          { fontWeight: "h6Font" },
          { fontFamily: "h6Font" },
        ],
      }}
      text="RB"
    >
      <Event
        event="click"
        method="openPage"
        params={{
          ordered: [
            { options: { ordered: [{ passDataWith: "urlParams" }] } },
            { pageName: "page2" },
          ],
        }}
        pluginId=""
        type="util"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="button9"
      iconBefore="bold/interface-arrows-all-direction"
      style={{
        ordered: [
          { background: "#4f97e5" },
          { fontSize: "h6Font" },
          { fontWeight: "h6Font" },
          { fontFamily: "h6Font" },
        ],
      }}
      submitTargetId=""
      text="WR"
    >
      <Event
        event="click"
        method="showNextView"
        params={{ ordered: [{ wrap: true }] }}
        pluginId="tabbedContainer3"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="button12"
      iconBefore="bold/interface-setting-menu-1"
      style={{
        ordered: [
          { background: "#283141" },
          { fontSize: "h6Font" },
          { fontWeight: "h6Font" },
          { fontFamily: "h6Font" },
        ],
      }}
      text="ALL"
    >
      <Event
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: 'if (table4.filterStack.some(f => f.id === "qb_filter")) {\n  table4.clearFilter("qb_filter");\n} else {\n  table4.setFilter({\n    columnId: "POS",\n    operator: "=",\n    value: "QB",\n    id: "qb_filter"\n  });\n}\n',
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="button7"
      iconBefore="bold/travel-map-location-target-1"
      style={{
        ordered: [
          { background: "#ff008a" },
          { fontSize: "h6Font" },
          { fontWeight: "h6Font" },
          { fontFamily: "h6Font" },
        ],
      }}
      text="QB"
    >
      <Event
        event="click"
        method="run"
        params={{
          ordered: [
            {
              src: 'if (table4.filterStack.some(f => f.id === "qb_filter")) {\n  table4.clearFilter("qb_filter");\n} else {\n  table4.setFilter({\n    columnId: "POS",\n    operator: "=",\n    value: "QB",\n    id: "qb_filter"\n  });\n}\n',
            },
          ],
        }}
        pluginId=""
        type="script"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
    <Button
      id="button11"
      style={{
        ordered: [{ background: "#7c83ff" }, { label: "surfacePrimary" }],
      }}
      text="FLX"
    />
    <Button
      id="button10"
      style={{
        ordered: [{ background: "#ffb056" }, { label: "surfacePrimary" }],
      }}
      text="TE"
    />
  </Header>
  <View id="9fb35" viewKey="View 1">
    <Table
      id="table4"
      clearChangesetOnSave={true}
      data="{{ query6.data }}"
      defaultSelectedRow={{ mode: "index", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      linkedFilterId=""
      primaryKeyColumnId="67fa7"
      rowHeight="small"
      showBorder={true}
      showFooter={true}
      showHeader={true}
      style={{
        headerBackground: "tertiary",
        alternateRowBackground: "rgb(13, 16, 20)",
        background: "primary",
        headerFontSize: "h6Font",
        headerFontWeight: "h6Font",
        headerFontFamily: "h6Font",
      }}
    >
      <Column
        id="67fa7"
        alignment="left"
        backgroundColor="rgba(40, 49, 65, 0.35)"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="Player"
        label="Player"
        placeholder="Enter value"
        position="left"
        size={140.640625}
        summaryAggregationMode="none"
        textColor="rgba(255, 255, 255, 1)"
      />
      <Column
        id="45cb7"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="TM"
        label="Tm"
        placeholder="Enter value"
        position="center"
        size={66}
        summaryAggregationMode="none"
      />
      <Column
        id="f83ae"
        alignment="center"
        editable="false"
        format="tag"
        formatOptions={{ automaticColors: true }}
        groupAggregationMode="none"
        key="POS"
        label="Pos"
        optionList={{
          manualData: [
            { ordered: [{ value: "QB" }] },
            { ordered: [{ value: "WR" }] },
            { ordered: [{ value: "RB" }] },
            { ordered: [{ value: "TE" }] },
          ],
        }}
        placeholder="Select option"
        position="center"
        size={60}
        summaryAggregationMode="none"
        valueOverride="{{ _.startCase(item) }}"
      />
      <Column
        id="75f99"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="DRFT
RND"
        label="Drft rnd"
        placeholder="Enter value"
        position="center"
        size={88.765625}
        summaryAggregationMode="none"
      />
      <Column
        id="0c1a6"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="EXP"
        label="Exp"
        placeholder="Enter value"
        position="center"
        size={54.90625}
        summaryAggregationMode="none"
      />
      <Column
        id="4909f"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="AGE"
        label="Age"
        placeholder="Enter value"
        position="center"
        size={58.78125}
        summaryAggregationMode="none"
      />
      <Column
        id="3f013"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="PPR"
        label="Ppr"
        placeholder="Enter value"
        position="center"
        size={70}
        summaryAggregationMode="none"
      />
      <Column
        id="f04b9"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="PPG"
        label="Ppg"
        placeholder="Enter value"
        position="center"
        size={68}
        summaryAggregationMode="none"
      />
      <Column
        id="4a1f4"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="VOBA"
        label="Voba"
        placeholder="Enter value"
        position="center"
        size={76}
        summaryAggregationMode="none"
      />
      <Column
        id="2560e"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="VOBApG"
        label="Vob ap g"
        placeholder="Enter value"
        position="center"
        size={78}
        summaryAggregationMode="none"
      />
      <Column
        id="ee081"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="GM"
        label="Gm"
        placeholder="Enter value"
        position="center"
        size={63}
        summaryAggregationMode="none"
      />
      <Column
        id="0e7d5"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="SNPS"
        label="Snps"
        placeholder="Enter value"
        position="center"
        size={82}
        summaryAggregationMode="none"
      />
      <Column
        id="95a7e"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="Ttl
Yds"
        label="Ttl yds"
        placeholder="Enter value"
        position="center"
        size={68}
        summaryAggregationMode="none"
      />
      <Column
        id="ab28b"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="TTL-TD"
        label="Ttl td"
        placeholder="Enter value"
        position="center"
        size={87}
        summaryAggregationMode="none"
      />
      <Column
        id="093d3"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="P–ATT"
        label="P att"
        placeholder="Enter value"
        position="center"
        size={61}
        summaryAggregationMode="none"
      />
      <Column
        id="28c0f"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="P–YDS"
        label="P yds"
        placeholder="Enter value"
        position="center"
        size={69}
        summaryAggregationMode="none"
      />
      <Column
        id="9b199"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="P-TD"
        label="P td"
        placeholder="Enter value"
        position="center"
        size={67}
        summaryAggregationMode="none"
      />
      <Column
        id="43739"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="YpATT"
        label="Yp att"
        placeholder="Enter value"
        position="center"
        size={78}
        summaryAggregationMode="none"
      />
      <Column
        id="6a39b"
        alignment="center"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="CAR"
        label="Car"
        placeholder="Enter value"
        position="center"
        size={75}
        summaryAggregationMode="none"
      />
      <Column
        id="36214"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="R-YDS"
        label="R yds"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="13174"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="R-TD"
        label="R td"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="d130f"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="YpC"
        label="Yp c"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="e837a"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="RR"
        label="Rr"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="5c30d"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="TGT"
        label="Tgt"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="a124c"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="REC-YDS"
        label="Rec yds"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <Column
        id="62564"
        alignment="right"
        editableOptions={{ showStepper: true }}
        format="decimal"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="REC-TD"
        label="Rec td"
        placeholder="Enter value"
        position="center"
        size={100}
        summaryAggregationMode="none"
      />
      <ToolbarButton
        id="1a"
        icon="bold/interface-text-formatting-filter-2"
        label="Filter"
        type="filter"
      />
      <ToolbarButton
        id="4d"
        icon="bold/interface-arrows-round-left"
        label="Refresh"
        type="custom"
      />
    </Table>
  </View>
</Container>
