<ModalFrame
  id="modalFrame3"
  footerPadding="8px 12px"
  headerPadding="8px 12px"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="large"
  style={{ ordered: [{ background: "primary" }] }}
>
  <Header>
    <Text
      id="modalTitle3"
      horizontalAlign="center"
      style={{
        ordered: [
          { fontSize: "h3Font" },
          { fontWeight: "h3Font" },
          { fontFamily: "h3Font" },
        ],
      }}
      value="KEY"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton3"
      ariaLabel="Close"
      horizontalAlign="right"
      iconBefore="bold/interface-delete-1"
      style={{ ordered: [{ border: "transparent" }] }}
      styleVariant="outline"
    >
      <Event
        event="click"
        method="setHidden"
        params={{ ordered: [{ hidden: true }] }}
        pluginId="modalFrame3"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <Table
      id="table9"
      cellSelection="none"
      clearChangesetOnSave={true}
      data="{{ query20.data }}"
      defaultSelectedRow={{ mode: "none", indexType: "display", index: 0 }}
      emptyMessage="No rows found"
      enableSaveActions={true}
      margin="0"
      primaryKeyColumnId="c05cb"
      rowBackgroundColor="4D708D"
      rowHeight="xsmall"
      rowSelection="none"
      showBorder={true}
      showFooter={true}
      showHeader={true}
      style={{
        background: "rgba(33, 33, 33, 1)",
        alternateRowBackground: "rgba(58, 58, 58, 1)",
        headerBackground: "rgba(16, 16, 16, 1)",
        headerFontSize: "h6Font",
        headerFontWeight: "h6Font",
        headerFontFamily: "h6Font",
      }}
      toolbarPosition="bottom"
    >
      <Column
        id="c05cb"
        alignment="center"
        editable="false"
        format="string"
        groupAggregationMode="none"
        key="Abbreviation"
        label="ABBR."
        placeholder="Enter value"
        position="center"
        size={82}
        summaryAggregationMode="none"
      />
      <Column
        id="6445b"
        alignment="left"
        format="string"
        groupAggregationMode="none"
        key="Meaning"
        label="Meaning"
        placeholder="Enter value"
        position="center"
        size={320}
      />
      <Column
        id="9450e"
        alignment="center"
        format="string"
        groupAggregationMode="none"
        key="Abbreviation_1"
        label="ABBR."
        placeholder="Enter value"
        position="center"
        size={117}
      />
      <Column
        id="f8582"
        alignment="left"
        editableOptions={{ showStepper: true }}
        format="string"
        formatOptions={{ showSeparators: true, notation: "standard" }}
        groupAggregationMode="sum"
        key="Meaning_1"
        label="Meaning"
        placeholder="Enter value"
        position="center"
        size={327.765625}
        summaryAggregationMode="none"
      />
    </Table>
  </Body>
</ModalFrame>
