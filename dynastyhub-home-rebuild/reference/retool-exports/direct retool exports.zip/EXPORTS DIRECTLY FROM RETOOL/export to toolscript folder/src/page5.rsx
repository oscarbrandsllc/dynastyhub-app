<Screen
  id="page5"
  _customShortcuts={[]}
  _hashParams={[]}
  _searchParams={[]}
  browserTitle=""
  title={null}
  urlSlug=""
  uuid="78d0e32c-780c-4acd-a357-2404fb3f40b4"
>
  <connectResource id="query15" _componentId="table7" />
  <Frame
    id="$main5"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <IFrame
      id="iFrame33"
      allowFullscreen={true}
      hidden=""
      margin="0px 0px 0px 0px"
      src="https://dh-leaguehq.netlify.app"
      title="{{ self.src }}"
    />
  </Frame>
</Screen>
