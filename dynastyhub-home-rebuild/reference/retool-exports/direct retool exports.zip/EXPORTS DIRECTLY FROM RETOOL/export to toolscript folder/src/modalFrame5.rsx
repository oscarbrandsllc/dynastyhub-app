<ModalFrame
  id="modalFrame5"
  footerPadding="8px 12px"
  headerPadding="0"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showHeader={true}
  showOverlay={true}
  size="medium"
  style={{ map: { background: "tertiary" } }}
>
  <Header>
    <Text
      id="modalTitle5"
      heightType="fixed"
      horizontalAlign="center"
      style={{
        background: "primary",
        fontSize: "15px",
        fontWeight: "400",
        fontFamily: "Bruno Ace",
      }}
      value="CAREER LENGTH ANALYTICS ｜ KEY "
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton5"
      ariaLabel="Close"
      horizontalAlign="center"
      iconBefore="bold/interface-delete-square-alternate"
      style={{
        fontSize: "28px",
        fontWeight: "600",
        fontFamily: "Quicksand",
        icon: "secondary",
        border: "rgba(255, 255, 255, 0)",
        hoverBackground: "danger",
      }}
      styleVariant="outline"
    >
      <Event
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="modalFrame5"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <Text
      id="text13"
      margin="4px 2px 10px 4px"
      style={{
        fontSize: "13px",
        fontWeight: "400",
        fontFamily: "Quicksand",
        background: "primary",
      }}
      value={
        '<div style="padding: 5px;">\n  <span style="font-weight: bold; font-size: 1.2em; color: #722eff;">\n    [SYOP | SY] ：\n  </span>\n  Significant Year(s) of Production   ⟶\n  <span style="font-weight: bold; font-size: 1.2em; color: #722eff;">\n    <br>[B/O ┃BO] ：\n  </span>\n  Breakout  ～  Player\'s Initial SYOP<br>\n  <span style="font-weight: bold; font-size: 1.2em; color: #6920ff;">\n    <br>[Mean | "𝛬"] ：\n  </span>\n  Average \n  <span style="font-weight: bold; font-size: 1.2em; color: #6920ff;">\n    <br>[Mode | "ϻ"] ：\n  </span>\n  Majority Value / Most Frequent Value\n</div>'
      }
      verticalAlign="center"
    />
    <Text
      id="text12"
      margin="4px 2px 10px 4px"
      style={{
        fontSize: "13px",
        fontWeight: "400",
        fontFamily: "Quicksand",
        background: "primary",
      }}
      value={
        '<div style="padding: 6px;">\n  <span style="font-weight: bold; font-size: 1.22em; color: #6920ff;">\n    SYOP & B/O Thresholds ↓\n  </span> \n  <span style="font-weight: 500; font-size: 1.01em; color: #ffffff;">\n    <br> - QB ➜ 179-fpts ｜ WR ➜ 179-fpts <br> - RB ➜ 169-fpts ｜ TE ➜ 159-fpts\n  </span> \n  <span style="font-weight: 500; font-size: 1.09em; color: #ff6283;">\n   <br> ✦ <i>Thresholds Derived From the <b><u>Average Minimum</u></b> <br>QB2, RB2, WR2, & TE1,  PPR Benchmarks</i> ✦  \n  </span>\n</div>\n'
      }
      verticalAlign="center"
    />
    <Text
      id="modalTitle6"
      heightType="fixed"
      horizontalAlign="center"
      style={{
        background: "primary",
        fontSize: "11px",
        fontWeight: "400",
        fontFamily: "Bruno Ace",
      }}
      value={
        '<span style=\n"font-weight: bold;\nfont-size: 1.35em;\ncolor: #efefef;"> SAMPLE INFO</span> \n'
      }
      verticalAlign="center"
    />
    <Text
      id="text16"
      margin="6px 2px 10px 4px"
      style={{
        fontSize: "13px",
        fontWeight: "400",
        fontFamily: "Quicksand",
        background: "primary",
      }}
      value={
        '<div style="padding: 5px;">\n  <span style="font-weight: bold; font-size: 1.15em; color: #6920ff;">\n    Total Sample Size ：\n  </span> 297 Players\n  <br>\n  <span style="font-weight: bold; font-size: 1.15em; color: #6920ff;">\n    Sample Qualification：\n  </span> Meeting indicated Threshold within the qualifying years\n  <br>\n  <span style="font-weight: bold; font-size: 1.15em; color: #6920ff;">\n    Qualifying Years ：\n  </span> 2008-2018\n  <br>\n  <span style="font-weight: bold; font-size: 1.15em; color: #6920ff;">\n    Sample Years Included ：\n  </span> If player met the qualification criteria, their entire career was referenced, but only the years in which the threshold was reached were counted as "Significant Year of  Production"\n    <div style="text-align: center;">\n    <span style="font-weight: 500; font-size: 1.05em; color: #ff6283;">\n 𒎓 Select  <em>Key Button</em> in <b><u>Side Bar</u></b> for Full Extended Key 𒎓\n    </span>  \n    \n  </div>\n\n</div> \n'
      }
      verticalAlign="center"
    />
  </Body>
</ModalFrame>
