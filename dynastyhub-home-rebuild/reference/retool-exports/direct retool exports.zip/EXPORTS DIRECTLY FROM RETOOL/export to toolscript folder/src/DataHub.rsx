<Screen
  id="DataHub"
  _customShortcuts={[]}
  _hashParams={[]}
  _searchParams={[]}
  browserTitle="Data Hub"
  margin="0"
  title="Data Hub"
  urlSlug="DataHub"
  uuid="3d9dc025-ac3d-4191-bf18-be228467fedb"
>
  <GoogleSheetsQuery
    id="query18"
    isMultiplayerEdited={false}
    limit="557"
    notificationDuration={4.5}
    offset="1"
    resourceDisplayName="2025 NFL Stats"
    resourceName="5ef8da66-41db-48e9-bcff-97c40d8f272c"
    resourceTypeOverride=""
    sheetName="ALL"
    showSuccessToaster={false}
    spreadsheetId="10axJkr_q6FbHJa9vHmZowJk4WI4D9DYii28EcnkfGoU"
  />
  <GoogleSheetsQuery
    id="query20"
    resourceDisplayName="Retool Key"
    resourceName="ecde9a04-1537-4d78-abe1-aab3f2699635"
    sheetName="Key"
    spreadsheetId="18qduTp-w-vcgkgQu40Yf79K4xovj1oA2k234Iq1pWoY"
  />
  <Include src="./modalFrame3.rsx" />
  <Frame
    id="$main9"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="0"
    style={{ ordered: [] }}
    type="main"
  >
    <Container
      id="container202"
      footerPadding="4px 12px"
      headerPadding="4px 12px"
      heightType="fixed"
      margin="0"
      overflowType="hidden"
      padding="0"
      showBody={true}
      style={{
        background: "rgba(20, 26, 50, 0.5)",
        borderRadius: "0px",
        border: "#141a32",
      }}
    >
      <View id="10a74" viewKey="View 1">
        <Container
          id="group14"
          footerPadding="4px 12px"
          headerPadding="4px 12px"
          margin="0"
          padding="0"
          showBody={true}
          showBorder={false}
          style={{ map: { background: "rgba(255, 255, 255, 0)" } }}
        >
          <View id="00030" viewKey="View 1">
            <Image
              id="image4"
              fit="contain"
              heightType="fixed"
              horizontalAlign="right"
              margin="5px 0px 5px 24px"
              retoolStorageFileId="44bf0765-e78a-43ea-bc38-ebcff7d64298"
              src="https://picsum.photos/id/1025/800/600"
              srcType="retoolStorageFileId"
            />
            <Text
              id="text18"
              heightType="fixed"
              margin="0"
              style={{
                fontSize: "39px",
                fontWeight: "400",
                fontFamily: "ORBITRON",
                background: "rgba(20, 26, 50, 0)",
              }}
              value={
                '  <span style="background: linear-gradient(to right, #5700ff, #6e00f6, #8d28ff, #c332ff);\n    -webkit-background-clip: text;\n    background-clip: text;\n    color: transparent;\n  ">data hub</span> '
              }
            />
          </View>
        </Container>
        <Navigation
          id="navigation17"
          data="{{ retoolContext.pages }}"
          highlightByIndex="{{ retoolContext.currentPage === item.id }}"
          horizontalAlignment="justify"
          itemMode="static"
          labels="{{ item.title || item.id }}"
          margin="4px 15px 4px 5px"
          retoolFileObject={{ ordered: [] }}
          showInEditor={true}
          style={{
            highlightText: "#7476ff",
            fontSize: "16px",
            fontWeight: "700",
            fontFamily: "Quicksand",
            background: "#212843",
            highlightBackground: "#2c334f",
            hoverText: "secondary",
          }}
        >
          <Option
            id="1de3f"
            caption="Home"
            icon="bold/interface-home-3"
            iconPosition="left"
            itemType="page"
            screenTargetId="Home"
          />
          <Option
            id="60b8d"
            caption="Data Hub"
            icon="bold/interface-arrows-diagonal"
            iconPosition="left"
            itemType="page"
          />
          <Option
            id="d4f21"
            caption="Rookies"
            icon="bold/shopping-business-startup"
            iconPosition="left"
            itemType="page"
            screenTargetId="Rookies"
          />
          <Option
            id="b6a91"
            caption="Rankings"
            disabled={false}
            hidden={false}
            highlight={false}
            icon="bold/interface-award-crown"
            iconPosition="replace"
            itemType="page"
            screenTargetId="page2"
          />
          <Event
            event="click"
            method="show"
            params={{}}
            pluginId="modalFrame2"
            targetId="718b5"
            type="widget"
            waitMs="0"
            waitType="debounce"
          />
          <Event
            event="click"
            method="show"
            params={{ ordered: [] }}
            pluginId="modalFrame2"
            targetId="1d317"
            type="widget"
            waitMs="0"
            waitType="debounce"
          />
          <Event
            event="click"
            method="openPage"
            params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
            pluginId=""
            type="util"
            waitMs="0"
            waitType="debounce"
          />
        </Navigation>
        <Navigation
          id="navigation16"
          data="{{ retoolContext.pages }}"
          highlightByIndex="{{ retoolContext.currentPage === item.id }}"
          horizontalAlignment="justify"
          itemMode="static"
          labels="{{ item.title || item.id }}"
          margin="4px 5px 4px 15px"
          retoolFileObject={{ ordered: [] }}
          showInEditor={true}
          style={{
            highlightText: "#7476ff",
            fontSize: "16px",
            fontWeight: "700",
            fontFamily: "Quicksand",
            background: "tertiary",
            highlightBackground: "#2c334f",
            hoverText: "secondary",
          }}
        >
          <Option
            id="c2822"
            caption="Research"
            disabled={false}
            hidden={false}
            icon="bold/ecology-science-erlenmeyer-flask"
            iconPosition="left"
            itemType="page"
            screenTargetId="page3"
          />
          <Option
            id="c05bb"
            caption="Charts"
            disabled={false}
            hidden={false}
            highlight={false}
            icon="bold/money-graph-arrow-increase"
            iconPosition="right"
            itemType="page"
            screenTargetId="Charts"
          />
          <Option
            id="a8f67"
            caption="Subscribe"
            disabled={false}
            hidden={false}
            highlight={false}
            icon="bold/shopping-jewelry-diamond-2"
            iconPosition="left"
            itemType="page"
            screenTargetId="page5"
          />
          <Option
            id="1d317"
            caption="— KEY"
            disabled={false}
            hidden={false}
            highlight={false}
            icon="bold/interface-login-key"
            iconPosition="left"
            itemType="custom"
          >
            <Event
              event="click"
              method="show"
              params={{ ordered: [] }}
              pluginId="modalFrame2"
              type="widget"
              waitMs="0"
              waitType="debounce"
            />
          </Option>
          <Event
            event="click"
            method="show"
            params={{}}
            pluginId="modalFrame2"
            targetId="718b5"
            type="widget"
            waitMs="0"
            waitType="debounce"
          />
          <Event
            event="click"
            method="openPage"
            params={{ ordered: [{ pageName: "{{ item.id }}" }] }}
            pluginId=""
            type="util"
            waitMs="0"
            waitType="debounce"
          />
        </Navigation>
      </View>
    </Container>
    <Include src="./tabbedContainer13.rsx" />
  </Frame>
</Screen>
