<ModalFrame
  id="modalFrame6"
  footerPadding="8px 12px"
  headerPadding="0"
  hidden={true}
  hideOnEscape={true}
  isHiddenOnMobile={true}
  overlayInteraction={true}
  padding="8px 12px"
  showFooter={true}
  showHeader={true}
  showOverlay={true}
  size="medium"
  style={{ background: "tertiary", headerBackground: "primary" }}
>
  <Header>
    <Text
      id="modalTitle8"
      heightType="fixed"
      horizontalAlign="center"
      style={{
        background: "primary",
        fontSize: "15px",
        fontWeight: "400",
        fontFamily: "Quicksand",
      }}
      value="𐘳onsistency and ℂeiling ｜ KEY"
      verticalAlign="center"
    />
    <Button
      id="modalCloseButton6"
      ariaLabel="Close"
      horizontalAlign="center"
      iconBefore="bold/interface-delete-square-alternate"
      style={{
        border: "rgba(115, 0, 255, 0)",
        borderRadius: "10px",
        icon: "secondary",
        hoverBackground: "danger",
        fontSize: "23px",
        fontWeight: "400",
        fontFamily: "Quicksand",
      }}
      styleVariant="outline"
    >
      <Event
        event="click"
        method="setHidden"
        params={{ map: { hidden: true } }}
        pluginId="modalFrame6"
        type="widget"
        waitMs="0"
        waitType="debounce"
      />
    </Button>
  </Header>
  <Body>
    <Text
      id="text17"
      margin="4px 2px 10px 4px"
      style={{
        fontSize: "13px",
        fontWeight: "400",
        fontFamily: "Quicksand",
        background: "primary",
      }}
      value={
        '<div style="padding: 5px;">\n  <span style="font-weight: bold; font-size: 1.2em; color: #722eff;">\n     𐘳onsistency and ℂeiling：\n  </span>\n  Significant Year(s) of Production   ⟶\n  <span style="font-weight: bold; font-size: 1.2em; color: #722eff;">\n    <br>[B/O ┃BO] ：\n  </span>\n  Breakout  ～  Player\'s Initial SYOP<br>\n  <span style="font-weight: bold; font-size: 1.2em; color: #6920ff;">\n    <br>[Mean | "𝛬"] ：\n  </span>\n  Average\n\n</div>'
      }
      verticalAlign="center"
    />
  </Body>
</ModalFrame>
